/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatasetConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the dataset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dataset#name Dataset#name}
    */
    readonly name: string;
    /**
    * An array of principals. A principal is a subject or group of subjects. Each principal is formatted as `type:id`. Supported types: `role` and `team`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dataset#principals Dataset#principals}
    */
    readonly principals: string[];
    /**
    * product_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dataset#product_filters Dataset#product_filters}
    */
    readonly productFilters?: DatasetProductFilters[] | cdktn.IResolvable;
}
export interface DatasetProductFilters {
    /**
    * A list of tag-based filters used to restrict access to the product type. Each filter is formatted as `@tag.key:value`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dataset#filters Dataset#filters}
    */
    readonly filters: string[];
    /**
    * The product type of the dataset. Supported types: `apm`, `rum`, `synthetics`, `metrics`, `logs`, `sd_repoinfo`, `error_tracking`, `cloud_cost`, and `ml_obs`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dataset#product Dataset#product}
    */
    readonly product: string;
}
export declare function datasetProductFiltersToTerraform(struct?: DatasetProductFilters | cdktn.IResolvable): any;
export declare function datasetProductFiltersToHclTerraform(struct?: DatasetProductFilters | cdktn.IResolvable): any;
export declare class DatasetProductFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatasetProductFilters | cdktn.IResolvable | undefined;
    set internalValue(value: DatasetProductFilters | cdktn.IResolvable | undefined);
    private _filters?;
    get filters(): string[];
    set filters(value: string[]);
    get filtersInput(): string[] | undefined;
    private _product?;
    get product(): string;
    set product(value: string);
    get productInput(): string | undefined;
}
export declare class DatasetProductFiltersList extends cdktn.ComplexList {
    internalValue?: DatasetProductFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatasetProductFiltersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dataset datadog_dataset}
*/
export declare class Dataset extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_dataset";
    /**
    * Generates CDKTN code for importing a Dataset resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Dataset to import
    * @param importFromId The id of the existing Dataset that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dataset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Dataset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dataset datadog_dataset} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatasetConfig
    */
    constructor(scope: Construct, id: string, config: DatasetConfig);
    get createdAt(): string;
    get createdBy(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _principals?;
    get principals(): string[];
    set principals(value: string[]);
    get principalsInput(): string[] | undefined;
    private _productFilters;
    get productFilters(): DatasetProductFiltersList;
    putProductFilters(value: DatasetProductFilters[] | cdktn.IResolvable): void;
    resetProductFilters(): void;
    get productFiltersInput(): cdktn.IResolvable | DatasetProductFilters[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
