/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogIntegrationAwsAvailableNamespacesConfig extends cdktn.TerraformMetaArguments {
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/integration_aws_available_namespaces datadog_integration_aws_available_namespaces}
*/
export declare class DataDatadogIntegrationAwsAvailableNamespaces extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_integration_aws_available_namespaces";
    /**
    * Generates CDKTN code for importing a DataDatadogIntegrationAwsAvailableNamespaces resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogIntegrationAwsAvailableNamespaces to import
    * @param importFromId The id of the existing DataDatadogIntegrationAwsAvailableNamespaces that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/integration_aws_available_namespaces#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogIntegrationAwsAvailableNamespaces to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/integration_aws_available_namespaces datadog_integration_aws_available_namespaces} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogIntegrationAwsAvailableNamespacesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogIntegrationAwsAvailableNamespacesConfig);
    get awsNamespaces(): string[];
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
