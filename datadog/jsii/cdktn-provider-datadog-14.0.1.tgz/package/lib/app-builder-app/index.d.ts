/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppBuilderAppConfig extends cdktn.TerraformMetaArguments {
    /**
    * If specified, this will override the Action Connection IDs for the specified Action Query Names in the App JSON. Otherwise, a map of the App's Action Query Names to Action Connection IDs will be returned in output.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/app_builder_app#action_query_names_to_connection_ids AppBuilderApp#action_query_names_to_connection_ids}
    */
    readonly actionQueryNamesToConnectionIds?: {
        [key: string]: string;
    };
    /**
    * The JSON representation of the App. String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/app_builder_app#app_json AppBuilderApp#app_json}
    */
    readonly appJson: string;
    /**
    * If specified, this will override the human-readable description of the App in the App JSON. String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/app_builder_app#description AppBuilderApp#description}
    */
    readonly description?: string;
    /**
    * If specified, this will override the name of the App in the App JSON. String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/app_builder_app#name AppBuilderApp#name}
    */
    readonly name?: string;
    /**
    * Set the app to published or unpublished. Published apps are available to other users. To ensure the app is accessible to the correct users, you also need to set a [Restriction Policy](https://docs.datadoghq.com/api/latest/restriction-policies/) on the app if a policy does not yet exist. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/app_builder_app#published AppBuilderApp#published}
    */
    readonly published?: boolean | cdktn.IResolvable;
    /**
    * The name of the root component of the app. This must be a grid component that contains all other components. If specified, this will override the root instance name of the App in the App JSON. String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/app_builder_app#root_instance_name AppBuilderApp#root_instance_name}
    */
    readonly rootInstanceName?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/app_builder_app datadog_app_builder_app}
*/
export declare class AppBuilderApp extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_app_builder_app";
    /**
    * Generates CDKTN code for importing a AppBuilderApp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppBuilderApp to import
    * @param importFromId The id of the existing AppBuilderApp that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/app_builder_app#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppBuilderApp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/app_builder_app datadog_app_builder_app} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppBuilderAppConfig
    */
    constructor(scope: Construct, id: string, config: AppBuilderAppConfig);
    private _actionQueryNamesToConnectionIds?;
    get actionQueryNamesToConnectionIds(): {
        [key: string]: string;
    };
    set actionQueryNamesToConnectionIds(value: {
        [key: string]: string;
    });
    resetActionQueryNamesToConnectionIds(): void;
    get actionQueryNamesToConnectionIdsInput(): {
        [key: string]: string;
    } | undefined;
    private _appJson?;
    get appJson(): string;
    set appJson(value: string);
    get appJsonInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _published?;
    get published(): boolean | cdktn.IResolvable;
    set published(value: boolean | cdktn.IResolvable);
    resetPublished(): void;
    get publishedInput(): boolean | cdktn.IResolvable | undefined;
    private _rootInstanceName?;
    get rootInstanceName(): string;
    set rootInstanceName(value: string);
    resetRootInstanceName(): void;
    get rootInstanceNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
