/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogMetricActiveTagsAndAggregationsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The metric for which to fetch tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/metric_active_tags_and_aggregations#metric DataDatadogMetricActiveTagsAndAggregations#metric}
    */
    readonly metric: string;
    /**
    * The number of seconds to look back from now.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/metric_active_tags_and_aggregations#window DataDatadogMetricActiveTagsAndAggregations#window}
    */
    readonly window?: number;
}
export interface DataDatadogMetricActiveTagsAndAggregationsActiveAggregations {
}
export declare function dataDatadogMetricActiveTagsAndAggregationsActiveAggregationsToTerraform(struct?: DataDatadogMetricActiveTagsAndAggregationsActiveAggregations): any;
export declare function dataDatadogMetricActiveTagsAndAggregationsActiveAggregationsToHclTerraform(struct?: DataDatadogMetricActiveTagsAndAggregationsActiveAggregations): any;
export declare class DataDatadogMetricActiveTagsAndAggregationsActiveAggregationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogMetricActiveTagsAndAggregationsActiveAggregations | undefined;
    set internalValue(value: DataDatadogMetricActiveTagsAndAggregationsActiveAggregations | undefined);
    get space(): string;
    get time(): string;
}
export declare class DataDatadogMetricActiveTagsAndAggregationsActiveAggregationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogMetricActiveTagsAndAggregationsActiveAggregationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/metric_active_tags_and_aggregations datadog_metric_active_tags_and_aggregations}
*/
export declare class DataDatadogMetricActiveTagsAndAggregations extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_metric_active_tags_and_aggregations";
    /**
    * Generates CDKTN code for importing a DataDatadogMetricActiveTagsAndAggregations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogMetricActiveTagsAndAggregations to import
    * @param importFromId The id of the existing DataDatadogMetricActiveTagsAndAggregations that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/metric_active_tags_and_aggregations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogMetricActiveTagsAndAggregations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/metric_active_tags_and_aggregations datadog_metric_active_tags_and_aggregations} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogMetricActiveTagsAndAggregationsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogMetricActiveTagsAndAggregationsConfig);
    private _activeAggregations;
    get activeAggregations(): DataDatadogMetricActiveTagsAndAggregationsActiveAggregationsList;
    get activeTags(): string[];
    get id(): string;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _window?;
    get window(): number;
    set window(value: number);
    resetWindow(): void;
    get windowInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
