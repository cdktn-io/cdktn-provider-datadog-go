/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ReferenceTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * The description of the reference table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#description ReferenceTable#description}
    */
    readonly description?: string;
    /**
    * The source type for the reference table. Valid values are `S3`, `GCS`, `AZURE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#source ReferenceTable#source}
    */
    readonly source: string;
    /**
    * The name of the reference table. This must be unique within your organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#table_name ReferenceTable#table_name}
    */
    readonly tableName: string;
    /**
    * A list of tags to associate with the reference table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#tags ReferenceTable#tags}
    */
    readonly tags?: string[];
    /**
    * file_metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#file_metadata ReferenceTable#file_metadata}
    */
    readonly fileMetadata?: ReferenceTableFileMetadata;
    /**
    * schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#schema ReferenceTable#schema}
    */
    readonly schema?: ReferenceTableSchema;
}
export interface ReferenceTableFileMetadataAccessDetailsAwsDetail {
    /**
    * The ID of the AWS account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#aws_account_id ReferenceTable#aws_account_id}
    */
    readonly awsAccountId?: string;
    /**
    * The name of the AWS S3 bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#aws_bucket_name ReferenceTable#aws_bucket_name}
    */
    readonly awsBucketName?: string;
    /**
    * The relative file path from the AWS S3 bucket root to the CSV file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#file_path ReferenceTable#file_path}
    */
    readonly filePath?: string;
}
export declare function referenceTableFileMetadataAccessDetailsAwsDetailToTerraform(struct?: ReferenceTableFileMetadataAccessDetailsAwsDetail | cdktn.IResolvable): any;
export declare function referenceTableFileMetadataAccessDetailsAwsDetailToHclTerraform(struct?: ReferenceTableFileMetadataAccessDetailsAwsDetail | cdktn.IResolvable): any;
export declare class ReferenceTableFileMetadataAccessDetailsAwsDetailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReferenceTableFileMetadataAccessDetailsAwsDetail | cdktn.IResolvable | undefined;
    set internalValue(value: ReferenceTableFileMetadataAccessDetailsAwsDetail | cdktn.IResolvable | undefined);
    private _awsAccountId?;
    get awsAccountId(): string;
    set awsAccountId(value: string);
    resetAwsAccountId(): void;
    get awsAccountIdInput(): string | undefined;
    private _awsBucketName?;
    get awsBucketName(): string;
    set awsBucketName(value: string);
    resetAwsBucketName(): void;
    get awsBucketNameInput(): string | undefined;
    private _filePath?;
    get filePath(): string;
    set filePath(value: string);
    resetFilePath(): void;
    get filePathInput(): string | undefined;
}
export interface ReferenceTableFileMetadataAccessDetailsAzureDetail {
    /**
    * The Azure client ID (application ID).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#azure_client_id ReferenceTable#azure_client_id}
    */
    readonly azureClientId?: string;
    /**
    * The name of the Azure container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#azure_container_name ReferenceTable#azure_container_name}
    */
    readonly azureContainerName?: string;
    /**
    * The name of the Azure storage account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#azure_storage_account_name ReferenceTable#azure_storage_account_name}
    */
    readonly azureStorageAccountName?: string;
    /**
    * The ID of the Azure tenant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#azure_tenant_id ReferenceTable#azure_tenant_id}
    */
    readonly azureTenantId?: string;
    /**
    * The relative file path from the Azure container root to the CSV file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#file_path ReferenceTable#file_path}
    */
    readonly filePath?: string;
}
export declare function referenceTableFileMetadataAccessDetailsAzureDetailToTerraform(struct?: ReferenceTableFileMetadataAccessDetailsAzureDetail | cdktn.IResolvable): any;
export declare function referenceTableFileMetadataAccessDetailsAzureDetailToHclTerraform(struct?: ReferenceTableFileMetadataAccessDetailsAzureDetail | cdktn.IResolvable): any;
export declare class ReferenceTableFileMetadataAccessDetailsAzureDetailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReferenceTableFileMetadataAccessDetailsAzureDetail | cdktn.IResolvable | undefined;
    set internalValue(value: ReferenceTableFileMetadataAccessDetailsAzureDetail | cdktn.IResolvable | undefined);
    private _azureClientId?;
    get azureClientId(): string;
    set azureClientId(value: string);
    resetAzureClientId(): void;
    get azureClientIdInput(): string | undefined;
    private _azureContainerName?;
    get azureContainerName(): string;
    set azureContainerName(value: string);
    resetAzureContainerName(): void;
    get azureContainerNameInput(): string | undefined;
    private _azureStorageAccountName?;
    get azureStorageAccountName(): string;
    set azureStorageAccountName(value: string);
    resetAzureStorageAccountName(): void;
    get azureStorageAccountNameInput(): string | undefined;
    private _azureTenantId?;
    get azureTenantId(): string;
    set azureTenantId(value: string);
    resetAzureTenantId(): void;
    get azureTenantIdInput(): string | undefined;
    private _filePath?;
    get filePath(): string;
    set filePath(value: string);
    resetFilePath(): void;
    get filePathInput(): string | undefined;
}
export interface ReferenceTableFileMetadataAccessDetailsGcpDetail {
    /**
    * The relative file path from the GCS bucket root to the CSV file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#file_path ReferenceTable#file_path}
    */
    readonly filePath?: string;
    /**
    * The name of the GCP bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#gcp_bucket_name ReferenceTable#gcp_bucket_name}
    */
    readonly gcpBucketName?: string;
    /**
    * The ID of the GCP project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#gcp_project_id ReferenceTable#gcp_project_id}
    */
    readonly gcpProjectId?: string;
    /**
    * The email of the GCP service account used to access the bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#gcp_service_account_email ReferenceTable#gcp_service_account_email}
    */
    readonly gcpServiceAccountEmail?: string;
}
export declare function referenceTableFileMetadataAccessDetailsGcpDetailToTerraform(struct?: ReferenceTableFileMetadataAccessDetailsGcpDetail | cdktn.IResolvable): any;
export declare function referenceTableFileMetadataAccessDetailsGcpDetailToHclTerraform(struct?: ReferenceTableFileMetadataAccessDetailsGcpDetail | cdktn.IResolvable): any;
export declare class ReferenceTableFileMetadataAccessDetailsGcpDetailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReferenceTableFileMetadataAccessDetailsGcpDetail | cdktn.IResolvable | undefined;
    set internalValue(value: ReferenceTableFileMetadataAccessDetailsGcpDetail | cdktn.IResolvable | undefined);
    private _filePath?;
    get filePath(): string;
    set filePath(value: string);
    resetFilePath(): void;
    get filePathInput(): string | undefined;
    private _gcpBucketName?;
    get gcpBucketName(): string;
    set gcpBucketName(value: string);
    resetGcpBucketName(): void;
    get gcpBucketNameInput(): string | undefined;
    private _gcpProjectId?;
    get gcpProjectId(): string;
    set gcpProjectId(value: string);
    resetGcpProjectId(): void;
    get gcpProjectIdInput(): string | undefined;
    private _gcpServiceAccountEmail?;
    get gcpServiceAccountEmail(): string;
    set gcpServiceAccountEmail(value: string);
    resetGcpServiceAccountEmail(): void;
    get gcpServiceAccountEmailInput(): string | undefined;
}
export interface ReferenceTableFileMetadataAccessDetails {
    /**
    * aws_detail block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#aws_detail ReferenceTable#aws_detail}
    */
    readonly awsDetail?: ReferenceTableFileMetadataAccessDetailsAwsDetail;
    /**
    * azure_detail block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#azure_detail ReferenceTable#azure_detail}
    */
    readonly azureDetail?: ReferenceTableFileMetadataAccessDetailsAzureDetail;
    /**
    * gcp_detail block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#gcp_detail ReferenceTable#gcp_detail}
    */
    readonly gcpDetail?: ReferenceTableFileMetadataAccessDetailsGcpDetail;
}
export declare function referenceTableFileMetadataAccessDetailsToTerraform(struct?: ReferenceTableFileMetadataAccessDetails | cdktn.IResolvable): any;
export declare function referenceTableFileMetadataAccessDetailsToHclTerraform(struct?: ReferenceTableFileMetadataAccessDetails | cdktn.IResolvable): any;
export declare class ReferenceTableFileMetadataAccessDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReferenceTableFileMetadataAccessDetails | cdktn.IResolvable | undefined;
    set internalValue(value: ReferenceTableFileMetadataAccessDetails | cdktn.IResolvable | undefined);
    private _awsDetail;
    get awsDetail(): ReferenceTableFileMetadataAccessDetailsAwsDetailOutputReference;
    putAwsDetail(value: ReferenceTableFileMetadataAccessDetailsAwsDetail): void;
    resetAwsDetail(): void;
    get awsDetailInput(): cdktn.IResolvable | ReferenceTableFileMetadataAccessDetailsAwsDetail | undefined;
    private _azureDetail;
    get azureDetail(): ReferenceTableFileMetadataAccessDetailsAzureDetailOutputReference;
    putAzureDetail(value: ReferenceTableFileMetadataAccessDetailsAzureDetail): void;
    resetAzureDetail(): void;
    get azureDetailInput(): cdktn.IResolvable | ReferenceTableFileMetadataAccessDetailsAzureDetail | undefined;
    private _gcpDetail;
    get gcpDetail(): ReferenceTableFileMetadataAccessDetailsGcpDetailOutputReference;
    putGcpDetail(value: ReferenceTableFileMetadataAccessDetailsGcpDetail): void;
    resetGcpDetail(): void;
    get gcpDetailInput(): cdktn.IResolvable | ReferenceTableFileMetadataAccessDetailsGcpDetail | undefined;
}
export interface ReferenceTableFileMetadata {
    /**
    * Whether this table should automatically sync with the cloud storage source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#sync_enabled ReferenceTable#sync_enabled}
    */
    readonly syncEnabled: boolean | cdktn.IResolvable;
    /**
    * access_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#access_details ReferenceTable#access_details}
    */
    readonly accessDetails?: ReferenceTableFileMetadataAccessDetails;
}
export declare function referenceTableFileMetadataToTerraform(struct?: ReferenceTableFileMetadata | cdktn.IResolvable): any;
export declare function referenceTableFileMetadataToHclTerraform(struct?: ReferenceTableFileMetadata | cdktn.IResolvable): any;
export declare class ReferenceTableFileMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReferenceTableFileMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: ReferenceTableFileMetadata | cdktn.IResolvable | undefined);
    get errorMessage(): string;
    get errorRowCount(): number;
    get errorType(): string;
    private _syncEnabled?;
    get syncEnabled(): boolean | cdktn.IResolvable;
    set syncEnabled(value: boolean | cdktn.IResolvable);
    get syncEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _accessDetails;
    get accessDetails(): ReferenceTableFileMetadataAccessDetailsOutputReference;
    putAccessDetails(value: ReferenceTableFileMetadataAccessDetails): void;
    resetAccessDetails(): void;
    get accessDetailsInput(): cdktn.IResolvable | ReferenceTableFileMetadataAccessDetails | undefined;
}
export interface ReferenceTableSchemaFields {
    /**
    * The name of the field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#name ReferenceTable#name}
    */
    readonly name: string;
    /**
    * The data type of the field. Must be one of: STRING, INT32. Valid values are `STRING`, `INT32`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#type ReferenceTable#type}
    */
    readonly type: string;
}
export declare function referenceTableSchemaFieldsToTerraform(struct?: ReferenceTableSchemaFields | cdktn.IResolvable): any;
export declare function referenceTableSchemaFieldsToHclTerraform(struct?: ReferenceTableSchemaFields | cdktn.IResolvable): any;
export declare class ReferenceTableSchemaFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ReferenceTableSchemaFields | cdktn.IResolvable | undefined;
    set internalValue(value: ReferenceTableSchemaFields | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class ReferenceTableSchemaFieldsList extends cdktn.ComplexList {
    internalValue?: ReferenceTableSchemaFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ReferenceTableSchemaFieldsOutputReference;
}
export interface ReferenceTableSchema {
    /**
    * List of field names that serve as primary keys for the table. Currently only one primary key is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#primary_keys ReferenceTable#primary_keys}
    */
    readonly primaryKeys: string[];
    /**
    * fields block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#fields ReferenceTable#fields}
    */
    readonly fields?: ReferenceTableSchemaFields[] | cdktn.IResolvable;
}
export declare function referenceTableSchemaToTerraform(struct?: ReferenceTableSchema | cdktn.IResolvable): any;
export declare function referenceTableSchemaToHclTerraform(struct?: ReferenceTableSchema | cdktn.IResolvable): any;
export declare class ReferenceTableSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ReferenceTableSchema | cdktn.IResolvable | undefined;
    set internalValue(value: ReferenceTableSchema | cdktn.IResolvable | undefined);
    private _primaryKeys?;
    get primaryKeys(): string[];
    set primaryKeys(value: string[]);
    get primaryKeysInput(): string[] | undefined;
    private _fields;
    get fields(): ReferenceTableSchemaFieldsList;
    putFields(value: ReferenceTableSchemaFields[] | cdktn.IResolvable): void;
    resetFields(): void;
    get fieldsInput(): cdktn.IResolvable | ReferenceTableSchemaFields[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table datadog_reference_table}
*/
export declare class ReferenceTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_reference_table";
    /**
    * Generates CDKTN code for importing a ReferenceTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ReferenceTable to import
    * @param importFromId The id of the existing ReferenceTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ReferenceTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/reference_table datadog_reference_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ReferenceTableConfig
    */
    constructor(scope: Construct, id: string, config: ReferenceTableConfig);
    get createdBy(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get lastUpdatedBy(): string;
    get rowCount(): number;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    get status(): string;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    get updatedAt(): string;
    private _fileMetadata;
    get fileMetadata(): ReferenceTableFileMetadataOutputReference;
    putFileMetadata(value: ReferenceTableFileMetadata): void;
    resetFileMetadata(): void;
    get fileMetadataInput(): cdktn.IResolvable | ReferenceTableFileMetadata | undefined;
    private _schema;
    get schema(): ReferenceTableSchemaOutputReference;
    putSchema(value: ReferenceTableSchema): void;
    resetSchema(): void;
    get schemaInput(): cdktn.IResolvable | ReferenceTableSchema | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
