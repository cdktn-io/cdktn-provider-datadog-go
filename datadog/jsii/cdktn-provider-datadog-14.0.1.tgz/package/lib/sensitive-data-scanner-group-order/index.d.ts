/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SensitiveDataScannerGroupOrderConfig extends cdktn.TerraformMetaArguments {
    /**
    * The list of Sensitive Data Scanner group IDs, in order. Logs are tested against the query filter of each index one by one following the order of the list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_group_order#group_ids SensitiveDataScannerGroupOrder#group_ids}
    */
    readonly groupIds: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_group_order datadog_sensitive_data_scanner_group_order}
*/
export declare class SensitiveDataScannerGroupOrder extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_sensitive_data_scanner_group_order";
    /**
    * Generates CDKTN code for importing a SensitiveDataScannerGroupOrder resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SensitiveDataScannerGroupOrder to import
    * @param importFromId The id of the existing SensitiveDataScannerGroupOrder that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_group_order#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SensitiveDataScannerGroupOrder to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_group_order datadog_sensitive_data_scanner_group_order} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SensitiveDataScannerGroupOrderConfig
    */
    constructor(scope: Construct, id: string, config: SensitiveDataScannerGroupOrderConfig);
    private _groupIds?;
    get groupIds(): string[];
    set groupIds(value: string[]);
    get groupIdsInput(): string[] | undefined;
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
