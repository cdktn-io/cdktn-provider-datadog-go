/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogTeamNotificationRulesConfig extends cdktn.TerraformMetaArguments {
    /**
    * The team ID to fetch notification rules for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team_notification_rules#team_id DataDatadogTeamNotificationRules#team_id}
    */
    readonly teamId: string;
    /**
    * notification_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team_notification_rules#notification_rules DataDatadogTeamNotificationRules#notification_rules}
    */
    readonly notificationRules?: DataDatadogTeamNotificationRulesNotificationRules[] | cdktn.IResolvable;
}
export interface DataDatadogTeamNotificationRulesNotificationRulesEmail {
}
export declare function dataDatadogTeamNotificationRulesNotificationRulesEmailToTerraform(struct?: DataDatadogTeamNotificationRulesNotificationRulesEmail | cdktn.IResolvable): any;
export declare function dataDatadogTeamNotificationRulesNotificationRulesEmailToHclTerraform(struct?: DataDatadogTeamNotificationRulesNotificationRulesEmail | cdktn.IResolvable): any;
export declare class DataDatadogTeamNotificationRulesNotificationRulesEmailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogTeamNotificationRulesNotificationRulesEmail | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogTeamNotificationRulesNotificationRulesEmail | cdktn.IResolvable | undefined);
    get enabled(): cdktn.IResolvable;
}
export interface DataDatadogTeamNotificationRulesNotificationRulesMsTeams {
}
export declare function dataDatadogTeamNotificationRulesNotificationRulesMsTeamsToTerraform(struct?: DataDatadogTeamNotificationRulesNotificationRulesMsTeams | cdktn.IResolvable): any;
export declare function dataDatadogTeamNotificationRulesNotificationRulesMsTeamsToHclTerraform(struct?: DataDatadogTeamNotificationRulesNotificationRulesMsTeams | cdktn.IResolvable): any;
export declare class DataDatadogTeamNotificationRulesNotificationRulesMsTeamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogTeamNotificationRulesNotificationRulesMsTeams | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogTeamNotificationRulesNotificationRulesMsTeams | cdktn.IResolvable | undefined);
    get connectorName(): string;
}
export interface DataDatadogTeamNotificationRulesNotificationRulesPagerduty {
}
export declare function dataDatadogTeamNotificationRulesNotificationRulesPagerdutyToTerraform(struct?: DataDatadogTeamNotificationRulesNotificationRulesPagerduty | cdktn.IResolvable): any;
export declare function dataDatadogTeamNotificationRulesNotificationRulesPagerdutyToHclTerraform(struct?: DataDatadogTeamNotificationRulesNotificationRulesPagerduty | cdktn.IResolvable): any;
export declare class DataDatadogTeamNotificationRulesNotificationRulesPagerdutyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogTeamNotificationRulesNotificationRulesPagerduty | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogTeamNotificationRulesNotificationRulesPagerduty | cdktn.IResolvable | undefined);
    get serviceName(): string;
}
export interface DataDatadogTeamNotificationRulesNotificationRulesSlack {
}
export declare function dataDatadogTeamNotificationRulesNotificationRulesSlackToTerraform(struct?: DataDatadogTeamNotificationRulesNotificationRulesSlack | cdktn.IResolvable): any;
export declare function dataDatadogTeamNotificationRulesNotificationRulesSlackToHclTerraform(struct?: DataDatadogTeamNotificationRulesNotificationRulesSlack | cdktn.IResolvable): any;
export declare class DataDatadogTeamNotificationRulesNotificationRulesSlackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogTeamNotificationRulesNotificationRulesSlack | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogTeamNotificationRulesNotificationRulesSlack | cdktn.IResolvable | undefined);
    get channel(): string;
    get workspace(): string;
}
export interface DataDatadogTeamNotificationRulesNotificationRules {
}
export declare function dataDatadogTeamNotificationRulesNotificationRulesToTerraform(struct?: DataDatadogTeamNotificationRulesNotificationRules | cdktn.IResolvable): any;
export declare function dataDatadogTeamNotificationRulesNotificationRulesToHclTerraform(struct?: DataDatadogTeamNotificationRulesNotificationRules | cdktn.IResolvable): any;
export declare class DataDatadogTeamNotificationRulesNotificationRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogTeamNotificationRulesNotificationRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogTeamNotificationRulesNotificationRules | cdktn.IResolvable | undefined);
    get id(): string;
    private _email;
    get email(): DataDatadogTeamNotificationRulesNotificationRulesEmailOutputReference;
    private _msTeams;
    get msTeams(): DataDatadogTeamNotificationRulesNotificationRulesMsTeamsOutputReference;
    private _pagerduty;
    get pagerduty(): DataDatadogTeamNotificationRulesNotificationRulesPagerdutyOutputReference;
    private _slack;
    get slack(): DataDatadogTeamNotificationRulesNotificationRulesSlackOutputReference;
}
export declare class DataDatadogTeamNotificationRulesNotificationRulesList extends cdktn.ComplexList {
    internalValue?: DataDatadogTeamNotificationRulesNotificationRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogTeamNotificationRulesNotificationRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team_notification_rules datadog_team_notification_rules}
*/
export declare class DataDatadogTeamNotificationRules extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_team_notification_rules";
    /**
    * Generates CDKTN code for importing a DataDatadogTeamNotificationRules resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogTeamNotificationRules to import
    * @param importFromId The id of the existing DataDatadogTeamNotificationRules that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team_notification_rules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogTeamNotificationRules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team_notification_rules datadog_team_notification_rules} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogTeamNotificationRulesConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogTeamNotificationRulesConfig);
    get id(): string;
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    get teamIdInput(): string | undefined;
    private _notificationRules;
    get notificationRules(): DataDatadogTeamNotificationRulesNotificationRulesList;
    putNotificationRules(value: DataDatadogTeamNotificationRulesNotificationRules[] | cdktn.IResolvable): void;
    resetNotificationRules(): void;
    get notificationRulesInput(): cdktn.IResolvable | DataDatadogTeamNotificationRulesNotificationRules[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
