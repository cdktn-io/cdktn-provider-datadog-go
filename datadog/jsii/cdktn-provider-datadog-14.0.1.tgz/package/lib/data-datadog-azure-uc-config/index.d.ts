/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogAzureUcConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Datadog cloud account ID for the Azure Usage Cost configuration you want to retrieve information about.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/azure_uc_config#cloud_account_id DataDatadogAzureUcConfig#cloud_account_id}
    */
    readonly cloudAccountId: number;
}
export interface DataDatadogAzureUcConfigActualBillConfig {
}
export declare function dataDatadogAzureUcConfigActualBillConfigToTerraform(struct?: DataDatadogAzureUcConfigActualBillConfig | cdktn.IResolvable): any;
export declare function dataDatadogAzureUcConfigActualBillConfigToHclTerraform(struct?: DataDatadogAzureUcConfigActualBillConfig | cdktn.IResolvable): any;
export declare class DataDatadogAzureUcConfigActualBillConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogAzureUcConfigActualBillConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogAzureUcConfigActualBillConfig | cdktn.IResolvable | undefined);
    get exportName(): string;
    get exportPath(): string;
    get storageAccount(): string;
    get storageContainer(): string;
}
export interface DataDatadogAzureUcConfigAmortizedBillConfig {
}
export declare function dataDatadogAzureUcConfigAmortizedBillConfigToTerraform(struct?: DataDatadogAzureUcConfigAmortizedBillConfig | cdktn.IResolvable): any;
export declare function dataDatadogAzureUcConfigAmortizedBillConfigToHclTerraform(struct?: DataDatadogAzureUcConfigAmortizedBillConfig | cdktn.IResolvable): any;
export declare class DataDatadogAzureUcConfigAmortizedBillConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogAzureUcConfigAmortizedBillConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogAzureUcConfigAmortizedBillConfig | cdktn.IResolvable | undefined);
    get exportName(): string;
    get exportPath(): string;
    get storageAccount(): string;
    get storageContainer(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/azure_uc_config datadog_azure_uc_config}
*/
export declare class DataDatadogAzureUcConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_azure_uc_config";
    /**
    * Generates CDKTN code for importing a DataDatadogAzureUcConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogAzureUcConfig to import
    * @param importFromId The id of the existing DataDatadogAzureUcConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/azure_uc_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogAzureUcConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/azure_uc_config datadog_azure_uc_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogAzureUcConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogAzureUcConfigConfig);
    get accountId(): string;
    get clientId(): string;
    private _cloudAccountId?;
    get cloudAccountId(): number;
    set cloudAccountId(value: number);
    get cloudAccountIdInput(): number | undefined;
    get createdAt(): string;
    get errorMessages(): string[];
    get id(): string;
    get scope(): string;
    get status(): string;
    get statusUpdatedAt(): string;
    get updatedAt(): string;
    private _actualBillConfig;
    get actualBillConfig(): DataDatadogAzureUcConfigActualBillConfigOutputReference;
    private _amortizedBillConfig;
    get amortizedBillConfig(): DataDatadogAzureUcConfigAmortizedBillConfigOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
