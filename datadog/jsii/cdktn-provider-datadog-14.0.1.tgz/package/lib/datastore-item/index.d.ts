/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatastoreItemConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique identifier of the datastore containing this item.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/datastore_item#datastore_id DatastoreItem#datastore_id}
    */
    readonly datastoreId: string;
    /**
    * The primary key value that identifies this item. Cannot exceed 256 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/datastore_item#item_key DatastoreItem#item_key}
    */
    readonly itemKey: string;
    /**
    * The data content (as key-value pairs) of the datastore item.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/datastore_item#value DatastoreItem#value}
    */
    readonly value: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/datastore_item datadog_datastore_item}
*/
export declare class DatastoreItem extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_datastore_item";
    /**
    * Generates CDKTN code for importing a DatastoreItem resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatastoreItem to import
    * @param importFromId The id of the existing DatastoreItem that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/datastore_item#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatastoreItem to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/datastore_item datadog_datastore_item} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatastoreItemConfig
    */
    constructor(scope: Construct, id: string, config: DatastoreItemConfig);
    private _datastoreId?;
    get datastoreId(): string;
    set datastoreId(value: string);
    get datastoreIdInput(): string | undefined;
    get id(): string;
    private _itemKey?;
    get itemKey(): string;
    set itemKey(value: string);
    get itemKeyInput(): string | undefined;
    private _value?;
    get value(): {
        [key: string]: string;
    };
    set value(value: {
        [key: string]: string;
    });
    get valueInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
