/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MonitorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Indicates whether the monitor is in a draft or published state. When set to `draft`, the monitor appears as Draft and does not send notifications. When set to `published`, the monitor is active, and it evaluates conditions and sends notifications as configured. Valid values are `draft`, `published`. Defaults to `"published"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#draft_status Monitor#draft_status}
    */
    readonly draftStatus?: string;
    /**
    * A boolean indicating whether or not to include a list of log values which triggered the alert. This is only used by log monitors. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#enable_logs_sample Monitor#enable_logs_sample}
    */
    readonly enableLogsSample?: boolean | cdktn.IResolvable;
    /**
    * Whether or not a list of samples which triggered the alert is included. This is only used by CI Test and Pipeline monitors.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#enable_samples Monitor#enable_samples}
    */
    readonly enableSamples?: boolean | cdktn.IResolvable;
    /**
    * A message to include with a re-notification. Supports the `@username` notification allowed elsewhere.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#escalation_message Monitor#escalation_message}
    */
    readonly escalationMessage?: string;
    /**
    * (Only applies to metric alert) Time (in seconds) to delay evaluation, as a non-negative integer.
    *
    * For example, if the value is set to `300` (5min), the `timeframe` is set to `last_5m` and the time is 7:00, the monitor will evaluate data from 6:50 to 6:55. This is useful for AWS CloudWatch and other backfilled metrics to ensure the monitor will always have data during evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#evaluation_delay Monitor#evaluation_delay}
    */
    readonly evaluationDelay?: number;
    /**
    * A boolean indicating whether this monitor can be deleted even if it’s referenced by other resources (e.g. SLO, composite monitor).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#force_delete Monitor#force_delete}
    */
    readonly forceDelete?: boolean | cdktn.IResolvable;
    /**
    * The time span after which groups with missing data are dropped from the monitor state. The minimum value is one hour, and the maximum value is 72 hours. Example values are: 60m, 1h, and 2d. This option is only available for APM Trace Analytics, Audit Trail, CI, Error Tracking, Event, Logs, and RUM monitors.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#group_retention_duration Monitor#group_retention_duration}
    */
    readonly groupRetentionDuration?: string;
    /**
    * Whether or not to trigger one alert if any source breaches a threshold. This is only used by log monitors. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#groupby_simple_monitor Monitor#groupby_simple_monitor}
    */
    readonly groupbySimpleMonitor?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#id Monitor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A boolean indicating whether notifications from this monitor automatically insert its triggering tags into the title. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#include_tags Monitor#include_tags}
    */
    readonly includeTags?: boolean | cdktn.IResolvable;
    /**
    * A boolean indicating whether changes to this monitor should be restricted to the creator or admins. Defaults to `false`. **Deprecated.** Use `restricted_roles`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#locked Monitor#locked}
    */
    readonly locked?: boolean | cdktn.IResolvable;
    /**
    * A message to include with notifications for this monitor.
    *
    * Email notifications can be sent to specific users by using the same `@username` notation as events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#message Monitor#message}
    */
    readonly message: string;
    /**
    * Name of Datadog monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#name Monitor#name}
    */
    readonly name: string;
    /**
    * The time (in seconds) to skip evaluations for new groups.
    *
    * `new_group_delay` overrides `new_host_delay` if it is set to a nonzero value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#new_group_delay Monitor#new_group_delay}
    */
    readonly newGroupDelay?: number;
    /**
    * **Deprecated**. See `new_group_delay`. Time (in seconds) to allow a host to boot and applications to fully start before starting the evaluation of monitor results. Should be a non-negative integer. This value is ignored for simple monitors and monitors not grouped by host. The only case when this should be used is to override the default and set `new_host_delay` to zero for monitors grouped by host. **Deprecated.** Use `new_group_delay` except when setting `new_host_delay` to zero. Defaults to `300`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#new_host_delay Monitor#new_host_delay}
    */
    readonly newHostDelay?: number;
    /**
    * The number of minutes before a monitor will notify when data stops reporting.
    *
    * We recommend at least 2x the monitor timeframe for metric alerts or 2 minutes for service checks. Defaults to `10`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#no_data_timeframe Monitor#no_data_timeframe}
    */
    readonly noDataTimeframe?: number;
    /**
    * Toggles the display of additional content sent in the monitor notification. Valid values are `show_all`, `hide_query`, `hide_handles`, `hide_all`, `hide_query_and_handles`, `show_only_snapshot`, `hide_handles_and_footer`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#notification_preset_name Monitor#notification_preset_name}
    */
    readonly notificationPresetName?: string;
    /**
    * A boolean indicating whether tagged users will be notified on changes to this monitor. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#notify_audit Monitor#notify_audit}
    */
    readonly notifyAudit?: boolean | cdktn.IResolvable;
    /**
    * Controls what granularity a monitor alerts on. Only available for monitors with groupings. For instance, a monitor grouped by `cluster`, `namespace`, and `pod` can be configured to only notify on each new `cluster` violating the alert conditions by setting `notify_by` to `['cluster']`. Tags mentioned in `notify_by` must be a subset of the grouping tags in the query. For example, a query grouped by `cluster` and `namespace` cannot notify on `region`. Setting `notify_by` to `[*]` configures the monitor to notify as a simple-alert.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#notify_by Monitor#notify_by}
    */
    readonly notifyBy?: string[];
    /**
    * A boolean indicating whether this monitor will notify when data stops reporting. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#notify_no_data Monitor#notify_no_data}
    */
    readonly notifyNoData?: boolean | cdktn.IResolvable;
    /**
    * Controls how groups or monitors are treated if an evaluation does not return any data points. The default option results in different behavior depending on the monitor query type. For monitors using `Count` queries, an empty monitor evaluation is treated as 0 and is compared to the threshold conditions. For monitors using any query type other than `Count`, for example `Gauge`, `Measure`, or `Rate`, the monitor shows the last known status. This option is not available for Service Check, Composite, or SLO monitors. Valid values are: `show_no_data`, `show_and_notify_no_data`, `resolve`, and `default`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#on_missing_data Monitor#on_missing_data}
    */
    readonly onMissingData?: string;
    /**
    * Integer from 1 (high) to 5 (low) indicating alert severity.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#priority Monitor#priority}
    */
    readonly priority?: string;
    /**
    * The monitor query to notify on. Note this is not the same query you see in the UI and the syntax is different depending on the monitor type, please see the [API Reference](https://docs.datadoghq.com/api/v1/monitors/#create-a-monitor) for details. `terraform plan` will validate query contents unless `validate` is set to `false`.
    *
    * **Note:** APM latency data is now available as Distribution Metrics. Existing monitors have been migrated automatically but all terraformed monitors can still use the existing metrics. We strongly recommend updating monitor definitions to query the new metrics. To learn more, or to see examples of how to update your terraform definitions to utilize the new distribution metrics, see the [detailed doc](https://docs.datadoghq.com/tracing/guide/ddsketch_trace_metrics/).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#query Monitor#query}
    */
    readonly query: string;
    /**
    * The number of minutes after the last notification before a monitor will re-notify on the current status. It will only re-notify if it's not resolved.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#renotify_interval Monitor#renotify_interval}
    */
    readonly renotifyInterval?: number;
    /**
    * The number of re-notification messages that should be sent on the current status.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#renotify_occurrences Monitor#renotify_occurrences}
    */
    readonly renotifyOccurrences?: number;
    /**
    * The types of statuses for which re-notification messages should be sent. Valid values are `alert`, `warn`, `no data`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#renotify_statuses Monitor#renotify_statuses}
    */
    readonly renotifyStatuses?: string[];
    /**
    * A boolean indicating whether this monitor needs a full window of data before it's evaluated. Datadog strongly recommends you set this to `false` for sparse metrics, otherwise some evaluations may be skipped. If there's a custom_schedule set, `require_full_window` must be false and will be ignored. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#require_full_window Monitor#require_full_window}
    */
    readonly requireFullWindow?: boolean | cdktn.IResolvable;
    /**
    * A list of unique role identifiers to define which roles are allowed to edit the monitor. Editing a monitor includes any updates to the monitor configuration, monitor deletion, and muting of the monitor for any amount of time. Roles unique identifiers can be pulled from the [Roles API](https://docs.datadoghq.com/api/latest/roles/#list-roles) in the `data.id` field.
    *  > **Note:** When the `TERRAFORM_MONITOR_EXPLICIT_RESTRICTED_ROLES` environment variable is set to `true`, this argument is treated as `Computed`. Terraform will automatically read the current restricted roles list from the Datadog API whenever the attribute is omitted. If `restricted_roles` is explicitly set in the configuration, that value always takes precedence over whatever is discovered during the read. This opt-in behaviour lets you migrate responsibility for monitor permissions to the `datadog_restriction_policy` resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#restricted_roles Monitor#restricted_roles}
    */
    readonly restrictedRoles?: string[];
    /**
    * A list of tags to associate with your monitor. This can help you categorize and filter monitors in the manage monitors page of the UI. Note: it's not currently possible to filter by these tags when querying via the API
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#tags Monitor#tags}
    */
    readonly tags?: string[];
    /**
    * The number of hours of the monitor not reporting data before it automatically resolves from a triggered state. The minimum allowed value is 0 hours. The maximum allowed value is 24 hours.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#timeout_h Monitor#timeout_h}
    */
    readonly timeoutH?: number;
    /**
    * The type of the monitor. The mapping from these types to the types found in the Datadog Web UI can be found in the Datadog API [documentation page](https://docs.datadoghq.com/api/v1/monitors/#create-a-monitor). Note: The monitor type cannot be changed after a monitor is created. Valid values are `composite`, `event alert`, `log alert`, `metric alert`, `process alert`, `query alert`, `rum alert`, `service check`, `synthetics alert`, `trace-analytics alert`, `slo alert`, `event-v2 alert`, `audit alert`, `ci-pipelines alert`, `ci-tests alert`, `error-tracking alert`, `database-monitoring alert`, `network-performance alert`, `cost alert`, `data-quality alert`, `network-path alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#type Monitor#type}
    */
    readonly type: string;
    /**
    * If set to `false`, skip the validation call done during plan.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#validate Monitor#validate}
    */
    readonly validate?: boolean | cdktn.IResolvable;
    /**
    * assets block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#assets Monitor#assets}
    */
    readonly assets?: MonitorAssets[] | cdktn.IResolvable;
    /**
    * monitor_threshold_windows block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#monitor_threshold_windows Monitor#monitor_threshold_windows}
    */
    readonly monitorThresholdWindows?: MonitorMonitorThresholdWindows;
    /**
    * monitor_thresholds block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#monitor_thresholds Monitor#monitor_thresholds}
    */
    readonly monitorThresholds?: MonitorMonitorThresholds;
    /**
    * scheduling_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#scheduling_options Monitor#scheduling_options}
    */
    readonly schedulingOptions?: MonitorSchedulingOptions;
    /**
    * variables block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#variables Monitor#variables}
    */
    readonly variables?: MonitorVariables;
}
export interface MonitorAssets {
    /**
    * Type of asset the entity represents on a monitor. Valid values are `runbook`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#category Monitor#category}
    */
    readonly category: string;
    /**
    * Name for the monitor asset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#name Monitor#name}
    */
    readonly name: string;
    /**
    * Identifier of the internal Datadog resource that this asset represents.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#resource_key Monitor#resource_key}
    */
    readonly resourceKey?: string;
    /**
    * Type of internal Datadog resource associated with a monitor asset. Valid values are `notebook`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#resource_type Monitor#resource_type}
    */
    readonly resourceType?: string;
    /**
    * URL for the asset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#url Monitor#url}
    */
    readonly url: string;
}
export declare function monitorAssetsToTerraform(struct?: MonitorAssets | cdktn.IResolvable): any;
export declare function monitorAssetsToHclTerraform(struct?: MonitorAssets | cdktn.IResolvable): any;
export declare class MonitorAssetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorAssets | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorAssets | cdktn.IResolvable | undefined);
    private _category?;
    get category(): string;
    set category(value: string);
    get categoryInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _resourceKey?;
    get resourceKey(): string;
    set resourceKey(value: string);
    resetResourceKey(): void;
    get resourceKeyInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    resetResourceType(): void;
    get resourceTypeInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export declare class MonitorAssetsList extends cdktn.ComplexList {
    internalValue?: MonitorAssets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorAssetsOutputReference;
}
export interface MonitorMonitorThresholdWindows {
    /**
    * Describes how long an anomalous metric must be normal before the alert recovers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#recovery_window Monitor#recovery_window}
    */
    readonly recoveryWindow?: string;
    /**
    * Describes how long a metric must be anomalous before an alert triggers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#trigger_window Monitor#trigger_window}
    */
    readonly triggerWindow?: string;
}
export declare function monitorMonitorThresholdWindowsToTerraform(struct?: MonitorMonitorThresholdWindowsOutputReference | MonitorMonitorThresholdWindows): any;
export declare function monitorMonitorThresholdWindowsToHclTerraform(struct?: MonitorMonitorThresholdWindowsOutputReference | MonitorMonitorThresholdWindows): any;
export declare class MonitorMonitorThresholdWindowsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorMonitorThresholdWindows | undefined;
    set internalValue(value: MonitorMonitorThresholdWindows | undefined);
    private _recoveryWindow?;
    get recoveryWindow(): string;
    set recoveryWindow(value: string);
    resetRecoveryWindow(): void;
    get recoveryWindowInput(): string | undefined;
    private _triggerWindow?;
    get triggerWindow(): string;
    set triggerWindow(value: string);
    resetTriggerWindow(): void;
    get triggerWindowInput(): string | undefined;
}
export interface MonitorMonitorThresholds {
    /**
    * The monitor `CRITICAL` threshold. Must be a number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#critical Monitor#critical}
    */
    readonly critical?: string;
    /**
    * The monitor `CRITICAL` recovery threshold. Must be a number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#critical_recovery Monitor#critical_recovery}
    */
    readonly criticalRecovery?: string;
    /**
    * The monitor `OK` threshold. Only supported in monitor type `service check`. Must be a number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#ok Monitor#ok}
    */
    readonly ok?: string;
    /**
    * The monitor `UNKNOWN` threshold. Only supported in monitor type `service check`. Must be a number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#unknown Monitor#unknown}
    */
    readonly unknown?: string;
    /**
    * The monitor `WARNING` threshold. Must be a number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#warning Monitor#warning}
    */
    readonly warning?: string;
    /**
    * The monitor `WARNING` recovery threshold. Must be a number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#warning_recovery Monitor#warning_recovery}
    */
    readonly warningRecovery?: string;
}
export declare function monitorMonitorThresholdsToTerraform(struct?: MonitorMonitorThresholdsOutputReference | MonitorMonitorThresholds): any;
export declare function monitorMonitorThresholdsToHclTerraform(struct?: MonitorMonitorThresholdsOutputReference | MonitorMonitorThresholds): any;
export declare class MonitorMonitorThresholdsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorMonitorThresholds | undefined;
    set internalValue(value: MonitorMonitorThresholds | undefined);
    private _critical?;
    get critical(): string;
    set critical(value: string);
    resetCritical(): void;
    get criticalInput(): string | undefined;
    private _criticalRecovery?;
    get criticalRecovery(): string;
    set criticalRecovery(value: string);
    resetCriticalRecovery(): void;
    get criticalRecoveryInput(): string | undefined;
    private _ok?;
    get ok(): string;
    set ok(value: string);
    resetOk(): void;
    get okInput(): string | undefined;
    private _unknown?;
    get unknown(): string;
    set unknown(value: string);
    resetUnknown(): void;
    get unknownInput(): string | undefined;
    private _warning?;
    get warning(): string;
    set warning(value: string);
    resetWarning(): void;
    get warningInput(): string | undefined;
    private _warningRecovery?;
    get warningRecovery(): string;
    set warningRecovery(value: string);
    resetWarningRecovery(): void;
    get warningRecoveryInput(): string | undefined;
}
export interface MonitorSchedulingOptionsCustomScheduleRecurrence {
    /**
    * Must be a valid `rrule`. See API docs for supported fields
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#rrule Monitor#rrule}
    */
    readonly rrule: string;
    /**
    * Time to start recurrence cycle. Similar to DTSTART. Expected format 'YYYY-MM-DDThh:mm:ss'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#start Monitor#start}
    */
    readonly start?: string;
    /**
    * 'tz database' format. Example: `America/New_York` or `UTC`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#timezone Monitor#timezone}
    */
    readonly timezone: string;
}
export declare function monitorSchedulingOptionsCustomScheduleRecurrenceToTerraform(struct?: MonitorSchedulingOptionsCustomScheduleRecurrenceOutputReference | MonitorSchedulingOptionsCustomScheduleRecurrence): any;
export declare function monitorSchedulingOptionsCustomScheduleRecurrenceToHclTerraform(struct?: MonitorSchedulingOptionsCustomScheduleRecurrenceOutputReference | MonitorSchedulingOptionsCustomScheduleRecurrence): any;
export declare class MonitorSchedulingOptionsCustomScheduleRecurrenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorSchedulingOptionsCustomScheduleRecurrence | undefined;
    set internalValue(value: MonitorSchedulingOptionsCustomScheduleRecurrence | undefined);
    private _rrule?;
    get rrule(): string;
    set rrule(value: string);
    get rruleInput(): string | undefined;
    private _start?;
    get start(): string;
    set start(value: string);
    resetStart(): void;
    get startInput(): string | undefined;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    get timezoneInput(): string | undefined;
}
export interface MonitorSchedulingOptionsCustomSchedule {
    /**
    * recurrence block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#recurrence Monitor#recurrence}
    */
    readonly recurrence: MonitorSchedulingOptionsCustomScheduleRecurrence;
}
export declare function monitorSchedulingOptionsCustomScheduleToTerraform(struct?: MonitorSchedulingOptionsCustomScheduleOutputReference | MonitorSchedulingOptionsCustomSchedule): any;
export declare function monitorSchedulingOptionsCustomScheduleToHclTerraform(struct?: MonitorSchedulingOptionsCustomScheduleOutputReference | MonitorSchedulingOptionsCustomSchedule): any;
export declare class MonitorSchedulingOptionsCustomScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorSchedulingOptionsCustomSchedule | undefined;
    set internalValue(value: MonitorSchedulingOptionsCustomSchedule | undefined);
    private _recurrence;
    get recurrence(): MonitorSchedulingOptionsCustomScheduleRecurrenceOutputReference;
    putRecurrence(value: MonitorSchedulingOptionsCustomScheduleRecurrence): void;
    get recurrenceInput(): MonitorSchedulingOptionsCustomScheduleRecurrence | undefined;
}
export interface MonitorSchedulingOptionsEvaluationWindow {
    /**
    * The time of the day at which a one day cumulative evaluation window starts. Must be defined in UTC time in `HH:mm` format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#day_starts Monitor#day_starts}
    */
    readonly dayStarts?: string;
    /**
    * The minute of the hour at which a one hour cumulative evaluation window starts. Must be between 0 and 59.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#hour_starts Monitor#hour_starts}
    */
    readonly hourStarts?: number;
    /**
    * The day of the month at which a one month cumulative evaluation window starts. Must be a value of 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#month_starts Monitor#month_starts}
    */
    readonly monthStarts?: number;
    /**
    * The timezone for the cumulative evaluation window start time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#timezone Monitor#timezone}
    */
    readonly timezone?: string;
}
export declare function monitorSchedulingOptionsEvaluationWindowToTerraform(struct?: MonitorSchedulingOptionsEvaluationWindowOutputReference | MonitorSchedulingOptionsEvaluationWindow): any;
export declare function monitorSchedulingOptionsEvaluationWindowToHclTerraform(struct?: MonitorSchedulingOptionsEvaluationWindowOutputReference | MonitorSchedulingOptionsEvaluationWindow): any;
export declare class MonitorSchedulingOptionsEvaluationWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorSchedulingOptionsEvaluationWindow | undefined;
    set internalValue(value: MonitorSchedulingOptionsEvaluationWindow | undefined);
    private _dayStarts?;
    get dayStarts(): string;
    set dayStarts(value: string);
    resetDayStarts(): void;
    get dayStartsInput(): string | undefined;
    private _hourStarts?;
    get hourStarts(): number;
    set hourStarts(value: number);
    resetHourStarts(): void;
    get hourStartsInput(): number | undefined;
    private _monthStarts?;
    get monthStarts(): number;
    set monthStarts(value: number);
    resetMonthStarts(): void;
    get monthStartsInput(): number | undefined;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    resetTimezone(): void;
    get timezoneInput(): string | undefined;
}
export interface MonitorSchedulingOptions {
    /**
    * custom_schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#custom_schedule Monitor#custom_schedule}
    */
    readonly customSchedule?: MonitorSchedulingOptionsCustomSchedule;
    /**
    * evaluation_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#evaluation_window Monitor#evaluation_window}
    */
    readonly evaluationWindow?: MonitorSchedulingOptionsEvaluationWindow;
}
export declare function monitorSchedulingOptionsToTerraform(struct?: MonitorSchedulingOptionsOutputReference | MonitorSchedulingOptions): any;
export declare function monitorSchedulingOptionsToHclTerraform(struct?: MonitorSchedulingOptionsOutputReference | MonitorSchedulingOptions): any;
export declare class MonitorSchedulingOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorSchedulingOptions | undefined;
    set internalValue(value: MonitorSchedulingOptions | undefined);
    private _customSchedule;
    get customSchedule(): MonitorSchedulingOptionsCustomScheduleOutputReference;
    putCustomSchedule(value: MonitorSchedulingOptionsCustomSchedule): void;
    resetCustomSchedule(): void;
    get customScheduleInput(): MonitorSchedulingOptionsCustomSchedule | undefined;
    private _evaluationWindow;
    get evaluationWindow(): MonitorSchedulingOptionsEvaluationWindowOutputReference;
    putEvaluationWindow(value: MonitorSchedulingOptionsEvaluationWindow): void;
    resetEvaluationWindow(): void;
    get evaluationWindowInput(): MonitorSchedulingOptionsEvaluationWindow | undefined;
}
export interface MonitorVariablesCloudCostQuery {
    /**
    * The aggregation methods available for cloud cost queries. Valid values are `avg`, `sum`, `max`, `min`, `last`, `area`, `l2norm`, `percentile`, `stddev`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#aggregator Monitor#aggregator}
    */
    readonly aggregator: string;
    /**
    * The data source for cloud cost queries. Valid values are `metrics`, `cloud_cost`, `datadog_usage`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#data_source Monitor#data_source}
    */
    readonly dataSource: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#name Monitor#name}
    */
    readonly name: string;
    /**
    * The cloud cost query definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#query Monitor#query}
    */
    readonly query: string;
}
export declare function monitorVariablesCloudCostQueryToTerraform(struct?: MonitorVariablesCloudCostQuery | cdktn.IResolvable): any;
export declare function monitorVariablesCloudCostQueryToHclTerraform(struct?: MonitorVariablesCloudCostQuery | cdktn.IResolvable): any;
export declare class MonitorVariablesCloudCostQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorVariablesCloudCostQuery | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorVariablesCloudCostQuery | cdktn.IResolvable | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    get aggregatorInput(): string | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class MonitorVariablesCloudCostQueryList extends cdktn.ComplexList {
    internalValue?: MonitorVariablesCloudCostQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorVariablesCloudCostQueryOutputReference;
}
export interface MonitorVariablesDataQualityQueryMonitorOptions {
    /**
    * Crontab expression to override the default schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#crontab_override Monitor#crontab_override}
    */
    readonly crontabOverride?: string;
    /**
    * Custom SQL query for the monitor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#custom_sql Monitor#custom_sql}
    */
    readonly customSql?: string;
    /**
    * Custom WHERE clause for the query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#custom_where Monitor#custom_where}
    */
    readonly customWhere?: string;
    /**
    * Columns to group results by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#group_by_columns Monitor#group_by_columns}
    */
    readonly groupByColumns?: string[];
    /**
    * Override for the model type. Valid values are `freshness`, `percentage`, `any`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#model_type_override Monitor#model_type_override}
    */
    readonly modelTypeOverride?: string;
}
export declare function monitorVariablesDataQualityQueryMonitorOptionsToTerraform(struct?: MonitorVariablesDataQualityQueryMonitorOptionsOutputReference | MonitorVariablesDataQualityQueryMonitorOptions): any;
export declare function monitorVariablesDataQualityQueryMonitorOptionsToHclTerraform(struct?: MonitorVariablesDataQualityQueryMonitorOptionsOutputReference | MonitorVariablesDataQualityQueryMonitorOptions): any;
export declare class MonitorVariablesDataQualityQueryMonitorOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorVariablesDataQualityQueryMonitorOptions | undefined;
    set internalValue(value: MonitorVariablesDataQualityQueryMonitorOptions | undefined);
    private _crontabOverride?;
    get crontabOverride(): string;
    set crontabOverride(value: string);
    resetCrontabOverride(): void;
    get crontabOverrideInput(): string | undefined;
    private _customSql?;
    get customSql(): string;
    set customSql(value: string);
    resetCustomSql(): void;
    get customSqlInput(): string | undefined;
    private _customWhere?;
    get customWhere(): string;
    set customWhere(value: string);
    resetCustomWhere(): void;
    get customWhereInput(): string | undefined;
    private _groupByColumns?;
    get groupByColumns(): string[];
    set groupByColumns(value: string[]);
    resetGroupByColumns(): void;
    get groupByColumnsInput(): string[] | undefined;
    private _modelTypeOverride?;
    get modelTypeOverride(): string;
    set modelTypeOverride(value: string);
    resetModelTypeOverride(): void;
    get modelTypeOverrideInput(): string | undefined;
}
export interface MonitorVariablesDataQualityQuery {
    /**
    * The data source for data quality queries. Valid value is `data_quality_metrics`. Valid values are `data_quality_metrics`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#data_source Monitor#data_source}
    */
    readonly dataSource: string;
    /**
    * Filter expression used to match on data entities. Uses AAstra query syntax.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#filter Monitor#filter}
    */
    readonly filter: string;
    /**
    * Optional grouping fields for aggregation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#group_by Monitor#group_by}
    */
    readonly groupBy?: string[];
    /**
    * The measure to query. Common values include `bytes`, `cardinality`, `custom`, `freshness`, `max`, `mean`, `min`, `nullness`, `percent_negative`, `percent_zero`, `row_count`, `stddev`, `sum`, `uniqueness`. Additional values may be supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#measure Monitor#measure}
    */
    readonly measure: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#name Monitor#name}
    */
    readonly name: string;
    /**
    * Schema version for the data quality query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#schema_version Monitor#schema_version}
    */
    readonly schemaVersion?: string;
    /**
    * Optional scoping expression to further filter metrics.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#scope Monitor#scope}
    */
    readonly scope?: string;
    /**
    * monitor_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#monitor_options Monitor#monitor_options}
    */
    readonly monitorOptions?: MonitorVariablesDataQualityQueryMonitorOptions;
}
export declare function monitorVariablesDataQualityQueryToTerraform(struct?: MonitorVariablesDataQualityQuery | cdktn.IResolvable): any;
export declare function monitorVariablesDataQualityQueryToHclTerraform(struct?: MonitorVariablesDataQualityQuery | cdktn.IResolvable): any;
export declare class MonitorVariablesDataQualityQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorVariablesDataQualityQuery | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorVariablesDataQualityQuery | cdktn.IResolvable | undefined);
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    get filterInput(): string | undefined;
    private _groupBy?;
    get groupBy(): string[];
    set groupBy(value: string[]);
    resetGroupBy(): void;
    get groupByInput(): string[] | undefined;
    private _measure?;
    get measure(): string;
    set measure(value: string);
    get measureInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schemaVersion?;
    get schemaVersion(): string;
    set schemaVersion(value: string);
    resetSchemaVersion(): void;
    get schemaVersionInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
    private _monitorOptions;
    get monitorOptions(): MonitorVariablesDataQualityQueryMonitorOptionsOutputReference;
    putMonitorOptions(value: MonitorVariablesDataQualityQueryMonitorOptions): void;
    resetMonitorOptions(): void;
    get monitorOptionsInput(): MonitorVariablesDataQualityQueryMonitorOptions | undefined;
}
export declare class MonitorVariablesDataQualityQueryList extends cdktn.ComplexList {
    internalValue?: MonitorVariablesDataQualityQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorVariablesDataQualityQueryOutputReference;
}
export interface MonitorVariablesEventQueryCompute {
    /**
    * The aggregation methods for event platform queries. Valid values are `count`, `cardinality`, `median`, `pc75`, `pc90`, `pc95`, `pc98`, `pc99`, `sum`, `min`, `max`, `avg`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#aggregation Monitor#aggregation}
    */
    readonly aggregation: string;
    /**
    * A time interval in milliseconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#interval Monitor#interval}
    */
    readonly interval?: number;
    /**
    * The measurable attribute to compute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#metric Monitor#metric}
    */
    readonly metric?: string;
}
export declare function monitorVariablesEventQueryComputeToTerraform(struct?: MonitorVariablesEventQueryCompute | cdktn.IResolvable): any;
export declare function monitorVariablesEventQueryComputeToHclTerraform(struct?: MonitorVariablesEventQueryCompute | cdktn.IResolvable): any;
export declare class MonitorVariablesEventQueryComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorVariablesEventQueryCompute | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorVariablesEventQueryCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
}
export declare class MonitorVariablesEventQueryComputeList extends cdktn.ComplexList {
    internalValue?: MonitorVariablesEventQueryCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorVariablesEventQueryComputeOutputReference;
}
export interface MonitorVariablesEventQueryGroupBySort {
    /**
    * The aggregation methods for the event platform queries. Valid values are `count`, `cardinality`, `median`, `pc75`, `pc90`, `pc95`, `pc98`, `pc99`, `sum`, `min`, `max`, `avg`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#aggregation Monitor#aggregation}
    */
    readonly aggregation: string;
    /**
    * The metric used for sorting group by results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#metric Monitor#metric}
    */
    readonly metric?: string;
    /**
    * Direction of sort. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#order Monitor#order}
    */
    readonly order?: string;
}
export declare function monitorVariablesEventQueryGroupBySortToTerraform(struct?: MonitorVariablesEventQueryGroupBySortOutputReference | MonitorVariablesEventQueryGroupBySort): any;
export declare function monitorVariablesEventQueryGroupBySortToHclTerraform(struct?: MonitorVariablesEventQueryGroupBySortOutputReference | MonitorVariablesEventQueryGroupBySort): any;
export declare class MonitorVariablesEventQueryGroupBySortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorVariablesEventQueryGroupBySort | undefined;
    set internalValue(value: MonitorVariablesEventQueryGroupBySort | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export interface MonitorVariablesEventQueryGroupBy {
    /**
    * The event facet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#facet Monitor#facet}
    */
    readonly facet: string;
    /**
    * The number of groups to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#limit Monitor#limit}
    */
    readonly limit?: number;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#sort Monitor#sort}
    */
    readonly sort?: MonitorVariablesEventQueryGroupBySort;
}
export declare function monitorVariablesEventQueryGroupByToTerraform(struct?: MonitorVariablesEventQueryGroupBy | cdktn.IResolvable): any;
export declare function monitorVariablesEventQueryGroupByToHclTerraform(struct?: MonitorVariablesEventQueryGroupBy | cdktn.IResolvable): any;
export declare class MonitorVariablesEventQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorVariablesEventQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorVariablesEventQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sort;
    get sort(): MonitorVariablesEventQueryGroupBySortOutputReference;
    putSort(value: MonitorVariablesEventQueryGroupBySort): void;
    resetSort(): void;
    get sortInput(): MonitorVariablesEventQueryGroupBySort | undefined;
}
export declare class MonitorVariablesEventQueryGroupByList extends cdktn.ComplexList {
    internalValue?: MonitorVariablesEventQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorVariablesEventQueryGroupByOutputReference;
}
export interface MonitorVariablesEventQuerySearch {
    /**
    * The events search string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#query Monitor#query}
    */
    readonly query: string;
}
export declare function monitorVariablesEventQuerySearchToTerraform(struct?: MonitorVariablesEventQuerySearchOutputReference | MonitorVariablesEventQuerySearch): any;
export declare function monitorVariablesEventQuerySearchToHclTerraform(struct?: MonitorVariablesEventQuerySearchOutputReference | MonitorVariablesEventQuerySearch): any;
export declare class MonitorVariablesEventQuerySearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorVariablesEventQuerySearch | undefined;
    set internalValue(value: MonitorVariablesEventQuerySearch | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface MonitorVariablesEventQuery {
    /**
    * The data source for event platform-based queries. Valid values are `rum`, `ci_pipelines`, `ci_tests`, `audit`, `events`, `logs`, `spans`, `database_queries`, `network`, `network_path`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#data_source Monitor#data_source}
    */
    readonly dataSource: string;
    /**
    * An array of index names to query in the stream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#indexes Monitor#indexes}
    */
    readonly indexes?: string[];
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#name Monitor#name}
    */
    readonly name: string;
    /**
    * compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#compute Monitor#compute}
    */
    readonly compute: MonitorVariablesEventQueryCompute[] | cdktn.IResolvable;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#group_by Monitor#group_by}
    */
    readonly groupBy?: MonitorVariablesEventQueryGroupBy[] | cdktn.IResolvable;
    /**
    * search block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#search Monitor#search}
    */
    readonly search: MonitorVariablesEventQuerySearch;
}
export declare function monitorVariablesEventQueryToTerraform(struct?: MonitorVariablesEventQuery | cdktn.IResolvable): any;
export declare function monitorVariablesEventQueryToHclTerraform(struct?: MonitorVariablesEventQuery | cdktn.IResolvable): any;
export declare class MonitorVariablesEventQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorVariablesEventQuery | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorVariablesEventQuery | cdktn.IResolvable | undefined);
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _indexes?;
    get indexes(): string[];
    set indexes(value: string[]);
    resetIndexes(): void;
    get indexesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _compute;
    get compute(): MonitorVariablesEventQueryComputeList;
    putCompute(value: MonitorVariablesEventQueryCompute[] | cdktn.IResolvable): void;
    get computeInput(): cdktn.IResolvable | MonitorVariablesEventQueryCompute[] | undefined;
    private _groupBy;
    get groupBy(): MonitorVariablesEventQueryGroupByList;
    putGroupBy(value: MonitorVariablesEventQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | MonitorVariablesEventQueryGroupBy[] | undefined;
    private _search;
    get search(): MonitorVariablesEventQuerySearchOutputReference;
    putSearch(value: MonitorVariablesEventQuerySearch): void;
    get searchInput(): MonitorVariablesEventQuerySearch | undefined;
}
export declare class MonitorVariablesEventQueryList extends cdktn.ComplexList {
    internalValue?: MonitorVariablesEventQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorVariablesEventQueryOutputReference;
}
export interface MonitorVariables {
    /**
    * cloud_cost_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#cloud_cost_query Monitor#cloud_cost_query}
    */
    readonly cloudCostQuery?: MonitorVariablesCloudCostQuery[] | cdktn.IResolvable;
    /**
    * data_quality_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#data_quality_query Monitor#data_quality_query}
    */
    readonly dataQualityQuery?: MonitorVariablesDataQualityQuery[] | cdktn.IResolvable;
    /**
    * event_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#event_query Monitor#event_query}
    */
    readonly eventQuery?: MonitorVariablesEventQuery[] | cdktn.IResolvable;
}
export declare function monitorVariablesToTerraform(struct?: MonitorVariablesOutputReference | MonitorVariables): any;
export declare function monitorVariablesToHclTerraform(struct?: MonitorVariablesOutputReference | MonitorVariables): any;
export declare class MonitorVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorVariables | undefined;
    set internalValue(value: MonitorVariables | undefined);
    private _cloudCostQuery;
    get cloudCostQuery(): MonitorVariablesCloudCostQueryList;
    putCloudCostQuery(value: MonitorVariablesCloudCostQuery[] | cdktn.IResolvable): void;
    resetCloudCostQuery(): void;
    get cloudCostQueryInput(): cdktn.IResolvable | MonitorVariablesCloudCostQuery[] | undefined;
    private _dataQualityQuery;
    get dataQualityQuery(): MonitorVariablesDataQualityQueryList;
    putDataQualityQuery(value: MonitorVariablesDataQualityQuery[] | cdktn.IResolvable): void;
    resetDataQualityQuery(): void;
    get dataQualityQueryInput(): cdktn.IResolvable | MonitorVariablesDataQualityQuery[] | undefined;
    private _eventQuery;
    get eventQuery(): MonitorVariablesEventQueryList;
    putEventQuery(value: MonitorVariablesEventQuery[] | cdktn.IResolvable): void;
    resetEventQuery(): void;
    get eventQueryInput(): cdktn.IResolvable | MonitorVariablesEventQuery[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor datadog_monitor}
*/
export declare class Monitor extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_monitor";
    /**
    * Generates CDKTN code for importing a Monitor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Monitor to import
    * @param importFromId The id of the existing Monitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Monitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor datadog_monitor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MonitorConfig
    */
    constructor(scope: Construct, id: string, config: MonitorConfig);
    private _draftStatus?;
    get draftStatus(): string;
    set draftStatus(value: string);
    resetDraftStatus(): void;
    get draftStatusInput(): string | undefined;
    private _enableLogsSample?;
    get enableLogsSample(): boolean | cdktn.IResolvable;
    set enableLogsSample(value: boolean | cdktn.IResolvable);
    resetEnableLogsSample(): void;
    get enableLogsSampleInput(): boolean | cdktn.IResolvable | undefined;
    private _enableSamples?;
    get enableSamples(): boolean | cdktn.IResolvable;
    set enableSamples(value: boolean | cdktn.IResolvable);
    resetEnableSamples(): void;
    get enableSamplesInput(): boolean | cdktn.IResolvable | undefined;
    private _escalationMessage?;
    get escalationMessage(): string;
    set escalationMessage(value: string);
    resetEscalationMessage(): void;
    get escalationMessageInput(): string | undefined;
    private _evaluationDelay?;
    get evaluationDelay(): number;
    set evaluationDelay(value: number);
    resetEvaluationDelay(): void;
    get evaluationDelayInput(): number | undefined;
    private _forceDelete?;
    get forceDelete(): boolean | cdktn.IResolvable;
    set forceDelete(value: boolean | cdktn.IResolvable);
    resetForceDelete(): void;
    get forceDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _groupRetentionDuration?;
    get groupRetentionDuration(): string;
    set groupRetentionDuration(value: string);
    resetGroupRetentionDuration(): void;
    get groupRetentionDurationInput(): string | undefined;
    private _groupbySimpleMonitor?;
    get groupbySimpleMonitor(): boolean | cdktn.IResolvable;
    set groupbySimpleMonitor(value: boolean | cdktn.IResolvable);
    resetGroupbySimpleMonitor(): void;
    get groupbySimpleMonitorInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _includeTags?;
    get includeTags(): boolean | cdktn.IResolvable;
    set includeTags(value: boolean | cdktn.IResolvable);
    resetIncludeTags(): void;
    get includeTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _locked?;
    get locked(): boolean | cdktn.IResolvable;
    set locked(value: boolean | cdktn.IResolvable);
    resetLocked(): void;
    get lockedInput(): boolean | cdktn.IResolvable | undefined;
    private _message?;
    get message(): string;
    set message(value: string);
    get messageInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _newGroupDelay?;
    get newGroupDelay(): number;
    set newGroupDelay(value: number);
    resetNewGroupDelay(): void;
    get newGroupDelayInput(): number | undefined;
    private _newHostDelay?;
    get newHostDelay(): number;
    set newHostDelay(value: number);
    resetNewHostDelay(): void;
    get newHostDelayInput(): number | undefined;
    private _noDataTimeframe?;
    get noDataTimeframe(): number;
    set noDataTimeframe(value: number);
    resetNoDataTimeframe(): void;
    get noDataTimeframeInput(): number | undefined;
    private _notificationPresetName?;
    get notificationPresetName(): string;
    set notificationPresetName(value: string);
    resetNotificationPresetName(): void;
    get notificationPresetNameInput(): string | undefined;
    private _notifyAudit?;
    get notifyAudit(): boolean | cdktn.IResolvable;
    set notifyAudit(value: boolean | cdktn.IResolvable);
    resetNotifyAudit(): void;
    get notifyAuditInput(): boolean | cdktn.IResolvable | undefined;
    private _notifyBy?;
    get notifyBy(): string[];
    set notifyBy(value: string[]);
    resetNotifyBy(): void;
    get notifyByInput(): string[] | undefined;
    private _notifyNoData?;
    get notifyNoData(): boolean | cdktn.IResolvable;
    set notifyNoData(value: boolean | cdktn.IResolvable);
    resetNotifyNoData(): void;
    get notifyNoDataInput(): boolean | cdktn.IResolvable | undefined;
    private _onMissingData?;
    get onMissingData(): string;
    set onMissingData(value: string);
    resetOnMissingData(): void;
    get onMissingDataInput(): string | undefined;
    private _priority?;
    get priority(): string;
    set priority(value: string);
    resetPriority(): void;
    get priorityInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _renotifyInterval?;
    get renotifyInterval(): number;
    set renotifyInterval(value: number);
    resetRenotifyInterval(): void;
    get renotifyIntervalInput(): number | undefined;
    private _renotifyOccurrences?;
    get renotifyOccurrences(): number;
    set renotifyOccurrences(value: number);
    resetRenotifyOccurrences(): void;
    get renotifyOccurrencesInput(): number | undefined;
    private _renotifyStatuses?;
    get renotifyStatuses(): string[];
    set renotifyStatuses(value: string[]);
    resetRenotifyStatuses(): void;
    get renotifyStatusesInput(): string[] | undefined;
    private _requireFullWindow?;
    get requireFullWindow(): boolean | cdktn.IResolvable;
    set requireFullWindow(value: boolean | cdktn.IResolvable);
    resetRequireFullWindow(): void;
    get requireFullWindowInput(): boolean | cdktn.IResolvable | undefined;
    private _restrictedRoles?;
    get restrictedRoles(): string[];
    set restrictedRoles(value: string[]);
    resetRestrictedRoles(): void;
    get restrictedRolesInput(): string[] | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _timeoutH?;
    get timeoutH(): number;
    set timeoutH(value: number);
    resetTimeoutH(): void;
    get timeoutHInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _validate?;
    get validate(): boolean | cdktn.IResolvable;
    set validate(value: boolean | cdktn.IResolvable);
    resetValidate(): void;
    get validateInput(): boolean | cdktn.IResolvable | undefined;
    private _assets;
    get assets(): MonitorAssetsList;
    putAssets(value: MonitorAssets[] | cdktn.IResolvable): void;
    resetAssets(): void;
    get assetsInput(): cdktn.IResolvable | MonitorAssets[] | undefined;
    private _monitorThresholdWindows;
    get monitorThresholdWindows(): MonitorMonitorThresholdWindowsOutputReference;
    putMonitorThresholdWindows(value: MonitorMonitorThresholdWindows): void;
    resetMonitorThresholdWindows(): void;
    get monitorThresholdWindowsInput(): MonitorMonitorThresholdWindows | undefined;
    private _monitorThresholds;
    get monitorThresholds(): MonitorMonitorThresholdsOutputReference;
    putMonitorThresholds(value: MonitorMonitorThresholds): void;
    resetMonitorThresholds(): void;
    get monitorThresholdsInput(): MonitorMonitorThresholds | undefined;
    private _schedulingOptions;
    get schedulingOptions(): MonitorSchedulingOptionsOutputReference;
    putSchedulingOptions(value: MonitorSchedulingOptions): void;
    resetSchedulingOptions(): void;
    get schedulingOptionsInput(): MonitorSchedulingOptions | undefined;
    private _variables;
    get variables(): MonitorVariablesOutputReference;
    putVariables(value: MonitorVariables): void;
    resetVariables(): void;
    get variablesInput(): MonitorVariables | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
