/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SecurityNotificationRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Indicates whether the rule is enabled. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_notification_rule#enabled SecurityNotificationRule#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The name of the rule (must be unique).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_notification_rule#name SecurityNotificationRule#name}
    */
    readonly name: string;
    /**
    * The list of handle targets for the notifications. A target must be prefixed with an @. It can be an email address (@bob@email.com), or any installed integration. For example, a Slack recipient (@slack-ops), or a Teams recipient (@teams-ops).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_notification_rule#targets SecurityNotificationRule#targets}
    */
    readonly targets: string[];
    /**
    * Specifies the time period, in seconds, used to aggregate the notification. Defaults to `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_notification_rule#time_aggregation SecurityNotificationRule#time_aggregation}
    */
    readonly timeAggregation?: number;
    /**
    * selectors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_notification_rule#selectors SecurityNotificationRule#selectors}
    */
    readonly selectors?: SecurityNotificationRuleSelectors;
}
export interface SecurityNotificationRuleSelectors {
    /**
    * Comprises one or several key:value pairs for filtering security issues based on tags and attributes. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_notification_rule#query SecurityNotificationRule#query}
    */
    readonly query?: string;
    /**
    * Specifies security rule types for filtering signals and vulnerabilities that generate notifications.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_notification_rule#rule_types SecurityNotificationRule#rule_types}
    */
    readonly ruleTypes: string[];
    /**
    * The security rules severities to consider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_notification_rule#severities SecurityNotificationRule#severities}
    */
    readonly severities?: string[];
    /**
    * The type of security issues the rule applies to. Use `security_signals` for rules based on security signals and `security_findings` for those based on vulnerabilities.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_notification_rule#trigger_source SecurityNotificationRule#trigger_source}
    */
    readonly triggerSource: string;
}
export declare function securityNotificationRuleSelectorsToTerraform(struct?: SecurityNotificationRuleSelectors | cdktn.IResolvable): any;
export declare function securityNotificationRuleSelectorsToHclTerraform(struct?: SecurityNotificationRuleSelectors | cdktn.IResolvable): any;
export declare class SecurityNotificationRuleSelectorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SecurityNotificationRuleSelectors | cdktn.IResolvable | undefined;
    set internalValue(value: SecurityNotificationRuleSelectors | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
    private _ruleTypes?;
    get ruleTypes(): string[];
    set ruleTypes(value: string[]);
    get ruleTypesInput(): string[] | undefined;
    private _severities?;
    get severities(): string[];
    set severities(value: string[]);
    resetSeverities(): void;
    get severitiesInput(): string[] | undefined;
    private _triggerSource?;
    get triggerSource(): string;
    set triggerSource(value: string);
    get triggerSourceInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_notification_rule datadog_security_notification_rule}
*/
export declare class SecurityNotificationRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_security_notification_rule";
    /**
    * Generates CDKTN code for importing a SecurityNotificationRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecurityNotificationRule to import
    * @param importFromId The id of the existing SecurityNotificationRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_notification_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecurityNotificationRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_notification_rule datadog_security_notification_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecurityNotificationRuleConfig
    */
    constructor(scope: Construct, id: string, config: SecurityNotificationRuleConfig);
    get createdAt(): number;
    get createdByHandle(): string;
    get createdByName(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    get modifiedAt(): number;
    get modifiedByHandle(): string;
    get modifiedByName(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _targets?;
    get targets(): string[];
    set targets(value: string[]);
    get targetsInput(): string[] | undefined;
    private _timeAggregation?;
    get timeAggregation(): number;
    set timeAggregation(value: number);
    resetTimeAggregation(): void;
    get timeAggregationInput(): number | undefined;
    get version(): number;
    private _selectors;
    get selectors(): SecurityNotificationRuleSelectorsOutputReference;
    putSelectors(value: SecurityNotificationRuleSelectors): void;
    resetSelectors(): void;
    get selectorsInput(): cdktn.IResolvable | SecurityNotificationRuleSelectors | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
