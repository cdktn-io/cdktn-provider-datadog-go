/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SensitiveDataScannerRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Description of the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_rule#description SensitiveDataScannerRule#description}
    */
    readonly description?: string;
    /**
    * Attributes excluded from the scan. If namespaces is provided, it has to be a sub-path of the namespaces array.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_rule#excluded_namespaces SensitiveDataScannerRule#excluded_namespaces}
    */
    readonly excludedNamespaces?: string[];
    /**
    * Id of the scanning group the rule belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_rule#group_id SensitiveDataScannerRule#group_id}
    */
    readonly groupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_rule#id SensitiveDataScannerRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Whether or not the rule is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_rule#is_enabled SensitiveDataScannerRule#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_rule#name SensitiveDataScannerRule#name}
    */
    readonly name?: string;
    /**
    * Attributes included in the scan. If namespaces is empty or missing, all attributes except excluded_namespaces are scanned. If both are missing the whole event is scanned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_rule#namespaces SensitiveDataScannerRule#namespaces}
    */
    readonly namespaces?: string[];
    /**
    * Not included if there is a relationship to a standard pattern.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_rule#pattern SensitiveDataScannerRule#pattern}
    */
    readonly pattern?: string;
    /**
    * Priority level of the rule (optional). Used to order sensitive data discovered in the sds summary page. It must be between 1 and 5 (1 being the most important).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_rule#priority SensitiveDataScannerRule#priority}
    */
    readonly priority?: number;
    /**
    * Id of the standard pattern the rule refers to. If provided, then pattern must not be provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_rule#standard_pattern_id SensitiveDataScannerRule#standard_pattern_id}
    */
    readonly standardPatternId?: string;
    /**
    * List of tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_rule#tags SensitiveDataScannerRule#tags}
    */
    readonly tags?: string[];
    /**
    * included_keyword_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_rule#included_keyword_configuration SensitiveDataScannerRule#included_keyword_configuration}
    */
    readonly includedKeywordConfiguration?: SensitiveDataScannerRuleIncludedKeywordConfiguration;
    /**
    * text_replacement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_rule#text_replacement SensitiveDataScannerRule#text_replacement}
    */
    readonly textReplacement?: SensitiveDataScannerRuleTextReplacement;
}
export interface SensitiveDataScannerRuleIncludedKeywordConfiguration {
    /**
    * Number of characters before the match to find a keyword validating the match. It must be between 1 and 50 (inclusive).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_rule#character_count SensitiveDataScannerRule#character_count}
    */
    readonly characterCount: number;
    /**
    * Keyword list that is checked during scanning in order to validate a match. The number of keywords in the list must be lower than or equal to 30.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_rule#keywords SensitiveDataScannerRule#keywords}
    */
    readonly keywords: string[];
}
export declare function sensitiveDataScannerRuleIncludedKeywordConfigurationToTerraform(struct?: SensitiveDataScannerRuleIncludedKeywordConfigurationOutputReference | SensitiveDataScannerRuleIncludedKeywordConfiguration): any;
export declare function sensitiveDataScannerRuleIncludedKeywordConfigurationToHclTerraform(struct?: SensitiveDataScannerRuleIncludedKeywordConfigurationOutputReference | SensitiveDataScannerRuleIncludedKeywordConfiguration): any;
export declare class SensitiveDataScannerRuleIncludedKeywordConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SensitiveDataScannerRuleIncludedKeywordConfiguration | undefined;
    set internalValue(value: SensitiveDataScannerRuleIncludedKeywordConfiguration | undefined);
    private _characterCount?;
    get characterCount(): number;
    set characterCount(value: number);
    get characterCountInput(): number | undefined;
    private _keywords?;
    get keywords(): string[];
    set keywords(value: string[]);
    get keywordsInput(): string[] | undefined;
}
export interface SensitiveDataScannerRuleTextReplacement {
    /**
    * Required if type == 'partial_replacement_from_beginning' or 'partial_replacement_from_end'. It must be > 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_rule#number_of_chars SensitiveDataScannerRule#number_of_chars}
    */
    readonly numberOfChars?: number;
    /**
    * Required if type == 'replacement_string'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_rule#replacement_string SensitiveDataScannerRule#replacement_string}
    */
    readonly replacementString?: string;
    /**
    * Only valid when type == `replacement_string`. When enabled, matches can be unmasked in logs by users with ‘Data Scanner Unmask’ permission. As a security best practice, avoid masking for highly-sensitive, long-lived data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_rule#should_save_match SensitiveDataScannerRule#should_save_match}
    */
    readonly shouldSaveMatch?: boolean | cdktn.IResolvable;
    /**
    * Type of the replacement text. None means no replacement. hash means the data will be stubbed. replacement_string means that one can chose a text to replace the data. partial_replacement_from_beginning allows a user to partially replace the data from the beginning, and partial_replacement_from_end on the other hand, allows to replace data from the end. Valid values are `none`, `hash`, `replacement_string`, `partial_replacement_from_beginning`, `partial_replacement_from_end`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_rule#type SensitiveDataScannerRule#type}
    */
    readonly type: string;
}
export declare function sensitiveDataScannerRuleTextReplacementToTerraform(struct?: SensitiveDataScannerRuleTextReplacementOutputReference | SensitiveDataScannerRuleTextReplacement): any;
export declare function sensitiveDataScannerRuleTextReplacementToHclTerraform(struct?: SensitiveDataScannerRuleTextReplacementOutputReference | SensitiveDataScannerRuleTextReplacement): any;
export declare class SensitiveDataScannerRuleTextReplacementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SensitiveDataScannerRuleTextReplacement | undefined;
    set internalValue(value: SensitiveDataScannerRuleTextReplacement | undefined);
    private _numberOfChars?;
    get numberOfChars(): number;
    set numberOfChars(value: number);
    resetNumberOfChars(): void;
    get numberOfCharsInput(): number | undefined;
    private _replacementString?;
    get replacementString(): string;
    set replacementString(value: string);
    resetReplacementString(): void;
    get replacementStringInput(): string | undefined;
    private _shouldSaveMatch?;
    get shouldSaveMatch(): boolean | cdktn.IResolvable;
    set shouldSaveMatch(value: boolean | cdktn.IResolvable);
    resetShouldSaveMatch(): void;
    get shouldSaveMatchInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_rule datadog_sensitive_data_scanner_rule}
*/
export declare class SensitiveDataScannerRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_sensitive_data_scanner_rule";
    /**
    * Generates CDKTN code for importing a SensitiveDataScannerRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SensitiveDataScannerRule to import
    * @param importFromId The id of the existing SensitiveDataScannerRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SensitiveDataScannerRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_rule datadog_sensitive_data_scanner_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SensitiveDataScannerRuleConfig
    */
    constructor(scope: Construct, id: string, config: SensitiveDataScannerRuleConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _excludedNamespaces?;
    get excludedNamespaces(): string[];
    set excludedNamespaces(value: string[]);
    resetExcludedNamespaces(): void;
    get excludedNamespacesInput(): string[] | undefined;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    get groupIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namespaces?;
    get namespaces(): string[];
    set namespaces(value: string[]);
    resetNamespaces(): void;
    get namespacesInput(): string[] | undefined;
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    resetPattern(): void;
    get patternInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _standardPatternId?;
    get standardPatternId(): string;
    set standardPatternId(value: string);
    resetStandardPatternId(): void;
    get standardPatternIdInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _includedKeywordConfiguration;
    get includedKeywordConfiguration(): SensitiveDataScannerRuleIncludedKeywordConfigurationOutputReference;
    putIncludedKeywordConfiguration(value: SensitiveDataScannerRuleIncludedKeywordConfiguration): void;
    resetIncludedKeywordConfiguration(): void;
    get includedKeywordConfigurationInput(): SensitiveDataScannerRuleIncludedKeywordConfiguration | undefined;
    private _textReplacement;
    get textReplacement(): SensitiveDataScannerRuleTextReplacementOutputReference;
    putTextReplacement(value: SensitiveDataScannerRuleTextReplacement): void;
    resetTextReplacement(): void;
    get textReplacementInput(): SensitiveDataScannerRuleTextReplacement | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
