/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RumRetentionFilterConfig extends cdktn.TerraformMetaArguments {
    /**
    * RUM application ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_retention_filter#application_id RumRetentionFilter#application_id}
    */
    readonly applicationId: string;
    /**
    * Whether the retention filter is to be enabled. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_retention_filter#enabled RumRetentionFilter#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The type of RUM events to filter on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_retention_filter#event_type RumRetentionFilter#event_type}
    */
    readonly eventType: string;
    /**
    * The name of a RUM retention filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_retention_filter#name RumRetentionFilter#name}
    */
    readonly name: string;
    /**
    * The Query string for a RUM retention filter. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_retention_filter#query RumRetentionFilter#query}
    */
    readonly query?: string;
    /**
    * The sample rate for a RUM retention filter, between 0.1 and 100. Supports one decimal place (for example, 50.5).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_retention_filter#sample_rate RumRetentionFilter#sample_rate}
    */
    readonly sampleRate: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_retention_filter datadog_rum_retention_filter}
*/
export declare class RumRetentionFilter extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_rum_retention_filter";
    /**
    * Generates CDKTN code for importing a RumRetentionFilter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RumRetentionFilter to import
    * @param importFromId The id of the existing RumRetentionFilter that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_retention_filter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RumRetentionFilter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_retention_filter datadog_rum_retention_filter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RumRetentionFilterConfig
    */
    constructor(scope: Construct, id: string, config: RumRetentionFilterConfig);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _eventType?;
    get eventType(): string;
    set eventType(value: string);
    get eventTypeInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
    private _sampleRate?;
    get sampleRate(): number;
    set sampleRate(value: number);
    get sampleRateInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
