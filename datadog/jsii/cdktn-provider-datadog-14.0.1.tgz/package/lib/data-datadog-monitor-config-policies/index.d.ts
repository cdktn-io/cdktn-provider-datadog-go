/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogMonitorConfigPoliciesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/monitor_config_policies#id DataDatadogMonitorConfigPolicies#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataDatadogMonitorConfigPoliciesMonitorConfigPoliciesTagPolicy {
}
export declare function dataDatadogMonitorConfigPoliciesMonitorConfigPoliciesTagPolicyToTerraform(struct?: DataDatadogMonitorConfigPoliciesMonitorConfigPoliciesTagPolicy): any;
export declare function dataDatadogMonitorConfigPoliciesMonitorConfigPoliciesTagPolicyToHclTerraform(struct?: DataDatadogMonitorConfigPoliciesMonitorConfigPoliciesTagPolicy): any;
export declare class DataDatadogMonitorConfigPoliciesMonitorConfigPoliciesTagPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogMonitorConfigPoliciesMonitorConfigPoliciesTagPolicy | undefined;
    set internalValue(value: DataDatadogMonitorConfigPoliciesMonitorConfigPoliciesTagPolicy | undefined);
    get tagKey(): string;
    get tagKeyRequired(): cdktn.IResolvable;
    get validTagValues(): string[];
}
export declare class DataDatadogMonitorConfigPoliciesMonitorConfigPoliciesTagPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogMonitorConfigPoliciesMonitorConfigPoliciesTagPolicyOutputReference;
}
export interface DataDatadogMonitorConfigPoliciesMonitorConfigPolicies {
}
export declare function dataDatadogMonitorConfigPoliciesMonitorConfigPoliciesToTerraform(struct?: DataDatadogMonitorConfigPoliciesMonitorConfigPolicies): any;
export declare function dataDatadogMonitorConfigPoliciesMonitorConfigPoliciesToHclTerraform(struct?: DataDatadogMonitorConfigPoliciesMonitorConfigPolicies): any;
export declare class DataDatadogMonitorConfigPoliciesMonitorConfigPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogMonitorConfigPoliciesMonitorConfigPolicies | undefined;
    set internalValue(value: DataDatadogMonitorConfigPoliciesMonitorConfigPolicies | undefined);
    get id(): string;
    get policyType(): string;
    private _tagPolicy;
    get tagPolicy(): DataDatadogMonitorConfigPoliciesMonitorConfigPoliciesTagPolicyList;
}
export declare class DataDatadogMonitorConfigPoliciesMonitorConfigPoliciesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogMonitorConfigPoliciesMonitorConfigPoliciesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/monitor_config_policies datadog_monitor_config_policies}
*/
export declare class DataDatadogMonitorConfigPolicies extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_monitor_config_policies";
    /**
    * Generates CDKTN code for importing a DataDatadogMonitorConfigPolicies resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogMonitorConfigPolicies to import
    * @param importFromId The id of the existing DataDatadogMonitorConfigPolicies that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/monitor_config_policies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogMonitorConfigPolicies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/monitor_config_policies datadog_monitor_config_policies} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogMonitorConfigPoliciesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogMonitorConfigPoliciesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _monitorConfigPolicies;
    get monitorConfigPolicies(): DataDatadogMonitorConfigPoliciesMonitorConfigPoliciesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
