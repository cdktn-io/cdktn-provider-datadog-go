/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApmRetentionFilterOrderConfig extends cdktn.TerraformMetaArguments {
    /**
    * The filter IDs list. The order of filters IDs in this attribute defines the overall APM retention filters order.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/apm_retention_filter_order#filter_ids ApmRetentionFilterOrder#filter_ids}
    */
    readonly filterIds: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/apm_retention_filter_order datadog_apm_retention_filter_order}
*/
export declare class ApmRetentionFilterOrder extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_apm_retention_filter_order";
    /**
    * Generates CDKTN code for importing a ApmRetentionFilterOrder resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApmRetentionFilterOrder to import
    * @param importFromId The id of the existing ApmRetentionFilterOrder that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/apm_retention_filter_order#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApmRetentionFilterOrder to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/apm_retention_filter_order datadog_apm_retention_filter_order} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApmRetentionFilterOrderConfig
    */
    constructor(scope: Construct, id: string, config: ApmRetentionFilterOrderConfig);
    private _filterIds?;
    get filterIds(): string[];
    set filterIds(value: string[]);
    get filterIdsInput(): string[] | undefined;
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
