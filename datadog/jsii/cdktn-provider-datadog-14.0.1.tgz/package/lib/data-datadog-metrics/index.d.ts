/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogMetricsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The search query to use when listing metrics.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/metrics#query DataDatadogMetrics#query}
    */
    readonly query: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/metrics datadog_metrics}
*/
export declare class DataDatadogMetrics extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_metrics";
    /**
    * Generates CDKTN code for importing a DataDatadogMetrics resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogMetrics to import
    * @param importFromId The id of the existing DataDatadogMetrics that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/metrics#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogMetrics to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/metrics datadog_metrics} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogMetricsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogMetricsConfig);
    get id(): string;
    get metrics(): string[];
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
