/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CustomAllocationRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether the custom allocation rule is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#enabled CustomAllocationRule#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * List of cloud providers the rule applies to. Valid values include `aws`, `azure`, and `gcp`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#providernames CustomAllocationRule#providernames}
    */
    readonly providernames: string[];
    /**
    * The name of the custom allocation rule. This field is immutable - changing it will force replacement of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#rule_name CustomAllocationRule#rule_name}
    */
    readonly ruleName: string;
    /**
    * costs_to_allocate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#costs_to_allocate CustomAllocationRule#costs_to_allocate}
    */
    readonly costsToAllocate?: CustomAllocationRuleCostsToAllocate[] | cdktn.IResolvable;
    /**
    * strategy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#strategy CustomAllocationRule#strategy}
    */
    readonly strategy?: CustomAllocationRuleStrategy;
}
export interface CustomAllocationRuleCostsToAllocate {
    /**
    * The condition to match. Valid values are `=`, `!=`, `is`, `is not`, `like`, `in`, `not in`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#condition CustomAllocationRule#condition}
    */
    readonly condition?: string;
    /**
    * The tag key to filter on (e.g., `aws_product`, `team`, `environment`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#tag CustomAllocationRule#tag}
    */
    readonly tag?: string;
    /**
    * The single tag value to match. Use this field for conditions like `=`, `!=`, `is`, `is not`, `like`. Do not use with `in` or `not in` conditions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#value CustomAllocationRule#value}
    */
    readonly value?: string;
    /**
    * A list of tag values to match. Use this field for `in` or `not in` conditions only. Do not use with single-value conditions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#values CustomAllocationRule#values}
    */
    readonly values?: string[];
}
export declare function customAllocationRuleCostsToAllocateToTerraform(struct?: CustomAllocationRuleCostsToAllocate | cdktn.IResolvable): any;
export declare function customAllocationRuleCostsToAllocateToHclTerraform(struct?: CustomAllocationRuleCostsToAllocate | cdktn.IResolvable): any;
export declare class CustomAllocationRuleCostsToAllocateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomAllocationRuleCostsToAllocate | cdktn.IResolvable | undefined;
    set internalValue(value: CustomAllocationRuleCostsToAllocate | cdktn.IResolvable | undefined);
    private _condition?;
    get condition(): string;
    set condition(value: string);
    resetCondition(): void;
    get conditionInput(): string | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CustomAllocationRuleCostsToAllocateList extends cdktn.ComplexList {
    internalValue?: CustomAllocationRuleCostsToAllocate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomAllocationRuleCostsToAllocateOutputReference;
}
export interface CustomAllocationRuleStrategyAllocatedByAllocatedTags {
    /**
    * The tag key to allocate costs to (e.g., `team`, `environment`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#key CustomAllocationRule#key}
    */
    readonly key?: string;
    /**
    * The tag value to allocate costs to (e.g., `backend`, `production`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#value CustomAllocationRule#value}
    */
    readonly value?: string;
}
export declare function customAllocationRuleStrategyAllocatedByAllocatedTagsToTerraform(struct?: CustomAllocationRuleStrategyAllocatedByAllocatedTags | cdktn.IResolvable): any;
export declare function customAllocationRuleStrategyAllocatedByAllocatedTagsToHclTerraform(struct?: CustomAllocationRuleStrategyAllocatedByAllocatedTags | cdktn.IResolvable): any;
export declare class CustomAllocationRuleStrategyAllocatedByAllocatedTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomAllocationRuleStrategyAllocatedByAllocatedTags | cdktn.IResolvable | undefined;
    set internalValue(value: CustomAllocationRuleStrategyAllocatedByAllocatedTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class CustomAllocationRuleStrategyAllocatedByAllocatedTagsList extends cdktn.ComplexList {
    internalValue?: CustomAllocationRuleStrategyAllocatedByAllocatedTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomAllocationRuleStrategyAllocatedByAllocatedTagsOutputReference;
}
export interface CustomAllocationRuleStrategyAllocatedBy {
    /**
    * The percentage of costs to allocate to this target as a decimal (e.g., 0.33 for 33%). Used when `method` is `percent`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#percentage CustomAllocationRule#percentage}
    */
    readonly percentage?: number;
    /**
    * allocated_tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#allocated_tags CustomAllocationRule#allocated_tags}
    */
    readonly allocatedTags?: CustomAllocationRuleStrategyAllocatedByAllocatedTags[] | cdktn.IResolvable;
}
export declare function customAllocationRuleStrategyAllocatedByToTerraform(struct?: CustomAllocationRuleStrategyAllocatedBy | cdktn.IResolvable): any;
export declare function customAllocationRuleStrategyAllocatedByToHclTerraform(struct?: CustomAllocationRuleStrategyAllocatedBy | cdktn.IResolvable): any;
export declare class CustomAllocationRuleStrategyAllocatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomAllocationRuleStrategyAllocatedBy | cdktn.IResolvable | undefined;
    set internalValue(value: CustomAllocationRuleStrategyAllocatedBy | cdktn.IResolvable | undefined);
    private _percentage?;
    get percentage(): number;
    set percentage(value: number);
    resetPercentage(): void;
    get percentageInput(): number | undefined;
    private _allocatedTags;
    get allocatedTags(): CustomAllocationRuleStrategyAllocatedByAllocatedTagsList;
    putAllocatedTags(value: CustomAllocationRuleStrategyAllocatedByAllocatedTags[] | cdktn.IResolvable): void;
    resetAllocatedTags(): void;
    get allocatedTagsInput(): cdktn.IResolvable | CustomAllocationRuleStrategyAllocatedByAllocatedTags[] | undefined;
}
export declare class CustomAllocationRuleStrategyAllocatedByList extends cdktn.ComplexList {
    internalValue?: CustomAllocationRuleStrategyAllocatedBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomAllocationRuleStrategyAllocatedByOutputReference;
}
export interface CustomAllocationRuleStrategyAllocatedByFilters {
    /**
    * The condition to match. Valid values are `=`, `!=`, `is`, `is not`, `like`, `in`, `not in`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#condition CustomAllocationRule#condition}
    */
    readonly condition?: string;
    /**
    * The tag key to filter on for allocation targets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#tag CustomAllocationRule#tag}
    */
    readonly tag?: string;
    /**
    * The single tag value to match for allocation. Use with conditions like `=`, `!=`, `is`, `is not`, `like`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#value CustomAllocationRule#value}
    */
    readonly value?: string;
    /**
    * A list of tag values to match for allocation. Use with `in` or `not in` conditions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#values CustomAllocationRule#values}
    */
    readonly values?: string[];
}
export declare function customAllocationRuleStrategyAllocatedByFiltersToTerraform(struct?: CustomAllocationRuleStrategyAllocatedByFilters | cdktn.IResolvable): any;
export declare function customAllocationRuleStrategyAllocatedByFiltersToHclTerraform(struct?: CustomAllocationRuleStrategyAllocatedByFilters | cdktn.IResolvable): any;
export declare class CustomAllocationRuleStrategyAllocatedByFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomAllocationRuleStrategyAllocatedByFilters | cdktn.IResolvable | undefined;
    set internalValue(value: CustomAllocationRuleStrategyAllocatedByFilters | cdktn.IResolvable | undefined);
    private _condition?;
    get condition(): string;
    set condition(value: string);
    resetCondition(): void;
    get conditionInput(): string | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CustomAllocationRuleStrategyAllocatedByFiltersList extends cdktn.ComplexList {
    internalValue?: CustomAllocationRuleStrategyAllocatedByFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomAllocationRuleStrategyAllocatedByFiltersOutputReference;
}
export interface CustomAllocationRuleStrategyBasedOnCosts {
    /**
    * The condition to match. Valid values are `=`, `!=`, `is`, `is not`, `like`, `in`, `not in`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#condition CustomAllocationRule#condition}
    */
    readonly condition?: string;
    /**
    * The tag key to use as the basis for cost allocation calculations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#tag CustomAllocationRule#tag}
    */
    readonly tag?: string;
    /**
    * The single tag value to use for cost calculations. Use with conditions like `=`, `!=`, `is`, `is not`, `like`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#value CustomAllocationRule#value}
    */
    readonly value?: string;
    /**
    * A list of tag values to use for cost calculations. Use with `in` or `not in` conditions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#values CustomAllocationRule#values}
    */
    readonly values?: string[];
}
export declare function customAllocationRuleStrategyBasedOnCostsToTerraform(struct?: CustomAllocationRuleStrategyBasedOnCosts | cdktn.IResolvable): any;
export declare function customAllocationRuleStrategyBasedOnCostsToHclTerraform(struct?: CustomAllocationRuleStrategyBasedOnCosts | cdktn.IResolvable): any;
export declare class CustomAllocationRuleStrategyBasedOnCostsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomAllocationRuleStrategyBasedOnCosts | cdktn.IResolvable | undefined;
    set internalValue(value: CustomAllocationRuleStrategyBasedOnCosts | cdktn.IResolvable | undefined);
    private _condition?;
    get condition(): string;
    set condition(value: string);
    resetCondition(): void;
    get conditionInput(): string | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CustomAllocationRuleStrategyBasedOnCostsList extends cdktn.ComplexList {
    internalValue?: CustomAllocationRuleStrategyBasedOnCosts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomAllocationRuleStrategyBasedOnCostsOutputReference;
}
export interface CustomAllocationRuleStrategyBasedOnTimeseries {
}
export declare function customAllocationRuleStrategyBasedOnTimeseriesToTerraform(struct?: CustomAllocationRuleStrategyBasedOnTimeseries | cdktn.IResolvable): any;
export declare function customAllocationRuleStrategyBasedOnTimeseriesToHclTerraform(struct?: CustomAllocationRuleStrategyBasedOnTimeseries | cdktn.IResolvable): any;
export declare class CustomAllocationRuleStrategyBasedOnTimeseriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomAllocationRuleStrategyBasedOnTimeseries | cdktn.IResolvable | undefined;
    set internalValue(value: CustomAllocationRuleStrategyBasedOnTimeseries | cdktn.IResolvable | undefined);
}
export interface CustomAllocationRuleStrategyEvaluateGroupedByFilters {
    /**
    * The condition to match. Valid values are `=`, `!=`, `is`, `is not`, `like`, `in`, `not in`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#condition CustomAllocationRule#condition}
    */
    readonly condition?: string;
    /**
    * The tag key to filter on when grouping costs for evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#tag CustomAllocationRule#tag}
    */
    readonly tag?: string;
    /**
    * The single tag value to match when grouping. Use with conditions like `=`, `!=`, `is`, `is not`, `like`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#value CustomAllocationRule#value}
    */
    readonly value?: string;
    /**
    * A list of tag values to match when grouping. Use with `in` or `not in` conditions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#values CustomAllocationRule#values}
    */
    readonly values?: string[];
}
export declare function customAllocationRuleStrategyEvaluateGroupedByFiltersToTerraform(struct?: CustomAllocationRuleStrategyEvaluateGroupedByFilters | cdktn.IResolvable): any;
export declare function customAllocationRuleStrategyEvaluateGroupedByFiltersToHclTerraform(struct?: CustomAllocationRuleStrategyEvaluateGroupedByFilters | cdktn.IResolvable): any;
export declare class CustomAllocationRuleStrategyEvaluateGroupedByFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomAllocationRuleStrategyEvaluateGroupedByFilters | cdktn.IResolvable | undefined;
    set internalValue(value: CustomAllocationRuleStrategyEvaluateGroupedByFilters | cdktn.IResolvable | undefined);
    private _condition?;
    get condition(): string;
    set condition(value: string);
    resetCondition(): void;
    get conditionInput(): string | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CustomAllocationRuleStrategyEvaluateGroupedByFiltersList extends cdktn.ComplexList {
    internalValue?: CustomAllocationRuleStrategyEvaluateGroupedByFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomAllocationRuleStrategyEvaluateGroupedByFiltersOutputReference;
}
export interface CustomAllocationRuleStrategy {
    /**
    * List of tag keys used to allocate costs (e.g., `["team", "project"]`). Costs will be distributed across unique values of these tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#allocated_by_tag_keys CustomAllocationRule#allocated_by_tag_keys}
    */
    readonly allocatedByTagKeys?: string[];
    /**
    * List of tag keys used to group costs before allocation. Costs are grouped by these tag values before applying the allocation strategy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#evaluate_grouped_by_tag_keys CustomAllocationRule#evaluate_grouped_by_tag_keys}
    */
    readonly evaluateGroupedByTagKeys?: string[];
    /**
    * The granularity level for cost allocation. Valid values are `daily` or `monthly`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#granularity CustomAllocationRule#granularity}
    */
    readonly granularity?: string;
    /**
    * The allocation method. Valid values are `even`, `proportional`, `proportional_timeseries`, or `percent`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#method CustomAllocationRule#method}
    */
    readonly method?: string;
    /**
    * allocated_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#allocated_by CustomAllocationRule#allocated_by}
    */
    readonly allocatedBy?: CustomAllocationRuleStrategyAllocatedBy[] | cdktn.IResolvable;
    /**
    * allocated_by_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#allocated_by_filters CustomAllocationRule#allocated_by_filters}
    */
    readonly allocatedByFilters?: CustomAllocationRuleStrategyAllocatedByFilters[] | cdktn.IResolvable;
    /**
    * based_on_costs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#based_on_costs CustomAllocationRule#based_on_costs}
    */
    readonly basedOnCosts?: CustomAllocationRuleStrategyBasedOnCosts[] | cdktn.IResolvable;
    /**
    * based_on_timeseries block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#based_on_timeseries CustomAllocationRule#based_on_timeseries}
    */
    readonly basedOnTimeseries?: CustomAllocationRuleStrategyBasedOnTimeseries;
    /**
    * evaluate_grouped_by_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#evaluate_grouped_by_filters CustomAllocationRule#evaluate_grouped_by_filters}
    */
    readonly evaluateGroupedByFilters?: CustomAllocationRuleStrategyEvaluateGroupedByFilters[] | cdktn.IResolvable;
}
export declare function customAllocationRuleStrategyToTerraform(struct?: CustomAllocationRuleStrategy | cdktn.IResolvable): any;
export declare function customAllocationRuleStrategyToHclTerraform(struct?: CustomAllocationRuleStrategy | cdktn.IResolvable): any;
export declare class CustomAllocationRuleStrategyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomAllocationRuleStrategy | cdktn.IResolvable | undefined;
    set internalValue(value: CustomAllocationRuleStrategy | cdktn.IResolvable | undefined);
    private _allocatedByTagKeys?;
    get allocatedByTagKeys(): string[];
    set allocatedByTagKeys(value: string[]);
    resetAllocatedByTagKeys(): void;
    get allocatedByTagKeysInput(): string[] | undefined;
    private _evaluateGroupedByTagKeys?;
    get evaluateGroupedByTagKeys(): string[];
    set evaluateGroupedByTagKeys(value: string[]);
    resetEvaluateGroupedByTagKeys(): void;
    get evaluateGroupedByTagKeysInput(): string[] | undefined;
    private _granularity?;
    get granularity(): string;
    set granularity(value: string);
    resetGranularity(): void;
    get granularityInput(): string | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _allocatedBy;
    get allocatedBy(): CustomAllocationRuleStrategyAllocatedByList;
    putAllocatedBy(value: CustomAllocationRuleStrategyAllocatedBy[] | cdktn.IResolvable): void;
    resetAllocatedBy(): void;
    get allocatedByInput(): cdktn.IResolvable | CustomAllocationRuleStrategyAllocatedBy[] | undefined;
    private _allocatedByFilters;
    get allocatedByFilters(): CustomAllocationRuleStrategyAllocatedByFiltersList;
    putAllocatedByFilters(value: CustomAllocationRuleStrategyAllocatedByFilters[] | cdktn.IResolvable): void;
    resetAllocatedByFilters(): void;
    get allocatedByFiltersInput(): cdktn.IResolvable | CustomAllocationRuleStrategyAllocatedByFilters[] | undefined;
    private _basedOnCosts;
    get basedOnCosts(): CustomAllocationRuleStrategyBasedOnCostsList;
    putBasedOnCosts(value: CustomAllocationRuleStrategyBasedOnCosts[] | cdktn.IResolvable): void;
    resetBasedOnCosts(): void;
    get basedOnCostsInput(): cdktn.IResolvable | CustomAllocationRuleStrategyBasedOnCosts[] | undefined;
    private _basedOnTimeseries;
    get basedOnTimeseries(): CustomAllocationRuleStrategyBasedOnTimeseriesOutputReference;
    putBasedOnTimeseries(value: CustomAllocationRuleStrategyBasedOnTimeseries): void;
    get basedOnTimeseriesInput(): cdktn.IResolvable | CustomAllocationRuleStrategyBasedOnTimeseries | undefined;
    private _evaluateGroupedByFilters;
    get evaluateGroupedByFilters(): CustomAllocationRuleStrategyEvaluateGroupedByFiltersList;
    putEvaluateGroupedByFilters(value: CustomAllocationRuleStrategyEvaluateGroupedByFilters[] | cdktn.IResolvable): void;
    resetEvaluateGroupedByFilters(): void;
    get evaluateGroupedByFiltersInput(): cdktn.IResolvable | CustomAllocationRuleStrategyEvaluateGroupedByFilters[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule datadog_custom_allocation_rule}
*/
export declare class CustomAllocationRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_custom_allocation_rule";
    /**
    * Generates CDKTN code for importing a CustomAllocationRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CustomAllocationRule to import
    * @param importFromId The id of the existing CustomAllocationRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CustomAllocationRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rule datadog_custom_allocation_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CustomAllocationRuleConfig
    */
    constructor(scope: Construct, id: string, config: CustomAllocationRuleConfig);
    get created(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    get lastModifiedUserUuid(): string;
    get orderId(): number;
    private _providernames?;
    get providernames(): string[];
    set providernames(value: string[]);
    get providernamesInput(): string[] | undefined;
    get rejected(): cdktn.IResolvable;
    private _ruleName?;
    get ruleName(): string;
    set ruleName(value: string);
    get ruleNameInput(): string | undefined;
    get updated(): string;
    get version(): number;
    private _costsToAllocate;
    get costsToAllocate(): CustomAllocationRuleCostsToAllocateList;
    putCostsToAllocate(value: CustomAllocationRuleCostsToAllocate[] | cdktn.IResolvable): void;
    resetCostsToAllocate(): void;
    get costsToAllocateInput(): cdktn.IResolvable | CustomAllocationRuleCostsToAllocate[] | undefined;
    private _strategy;
    get strategy(): CustomAllocationRuleStrategyOutputReference;
    putStrategy(value: CustomAllocationRuleStrategy): void;
    resetStrategy(): void;
    get strategyInput(): cdktn.IResolvable | CustomAllocationRuleStrategy | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
