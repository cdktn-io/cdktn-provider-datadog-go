/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DowntimeScheduleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The timezone in which to display the downtime's start and end times in Datadog applications. This is not used as an offset for scheduling.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/downtime_schedule#display_timezone DowntimeSchedule#display_timezone}
    */
    readonly displayTimezone?: string;
    /**
    * A message to include with notifications for this downtime. Email notifications can be sent to specific users by using the same `@username` notation as events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/downtime_schedule#message DowntimeSchedule#message}
    */
    readonly message?: string;
    /**
    * If the first recovery notification during a downtime should be muted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/downtime_schedule#mute_first_recovery_notification DowntimeSchedule#mute_first_recovery_notification}
    */
    readonly muteFirstRecoveryNotification?: boolean | cdktn.IResolvable;
    /**
    * States that will trigger a monitor notification when the `notify_end_types` action occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/downtime_schedule#notify_end_states DowntimeSchedule#notify_end_states}
    */
    readonly notifyEndStates?: string[];
    /**
    * Actions that will trigger a monitor notification if the downtime is in the `notify_end_types` state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/downtime_schedule#notify_end_types DowntimeSchedule#notify_end_types}
    */
    readonly notifyEndTypes?: string[];
    /**
    * The scope to which the downtime applies. Must follow the [common search syntax](https://docs.datadoghq.com/logs/explorer/search_syntax/).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/downtime_schedule#scope DowntimeSchedule#scope}
    */
    readonly scope: string;
    /**
    * monitor_identifier block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/downtime_schedule#monitor_identifier DowntimeSchedule#monitor_identifier}
    */
    readonly monitorIdentifier?: DowntimeScheduleMonitorIdentifier;
    /**
    * one_time_schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/downtime_schedule#one_time_schedule DowntimeSchedule#one_time_schedule}
    */
    readonly oneTimeSchedule?: DowntimeScheduleOneTimeSchedule;
    /**
    * recurring_schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/downtime_schedule#recurring_schedule DowntimeSchedule#recurring_schedule}
    */
    readonly recurringSchedule?: DowntimeScheduleRecurringSchedule;
}
export interface DowntimeScheduleMonitorIdentifier {
    /**
    * ID of the monitor to prevent notifications.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/downtime_schedule#monitor_id DowntimeSchedule#monitor_id}
    */
    readonly monitorId?: number;
    /**
    * A list of monitor tags. For example, tags that are applied directly to monitors, not tags that are used in monitor queries (which are filtered by the scope parameter), to which the downtime applies. The resulting downtime applies to monitors that match **all** provided monitor tags. Setting `monitor_tags` to `[*]` configures the downtime to mute all monitors for the given scope.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/downtime_schedule#monitor_tags DowntimeSchedule#monitor_tags}
    */
    readonly monitorTags?: string[];
}
export declare function downtimeScheduleMonitorIdentifierToTerraform(struct?: DowntimeScheduleMonitorIdentifier | cdktn.IResolvable): any;
export declare function downtimeScheduleMonitorIdentifierToHclTerraform(struct?: DowntimeScheduleMonitorIdentifier | cdktn.IResolvable): any;
export declare class DowntimeScheduleMonitorIdentifierOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DowntimeScheduleMonitorIdentifier | cdktn.IResolvable | undefined;
    set internalValue(value: DowntimeScheduleMonitorIdentifier | cdktn.IResolvable | undefined);
    private _monitorId?;
    get monitorId(): number;
    set monitorId(value: number);
    resetMonitorId(): void;
    get monitorIdInput(): number | undefined;
    private _monitorTags?;
    get monitorTags(): string[];
    set monitorTags(value: string[]);
    resetMonitorTags(): void;
    get monitorTagsInput(): string[] | undefined;
}
export interface DowntimeScheduleOneTimeSchedule {
    /**
    * ISO-8601 Datetime to end the downtime. Must include a UTC offset of zero. If not provided, the downtime never ends.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/downtime_schedule#end DowntimeSchedule#end}
    */
    readonly end?: string;
    /**
    * ISO-8601 Datetime to start the downtime. Must include a UTC offset of zero. If not provided, the downtime starts the moment it is created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/downtime_schedule#start DowntimeSchedule#start}
    */
    readonly start?: string;
}
export declare function downtimeScheduleOneTimeScheduleToTerraform(struct?: DowntimeScheduleOneTimeSchedule | cdktn.IResolvable): any;
export declare function downtimeScheduleOneTimeScheduleToHclTerraform(struct?: DowntimeScheduleOneTimeSchedule | cdktn.IResolvable): any;
export declare class DowntimeScheduleOneTimeScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DowntimeScheduleOneTimeSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: DowntimeScheduleOneTimeSchedule | cdktn.IResolvable | undefined);
    private _end?;
    get end(): string;
    set end(value: string);
    resetEnd(): void;
    get endInput(): string | undefined;
    private _start?;
    get start(): string;
    set start(value: string);
    resetStart(): void;
    get startInput(): string | undefined;
}
export interface DowntimeScheduleRecurringScheduleRecurrence {
    /**
    * The length of the downtime. Must begin with an integer and end with one of 'm', 'h', d', or 'w'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/downtime_schedule#duration DowntimeSchedule#duration}
    */
    readonly duration: string;
    /**
    * The `RRULE` standard for defining recurring events. For example, to have a recurring event on the first day of each month, set the type to `rrule` and set the `FREQ` to `MONTHLY` and `BYMONTHDAY` to `1`. Most common `rrule` options from the [iCalendar Spec](https://tools.ietf.org/html/rfc5545) are supported.  **Note**: Attributes specifying the duration in `RRULE` are not supported (for example, `DTSTART`, `DTEND`, `DURATION`). More examples available in this [downtime guide](https://docs.datadoghq.com/monitors/guide/suppress-alert-with-downtimes/?tab=api).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/downtime_schedule#rrule DowntimeSchedule#rrule}
    */
    readonly rrule: string;
    /**
    * ISO-8601 Datetime to start the downtime. Must not include a UTC offset. If not provided, the downtime starts the moment it is created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/downtime_schedule#start DowntimeSchedule#start}
    */
    readonly start?: string;
}
export declare function downtimeScheduleRecurringScheduleRecurrenceToTerraform(struct?: DowntimeScheduleRecurringScheduleRecurrence | cdktn.IResolvable): any;
export declare function downtimeScheduleRecurringScheduleRecurrenceToHclTerraform(struct?: DowntimeScheduleRecurringScheduleRecurrence | cdktn.IResolvable): any;
export declare class DowntimeScheduleRecurringScheduleRecurrenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DowntimeScheduleRecurringScheduleRecurrence | cdktn.IResolvable | undefined;
    set internalValue(value: DowntimeScheduleRecurringScheduleRecurrence | cdktn.IResolvable | undefined);
    private _duration?;
    get duration(): string;
    set duration(value: string);
    get durationInput(): string | undefined;
    private _rrule?;
    get rrule(): string;
    set rrule(value: string);
    get rruleInput(): string | undefined;
    private _start?;
    get start(): string;
    set start(value: string);
    resetStart(): void;
    get startInput(): string | undefined;
}
export declare class DowntimeScheduleRecurringScheduleRecurrenceList extends cdktn.ComplexList {
    internalValue?: DowntimeScheduleRecurringScheduleRecurrence[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DowntimeScheduleRecurringScheduleRecurrenceOutputReference;
}
export interface DowntimeScheduleRecurringSchedule {
    /**
    * The timezone in which to schedule the downtime.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/downtime_schedule#timezone DowntimeSchedule#timezone}
    */
    readonly timezone?: string;
    /**
    * recurrence block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/downtime_schedule#recurrence DowntimeSchedule#recurrence}
    */
    readonly recurrence?: DowntimeScheduleRecurringScheduleRecurrence[] | cdktn.IResolvable;
}
export declare function downtimeScheduleRecurringScheduleToTerraform(struct?: DowntimeScheduleRecurringSchedule | cdktn.IResolvable): any;
export declare function downtimeScheduleRecurringScheduleToHclTerraform(struct?: DowntimeScheduleRecurringSchedule | cdktn.IResolvable): any;
export declare class DowntimeScheduleRecurringScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DowntimeScheduleRecurringSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: DowntimeScheduleRecurringSchedule | cdktn.IResolvable | undefined);
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    resetTimezone(): void;
    get timezoneInput(): string | undefined;
    private _recurrence;
    get recurrence(): DowntimeScheduleRecurringScheduleRecurrenceList;
    putRecurrence(value: DowntimeScheduleRecurringScheduleRecurrence[] | cdktn.IResolvable): void;
    resetRecurrence(): void;
    get recurrenceInput(): cdktn.IResolvable | DowntimeScheduleRecurringScheduleRecurrence[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/downtime_schedule datadog_downtime_schedule}
*/
export declare class DowntimeSchedule extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_downtime_schedule";
    /**
    * Generates CDKTN code for importing a DowntimeSchedule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DowntimeSchedule to import
    * @param importFromId The id of the existing DowntimeSchedule that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/downtime_schedule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DowntimeSchedule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/downtime_schedule datadog_downtime_schedule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DowntimeScheduleConfig
    */
    constructor(scope: Construct, id: string, config: DowntimeScheduleConfig);
    private _displayTimezone?;
    get displayTimezone(): string;
    set displayTimezone(value: string);
    resetDisplayTimezone(): void;
    get displayTimezoneInput(): string | undefined;
    get id(): string;
    private _message?;
    get message(): string;
    set message(value: string);
    resetMessage(): void;
    get messageInput(): string | undefined;
    private _muteFirstRecoveryNotification?;
    get muteFirstRecoveryNotification(): boolean | cdktn.IResolvable;
    set muteFirstRecoveryNotification(value: boolean | cdktn.IResolvable);
    resetMuteFirstRecoveryNotification(): void;
    get muteFirstRecoveryNotificationInput(): boolean | cdktn.IResolvable | undefined;
    private _notifyEndStates?;
    get notifyEndStates(): string[];
    set notifyEndStates(value: string[]);
    resetNotifyEndStates(): void;
    get notifyEndStatesInput(): string[] | undefined;
    private _notifyEndTypes?;
    get notifyEndTypes(): string[];
    set notifyEndTypes(value: string[]);
    resetNotifyEndTypes(): void;
    get notifyEndTypesInput(): string[] | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
    private _monitorIdentifier;
    get monitorIdentifier(): DowntimeScheduleMonitorIdentifierOutputReference;
    putMonitorIdentifier(value: DowntimeScheduleMonitorIdentifier): void;
    resetMonitorIdentifier(): void;
    get monitorIdentifierInput(): cdktn.IResolvable | DowntimeScheduleMonitorIdentifier | undefined;
    private _oneTimeSchedule;
    get oneTimeSchedule(): DowntimeScheduleOneTimeScheduleOutputReference;
    putOneTimeSchedule(value: DowntimeScheduleOneTimeSchedule): void;
    resetOneTimeSchedule(): void;
    get oneTimeScheduleInput(): cdktn.IResolvable | DowntimeScheduleOneTimeSchedule | undefined;
    private _recurringSchedule;
    get recurringSchedule(): DowntimeScheduleRecurringScheduleOutputReference;
    putRecurringSchedule(value: DowntimeScheduleRecurringSchedule): void;
    resetRecurringSchedule(): void;
    get recurringScheduleInput(): cdktn.IResolvable | DowntimeScheduleRecurringSchedule | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
