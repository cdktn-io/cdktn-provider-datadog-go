/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LogsCustomDestinationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether logs matching this custom destination should be forwarded or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#enabled LogsCustomDestination#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Whether tags from the forwarded logs should be forwarded or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#forward_tags LogsCustomDestination#forward_tags}
    */
    readonly forwardTags?: boolean | cdktn.IResolvable;
    /**
    * List of [tag keys](https://docs.datadoghq.com/getting_started/tagging/#define-tags) to be filtered.
    * 				An empty list represents no restriction is in place and either all or no tags will be
    * 				forwarded depending on `forward_tags_restriction_list_type` parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#forward_tags_restriction_list LogsCustomDestination#forward_tags_restriction_list}
    */
    readonly forwardTagsRestrictionList?: string[];
    /**
    * How the `forward_tags_restriction_list` parameter should be interpreted.
    * 				If `ALLOW_LIST`, then only tags whose keys on the forwarded logs match the ones on the restriction list
    * 				are forwarded.
    * 				`BLOCK_LIST` works the opposite way. It does not forward the tags matching the ones on the list. Valid values are `ALLOW_LIST`, `BLOCK_LIST`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#forward_tags_restriction_list_type LogsCustomDestination#forward_tags_restriction_list_type}
    */
    readonly forwardTagsRestrictionListType?: string;
    /**
    * The custom destination name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#name LogsCustomDestination#name}
    */
    readonly name: string;
    /**
    * The custom destination query filter. Logs matching this query are forwarded to the destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#query LogsCustomDestination#query}
    */
    readonly query?: string;
    /**
    * elasticsearch_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#elasticsearch_destination LogsCustomDestination#elasticsearch_destination}
    */
    readonly elasticsearchDestination?: LogsCustomDestinationElasticsearchDestination[] | cdktn.IResolvable;
    /**
    * http_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#http_destination LogsCustomDestination#http_destination}
    */
    readonly httpDestination?: LogsCustomDestinationHttpDestination[] | cdktn.IResolvable;
    /**
    * microsoft_sentinel_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#microsoft_sentinel_destination LogsCustomDestination#microsoft_sentinel_destination}
    */
    readonly microsoftSentinelDestination?: LogsCustomDestinationMicrosoftSentinelDestination[] | cdktn.IResolvable;
    /**
    * splunk_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#splunk_destination LogsCustomDestination#splunk_destination}
    */
    readonly splunkDestination?: LogsCustomDestinationSplunkDestination[] | cdktn.IResolvable;
}
export interface LogsCustomDestinationElasticsearchDestinationBasicAuth {
    /**
    * The password of the authentication. This field is not returned by the API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#password LogsCustomDestination#password}
    */
    readonly password: string;
    /**
    * The username of the authentication. This field is not returned by the API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#username LogsCustomDestination#username}
    */
    readonly username: string;
}
export declare function logsCustomDestinationElasticsearchDestinationBasicAuthToTerraform(struct?: LogsCustomDestinationElasticsearchDestinationBasicAuth | cdktn.IResolvable): any;
export declare function logsCustomDestinationElasticsearchDestinationBasicAuthToHclTerraform(struct?: LogsCustomDestinationElasticsearchDestinationBasicAuth | cdktn.IResolvable): any;
export declare class LogsCustomDestinationElasticsearchDestinationBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsCustomDestinationElasticsearchDestinationBasicAuth | cdktn.IResolvable | undefined;
    set internalValue(value: LogsCustomDestinationElasticsearchDestinationBasicAuth | cdktn.IResolvable | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
}
export declare class LogsCustomDestinationElasticsearchDestinationBasicAuthList extends cdktn.ComplexList {
    internalValue?: LogsCustomDestinationElasticsearchDestinationBasicAuth[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsCustomDestinationElasticsearchDestinationBasicAuthOutputReference;
}
export interface LogsCustomDestinationElasticsearchDestination {
    /**
    * The destination for which logs will be forwarded to. Must have HTTPS scheme. Forwarding back to Datadog is not allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#endpoint LogsCustomDestination#endpoint}
    */
    readonly endpoint: string;
    /**
    * Name of the Elasticsearch index (must follow [Elasticsearch's criteria](https://www.elastic.co/guide/en/elasticsearch/reference/8.11/indices-create-index.html#indices-create-api-path-params)).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#index_name LogsCustomDestination#index_name}
    */
    readonly indexName: string;
    /**
    * Date pattern with US locale and UTC timezone to be appended to the index name after adding '-'
    * 							(that is, '${index_name}-${indexPattern}').
    * 							You can customize the index rotation naming pattern by choosing one of these options:
    * 							- Hourly: 'yyyy-MM-dd-HH' (as an example, it would render: '2022-10-19-09')
    * 							- Daily: 'yyyy-MM-dd' (as an example, it would render: '2022-10-19')
    * 							- Weekly: 'yyyy-'W'ww' (as an example, it would render: '2022-W42')
    * 							- Monthly: 'yyyy-MM' (as an example, it would render: '2022-10')
    * 							If this field is missing or is blank, it means that the index name will always be the same
    * 							(that is, no rotation).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#index_rotation LogsCustomDestination#index_rotation}
    */
    readonly indexRotation?: string;
    /**
    * basic_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#basic_auth LogsCustomDestination#basic_auth}
    */
    readonly basicAuth?: LogsCustomDestinationElasticsearchDestinationBasicAuth[] | cdktn.IResolvable;
}
export declare function logsCustomDestinationElasticsearchDestinationToTerraform(struct?: LogsCustomDestinationElasticsearchDestination | cdktn.IResolvable): any;
export declare function logsCustomDestinationElasticsearchDestinationToHclTerraform(struct?: LogsCustomDestinationElasticsearchDestination | cdktn.IResolvable): any;
export declare class LogsCustomDestinationElasticsearchDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsCustomDestinationElasticsearchDestination | cdktn.IResolvable | undefined;
    set internalValue(value: LogsCustomDestinationElasticsearchDestination | cdktn.IResolvable | undefined);
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    get endpointInput(): string | undefined;
    private _indexName?;
    get indexName(): string;
    set indexName(value: string);
    get indexNameInput(): string | undefined;
    private _indexRotation?;
    get indexRotation(): string;
    set indexRotation(value: string);
    resetIndexRotation(): void;
    get indexRotationInput(): string | undefined;
    private _basicAuth;
    get basicAuth(): LogsCustomDestinationElasticsearchDestinationBasicAuthList;
    putBasicAuth(value: LogsCustomDestinationElasticsearchDestinationBasicAuth[] | cdktn.IResolvable): void;
    resetBasicAuth(): void;
    get basicAuthInput(): cdktn.IResolvable | LogsCustomDestinationElasticsearchDestinationBasicAuth[] | undefined;
}
export declare class LogsCustomDestinationElasticsearchDestinationList extends cdktn.ComplexList {
    internalValue?: LogsCustomDestinationElasticsearchDestination[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsCustomDestinationElasticsearchDestinationOutputReference;
}
export interface LogsCustomDestinationHttpDestinationBasicAuth {
    /**
    * The password of the authentication. This field is not returned by the API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#password LogsCustomDestination#password}
    */
    readonly password: string;
    /**
    * The username of the authentication. This field is not returned by the API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#username LogsCustomDestination#username}
    */
    readonly username: string;
}
export declare function logsCustomDestinationHttpDestinationBasicAuthToTerraform(struct?: LogsCustomDestinationHttpDestinationBasicAuth | cdktn.IResolvable): any;
export declare function logsCustomDestinationHttpDestinationBasicAuthToHclTerraform(struct?: LogsCustomDestinationHttpDestinationBasicAuth | cdktn.IResolvable): any;
export declare class LogsCustomDestinationHttpDestinationBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsCustomDestinationHttpDestinationBasicAuth | cdktn.IResolvable | undefined;
    set internalValue(value: LogsCustomDestinationHttpDestinationBasicAuth | cdktn.IResolvable | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
}
export declare class LogsCustomDestinationHttpDestinationBasicAuthList extends cdktn.ComplexList {
    internalValue?: LogsCustomDestinationHttpDestinationBasicAuth[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsCustomDestinationHttpDestinationBasicAuthOutputReference;
}
export interface LogsCustomDestinationHttpDestinationCustomHeaderAuth {
    /**
    * The header name of the authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#header_name LogsCustomDestination#header_name}
    */
    readonly headerName: string;
    /**
    * The header value of the authentication. This field is not returned by the API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#header_value LogsCustomDestination#header_value}
    */
    readonly headerValue: string;
}
export declare function logsCustomDestinationHttpDestinationCustomHeaderAuthToTerraform(struct?: LogsCustomDestinationHttpDestinationCustomHeaderAuth | cdktn.IResolvable): any;
export declare function logsCustomDestinationHttpDestinationCustomHeaderAuthToHclTerraform(struct?: LogsCustomDestinationHttpDestinationCustomHeaderAuth | cdktn.IResolvable): any;
export declare class LogsCustomDestinationHttpDestinationCustomHeaderAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsCustomDestinationHttpDestinationCustomHeaderAuth | cdktn.IResolvable | undefined;
    set internalValue(value: LogsCustomDestinationHttpDestinationCustomHeaderAuth | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    get headerValueInput(): string | undefined;
}
export declare class LogsCustomDestinationHttpDestinationCustomHeaderAuthList extends cdktn.ComplexList {
    internalValue?: LogsCustomDestinationHttpDestinationCustomHeaderAuth[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsCustomDestinationHttpDestinationCustomHeaderAuthOutputReference;
}
export interface LogsCustomDestinationHttpDestination {
    /**
    * The destination for which logs will be forwarded to. Must have HTTPS scheme. Forwarding back to Datadog is not allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#endpoint LogsCustomDestination#endpoint}
    */
    readonly endpoint: string;
    /**
    * basic_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#basic_auth LogsCustomDestination#basic_auth}
    */
    readonly basicAuth?: LogsCustomDestinationHttpDestinationBasicAuth[] | cdktn.IResolvable;
    /**
    * custom_header_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#custom_header_auth LogsCustomDestination#custom_header_auth}
    */
    readonly customHeaderAuth?: LogsCustomDestinationHttpDestinationCustomHeaderAuth[] | cdktn.IResolvable;
}
export declare function logsCustomDestinationHttpDestinationToTerraform(struct?: LogsCustomDestinationHttpDestination | cdktn.IResolvable): any;
export declare function logsCustomDestinationHttpDestinationToHclTerraform(struct?: LogsCustomDestinationHttpDestination | cdktn.IResolvable): any;
export declare class LogsCustomDestinationHttpDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsCustomDestinationHttpDestination | cdktn.IResolvable | undefined;
    set internalValue(value: LogsCustomDestinationHttpDestination | cdktn.IResolvable | undefined);
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    get endpointInput(): string | undefined;
    private _basicAuth;
    get basicAuth(): LogsCustomDestinationHttpDestinationBasicAuthList;
    putBasicAuth(value: LogsCustomDestinationHttpDestinationBasicAuth[] | cdktn.IResolvable): void;
    resetBasicAuth(): void;
    get basicAuthInput(): cdktn.IResolvable | LogsCustomDestinationHttpDestinationBasicAuth[] | undefined;
    private _customHeaderAuth;
    get customHeaderAuth(): LogsCustomDestinationHttpDestinationCustomHeaderAuthList;
    putCustomHeaderAuth(value: LogsCustomDestinationHttpDestinationCustomHeaderAuth[] | cdktn.IResolvable): void;
    resetCustomHeaderAuth(): void;
    get customHeaderAuthInput(): cdktn.IResolvable | LogsCustomDestinationHttpDestinationCustomHeaderAuth[] | undefined;
}
export declare class LogsCustomDestinationHttpDestinationList extends cdktn.ComplexList {
    internalValue?: LogsCustomDestinationHttpDestination[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsCustomDestinationHttpDestinationOutputReference;
}
export interface LogsCustomDestinationMicrosoftSentinelDestination {
    /**
    * Client ID from the Datadog Azure Integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#client_id LogsCustomDestination#client_id}
    */
    readonly clientId: string;
    /**
    * Azure Data Collection Endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#data_collection_endpoint LogsCustomDestination#data_collection_endpoint}
    */
    readonly dataCollectionEndpoint: string;
    /**
    *  Azure Data Collection Rule ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#data_collection_rule_id LogsCustomDestination#data_collection_rule_id}
    */
    readonly dataCollectionRuleId: string;
    /**
    * Azure stream name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#stream_name LogsCustomDestination#stream_name}
    */
    readonly streamName: string;
    /**
    * Tenant ID from the Datadog Azure Integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#tenant_id LogsCustomDestination#tenant_id}
    */
    readonly tenantId: string;
}
export declare function logsCustomDestinationMicrosoftSentinelDestinationToTerraform(struct?: LogsCustomDestinationMicrosoftSentinelDestination | cdktn.IResolvable): any;
export declare function logsCustomDestinationMicrosoftSentinelDestinationToHclTerraform(struct?: LogsCustomDestinationMicrosoftSentinelDestination | cdktn.IResolvable): any;
export declare class LogsCustomDestinationMicrosoftSentinelDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsCustomDestinationMicrosoftSentinelDestination | cdktn.IResolvable | undefined;
    set internalValue(value: LogsCustomDestinationMicrosoftSentinelDestination | cdktn.IResolvable | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    private _dataCollectionEndpoint?;
    get dataCollectionEndpoint(): string;
    set dataCollectionEndpoint(value: string);
    get dataCollectionEndpointInput(): string | undefined;
    private _dataCollectionRuleId?;
    get dataCollectionRuleId(): string;
    set dataCollectionRuleId(value: string);
    get dataCollectionRuleIdInput(): string | undefined;
    private _streamName?;
    get streamName(): string;
    set streamName(value: string);
    get streamNameInput(): string | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    get tenantIdInput(): string | undefined;
}
export declare class LogsCustomDestinationMicrosoftSentinelDestinationList extends cdktn.ComplexList {
    internalValue?: LogsCustomDestinationMicrosoftSentinelDestination[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsCustomDestinationMicrosoftSentinelDestinationOutputReference;
}
export interface LogsCustomDestinationSplunkDestination {
    /**
    * Access token of the Splunk HTTP Event Collector. This field is not returned by the API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#access_token LogsCustomDestination#access_token}
    */
    readonly accessToken: string;
    /**
    * The destination for which logs will be forwarded to. Must have HTTPS scheme. Forwarding back to Datadog is not allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#endpoint LogsCustomDestination#endpoint}
    */
    readonly endpoint: string;
}
export declare function logsCustomDestinationSplunkDestinationToTerraform(struct?: LogsCustomDestinationSplunkDestination | cdktn.IResolvable): any;
export declare function logsCustomDestinationSplunkDestinationToHclTerraform(struct?: LogsCustomDestinationSplunkDestination | cdktn.IResolvable): any;
export declare class LogsCustomDestinationSplunkDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsCustomDestinationSplunkDestination | cdktn.IResolvable | undefined;
    set internalValue(value: LogsCustomDestinationSplunkDestination | cdktn.IResolvable | undefined);
    private _accessToken?;
    get accessToken(): string;
    set accessToken(value: string);
    get accessTokenInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    get endpointInput(): string | undefined;
}
export declare class LogsCustomDestinationSplunkDestinationList extends cdktn.ComplexList {
    internalValue?: LogsCustomDestinationSplunkDestination[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsCustomDestinationSplunkDestinationOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination datadog_logs_custom_destination}
*/
export declare class LogsCustomDestination extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_logs_custom_destination";
    /**
    * Generates CDKTN code for importing a LogsCustomDestination resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LogsCustomDestination to import
    * @param importFromId The id of the existing LogsCustomDestination that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LogsCustomDestination to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_destination datadog_logs_custom_destination} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LogsCustomDestinationConfig
    */
    constructor(scope: Construct, id: string, config: LogsCustomDestinationConfig);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _forwardTags?;
    get forwardTags(): boolean | cdktn.IResolvable;
    set forwardTags(value: boolean | cdktn.IResolvable);
    resetForwardTags(): void;
    get forwardTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _forwardTagsRestrictionList?;
    get forwardTagsRestrictionList(): string[];
    set forwardTagsRestrictionList(value: string[]);
    resetForwardTagsRestrictionList(): void;
    get forwardTagsRestrictionListInput(): string[] | undefined;
    private _forwardTagsRestrictionListType?;
    get forwardTagsRestrictionListType(): string;
    set forwardTagsRestrictionListType(value: string);
    resetForwardTagsRestrictionListType(): void;
    get forwardTagsRestrictionListTypeInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
    private _elasticsearchDestination;
    get elasticsearchDestination(): LogsCustomDestinationElasticsearchDestinationList;
    putElasticsearchDestination(value: LogsCustomDestinationElasticsearchDestination[] | cdktn.IResolvable): void;
    resetElasticsearchDestination(): void;
    get elasticsearchDestinationInput(): cdktn.IResolvable | LogsCustomDestinationElasticsearchDestination[] | undefined;
    private _httpDestination;
    get httpDestination(): LogsCustomDestinationHttpDestinationList;
    putHttpDestination(value: LogsCustomDestinationHttpDestination[] | cdktn.IResolvable): void;
    resetHttpDestination(): void;
    get httpDestinationInput(): cdktn.IResolvable | LogsCustomDestinationHttpDestination[] | undefined;
    private _microsoftSentinelDestination;
    get microsoftSentinelDestination(): LogsCustomDestinationMicrosoftSentinelDestinationList;
    putMicrosoftSentinelDestination(value: LogsCustomDestinationMicrosoftSentinelDestination[] | cdktn.IResolvable): void;
    resetMicrosoftSentinelDestination(): void;
    get microsoftSentinelDestinationInput(): cdktn.IResolvable | LogsCustomDestinationMicrosoftSentinelDestination[] | undefined;
    private _splunkDestination;
    get splunkDestination(): LogsCustomDestinationSplunkDestinationList;
    putSplunkDestination(value: LogsCustomDestinationSplunkDestination[] | cdktn.IResolvable): void;
    resetSplunkDestination(): void;
    get splunkDestinationInput(): cdktn.IResolvable | LogsCustomDestinationSplunkDestination[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
