/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogLogsIndexesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/logs_indexes#id DataDatadogLogsIndexes#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataDatadogLogsIndexesLogsIndexesDailyLimitReset {
}
export declare function dataDatadogLogsIndexesLogsIndexesDailyLimitResetToTerraform(struct?: DataDatadogLogsIndexesLogsIndexesDailyLimitReset): any;
export declare function dataDatadogLogsIndexesLogsIndexesDailyLimitResetToHclTerraform(struct?: DataDatadogLogsIndexesLogsIndexesDailyLimitReset): any;
export declare class DataDatadogLogsIndexesLogsIndexesDailyLimitResetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogLogsIndexesLogsIndexesDailyLimitReset | undefined;
    set internalValue(value: DataDatadogLogsIndexesLogsIndexesDailyLimitReset | undefined);
    get resetTime(): string;
    get resetUtcOffset(): string;
}
export declare class DataDatadogLogsIndexesLogsIndexesDailyLimitResetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogLogsIndexesLogsIndexesDailyLimitResetOutputReference;
}
export interface DataDatadogLogsIndexesLogsIndexesExclusionFilterFilter {
}
export declare function dataDatadogLogsIndexesLogsIndexesExclusionFilterFilterToTerraform(struct?: DataDatadogLogsIndexesLogsIndexesExclusionFilterFilter): any;
export declare function dataDatadogLogsIndexesLogsIndexesExclusionFilterFilterToHclTerraform(struct?: DataDatadogLogsIndexesLogsIndexesExclusionFilterFilter): any;
export declare class DataDatadogLogsIndexesLogsIndexesExclusionFilterFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogLogsIndexesLogsIndexesExclusionFilterFilter | undefined;
    set internalValue(value: DataDatadogLogsIndexesLogsIndexesExclusionFilterFilter | undefined);
    get query(): string;
    get sampleRate(): number;
}
export declare class DataDatadogLogsIndexesLogsIndexesExclusionFilterFilterList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogLogsIndexesLogsIndexesExclusionFilterFilterOutputReference;
}
export interface DataDatadogLogsIndexesLogsIndexesExclusionFilter {
}
export declare function dataDatadogLogsIndexesLogsIndexesExclusionFilterToTerraform(struct?: DataDatadogLogsIndexesLogsIndexesExclusionFilter): any;
export declare function dataDatadogLogsIndexesLogsIndexesExclusionFilterToHclTerraform(struct?: DataDatadogLogsIndexesLogsIndexesExclusionFilter): any;
export declare class DataDatadogLogsIndexesLogsIndexesExclusionFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogLogsIndexesLogsIndexesExclusionFilter | undefined;
    set internalValue(value: DataDatadogLogsIndexesLogsIndexesExclusionFilter | undefined);
    private _filter;
    get filter(): DataDatadogLogsIndexesLogsIndexesExclusionFilterFilterList;
    get isEnabled(): cdktn.IResolvable;
    get name(): string;
}
export declare class DataDatadogLogsIndexesLogsIndexesExclusionFilterList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogLogsIndexesLogsIndexesExclusionFilterOutputReference;
}
export interface DataDatadogLogsIndexesLogsIndexesFilter {
}
export declare function dataDatadogLogsIndexesLogsIndexesFilterToTerraform(struct?: DataDatadogLogsIndexesLogsIndexesFilter): any;
export declare function dataDatadogLogsIndexesLogsIndexesFilterToHclTerraform(struct?: DataDatadogLogsIndexesLogsIndexesFilter): any;
export declare class DataDatadogLogsIndexesLogsIndexesFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogLogsIndexesLogsIndexesFilter | undefined;
    set internalValue(value: DataDatadogLogsIndexesLogsIndexesFilter | undefined);
    get query(): string;
}
export declare class DataDatadogLogsIndexesLogsIndexesFilterList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogLogsIndexesLogsIndexesFilterOutputReference;
}
export interface DataDatadogLogsIndexesLogsIndexes {
}
export declare function dataDatadogLogsIndexesLogsIndexesToTerraform(struct?: DataDatadogLogsIndexesLogsIndexes): any;
export declare function dataDatadogLogsIndexesLogsIndexesToHclTerraform(struct?: DataDatadogLogsIndexesLogsIndexes): any;
export declare class DataDatadogLogsIndexesLogsIndexesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogLogsIndexesLogsIndexes | undefined;
    set internalValue(value: DataDatadogLogsIndexesLogsIndexes | undefined);
    get dailyLimit(): number;
    private _dailyLimitReset;
    get dailyLimitReset(): DataDatadogLogsIndexesLogsIndexesDailyLimitResetList;
    get dailyLimitWarningThresholdPercentage(): number;
    private _exclusionFilter;
    get exclusionFilter(): DataDatadogLogsIndexesLogsIndexesExclusionFilterList;
    private _filter;
    get filter(): DataDatadogLogsIndexesLogsIndexesFilterList;
    get flexRetentionDays(): number;
    get name(): string;
    get retentionDays(): number;
    get tags(): string[];
}
export declare class DataDatadogLogsIndexesLogsIndexesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogLogsIndexesLogsIndexesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/logs_indexes datadog_logs_indexes}
*/
export declare class DataDatadogLogsIndexes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_logs_indexes";
    /**
    * Generates CDKTN code for importing a DataDatadogLogsIndexes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogLogsIndexes to import
    * @param importFromId The id of the existing DataDatadogLogsIndexes that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/logs_indexes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogLogsIndexes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/logs_indexes datadog_logs_indexes} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogLogsIndexesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogLogsIndexesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logsIndexes;
    get logsIndexes(): DataDatadogLogsIndexesLogsIndexesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
