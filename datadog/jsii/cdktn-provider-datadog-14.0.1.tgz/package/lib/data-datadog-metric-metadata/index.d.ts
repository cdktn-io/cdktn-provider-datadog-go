/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogMetricMetadataConfig extends cdktn.TerraformMetaArguments {
    /**
    * The metric for which to fetch metadata.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/metric_metadata#metric_name DataDatadogMetricMetadata#metric_name}
    */
    readonly metricName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/metric_metadata datadog_metric_metadata}
*/
export declare class DataDatadogMetricMetadata extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_metric_metadata";
    /**
    * Generates CDKTN code for importing a DataDatadogMetricMetadata resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogMetricMetadata to import
    * @param importFromId The id of the existing DataDatadogMetricMetadata that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/metric_metadata#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogMetricMetadata to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/metric_metadata datadog_metric_metadata} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogMetricMetadataConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogMetricMetadataConfig);
    get description(): string;
    get id(): string;
    get integration(): string;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    get metricNameInput(): string | undefined;
    get perUnit(): string;
    get shortName(): string;
    get statsdInterval(): number;
    get type(): string;
    get unit(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
