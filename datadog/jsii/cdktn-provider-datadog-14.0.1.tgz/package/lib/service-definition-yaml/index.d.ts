/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ServiceDefinitionYamlConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_definition_yaml#id ServiceDefinitionYaml#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The YAML/JSON formatted definition of the service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_definition_yaml#service_definition ServiceDefinitionYaml#service_definition}
    */
    readonly serviceDefinition: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_definition_yaml datadog_service_definition_yaml}
*/
export declare class ServiceDefinitionYaml extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_service_definition_yaml";
    /**
    * Generates CDKTN code for importing a ServiceDefinitionYaml resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServiceDefinitionYaml to import
    * @param importFromId The id of the existing ServiceDefinitionYaml that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_definition_yaml#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServiceDefinitionYaml to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_definition_yaml datadog_service_definition_yaml} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServiceDefinitionYamlConfig
    */
    constructor(scope: Construct, id: string, config: ServiceDefinitionYamlConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _serviceDefinition?;
    get serviceDefinition(): string;
    set serviceDefinition(value: string);
    get serviceDefinitionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
