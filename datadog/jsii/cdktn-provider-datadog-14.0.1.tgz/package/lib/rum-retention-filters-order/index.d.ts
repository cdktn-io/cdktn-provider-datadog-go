/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RumRetentionFiltersOrderConfig extends cdktn.TerraformMetaArguments {
    /**
    * RUM application ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_retention_filters_order#application_id RumRetentionFiltersOrder#application_id}
    */
    readonly applicationId: string;
    /**
    * RUM retention filter ID list. The order of IDs in this attribute defines the order of RUM retention filters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_retention_filters_order#retention_filter_ids RumRetentionFiltersOrder#retention_filter_ids}
    */
    readonly retentionFilterIds: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_retention_filters_order datadog_rum_retention_filters_order}
*/
export declare class RumRetentionFiltersOrder extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_rum_retention_filters_order";
    /**
    * Generates CDKTN code for importing a RumRetentionFiltersOrder resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RumRetentionFiltersOrder to import
    * @param importFromId The id of the existing RumRetentionFiltersOrder that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_retention_filters_order#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RumRetentionFiltersOrder to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_retention_filters_order datadog_rum_retention_filters_order} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RumRetentionFiltersOrderConfig
    */
    constructor(scope: Construct, id: string, config: RumRetentionFiltersOrderConfig);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    get id(): string;
    private _retentionFilterIds?;
    get retentionFilterIds(): string[];
    set retentionFilterIds(value: string[]);
    get retentionFilterIdsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
