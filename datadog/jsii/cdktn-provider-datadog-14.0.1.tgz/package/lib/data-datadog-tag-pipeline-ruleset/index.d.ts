/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogTagPipelineRulesetConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the ruleset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/tag_pipeline_ruleset#id DataDatadogTagPipelineRuleset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/tag_pipeline_ruleset#rules DataDatadogTagPipelineRuleset#rules}
    */
    readonly rules?: DataDatadogTagPipelineRulesetRules[] | cdktn.IResolvable;
}
export interface DataDatadogTagPipelineRulesetRulesMapping {
}
export declare function dataDatadogTagPipelineRulesetRulesMappingToTerraform(struct?: DataDatadogTagPipelineRulesetRulesMapping | cdktn.IResolvable): any;
export declare function dataDatadogTagPipelineRulesetRulesMappingToHclTerraform(struct?: DataDatadogTagPipelineRulesetRulesMapping | cdktn.IResolvable): any;
export declare class DataDatadogTagPipelineRulesetRulesMappingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogTagPipelineRulesetRulesMapping | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogTagPipelineRulesetRulesMapping | cdktn.IResolvable | undefined);
    get destinationKey(): string;
    get ifNotExists(): cdktn.IResolvable;
    get ifTagExists(): string;
    get sourceKeys(): string[];
}
export interface DataDatadogTagPipelineRulesetRulesQueryAddition {
}
export declare function dataDatadogTagPipelineRulesetRulesQueryAdditionToTerraform(struct?: DataDatadogTagPipelineRulesetRulesQueryAddition | cdktn.IResolvable): any;
export declare function dataDatadogTagPipelineRulesetRulesQueryAdditionToHclTerraform(struct?: DataDatadogTagPipelineRulesetRulesQueryAddition | cdktn.IResolvable): any;
export declare class DataDatadogTagPipelineRulesetRulesQueryAdditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogTagPipelineRulesetRulesQueryAddition | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogTagPipelineRulesetRulesQueryAddition | cdktn.IResolvable | undefined);
    get key(): string;
    get value(): string;
}
export interface DataDatadogTagPipelineRulesetRulesQuery {
}
export declare function dataDatadogTagPipelineRulesetRulesQueryToTerraform(struct?: DataDatadogTagPipelineRulesetRulesQuery | cdktn.IResolvable): any;
export declare function dataDatadogTagPipelineRulesetRulesQueryToHclTerraform(struct?: DataDatadogTagPipelineRulesetRulesQuery | cdktn.IResolvable): any;
export declare class DataDatadogTagPipelineRulesetRulesQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogTagPipelineRulesetRulesQuery | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogTagPipelineRulesetRulesQuery | cdktn.IResolvable | undefined);
    get caseInsensitivity(): cdktn.IResolvable;
    get ifNotExists(): cdktn.IResolvable;
    get ifTagExists(): string;
    get query(): string;
    private _addition;
    get addition(): DataDatadogTagPipelineRulesetRulesQueryAdditionOutputReference;
}
export interface DataDatadogTagPipelineRulesetRulesReferenceTableFieldPairs {
}
export declare function dataDatadogTagPipelineRulesetRulesReferenceTableFieldPairsToTerraform(struct?: DataDatadogTagPipelineRulesetRulesReferenceTableFieldPairs | cdktn.IResolvable): any;
export declare function dataDatadogTagPipelineRulesetRulesReferenceTableFieldPairsToHclTerraform(struct?: DataDatadogTagPipelineRulesetRulesReferenceTableFieldPairs | cdktn.IResolvable): any;
export declare class DataDatadogTagPipelineRulesetRulesReferenceTableFieldPairsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogTagPipelineRulesetRulesReferenceTableFieldPairs | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogTagPipelineRulesetRulesReferenceTableFieldPairs | cdktn.IResolvable | undefined);
    get inputColumn(): string;
    get outputKey(): string;
}
export declare class DataDatadogTagPipelineRulesetRulesReferenceTableFieldPairsList extends cdktn.ComplexList {
    internalValue?: DataDatadogTagPipelineRulesetRulesReferenceTableFieldPairs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogTagPipelineRulesetRulesReferenceTableFieldPairsOutputReference;
}
export interface DataDatadogTagPipelineRulesetRulesReferenceTable {
    /**
    * field_pairs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/tag_pipeline_ruleset#field_pairs DataDatadogTagPipelineRuleset#field_pairs}
    */
    readonly fieldPairs?: DataDatadogTagPipelineRulesetRulesReferenceTableFieldPairs[] | cdktn.IResolvable;
}
export declare function dataDatadogTagPipelineRulesetRulesReferenceTableToTerraform(struct?: DataDatadogTagPipelineRulesetRulesReferenceTable | cdktn.IResolvable): any;
export declare function dataDatadogTagPipelineRulesetRulesReferenceTableToHclTerraform(struct?: DataDatadogTagPipelineRulesetRulesReferenceTable | cdktn.IResolvable): any;
export declare class DataDatadogTagPipelineRulesetRulesReferenceTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogTagPipelineRulesetRulesReferenceTable | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogTagPipelineRulesetRulesReferenceTable | cdktn.IResolvable | undefined);
    get caseInsensitivity(): cdktn.IResolvable;
    get ifNotExists(): cdktn.IResolvable;
    get ifTagExists(): string;
    get sourceKeys(): string[];
    get tableName(): string;
    private _fieldPairs;
    get fieldPairs(): DataDatadogTagPipelineRulesetRulesReferenceTableFieldPairsList;
    putFieldPairs(value: DataDatadogTagPipelineRulesetRulesReferenceTableFieldPairs[] | cdktn.IResolvable): void;
    resetFieldPairs(): void;
    get fieldPairsInput(): cdktn.IResolvable | DataDatadogTagPipelineRulesetRulesReferenceTableFieldPairs[] | undefined;
}
export interface DataDatadogTagPipelineRulesetRules {
    /**
    * reference_table block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/tag_pipeline_ruleset#reference_table DataDatadogTagPipelineRuleset#reference_table}
    */
    readonly referenceTable?: DataDatadogTagPipelineRulesetRulesReferenceTable;
}
export declare function dataDatadogTagPipelineRulesetRulesToTerraform(struct?: DataDatadogTagPipelineRulesetRules | cdktn.IResolvable): any;
export declare function dataDatadogTagPipelineRulesetRulesToHclTerraform(struct?: DataDatadogTagPipelineRulesetRules | cdktn.IResolvable): any;
export declare class DataDatadogTagPipelineRulesetRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogTagPipelineRulesetRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogTagPipelineRulesetRules | cdktn.IResolvable | undefined);
    get enabled(): cdktn.IResolvable;
    private _metadata;
    get metadata(): cdktn.StringMap;
    get name(): string;
    private _mapping;
    get mapping(): DataDatadogTagPipelineRulesetRulesMappingOutputReference;
    private _query;
    get query(): DataDatadogTagPipelineRulesetRulesQueryOutputReference;
    private _referenceTable;
    get referenceTable(): DataDatadogTagPipelineRulesetRulesReferenceTableOutputReference;
    putReferenceTable(value: DataDatadogTagPipelineRulesetRulesReferenceTable): void;
    resetReferenceTable(): void;
    get referenceTableInput(): cdktn.IResolvable | DataDatadogTagPipelineRulesetRulesReferenceTable | undefined;
}
export declare class DataDatadogTagPipelineRulesetRulesList extends cdktn.ComplexList {
    internalValue?: DataDatadogTagPipelineRulesetRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogTagPipelineRulesetRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/tag_pipeline_ruleset datadog_tag_pipeline_ruleset}
*/
export declare class DataDatadogTagPipelineRuleset extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_tag_pipeline_ruleset";
    /**
    * Generates CDKTN code for importing a DataDatadogTagPipelineRuleset resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogTagPipelineRuleset to import
    * @param importFromId The id of the existing DataDatadogTagPipelineRuleset that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/tag_pipeline_ruleset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogTagPipelineRuleset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/tag_pipeline_ruleset datadog_tag_pipeline_ruleset} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogTagPipelineRulesetConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogTagPipelineRulesetConfig);
    get enabled(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get name(): string;
    get position(): number;
    get version(): number;
    private _rules;
    get rules(): DataDatadogTagPipelineRulesetRulesList;
    putRules(value: DataDatadogTagPipelineRulesetRules[] | cdktn.IResolvable): void;
    resetRules(): void;
    get rulesInput(): cdktn.IResolvable | DataDatadogTagPipelineRulesetRules[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
