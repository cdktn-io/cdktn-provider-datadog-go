/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IntegrationSlackChannelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Slack account name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_slack_channel#account_name IntegrationSlackChannel#account_name}
    */
    readonly accountName: string;
    /**
    * Slack channel name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_slack_channel#channel_name IntegrationSlackChannel#channel_name}
    */
    readonly channelName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_slack_channel#id IntegrationSlackChannel#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * display block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_slack_channel#display IntegrationSlackChannel#display}
    */
    readonly display: IntegrationSlackChannelDisplay;
}
export interface IntegrationSlackChannelDisplay {
    /**
    * Show the main body of the alert event. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_slack_channel#message IntegrationSlackChannel#message}
    */
    readonly message?: boolean | cdktn.IResolvable;
    /**
    * Show interactive buttons to mute the alerting monitor. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_slack_channel#mute_buttons IntegrationSlackChannel#mute_buttons}
    */
    readonly muteButtons?: boolean | cdktn.IResolvable;
    /**
    * Show the list of @-handles in the alert event. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_slack_channel#notified IntegrationSlackChannel#notified}
    */
    readonly notified?: boolean | cdktn.IResolvable;
    /**
    * Show the alert event's snapshot image. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_slack_channel#snapshot IntegrationSlackChannel#snapshot}
    */
    readonly snapshot?: boolean | cdktn.IResolvable;
    /**
    * Show the scopes on which the monitor alerted. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_slack_channel#tags IntegrationSlackChannel#tags}
    */
    readonly tags?: boolean | cdktn.IResolvable;
}
export declare function integrationSlackChannelDisplayToTerraform(struct?: IntegrationSlackChannelDisplayOutputReference | IntegrationSlackChannelDisplay): any;
export declare function integrationSlackChannelDisplayToHclTerraform(struct?: IntegrationSlackChannelDisplayOutputReference | IntegrationSlackChannelDisplay): any;
export declare class IntegrationSlackChannelDisplayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IntegrationSlackChannelDisplay | undefined;
    set internalValue(value: IntegrationSlackChannelDisplay | undefined);
    private _message?;
    get message(): boolean | cdktn.IResolvable;
    set message(value: boolean | cdktn.IResolvable);
    resetMessage(): void;
    get messageInput(): boolean | cdktn.IResolvable | undefined;
    private _muteButtons?;
    get muteButtons(): boolean | cdktn.IResolvable;
    set muteButtons(value: boolean | cdktn.IResolvable);
    resetMuteButtons(): void;
    get muteButtonsInput(): boolean | cdktn.IResolvable | undefined;
    private _notified?;
    get notified(): boolean | cdktn.IResolvable;
    set notified(value: boolean | cdktn.IResolvable);
    resetNotified(): void;
    get notifiedInput(): boolean | cdktn.IResolvable | undefined;
    private _snapshot?;
    get snapshot(): boolean | cdktn.IResolvable;
    set snapshot(value: boolean | cdktn.IResolvable);
    resetSnapshot(): void;
    get snapshotInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): boolean | cdktn.IResolvable;
    set tags(value: boolean | cdktn.IResolvable);
    resetTags(): void;
    get tagsInput(): boolean | cdktn.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_slack_channel datadog_integration_slack_channel}
*/
export declare class IntegrationSlackChannel extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_integration_slack_channel";
    /**
    * Generates CDKTN code for importing a IntegrationSlackChannel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IntegrationSlackChannel to import
    * @param importFromId The id of the existing IntegrationSlackChannel that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_slack_channel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IntegrationSlackChannel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_slack_channel datadog_integration_slack_channel} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IntegrationSlackChannelConfig
    */
    constructor(scope: Construct, id: string, config: IntegrationSlackChannelConfig);
    private _accountName?;
    get accountName(): string;
    set accountName(value: string);
    get accountNameInput(): string | undefined;
    private _channelName?;
    get channelName(): string;
    set channelName(value: string);
    get channelNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _display;
    get display(): IntegrationSlackChannelDisplayOutputReference;
    putDisplay(value: IntegrationSlackChannelDisplay): void;
    get displayInput(): IntegrationSlackChannelDisplay | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
