/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SecurityMonitoringFilterConfig extends cdktn.TerraformMetaArguments {
    /**
    * The filtered data type. Valid values are `logs`. Defaults to `"logs"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_filter#filtered_data_type SecurityMonitoringFilter#filtered_data_type}
    */
    readonly filteredDataType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_filter#id SecurityMonitoringFilter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Whether the security filter is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_filter#is_enabled SecurityMonitoringFilter#is_enabled}
    */
    readonly isEnabled: boolean | cdktn.IResolvable;
    /**
    * The name of the security filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_filter#name SecurityMonitoringFilter#name}
    */
    readonly name: string;
    /**
    * The query of the security filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_filter#query SecurityMonitoringFilter#query}
    */
    readonly query: string;
    /**
    * exclusion_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_filter#exclusion_filter SecurityMonitoringFilter#exclusion_filter}
    */
    readonly exclusionFilter?: SecurityMonitoringFilterExclusionFilter[] | cdktn.IResolvable;
}
export interface SecurityMonitoringFilterExclusionFilter {
    /**
    * Exclusion filter name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_filter#name SecurityMonitoringFilter#name}
    */
    readonly name: string;
    /**
    * Exclusion filter query. Logs that match this query are excluded from the security filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_filter#query SecurityMonitoringFilter#query}
    */
    readonly query: string;
}
export declare function securityMonitoringFilterExclusionFilterToTerraform(struct?: SecurityMonitoringFilterExclusionFilter | cdktn.IResolvable): any;
export declare function securityMonitoringFilterExclusionFilterToHclTerraform(struct?: SecurityMonitoringFilterExclusionFilter | cdktn.IResolvable): any;
export declare class SecurityMonitoringFilterExclusionFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SecurityMonitoringFilterExclusionFilter | cdktn.IResolvable | undefined;
    set internalValue(value: SecurityMonitoringFilterExclusionFilter | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SecurityMonitoringFilterExclusionFilterList extends cdktn.ComplexList {
    internalValue?: SecurityMonitoringFilterExclusionFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SecurityMonitoringFilterExclusionFilterOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_filter datadog_security_monitoring_filter}
*/
export declare class SecurityMonitoringFilter extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_security_monitoring_filter";
    /**
    * Generates CDKTN code for importing a SecurityMonitoringFilter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecurityMonitoringFilter to import
    * @param importFromId The id of the existing SecurityMonitoringFilter that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_filter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecurityMonitoringFilter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_filter datadog_security_monitoring_filter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecurityMonitoringFilterConfig
    */
    constructor(scope: Construct, id: string, config: SecurityMonitoringFilterConfig);
    private _filteredDataType?;
    get filteredDataType(): string;
    set filteredDataType(value: string);
    resetFilteredDataType(): void;
    get filteredDataTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    get version(): number;
    private _exclusionFilter;
    get exclusionFilter(): SecurityMonitoringFilterExclusionFilterList;
    putExclusionFilter(value: SecurityMonitoringFilterExclusionFilter[] | cdktn.IResolvable): void;
    resetExclusionFilter(): void;
    get exclusionFilterInput(): cdktn.IResolvable | SecurityMonitoringFilterExclusionFilter[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
