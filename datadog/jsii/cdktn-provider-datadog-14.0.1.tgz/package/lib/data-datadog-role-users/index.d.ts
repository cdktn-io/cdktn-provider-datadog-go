/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogRoleUsersConfig extends cdktn.TerraformMetaArguments {
    /**
    * When true, `filter_keyword` string is exact matched against the user's `name`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/role_users#exact_match DataDatadogRoleUsers#exact_match}
    */
    readonly exactMatch?: boolean | cdktn.IResolvable;
    /**
    * Search query, can be user name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/role_users#filter DataDatadogRoleUsers#filter}
    */
    readonly filter?: string;
    /**
    * The role's identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/role_users#role_id DataDatadogRoleUsers#role_id}
    */
    readonly roleId: string;
}
export interface DataDatadogRoleUsersRoleUsers {
}
export declare function dataDatadogRoleUsersRoleUsersToTerraform(struct?: DataDatadogRoleUsersRoleUsers): any;
export declare function dataDatadogRoleUsersRoleUsersToHclTerraform(struct?: DataDatadogRoleUsersRoleUsers): any;
export declare class DataDatadogRoleUsersRoleUsersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogRoleUsersRoleUsers | undefined;
    set internalValue(value: DataDatadogRoleUsersRoleUsers | undefined);
    get roleId(): string;
    get userId(): string;
}
export declare class DataDatadogRoleUsersRoleUsersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogRoleUsersRoleUsersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/role_users datadog_role_users}
*/
export declare class DataDatadogRoleUsers extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_role_users";
    /**
    * Generates CDKTN code for importing a DataDatadogRoleUsers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogRoleUsers to import
    * @param importFromId The id of the existing DataDatadogRoleUsers that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/role_users#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogRoleUsers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/role_users datadog_role_users} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogRoleUsersConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogRoleUsersConfig);
    private _exactMatch?;
    get exactMatch(): boolean | cdktn.IResolvable;
    set exactMatch(value: boolean | cdktn.IResolvable);
    resetExactMatch(): void;
    get exactMatchInput(): boolean | cdktn.IResolvable | undefined;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    get id(): string;
    private _roleId?;
    get roleId(): string;
    set roleId(value: string);
    get roleIdInput(): string | undefined;
    private _roleUsers;
    get roleUsers(): DataDatadogRoleUsersRoleUsersList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
