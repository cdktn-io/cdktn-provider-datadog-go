/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IntegrationAwsAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * Tags to apply to all metrics in the account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#account_tags IntegrationAwsAccount#account_tags}
    */
    readonly accountTags?: string[];
    /**
    * Your AWS Account ID without dashes. Invalid aws_account_id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#aws_account_id IntegrationAwsAccount#aws_account_id}
    */
    readonly awsAccountId: string;
    /**
    * AWS Account partition. Valid values are `aws`, `aws-cn`, `aws-us-gov`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#aws_partition IntegrationAwsAccount#aws_partition}
    */
    readonly awsPartition: string;
    /**
    * auth_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#auth_config IntegrationAwsAccount#auth_config}
    */
    readonly authConfig?: IntegrationAwsAccountAuthConfig;
    /**
    * aws_regions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#aws_regions IntegrationAwsAccount#aws_regions}
    */
    readonly awsRegions?: IntegrationAwsAccountAwsRegions;
    /**
    * logs_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#logs_config IntegrationAwsAccount#logs_config}
    */
    readonly logsConfig?: IntegrationAwsAccountLogsConfig;
    /**
    * metrics_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#metrics_config IntegrationAwsAccount#metrics_config}
    */
    readonly metricsConfig?: IntegrationAwsAccountMetricsConfig;
    /**
    * resources_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#resources_config IntegrationAwsAccount#resources_config}
    */
    readonly resourcesConfig?: IntegrationAwsAccountResourcesConfig;
    /**
    * traces_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#traces_config IntegrationAwsAccount#traces_config}
    */
    readonly tracesConfig?: IntegrationAwsAccountTracesConfig;
}
export interface IntegrationAwsAccountAuthConfigAwsAuthConfigKeys {
    /**
    * AWS Access Key ID. Invalid access_key_id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#access_key_id IntegrationAwsAccount#access_key_id}
    */
    readonly accessKeyId?: string;
    /**
    * AWS Secret Access Key. This value is write-only; changes made outside of Terraform will not be drift-detected. Secret_access_key must be non-empty and not contain whitespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#secret_access_key IntegrationAwsAccount#secret_access_key}
    */
    readonly secretAccessKey?: string;
}
export declare function integrationAwsAccountAuthConfigAwsAuthConfigKeysToTerraform(struct?: IntegrationAwsAccountAuthConfigAwsAuthConfigKeys | cdktn.IResolvable): any;
export declare function integrationAwsAccountAuthConfigAwsAuthConfigKeysToHclTerraform(struct?: IntegrationAwsAccountAuthConfigAwsAuthConfigKeys | cdktn.IResolvable): any;
export declare class IntegrationAwsAccountAuthConfigAwsAuthConfigKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IntegrationAwsAccountAuthConfigAwsAuthConfigKeys | cdktn.IResolvable | undefined;
    set internalValue(value: IntegrationAwsAccountAuthConfigAwsAuthConfigKeys | cdktn.IResolvable | undefined);
    private _accessKeyId?;
    get accessKeyId(): string;
    set accessKeyId(value: string);
    resetAccessKeyId(): void;
    get accessKeyIdInput(): string | undefined;
    private _secretAccessKey?;
    get secretAccessKey(): string;
    set secretAccessKey(value: string);
    resetSecretAccessKey(): void;
    get secretAccessKeyInput(): string | undefined;
}
export interface IntegrationAwsAccountAuthConfigAwsAuthConfigRole {
    /**
    * AWS IAM External ID for associated role. If omitted, one will be generated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#external_id IntegrationAwsAccount#external_id}
    */
    readonly externalId?: string;
    /**
    * AWS IAM Role name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#role_name IntegrationAwsAccount#role_name}
    */
    readonly roleName?: string;
}
export declare function integrationAwsAccountAuthConfigAwsAuthConfigRoleToTerraform(struct?: IntegrationAwsAccountAuthConfigAwsAuthConfigRole | cdktn.IResolvable): any;
export declare function integrationAwsAccountAuthConfigAwsAuthConfigRoleToHclTerraform(struct?: IntegrationAwsAccountAuthConfigAwsAuthConfigRole | cdktn.IResolvable): any;
export declare class IntegrationAwsAccountAuthConfigAwsAuthConfigRoleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IntegrationAwsAccountAuthConfigAwsAuthConfigRole | cdktn.IResolvable | undefined;
    set internalValue(value: IntegrationAwsAccountAuthConfigAwsAuthConfigRole | cdktn.IResolvable | undefined);
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _roleName?;
    get roleName(): string;
    set roleName(value: string);
    resetRoleName(): void;
    get roleNameInput(): string | undefined;
}
export interface IntegrationAwsAccountAuthConfig {
    /**
    * aws_auth_config_keys block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#aws_auth_config_keys IntegrationAwsAccount#aws_auth_config_keys}
    */
    readonly awsAuthConfigKeys?: IntegrationAwsAccountAuthConfigAwsAuthConfigKeys;
    /**
    * aws_auth_config_role block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#aws_auth_config_role IntegrationAwsAccount#aws_auth_config_role}
    */
    readonly awsAuthConfigRole?: IntegrationAwsAccountAuthConfigAwsAuthConfigRole;
}
export declare function integrationAwsAccountAuthConfigToTerraform(struct?: IntegrationAwsAccountAuthConfig | cdktn.IResolvable): any;
export declare function integrationAwsAccountAuthConfigToHclTerraform(struct?: IntegrationAwsAccountAuthConfig | cdktn.IResolvable): any;
export declare class IntegrationAwsAccountAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IntegrationAwsAccountAuthConfig | cdktn.IResolvable | undefined;
    set internalValue(value: IntegrationAwsAccountAuthConfig | cdktn.IResolvable | undefined);
    private _awsAuthConfigKeys;
    get awsAuthConfigKeys(): IntegrationAwsAccountAuthConfigAwsAuthConfigKeysOutputReference;
    putAwsAuthConfigKeys(value: IntegrationAwsAccountAuthConfigAwsAuthConfigKeys): void;
    resetAwsAuthConfigKeys(): void;
    get awsAuthConfigKeysInput(): cdktn.IResolvable | IntegrationAwsAccountAuthConfigAwsAuthConfigKeys | undefined;
    private _awsAuthConfigRole;
    get awsAuthConfigRole(): IntegrationAwsAccountAuthConfigAwsAuthConfigRoleOutputReference;
    putAwsAuthConfigRole(value: IntegrationAwsAccountAuthConfigAwsAuthConfigRole): void;
    resetAwsAuthConfigRole(): void;
    get awsAuthConfigRoleInput(): cdktn.IResolvable | IntegrationAwsAccountAuthConfigAwsAuthConfigRole | undefined;
}
export interface IntegrationAwsAccountAwsRegions {
    /**
    * Include all regions. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#include_all IntegrationAwsAccount#include_all}
    */
    readonly includeAll?: boolean | cdktn.IResolvable;
    /**
    * Include only these regions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#include_only IntegrationAwsAccount#include_only}
    */
    readonly includeOnly?: string[];
}
export declare function integrationAwsAccountAwsRegionsToTerraform(struct?: IntegrationAwsAccountAwsRegions | cdktn.IResolvable): any;
export declare function integrationAwsAccountAwsRegionsToHclTerraform(struct?: IntegrationAwsAccountAwsRegions | cdktn.IResolvable): any;
export declare class IntegrationAwsAccountAwsRegionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IntegrationAwsAccountAwsRegions | cdktn.IResolvable | undefined;
    set internalValue(value: IntegrationAwsAccountAwsRegions | cdktn.IResolvable | undefined);
    private _includeAll?;
    get includeAll(): boolean | cdktn.IResolvable;
    set includeAll(value: boolean | cdktn.IResolvable);
    resetIncludeAll(): void;
    get includeAllInput(): boolean | cdktn.IResolvable | undefined;
    private _includeOnly?;
    get includeOnly(): string[];
    set includeOnly(value: string[]);
    resetIncludeOnly(): void;
    get includeOnlyInput(): string[] | undefined;
}
export interface IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfigTagFilters {
    /**
    * The AWS service for which the tag filters defined in `tags` will be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#source IntegrationAwsAccount#source}
    */
    readonly source: string;
    /**
    * The AWS resource tags to filter on for the service specified by `source`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#tags IntegrationAwsAccount#tags}
    */
    readonly tags: string[];
}
export declare function integrationAwsAccountLogsConfigLambdaForwarderLogSourceConfigTagFiltersToTerraform(struct?: IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfigTagFilters | cdktn.IResolvable): any;
export declare function integrationAwsAccountLogsConfigLambdaForwarderLogSourceConfigTagFiltersToHclTerraform(struct?: IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfigTagFilters | cdktn.IResolvable): any;
export declare class IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfigTagFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfigTagFilters | cdktn.IResolvable | undefined;
    set internalValue(value: IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfigTagFilters | cdktn.IResolvable | undefined);
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    get tagsInput(): string[] | undefined;
}
export declare class IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfigTagFiltersList extends cdktn.ComplexList {
    internalValue?: IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfigTagFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfigTagFiltersOutputReference;
}
export interface IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfig {
    /**
    * tag_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#tag_filters IntegrationAwsAccount#tag_filters}
    */
    readonly tagFilters?: IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfigTagFilters[] | cdktn.IResolvable;
}
export declare function integrationAwsAccountLogsConfigLambdaForwarderLogSourceConfigToTerraform(struct?: IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfig | cdktn.IResolvable): any;
export declare function integrationAwsAccountLogsConfigLambdaForwarderLogSourceConfigToHclTerraform(struct?: IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfig | cdktn.IResolvable): any;
export declare class IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfig | cdktn.IResolvable | undefined;
    set internalValue(value: IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfig | cdktn.IResolvable | undefined);
    private _tagFilters;
    get tagFilters(): IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfigTagFiltersList;
    putTagFilters(value: IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfigTagFilters[] | cdktn.IResolvable): void;
    resetTagFilters(): void;
    get tagFiltersInput(): cdktn.IResolvable | IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfigTagFilters[] | undefined;
}
export interface IntegrationAwsAccountLogsConfigLambdaForwarder {
    /**
    * List of Datadog Lambda Log Forwarder ARNs in your AWS account. Defaults to `[]`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#lambdas IntegrationAwsAccount#lambdas}
    */
    readonly lambdas?: string[];
    /**
    * List of service IDs set to enable automatic log collection. Use [`datadog_integration_aws_available_logs_services` data source](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/data-sources/integration_aws_available_logs_services) or [the AWS Logs Integration API](https://docs.datadoghq.com/api/latest/aws-logs-integration/?#get-list-of-aws-log-ready-services) to get allowed values. Defaults to `[]`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#sources IntegrationAwsAccount#sources}
    */
    readonly sources?: string[];
    /**
    * log_source_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#log_source_config IntegrationAwsAccount#log_source_config}
    */
    readonly logSourceConfig?: IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfig;
}
export declare function integrationAwsAccountLogsConfigLambdaForwarderToTerraform(struct?: IntegrationAwsAccountLogsConfigLambdaForwarder | cdktn.IResolvable): any;
export declare function integrationAwsAccountLogsConfigLambdaForwarderToHclTerraform(struct?: IntegrationAwsAccountLogsConfigLambdaForwarder | cdktn.IResolvable): any;
export declare class IntegrationAwsAccountLogsConfigLambdaForwarderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IntegrationAwsAccountLogsConfigLambdaForwarder | cdktn.IResolvable | undefined;
    set internalValue(value: IntegrationAwsAccountLogsConfigLambdaForwarder | cdktn.IResolvable | undefined);
    private _lambdas?;
    get lambdas(): string[];
    set lambdas(value: string[]);
    resetLambdas(): void;
    get lambdasInput(): string[] | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    resetSources(): void;
    get sourcesInput(): string[] | undefined;
    private _logSourceConfig;
    get logSourceConfig(): IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfigOutputReference;
    putLogSourceConfig(value: IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfig): void;
    resetLogSourceConfig(): void;
    get logSourceConfigInput(): cdktn.IResolvable | IntegrationAwsAccountLogsConfigLambdaForwarderLogSourceConfig | undefined;
}
export interface IntegrationAwsAccountLogsConfig {
    /**
    * lambda_forwarder block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#lambda_forwarder IntegrationAwsAccount#lambda_forwarder}
    */
    readonly lambdaForwarder?: IntegrationAwsAccountLogsConfigLambdaForwarder;
}
export declare function integrationAwsAccountLogsConfigToTerraform(struct?: IntegrationAwsAccountLogsConfig | cdktn.IResolvable): any;
export declare function integrationAwsAccountLogsConfigToHclTerraform(struct?: IntegrationAwsAccountLogsConfig | cdktn.IResolvable): any;
export declare class IntegrationAwsAccountLogsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IntegrationAwsAccountLogsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: IntegrationAwsAccountLogsConfig | cdktn.IResolvable | undefined);
    private _lambdaForwarder;
    get lambdaForwarder(): IntegrationAwsAccountLogsConfigLambdaForwarderOutputReference;
    putLambdaForwarder(value: IntegrationAwsAccountLogsConfigLambdaForwarder): void;
    resetLambdaForwarder(): void;
    get lambdaForwarderInput(): cdktn.IResolvable | IntegrationAwsAccountLogsConfigLambdaForwarder | undefined;
}
export interface IntegrationAwsAccountMetricsConfigNamespaceFilters {
    /**
    * Exclude only these namespaces from metrics collection. Use [`datadog_integration_aws_available_namespaces` data source](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/data-sources/integration_aws_available_namespaces) to get allowed values. Defaults to `["AWS/SQS", "AWS/ElasticMapReduce", "AWS/Usage"]`. `AWS/SQS`, `AWS/ElasticMapReduce`, and `AWS/Usage` are excluded by default to reduce your AWS CloudWatch costs from `GetMetricData` API calls.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#exclude_only IntegrationAwsAccount#exclude_only}
    */
    readonly excludeOnly?: string[];
    /**
    * Include only these namespaces for metrics collection. Use [`datadog_integration_aws_available_namespaces` data source](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/data-sources/integration_aws_available_namespaces) to get allowed values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#include_only IntegrationAwsAccount#include_only}
    */
    readonly includeOnly?: string[];
}
export declare function integrationAwsAccountMetricsConfigNamespaceFiltersToTerraform(struct?: IntegrationAwsAccountMetricsConfigNamespaceFilters | cdktn.IResolvable): any;
export declare function integrationAwsAccountMetricsConfigNamespaceFiltersToHclTerraform(struct?: IntegrationAwsAccountMetricsConfigNamespaceFilters | cdktn.IResolvable): any;
export declare class IntegrationAwsAccountMetricsConfigNamespaceFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IntegrationAwsAccountMetricsConfigNamespaceFilters | cdktn.IResolvable | undefined;
    set internalValue(value: IntegrationAwsAccountMetricsConfigNamespaceFilters | cdktn.IResolvable | undefined);
    private _excludeOnly?;
    get excludeOnly(): string[];
    set excludeOnly(value: string[]);
    resetExcludeOnly(): void;
    get excludeOnlyInput(): string[] | undefined;
    private _includeOnly?;
    get includeOnly(): string[];
    set includeOnly(value: string[]);
    resetIncludeOnly(): void;
    get includeOnlyInput(): string[] | undefined;
}
export interface IntegrationAwsAccountMetricsConfigTagFilters {
    /**
    * The AWS service for which the tag filters defined in `tags` will be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#namespace IntegrationAwsAccount#namespace}
    */
    readonly namespace: string;
    /**
    * The AWS resource tags to filter on for the service specified by `namespace`. Defaults to `[]`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#tags IntegrationAwsAccount#tags}
    */
    readonly tags?: string[];
}
export declare function integrationAwsAccountMetricsConfigTagFiltersToTerraform(struct?: IntegrationAwsAccountMetricsConfigTagFilters | cdktn.IResolvable): any;
export declare function integrationAwsAccountMetricsConfigTagFiltersToHclTerraform(struct?: IntegrationAwsAccountMetricsConfigTagFilters | cdktn.IResolvable): any;
export declare class IntegrationAwsAccountMetricsConfigTagFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IntegrationAwsAccountMetricsConfigTagFilters | cdktn.IResolvable | undefined;
    set internalValue(value: IntegrationAwsAccountMetricsConfigTagFilters | cdktn.IResolvable | undefined);
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    get namespaceInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
}
export declare class IntegrationAwsAccountMetricsConfigTagFiltersList extends cdktn.ComplexList {
    internalValue?: IntegrationAwsAccountMetricsConfigTagFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IntegrationAwsAccountMetricsConfigTagFiltersOutputReference;
}
export interface IntegrationAwsAccountMetricsConfig {
    /**
    * Enable EC2 automute for AWS metrics Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#automute_enabled IntegrationAwsAccount#automute_enabled}
    */
    readonly automuteEnabled?: boolean | cdktn.IResolvable;
    /**
    * Enable CloudWatch alarms collection Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#collect_cloudwatch_alarms IntegrationAwsAccount#collect_cloudwatch_alarms}
    */
    readonly collectCloudwatchAlarms?: boolean | cdktn.IResolvable;
    /**
    * Enable custom metrics collection Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#collect_custom_metrics IntegrationAwsAccount#collect_custom_metrics}
    */
    readonly collectCustomMetrics?: boolean | cdktn.IResolvable;
    /**
    * Enable AWS metrics collection Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#enabled IntegrationAwsAccount#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * namespace_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#namespace_filters IntegrationAwsAccount#namespace_filters}
    */
    readonly namespaceFilters?: IntegrationAwsAccountMetricsConfigNamespaceFilters;
    /**
    * tag_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#tag_filters IntegrationAwsAccount#tag_filters}
    */
    readonly tagFilters?: IntegrationAwsAccountMetricsConfigTagFilters[] | cdktn.IResolvable;
}
export declare function integrationAwsAccountMetricsConfigToTerraform(struct?: IntegrationAwsAccountMetricsConfig | cdktn.IResolvable): any;
export declare function integrationAwsAccountMetricsConfigToHclTerraform(struct?: IntegrationAwsAccountMetricsConfig | cdktn.IResolvable): any;
export declare class IntegrationAwsAccountMetricsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IntegrationAwsAccountMetricsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: IntegrationAwsAccountMetricsConfig | cdktn.IResolvable | undefined);
    private _automuteEnabled?;
    get automuteEnabled(): boolean | cdktn.IResolvable;
    set automuteEnabled(value: boolean | cdktn.IResolvable);
    resetAutomuteEnabled(): void;
    get automuteEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _collectCloudwatchAlarms?;
    get collectCloudwatchAlarms(): boolean | cdktn.IResolvable;
    set collectCloudwatchAlarms(value: boolean | cdktn.IResolvable);
    resetCollectCloudwatchAlarms(): void;
    get collectCloudwatchAlarmsInput(): boolean | cdktn.IResolvable | undefined;
    private _collectCustomMetrics?;
    get collectCustomMetrics(): boolean | cdktn.IResolvable;
    set collectCustomMetrics(value: boolean | cdktn.IResolvable);
    resetCollectCustomMetrics(): void;
    get collectCustomMetricsInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _namespaceFilters;
    get namespaceFilters(): IntegrationAwsAccountMetricsConfigNamespaceFiltersOutputReference;
    putNamespaceFilters(value: IntegrationAwsAccountMetricsConfigNamespaceFilters): void;
    resetNamespaceFilters(): void;
    get namespaceFiltersInput(): cdktn.IResolvable | IntegrationAwsAccountMetricsConfigNamespaceFilters | undefined;
    private _tagFilters;
    get tagFilters(): IntegrationAwsAccountMetricsConfigTagFiltersList;
    putTagFilters(value: IntegrationAwsAccountMetricsConfigTagFilters[] | cdktn.IResolvable): void;
    resetTagFilters(): void;
    get tagFiltersInput(): cdktn.IResolvable | IntegrationAwsAccountMetricsConfigTagFilters[] | undefined;
}
export interface IntegrationAwsAccountResourcesConfig {
    /**
    * Enable Cloud Security Management to scan AWS resources for vulnerabilities, misconfigurations, identity risks, and compliance violations. Requires `extended_collection` to be set to `true`. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#cloud_security_posture_management_collection IntegrationAwsAccount#cloud_security_posture_management_collection}
    */
    readonly cloudSecurityPostureManagementCollection?: boolean | cdktn.IResolvable;
    /**
    * Whether Datadog collects additional attributes and configuration information about the resources in your AWS account. Required for `cloud_security_posture_management_collection`. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#extended_collection IntegrationAwsAccount#extended_collection}
    */
    readonly extendedCollection?: boolean | cdktn.IResolvable;
}
export declare function integrationAwsAccountResourcesConfigToTerraform(struct?: IntegrationAwsAccountResourcesConfig | cdktn.IResolvable): any;
export declare function integrationAwsAccountResourcesConfigToHclTerraform(struct?: IntegrationAwsAccountResourcesConfig | cdktn.IResolvable): any;
export declare class IntegrationAwsAccountResourcesConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IntegrationAwsAccountResourcesConfig | cdktn.IResolvable | undefined;
    set internalValue(value: IntegrationAwsAccountResourcesConfig | cdktn.IResolvable | undefined);
    private _cloudSecurityPostureManagementCollection?;
    get cloudSecurityPostureManagementCollection(): boolean | cdktn.IResolvable;
    set cloudSecurityPostureManagementCollection(value: boolean | cdktn.IResolvable);
    resetCloudSecurityPostureManagementCollection(): void;
    get cloudSecurityPostureManagementCollectionInput(): boolean | cdktn.IResolvable | undefined;
    private _extendedCollection?;
    get extendedCollection(): boolean | cdktn.IResolvable;
    set extendedCollection(value: boolean | cdktn.IResolvable);
    resetExtendedCollection(): void;
    get extendedCollectionInput(): boolean | cdktn.IResolvable | undefined;
}
export interface IntegrationAwsAccountTracesConfigXrayServices {
    /**
    * Include all services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#include_all IntegrationAwsAccount#include_all}
    */
    readonly includeAll?: boolean | cdktn.IResolvable;
    /**
    * Include only these services. Defaults to `[]`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#include_only IntegrationAwsAccount#include_only}
    */
    readonly includeOnly?: string[];
}
export declare function integrationAwsAccountTracesConfigXrayServicesToTerraform(struct?: IntegrationAwsAccountTracesConfigXrayServices | cdktn.IResolvable): any;
export declare function integrationAwsAccountTracesConfigXrayServicesToHclTerraform(struct?: IntegrationAwsAccountTracesConfigXrayServices | cdktn.IResolvable): any;
export declare class IntegrationAwsAccountTracesConfigXrayServicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IntegrationAwsAccountTracesConfigXrayServices | cdktn.IResolvable | undefined;
    set internalValue(value: IntegrationAwsAccountTracesConfigXrayServices | cdktn.IResolvable | undefined);
    private _includeAll?;
    get includeAll(): boolean | cdktn.IResolvable;
    set includeAll(value: boolean | cdktn.IResolvable);
    resetIncludeAll(): void;
    get includeAllInput(): boolean | cdktn.IResolvable | undefined;
    private _includeOnly?;
    get includeOnly(): string[];
    set includeOnly(value: string[]);
    resetIncludeOnly(): void;
    get includeOnlyInput(): string[] | undefined;
}
export interface IntegrationAwsAccountTracesConfig {
    /**
    * xray_services block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#xray_services IntegrationAwsAccount#xray_services}
    */
    readonly xrayServices?: IntegrationAwsAccountTracesConfigXrayServices;
}
export declare function integrationAwsAccountTracesConfigToTerraform(struct?: IntegrationAwsAccountTracesConfig | cdktn.IResolvable): any;
export declare function integrationAwsAccountTracesConfigToHclTerraform(struct?: IntegrationAwsAccountTracesConfig | cdktn.IResolvable): any;
export declare class IntegrationAwsAccountTracesConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IntegrationAwsAccountTracesConfig | cdktn.IResolvable | undefined;
    set internalValue(value: IntegrationAwsAccountTracesConfig | cdktn.IResolvable | undefined);
    private _xrayServices;
    get xrayServices(): IntegrationAwsAccountTracesConfigXrayServicesOutputReference;
    putXrayServices(value: IntegrationAwsAccountTracesConfigXrayServices): void;
    resetXrayServices(): void;
    get xrayServicesInput(): cdktn.IResolvable | IntegrationAwsAccountTracesConfigXrayServices | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account datadog_integration_aws_account}
*/
export declare class IntegrationAwsAccount extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_integration_aws_account";
    /**
    * Generates CDKTN code for importing a IntegrationAwsAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IntegrationAwsAccount to import
    * @param importFromId The id of the existing IntegrationAwsAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IntegrationAwsAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_account datadog_integration_aws_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IntegrationAwsAccountConfig
    */
    constructor(scope: Construct, id: string, config: IntegrationAwsAccountConfig);
    private _accountTags?;
    get accountTags(): string[];
    set accountTags(value: string[]);
    resetAccountTags(): void;
    get accountTagsInput(): string[] | undefined;
    private _awsAccountId?;
    get awsAccountId(): string;
    set awsAccountId(value: string);
    get awsAccountIdInput(): string | undefined;
    private _awsPartition?;
    get awsPartition(): string;
    set awsPartition(value: string);
    get awsPartitionInput(): string | undefined;
    get id(): string;
    private _authConfig;
    get authConfig(): IntegrationAwsAccountAuthConfigOutputReference;
    putAuthConfig(value: IntegrationAwsAccountAuthConfig): void;
    resetAuthConfig(): void;
    get authConfigInput(): cdktn.IResolvable | IntegrationAwsAccountAuthConfig | undefined;
    private _awsRegions;
    get awsRegions(): IntegrationAwsAccountAwsRegionsOutputReference;
    putAwsRegions(value: IntegrationAwsAccountAwsRegions): void;
    resetAwsRegions(): void;
    get awsRegionsInput(): cdktn.IResolvable | IntegrationAwsAccountAwsRegions | undefined;
    private _logsConfig;
    get logsConfig(): IntegrationAwsAccountLogsConfigOutputReference;
    putLogsConfig(value: IntegrationAwsAccountLogsConfig): void;
    resetLogsConfig(): void;
    get logsConfigInput(): cdktn.IResolvable | IntegrationAwsAccountLogsConfig | undefined;
    private _metricsConfig;
    get metricsConfig(): IntegrationAwsAccountMetricsConfigOutputReference;
    putMetricsConfig(value: IntegrationAwsAccountMetricsConfig): void;
    resetMetricsConfig(): void;
    get metricsConfigInput(): cdktn.IResolvable | IntegrationAwsAccountMetricsConfig | undefined;
    private _resourcesConfig;
    get resourcesConfig(): IntegrationAwsAccountResourcesConfigOutputReference;
    putResourcesConfig(value: IntegrationAwsAccountResourcesConfig): void;
    resetResourcesConfig(): void;
    get resourcesConfigInput(): cdktn.IResolvable | IntegrationAwsAccountResourcesConfig | undefined;
    private _tracesConfig;
    get tracesConfig(): IntegrationAwsAccountTracesConfigOutputReference;
    putTracesConfig(value: IntegrationAwsAccountTracesConfig): void;
    resetTracesConfig(): void;
    get tracesConfigInput(): cdktn.IResolvable | IntegrationAwsAccountTracesConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
