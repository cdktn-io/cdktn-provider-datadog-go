/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SoftwareCatalogConfig extends cdktn.TerraformMetaArguments {
    /**
    * The catalog entity definition. Entity must be a valid entity YAML/JSON structure.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/software_catalog#entity SoftwareCatalog#entity}
    */
    readonly entity: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/software_catalog datadog_software_catalog}
*/
export declare class SoftwareCatalog extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_software_catalog";
    /**
    * Generates CDKTN code for importing a SoftwareCatalog resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SoftwareCatalog to import
    * @param importFromId The id of the existing SoftwareCatalog that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/software_catalog#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SoftwareCatalog to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/software_catalog datadog_software_catalog} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SoftwareCatalogConfig
    */
    constructor(scope: Construct, id: string, config: SoftwareCatalogConfig);
    private _entity?;
    get entity(): string;
    set entity(value: string);
    get entityInput(): string | undefined;
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
