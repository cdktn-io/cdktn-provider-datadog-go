/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppsecWafCustomRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Indicates whether the WAF custom rule will block the request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#blocking AppsecWafCustomRule#blocking}
    */
    readonly blocking: boolean | cdktn.IResolvable;
    /**
    * Indicates whether the WAF custom rule is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#enabled AppsecWafCustomRule#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * The Name of the WAF custom rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#name AppsecWafCustomRule#name}
    */
    readonly name: string;
    /**
    * The path glob for the WAF custom rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#path_glob AppsecWafCustomRule#path_glob}
    */
    readonly pathGlob?: string;
    /**
    * Tags associated with the WAF custom rule. `category` and `type` tags are required. Supported categories include `business_logic`, `attack_attempt` and `security_response`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#tags AppsecWafCustomRule#tags}
    */
    readonly tags: {
        [key: string]: string;
    };
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#action AppsecWafCustomRule#action}
    */
    readonly action?: AppsecWafCustomRuleAction;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#condition AppsecWafCustomRule#condition}
    */
    readonly condition?: AppsecWafCustomRuleCondition[] | cdktn.IResolvable;
    /**
    * scope block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#scope AppsecWafCustomRule#scope}
    */
    readonly scope?: AppsecWafCustomRuleScope[] | cdktn.IResolvable;
}
export interface AppsecWafCustomRuleActionParameters {
    /**
    * The location to redirect to when the WAF custom rule triggers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#location AppsecWafCustomRule#location}
    */
    readonly location?: string;
    /**
    * The status code to return when the WAF custom rule triggers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#status_code AppsecWafCustomRule#status_code}
    */
    readonly statusCode?: number;
}
export declare function appsecWafCustomRuleActionParametersToTerraform(struct?: AppsecWafCustomRuleActionParameters | cdktn.IResolvable): any;
export declare function appsecWafCustomRuleActionParametersToHclTerraform(struct?: AppsecWafCustomRuleActionParameters | cdktn.IResolvable): any;
export declare class AppsecWafCustomRuleActionParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsecWafCustomRuleActionParameters | cdktn.IResolvable | undefined;
    set internalValue(value: AppsecWafCustomRuleActionParameters | cdktn.IResolvable | undefined);
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _statusCode?;
    get statusCode(): number;
    set statusCode(value: number);
    resetStatusCode(): void;
    get statusCodeInput(): number | undefined;
}
export interface AppsecWafCustomRuleAction {
    /**
    * Override the default action to take when the WAF custom rule would block.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#action AppsecWafCustomRule#action}
    */
    readonly action?: string;
    /**
    * parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#parameters AppsecWafCustomRule#parameters}
    */
    readonly parameters?: AppsecWafCustomRuleActionParameters;
}
export declare function appsecWafCustomRuleActionToTerraform(struct?: AppsecWafCustomRuleAction | cdktn.IResolvable): any;
export declare function appsecWafCustomRuleActionToHclTerraform(struct?: AppsecWafCustomRuleAction | cdktn.IResolvable): any;
export declare class AppsecWafCustomRuleActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsecWafCustomRuleAction | cdktn.IResolvable | undefined;
    set internalValue(value: AppsecWafCustomRuleAction | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _parameters;
    get parameters(): AppsecWafCustomRuleActionParametersOutputReference;
    putParameters(value: AppsecWafCustomRuleActionParameters): void;
    resetParameters(): void;
    get parametersInput(): cdktn.IResolvable | AppsecWafCustomRuleActionParameters | undefined;
}
export interface AppsecWafCustomRuleConditionParametersInput {
    /**
    * Input from the request on which the condition should apply.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#address AppsecWafCustomRule#address}
    */
    readonly address?: string;
    /**
    * Specific path for the input.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#key_path AppsecWafCustomRule#key_path}
    */
    readonly keyPath?: string[];
}
export declare function appsecWafCustomRuleConditionParametersInputToTerraform(struct?: AppsecWafCustomRuleConditionParametersInput | cdktn.IResolvable): any;
export declare function appsecWafCustomRuleConditionParametersInputToHclTerraform(struct?: AppsecWafCustomRuleConditionParametersInput | cdktn.IResolvable): any;
export declare class AppsecWafCustomRuleConditionParametersInputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsecWafCustomRuleConditionParametersInput | cdktn.IResolvable | undefined;
    set internalValue(value: AppsecWafCustomRuleConditionParametersInput | cdktn.IResolvable | undefined);
    private _address?;
    get address(): string;
    set address(value: string);
    resetAddress(): void;
    get addressInput(): string | undefined;
    private _keyPath?;
    get keyPath(): string[];
    set keyPath(value: string[]);
    resetKeyPath(): void;
    get keyPathInput(): string[] | undefined;
}
export declare class AppsecWafCustomRuleConditionParametersInputList extends cdktn.ComplexList {
    internalValue?: AppsecWafCustomRuleConditionParametersInput[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsecWafCustomRuleConditionParametersInputOutputReference;
}
export interface AppsecWafCustomRuleConditionParametersOptions {
    /**
    * Evaluate the value as case sensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#case_sensitive AppsecWafCustomRule#case_sensitive}
    */
    readonly caseSensitive?: boolean | cdktn.IResolvable;
    /**
    * Only evaluate this condition if the value has a minimum amount of characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#min_length AppsecWafCustomRule#min_length}
    */
    readonly minLength?: number;
}
export declare function appsecWafCustomRuleConditionParametersOptionsToTerraform(struct?: AppsecWafCustomRuleConditionParametersOptions | cdktn.IResolvable): any;
export declare function appsecWafCustomRuleConditionParametersOptionsToHclTerraform(struct?: AppsecWafCustomRuleConditionParametersOptions | cdktn.IResolvable): any;
export declare class AppsecWafCustomRuleConditionParametersOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsecWafCustomRuleConditionParametersOptions | cdktn.IResolvable | undefined;
    set internalValue(value: AppsecWafCustomRuleConditionParametersOptions | cdktn.IResolvable | undefined);
    private _caseSensitive?;
    get caseSensitive(): boolean | cdktn.IResolvable;
    set caseSensitive(value: boolean | cdktn.IResolvable);
    resetCaseSensitive(): void;
    get caseSensitiveInput(): boolean | cdktn.IResolvable | undefined;
    private _minLength?;
    get minLength(): number;
    set minLength(value: number);
    resetMinLength(): void;
    get minLengthInput(): number | undefined;
}
export interface AppsecWafCustomRuleConditionParameters {
    /**
    * Identifier of a list of data from the denylist. Can only be used as substitution from the list parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#data AppsecWafCustomRule#data}
    */
    readonly data?: string;
    /**
    * List of value to use with the condition. Only used with the phrase_match, !phrase_match, exact_match and !exact_match operator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#list AppsecWafCustomRule#list}
    */
    readonly list?: string[];
    /**
    * Regex to use with the condition. Only used with match_regex and !match_regex operator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#regex AppsecWafCustomRule#regex}
    */
    readonly regex?: string;
    /**
    * Store the captured value in the specified tag name. Only used with the capture_data operator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#value AppsecWafCustomRule#value}
    */
    readonly value?: string;
    /**
    * input block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#input AppsecWafCustomRule#input}
    */
    readonly input?: AppsecWafCustomRuleConditionParametersInput[] | cdktn.IResolvable;
    /**
    * options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#options AppsecWafCustomRule#options}
    */
    readonly options?: AppsecWafCustomRuleConditionParametersOptions;
}
export declare function appsecWafCustomRuleConditionParametersToTerraform(struct?: AppsecWafCustomRuleConditionParameters | cdktn.IResolvable): any;
export declare function appsecWafCustomRuleConditionParametersToHclTerraform(struct?: AppsecWafCustomRuleConditionParameters | cdktn.IResolvable): any;
export declare class AppsecWafCustomRuleConditionParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsecWafCustomRuleConditionParameters | cdktn.IResolvable | undefined;
    set internalValue(value: AppsecWafCustomRuleConditionParameters | cdktn.IResolvable | undefined);
    private _data?;
    get data(): string;
    set data(value: string);
    resetData(): void;
    get dataInput(): string | undefined;
    private _list?;
    get list(): string[];
    set list(value: string[]);
    resetList(): void;
    get listInput(): string[] | undefined;
    private _regex?;
    get regex(): string;
    set regex(value: string);
    resetRegex(): void;
    get regexInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _input;
    get input(): AppsecWafCustomRuleConditionParametersInputList;
    putInput(value: AppsecWafCustomRuleConditionParametersInput[] | cdktn.IResolvable): void;
    resetInput(): void;
    get inputInput(): cdktn.IResolvable | AppsecWafCustomRuleConditionParametersInput[] | undefined;
    private _options;
    get options(): AppsecWafCustomRuleConditionParametersOptionsOutputReference;
    putOptions(value: AppsecWafCustomRuleConditionParametersOptions): void;
    resetOptions(): void;
    get optionsInput(): cdktn.IResolvable | AppsecWafCustomRuleConditionParametersOptions | undefined;
}
export interface AppsecWafCustomRuleCondition {
    /**
    * Operator to use for the WAF Condition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#operator AppsecWafCustomRule#operator}
    */
    readonly operator?: string;
    /**
    * parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#parameters AppsecWafCustomRule#parameters}
    */
    readonly parameters?: AppsecWafCustomRuleConditionParameters;
}
export declare function appsecWafCustomRuleConditionToTerraform(struct?: AppsecWafCustomRuleCondition | cdktn.IResolvable): any;
export declare function appsecWafCustomRuleConditionToHclTerraform(struct?: AppsecWafCustomRuleCondition | cdktn.IResolvable): any;
export declare class AppsecWafCustomRuleConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsecWafCustomRuleCondition | cdktn.IResolvable | undefined;
    set internalValue(value: AppsecWafCustomRuleCondition | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _parameters;
    get parameters(): AppsecWafCustomRuleConditionParametersOutputReference;
    putParameters(value: AppsecWafCustomRuleConditionParameters): void;
    resetParameters(): void;
    get parametersInput(): cdktn.IResolvable | AppsecWafCustomRuleConditionParameters | undefined;
}
export declare class AppsecWafCustomRuleConditionList extends cdktn.ComplexList {
    internalValue?: AppsecWafCustomRuleCondition[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsecWafCustomRuleConditionOutputReference;
}
export interface AppsecWafCustomRuleScope {
    /**
    * The environment scope for the WAF custom rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#env AppsecWafCustomRule#env}
    */
    readonly env?: string;
    /**
    * The service scope for the WAF custom rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#service AppsecWafCustomRule#service}
    */
    readonly service?: string;
}
export declare function appsecWafCustomRuleScopeToTerraform(struct?: AppsecWafCustomRuleScope | cdktn.IResolvable): any;
export declare function appsecWafCustomRuleScopeToHclTerraform(struct?: AppsecWafCustomRuleScope | cdktn.IResolvable): any;
export declare class AppsecWafCustomRuleScopeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsecWafCustomRuleScope | cdktn.IResolvable | undefined;
    set internalValue(value: AppsecWafCustomRuleScope | cdktn.IResolvable | undefined);
    private _env?;
    get env(): string;
    set env(value: string);
    resetEnv(): void;
    get envInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
}
export declare class AppsecWafCustomRuleScopeList extends cdktn.ComplexList {
    internalValue?: AppsecWafCustomRuleScope[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsecWafCustomRuleScopeOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule datadog_appsec_waf_custom_rule}
*/
export declare class AppsecWafCustomRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_appsec_waf_custom_rule";
    /**
    * Generates CDKTN code for importing a AppsecWafCustomRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppsecWafCustomRule to import
    * @param importFromId The id of the existing AppsecWafCustomRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppsecWafCustomRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_custom_rule datadog_appsec_waf_custom_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppsecWafCustomRuleConfig
    */
    constructor(scope: Construct, id: string, config: AppsecWafCustomRuleConfig);
    private _blocking?;
    get blocking(): boolean | cdktn.IResolvable;
    set blocking(value: boolean | cdktn.IResolvable);
    get blockingInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _pathGlob?;
    get pathGlob(): string;
    set pathGlob(value: string);
    resetPathGlob(): void;
    get pathGlobInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _action;
    get action(): AppsecWafCustomRuleActionOutputReference;
    putAction(value: AppsecWafCustomRuleAction): void;
    resetAction(): void;
    get actionInput(): cdktn.IResolvable | AppsecWafCustomRuleAction | undefined;
    private _condition;
    get condition(): AppsecWafCustomRuleConditionList;
    putCondition(value: AppsecWafCustomRuleCondition[] | cdktn.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktn.IResolvable | AppsecWafCustomRuleCondition[] | undefined;
    private _scope;
    get scope(): AppsecWafCustomRuleScopeList;
    putScope(value: AppsecWafCustomRuleScope[] | cdktn.IResolvable): void;
    resetScope(): void;
    get scopeInput(): cdktn.IResolvable | AppsecWafCustomRuleScope[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
