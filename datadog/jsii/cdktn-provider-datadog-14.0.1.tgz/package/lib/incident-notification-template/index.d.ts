/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IncidentNotificationTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * The category of the notification template. Valid values are `alert`, `incident`, `recovery`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_notification_template#category IncidentNotificationTemplate#category}
    */
    readonly category: string;
    /**
    * The content body of the notification template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_notification_template#content IncidentNotificationTemplate#content}
    */
    readonly content: string;
    /**
    * The ID of the incident type this notification template is associated with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_notification_template#incident_type IncidentNotificationTemplate#incident_type}
    */
    readonly incidentType: string;
    /**
    * The name of the notification template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_notification_template#name IncidentNotificationTemplate#name}
    */
    readonly name: string;
    /**
    * The subject line of the notification template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_notification_template#subject IncidentNotificationTemplate#subject}
    */
    readonly subject: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_notification_template datadog_incident_notification_template}
*/
export declare class IncidentNotificationTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_incident_notification_template";
    /**
    * Generates CDKTN code for importing a IncidentNotificationTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IncidentNotificationTemplate to import
    * @param importFromId The id of the existing IncidentNotificationTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_notification_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IncidentNotificationTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_notification_template datadog_incident_notification_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IncidentNotificationTemplateConfig
    */
    constructor(scope: Construct, id: string, config: IncidentNotificationTemplateConfig);
    private _category?;
    get category(): string;
    set category(value: string);
    get categoryInput(): string | undefined;
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    get created(): string;
    get id(): string;
    private _incidentType?;
    get incidentType(): string;
    set incidentType(value: string);
    get incidentTypeInput(): string | undefined;
    get modified(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
