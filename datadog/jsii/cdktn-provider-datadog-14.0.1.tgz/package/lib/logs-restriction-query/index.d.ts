/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LogsRestrictionQueryConfig extends cdktn.TerraformMetaArguments {
    /**
    * The query that defines the restriction. Only the content matching the query can be returned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_restriction_query#restriction_query LogsRestrictionQuery#restriction_query}
    */
    readonly restrictionQuery: string;
    /**
    * An array of role IDs that have access to this restriction query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_restriction_query#role_ids LogsRestrictionQuery#role_ids}
    */
    readonly roleIds?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_restriction_query datadog_logs_restriction_query}
*/
export declare class LogsRestrictionQuery extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_logs_restriction_query";
    /**
    * Generates CDKTN code for importing a LogsRestrictionQuery resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LogsRestrictionQuery to import
    * @param importFromId The id of the existing LogsRestrictionQuery that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_restriction_query#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LogsRestrictionQuery to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_restriction_query datadog_logs_restriction_query} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LogsRestrictionQueryConfig
    */
    constructor(scope: Construct, id: string, config: LogsRestrictionQueryConfig);
    get createdAt(): string;
    get id(): string;
    get modifiedAt(): string;
    private _restrictionQuery?;
    get restrictionQuery(): string;
    set restrictionQuery(value: string);
    get restrictionQueryInput(): string | undefined;
    private _roleIds?;
    get roleIds(): string[];
    set roleIds(value: string[]);
    resetRoleIds(): void;
    get roleIdsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
