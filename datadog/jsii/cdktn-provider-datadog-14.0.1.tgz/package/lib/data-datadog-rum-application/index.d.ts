/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogRumApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the RUM application. Cannot be used with name and type filters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/rum_application#id DataDatadogRumApplication#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name used to search for a RUM application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/rum_application#name_filter DataDatadogRumApplication#name_filter}
    */
    readonly nameFilter?: string;
    /**
    * The type used to search for a RUM application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/rum_application#type_filter DataDatadogRumApplication#type_filter}
    */
    readonly typeFilter?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/rum_application datadog_rum_application}
*/
export declare class DataDatadogRumApplication extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_rum_application";
    /**
    * Generates CDKTN code for importing a DataDatadogRumApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogRumApplication to import
    * @param importFromId The id of the existing DataDatadogRumApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/rum_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogRumApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/rum_application datadog_rum_application} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogRumApplicationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogRumApplicationConfig);
    get apiKeyId(): number;
    get clientToken(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _nameFilter?;
    get nameFilter(): string;
    set nameFilter(value: string);
    resetNameFilter(): void;
    get nameFilterInput(): string | undefined;
    get type(): string;
    private _typeFilter?;
    get typeFilter(): string;
    set typeFilter(value: string);
    resetTypeFilter(): void;
    get typeFilterInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
