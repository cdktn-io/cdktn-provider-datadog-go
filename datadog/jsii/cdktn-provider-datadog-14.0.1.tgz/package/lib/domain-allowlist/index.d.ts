/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DomainAllowlistConfig extends cdktn.TerraformMetaArguments {
    /**
    * The domains within the domain allowlist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/domain_allowlist#domains DomainAllowlist#domains}
    */
    readonly domains: string[];
    /**
    * Whether the Email Domain Allowlist is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/domain_allowlist#enabled DomainAllowlist#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/domain_allowlist datadog_domain_allowlist}
*/
export declare class DomainAllowlist extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_domain_allowlist";
    /**
    * Generates CDKTN code for importing a DomainAllowlist resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DomainAllowlist to import
    * @param importFromId The id of the existing DomainAllowlist that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/domain_allowlist#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DomainAllowlist to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/domain_allowlist datadog_domain_allowlist} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DomainAllowlistConfig
    */
    constructor(scope: Construct, id: string, config: DomainAllowlistConfig);
    private _domains?;
    get domains(): string[];
    set domains(value: string[]);
    get domainsInput(): string[] | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
