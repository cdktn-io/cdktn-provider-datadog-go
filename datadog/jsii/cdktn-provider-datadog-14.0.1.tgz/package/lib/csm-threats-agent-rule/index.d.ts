/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CsmThreatsAgentRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * A description for the Agent rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule#description CsmThreatsAgentRule#description}
    */
    readonly description?: string;
    /**
    * Indicates whether the Agent rule is enabled. Must not be used without policy_id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule#enabled CsmThreatsAgentRule#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The SECL expression of the Agent rule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule#expression CsmThreatsAgentRule#expression}
    */
    readonly expression: string;
    /**
    * The name of the Agent rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule#name CsmThreatsAgentRule#name}
    */
    readonly name: string;
    /**
    * The ID of the agent policy in which the rule is saved
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule#policy_id CsmThreatsAgentRule#policy_id}
    */
    readonly policyId?: string;
    /**
    * The list of product tags associated with the rule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule#product_tags CsmThreatsAgentRule#product_tags}
    */
    readonly productTags?: string[];
    /**
    * Indicates whether the Agent rule is silent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule#silent CsmThreatsAgentRule#silent}
    */
    readonly silent?: boolean | cdktn.IResolvable;
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule#actions CsmThreatsAgentRule#actions}
    */
    readonly actions?: CsmThreatsAgentRuleActions[] | cdktn.IResolvable;
}
export interface CsmThreatsAgentRuleActionsHash {
    /**
    * The field to hash
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule#field CsmThreatsAgentRule#field}
    */
    readonly field?: string;
}
export declare function csmThreatsAgentRuleActionsHashToTerraform(struct?: CsmThreatsAgentRuleActionsHash | cdktn.IResolvable): any;
export declare function csmThreatsAgentRuleActionsHashToHclTerraform(struct?: CsmThreatsAgentRuleActionsHash | cdktn.IResolvable): any;
export declare class CsmThreatsAgentRuleActionsHashOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CsmThreatsAgentRuleActionsHash | cdktn.IResolvable | undefined;
    set internalValue(value: CsmThreatsAgentRuleActionsHash | cdktn.IResolvable | undefined);
    private _field?;
    get field(): string;
    set field(value: string);
    resetField(): void;
    get fieldInput(): string | undefined;
}
export interface CsmThreatsAgentRuleActionsSet {
    /**
    * Whether to append to the set
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule#append CsmThreatsAgentRule#append}
    */
    readonly append?: boolean | cdktn.IResolvable;
    /**
    * The default value to set
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule#default_value CsmThreatsAgentRule#default_value}
    */
    readonly defaultValue?: string;
    /**
    * The expression to use for the set action
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule#expression CsmThreatsAgentRule#expression}
    */
    readonly expression?: string;
    /**
    * The field to get the value from
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule#field CsmThreatsAgentRule#field}
    */
    readonly field?: string;
    /**
    * Whether the set action is inherited
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule#inherited CsmThreatsAgentRule#inherited}
    */
    readonly inherited?: boolean | cdktn.IResolvable;
    /**
    * The name of the set action
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule#name CsmThreatsAgentRule#name}
    */
    readonly name?: string;
    /**
    * The scope of the set action (process, container, cgroup, or empty)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule#scope CsmThreatsAgentRule#scope}
    */
    readonly scope?: string;
    /**
    * The maximum size of the set
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule#size CsmThreatsAgentRule#size}
    */
    readonly size?: number;
    /**
    * The time to live for the set in nanoseconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule#ttl CsmThreatsAgentRule#ttl}
    */
    readonly ttl?: number;
    /**
    * The value to set
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule#value CsmThreatsAgentRule#value}
    */
    readonly value?: string;
}
export declare function csmThreatsAgentRuleActionsSetToTerraform(struct?: CsmThreatsAgentRuleActionsSet | cdktn.IResolvable): any;
export declare function csmThreatsAgentRuleActionsSetToHclTerraform(struct?: CsmThreatsAgentRuleActionsSet | cdktn.IResolvable): any;
export declare class CsmThreatsAgentRuleActionsSetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CsmThreatsAgentRuleActionsSet | cdktn.IResolvable | undefined;
    set internalValue(value: CsmThreatsAgentRuleActionsSet | cdktn.IResolvable | undefined);
    private _append?;
    get append(): boolean | cdktn.IResolvable;
    set append(value: boolean | cdktn.IResolvable);
    resetAppend(): void;
    get appendInput(): boolean | cdktn.IResolvable | undefined;
    private _defaultValue?;
    get defaultValue(): string;
    set defaultValue(value: string);
    resetDefaultValue(): void;
    get defaultValueInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _field?;
    get field(): string;
    set field(value: string);
    resetField(): void;
    get fieldInput(): string | undefined;
    private _inherited?;
    get inherited(): boolean | cdktn.IResolvable;
    set inherited(value: boolean | cdktn.IResolvable);
    resetInherited(): void;
    get inheritedInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    resetTtl(): void;
    get ttlInput(): number | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface CsmThreatsAgentRuleActions {
    /**
    * hash block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule#hash CsmThreatsAgentRule#hash}
    */
    readonly hash?: CsmThreatsAgentRuleActionsHash;
    /**
    * set block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule#set CsmThreatsAgentRule#set}
    */
    readonly set?: CsmThreatsAgentRuleActionsSet;
}
export declare function csmThreatsAgentRuleActionsToTerraform(struct?: CsmThreatsAgentRuleActions | cdktn.IResolvable): any;
export declare function csmThreatsAgentRuleActionsToHclTerraform(struct?: CsmThreatsAgentRuleActions | cdktn.IResolvable): any;
export declare class CsmThreatsAgentRuleActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CsmThreatsAgentRuleActions | cdktn.IResolvable | undefined;
    set internalValue(value: CsmThreatsAgentRuleActions | cdktn.IResolvable | undefined);
    private _hash;
    get hash(): CsmThreatsAgentRuleActionsHashOutputReference;
    putHash(value: CsmThreatsAgentRuleActionsHash): void;
    resetHash(): void;
    get hashInput(): cdktn.IResolvable | CsmThreatsAgentRuleActionsHash | undefined;
    private _set;
    get set(): CsmThreatsAgentRuleActionsSetOutputReference;
    putSet(value: CsmThreatsAgentRuleActionsSet): void;
    resetSet(): void;
    get setInput(): cdktn.IResolvable | CsmThreatsAgentRuleActionsSet | undefined;
}
export declare class CsmThreatsAgentRuleActionsList extends cdktn.ComplexList {
    internalValue?: CsmThreatsAgentRuleActions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CsmThreatsAgentRuleActionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule datadog_csm_threats_agent_rule}
*/
export declare class CsmThreatsAgentRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_csm_threats_agent_rule";
    /**
    * Generates CDKTN code for importing a CsmThreatsAgentRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CsmThreatsAgentRule to import
    * @param importFromId The id of the existing CsmThreatsAgentRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CsmThreatsAgentRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_agent_rule datadog_csm_threats_agent_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CsmThreatsAgentRuleConfig
    */
    constructor(scope: Construct, id: string, config: CsmThreatsAgentRuleConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _productTags?;
    get productTags(): string[];
    set productTags(value: string[]);
    resetProductTags(): void;
    get productTagsInput(): string[] | undefined;
    private _silent?;
    get silent(): boolean | cdktn.IResolvable;
    set silent(value: boolean | cdktn.IResolvable);
    resetSilent(): void;
    get silentInput(): boolean | cdktn.IResolvable | undefined;
    private _actions;
    get actions(): CsmThreatsAgentRuleActionsList;
    putActions(value: CsmThreatsAgentRuleActions[] | cdktn.IResolvable): void;
    resetActions(): void;
    get actionsInput(): cdktn.IResolvable | CsmThreatsAgentRuleActions[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
