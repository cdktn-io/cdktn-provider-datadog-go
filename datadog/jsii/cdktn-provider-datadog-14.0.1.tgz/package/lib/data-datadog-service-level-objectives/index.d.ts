/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogServiceLevelObjectivesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Throw an error if no results are found. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_level_objectives#error_on_empty_result DataDatadogServiceLevelObjectives#error_on_empty_result}
    */
    readonly errorOnEmptyResult?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_level_objectives#id DataDatadogServiceLevelObjectives#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * An array of SLO IDs to limit the search.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_level_objectives#ids DataDatadogServiceLevelObjectives#ids}
    */
    readonly ids?: string[];
    /**
    * Filter results based on SLO numerator and denominator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_level_objectives#metrics_query DataDatadogServiceLevelObjectives#metrics_query}
    */
    readonly metricsQuery?: string;
    /**
    * Filter results based on SLO names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_level_objectives#name_query DataDatadogServiceLevelObjectives#name_query}
    */
    readonly nameQuery?: string;
    /**
    * The query string to filter results based on SLO names. Some examples of queries include service:<service-name> and <slo-name>.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_level_objectives#query DataDatadogServiceLevelObjectives#query}
    */
    readonly query?: string;
    /**
    * Filter results based on a single SLO tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_level_objectives#tags_query DataDatadogServiceLevelObjectives#tags_query}
    */
    readonly tagsQuery?: string;
}
export interface DataDatadogServiceLevelObjectivesSlos {
}
export declare function dataDatadogServiceLevelObjectivesSlosToTerraform(struct?: DataDatadogServiceLevelObjectivesSlos): any;
export declare function dataDatadogServiceLevelObjectivesSlosToHclTerraform(struct?: DataDatadogServiceLevelObjectivesSlos): any;
export declare class DataDatadogServiceLevelObjectivesSlosOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogServiceLevelObjectivesSlos | undefined;
    set internalValue(value: DataDatadogServiceLevelObjectivesSlos | undefined);
    get id(): string;
    get name(): string;
    get type(): string;
}
export declare class DataDatadogServiceLevelObjectivesSlosList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogServiceLevelObjectivesSlosOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_level_objectives datadog_service_level_objectives}
*/
export declare class DataDatadogServiceLevelObjectives extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_service_level_objectives";
    /**
    * Generates CDKTN code for importing a DataDatadogServiceLevelObjectives resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogServiceLevelObjectives to import
    * @param importFromId The id of the existing DataDatadogServiceLevelObjectives that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_level_objectives#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogServiceLevelObjectives to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_level_objectives datadog_service_level_objectives} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogServiceLevelObjectivesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogServiceLevelObjectivesConfig);
    private _errorOnEmptyResult?;
    get errorOnEmptyResult(): boolean | cdktn.IResolvable;
    set errorOnEmptyResult(value: boolean | cdktn.IResolvable);
    resetErrorOnEmptyResult(): void;
    get errorOnEmptyResultInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ids?;
    get ids(): string[];
    set ids(value: string[]);
    resetIds(): void;
    get idsInput(): string[] | undefined;
    private _metricsQuery?;
    get metricsQuery(): string;
    set metricsQuery(value: string);
    resetMetricsQuery(): void;
    get metricsQueryInput(): string | undefined;
    private _nameQuery?;
    get nameQuery(): string;
    set nameQuery(value: string);
    resetNameQuery(): void;
    get nameQueryInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
    private _slos;
    get slos(): DataDatadogServiceLevelObjectivesSlosList;
    private _tagsQuery?;
    get tagsQuery(): string;
    set tagsQuery(value: string);
    resetTagsQuery(): void;
    get tagsQueryInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
