/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogCsmThreatsAgentRulesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Listing only the rules in the policy with this field as the ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/csm_threats_agent_rules#policy_id DataDatadogCsmThreatsAgentRules#policy_id}
    */
    readonly policyId?: string;
}
export interface DataDatadogCsmThreatsAgentRulesAgentRulesActionsHash {
}
export declare function dataDatadogCsmThreatsAgentRulesAgentRulesActionsHashToTerraform(struct?: DataDatadogCsmThreatsAgentRulesAgentRulesActionsHash): any;
export declare function dataDatadogCsmThreatsAgentRulesAgentRulesActionsHashToHclTerraform(struct?: DataDatadogCsmThreatsAgentRulesAgentRulesActionsHash): any;
export declare class DataDatadogCsmThreatsAgentRulesAgentRulesActionsHashOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogCsmThreatsAgentRulesAgentRulesActionsHash | undefined;
    set internalValue(value: DataDatadogCsmThreatsAgentRulesAgentRulesActionsHash | undefined);
    get field(): string;
}
export interface DataDatadogCsmThreatsAgentRulesAgentRulesActionsSet {
}
export declare function dataDatadogCsmThreatsAgentRulesAgentRulesActionsSetToTerraform(struct?: DataDatadogCsmThreatsAgentRulesAgentRulesActionsSet): any;
export declare function dataDatadogCsmThreatsAgentRulesAgentRulesActionsSetToHclTerraform(struct?: DataDatadogCsmThreatsAgentRulesAgentRulesActionsSet): any;
export declare class DataDatadogCsmThreatsAgentRulesAgentRulesActionsSetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogCsmThreatsAgentRulesAgentRulesActionsSet | undefined;
    set internalValue(value: DataDatadogCsmThreatsAgentRulesAgentRulesActionsSet | undefined);
    get append(): cdktn.IResolvable;
    get defaultValue(): string;
    get expression(): string;
    get field(): string;
    get inherited(): cdktn.IResolvable;
    get name(): string;
    get scope(): string;
    get size(): number;
    get ttl(): number;
    get value(): string;
}
export interface DataDatadogCsmThreatsAgentRulesAgentRulesActions {
}
export declare function dataDatadogCsmThreatsAgentRulesAgentRulesActionsToTerraform(struct?: DataDatadogCsmThreatsAgentRulesAgentRulesActions): any;
export declare function dataDatadogCsmThreatsAgentRulesAgentRulesActionsToHclTerraform(struct?: DataDatadogCsmThreatsAgentRulesAgentRulesActions): any;
export declare class DataDatadogCsmThreatsAgentRulesAgentRulesActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogCsmThreatsAgentRulesAgentRulesActions | undefined;
    set internalValue(value: DataDatadogCsmThreatsAgentRulesAgentRulesActions | undefined);
    private _hash;
    get hash(): DataDatadogCsmThreatsAgentRulesAgentRulesActionsHashOutputReference;
    private _set;
    get set(): DataDatadogCsmThreatsAgentRulesAgentRulesActionsSetOutputReference;
}
export declare class DataDatadogCsmThreatsAgentRulesAgentRulesActionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogCsmThreatsAgentRulesAgentRulesActionsOutputReference;
}
export interface DataDatadogCsmThreatsAgentRulesAgentRules {
}
export declare function dataDatadogCsmThreatsAgentRulesAgentRulesToTerraform(struct?: DataDatadogCsmThreatsAgentRulesAgentRules): any;
export declare function dataDatadogCsmThreatsAgentRulesAgentRulesToHclTerraform(struct?: DataDatadogCsmThreatsAgentRulesAgentRules): any;
export declare class DataDatadogCsmThreatsAgentRulesAgentRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogCsmThreatsAgentRulesAgentRules | undefined;
    set internalValue(value: DataDatadogCsmThreatsAgentRulesAgentRules | undefined);
    private _actions;
    get actions(): DataDatadogCsmThreatsAgentRulesAgentRulesActionsList;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get expression(): string;
    get id(): string;
    get name(): string;
    get productTags(): string[];
}
export declare class DataDatadogCsmThreatsAgentRulesAgentRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogCsmThreatsAgentRulesAgentRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/csm_threats_agent_rules datadog_csm_threats_agent_rules}
*/
export declare class DataDatadogCsmThreatsAgentRules extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_csm_threats_agent_rules";
    /**
    * Generates CDKTN code for importing a DataDatadogCsmThreatsAgentRules resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogCsmThreatsAgentRules to import
    * @param importFromId The id of the existing DataDatadogCsmThreatsAgentRules that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/csm_threats_agent_rules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogCsmThreatsAgentRules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/csm_threats_agent_rules datadog_csm_threats_agent_rules} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogCsmThreatsAgentRulesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogCsmThreatsAgentRulesConfig);
    private _agentRules;
    get agentRules(): DataDatadogCsmThreatsAgentRulesAgentRulesList;
    get agentRulesIds(): string[];
    get id(): string;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
