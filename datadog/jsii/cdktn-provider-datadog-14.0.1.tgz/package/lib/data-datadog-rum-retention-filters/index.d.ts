/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogRumRetentionFiltersConfig extends cdktn.TerraformMetaArguments {
    /**
    * RUM application ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/rum_retention_filters#application_id DataDatadogRumRetentionFilters#application_id}
    */
    readonly applicationId: string;
}
export interface DataDatadogRumRetentionFiltersRetentionFilters {
}
export declare function dataDatadogRumRetentionFiltersRetentionFiltersToTerraform(struct?: DataDatadogRumRetentionFiltersRetentionFilters): any;
export declare function dataDatadogRumRetentionFiltersRetentionFiltersToHclTerraform(struct?: DataDatadogRumRetentionFiltersRetentionFilters): any;
export declare class DataDatadogRumRetentionFiltersRetentionFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogRumRetentionFiltersRetentionFilters | undefined;
    set internalValue(value: DataDatadogRumRetentionFiltersRetentionFilters | undefined);
    get enabled(): cdktn.IResolvable;
    get eventType(): string;
    get id(): string;
    get name(): string;
    get query(): string;
    get sampleRate(): number;
}
export declare class DataDatadogRumRetentionFiltersRetentionFiltersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogRumRetentionFiltersRetentionFiltersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/rum_retention_filters datadog_rum_retention_filters}
*/
export declare class DataDatadogRumRetentionFilters extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_rum_retention_filters";
    /**
    * Generates CDKTN code for importing a DataDatadogRumRetentionFilters resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogRumRetentionFilters to import
    * @param importFromId The id of the existing DataDatadogRumRetentionFilters that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/rum_retention_filters#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogRumRetentionFilters to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/rum_retention_filters datadog_rum_retention_filters} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogRumRetentionFiltersConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogRumRetentionFiltersConfig);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    get id(): string;
    private _retentionFilters;
    get retentionFilters(): DataDatadogRumRetentionFiltersRetentionFiltersList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
