/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DashboardListConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the Dashboard List
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard_list#name DashboardList#name}
    */
    readonly name: string;
    /**
    * dash_item block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard_list#dash_item DashboardList#dash_item}
    */
    readonly dashItem?: DashboardListDashItem[] | cdktn.IResolvable;
}
export interface DashboardListDashItem {
    /**
    * The ID of the dashboard to add
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard_list#dash_id DashboardList#dash_id}
    */
    readonly dashId: string;
    /**
    * The type of this dashboard. Valid values are `custom_timeboard`, `custom_screenboard`, `integration_screenboard`, `integration_timeboard`, `host_timeboard`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard_list#type DashboardList#type}
    */
    readonly type: string;
}
export declare function dashboardListDashItemToTerraform(struct?: DashboardListDashItem | cdktn.IResolvable): any;
export declare function dashboardListDashItemToHclTerraform(struct?: DashboardListDashItem | cdktn.IResolvable): any;
export declare class DashboardListDashItemOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardListDashItem | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardListDashItem | cdktn.IResolvable | undefined);
    private _dashId?;
    get dashId(): string;
    set dashId(value: string);
    get dashIdInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class DashboardListDashItemList extends cdktn.ComplexList {
    internalValue?: DashboardListDashItem[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardListDashItemOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard_list datadog_dashboard_list}
*/
export declare class DashboardList extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_dashboard_list";
    /**
    * Generates CDKTN code for importing a DashboardList resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DashboardList to import
    * @param importFromId The id of the existing DashboardList that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard_list#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DashboardList to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard_list datadog_dashboard_list} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DashboardListConfig
    */
    constructor(scope: Construct, id: string, config: DashboardListConfig);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _dashItem;
    get dashItem(): DashboardListDashItemList;
    putDashItem(value: DashboardListDashItem[] | cdktn.IResolvable): void;
    resetDashItem(): void;
    get dashItemInput(): cdktn.IResolvable | DashboardListDashItem[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
