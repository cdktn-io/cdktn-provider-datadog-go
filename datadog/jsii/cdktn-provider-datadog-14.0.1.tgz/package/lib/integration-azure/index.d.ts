/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IntegrationAzureConfig extends cdktn.TerraformMetaArguments {
    /**
    * This comma-separated list of tags (in the form `key:value,key:value`) defines a filter that Datadog uses when collecting metrics from Azure App Service Plans. Only App Service Plans that match one of the defined tags are imported into Datadog. The rest, including the apps and functions running on them, are ignored. This also filters the metrics for any App or Function running on the App Service Plan(s). Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_azure#app_service_plan_filters IntegrationAzure#app_service_plan_filters}
    */
    readonly appServicePlanFilters?: string;
    /**
    * Silence monitors for expected Azure VM shutdowns. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_azure#automute IntegrationAzure#automute}
    */
    readonly automute?: boolean | cdktn.IResolvable;
    /**
    * Your Azure web application ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_azure#client_id IntegrationAzure#client_id}
    */
    readonly clientId: string;
    /**
    * (Required for Initial Creation) Your Azure web application secret key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_azure#client_secret IntegrationAzure#client_secret}
    */
    readonly clientSecret: string;
    /**
    * This comma-separated list of tags (in the form `key:value,key:value`) defines a filter that Datadog uses when collecting metrics from Azure Container Apps. Only Container Apps that match one of the defined tags are imported into Datadog. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_azure#container_app_filters IntegrationAzure#container_app_filters}
    */
    readonly containerAppFilters?: string;
    /**
    * When enabled, Datadog’s Cloud Security Management product scans resource configurations monitored by this app registration.
    * Note: This requires `resource_collection_enabled` to be set to true. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_azure#cspm_enabled IntegrationAzure#cspm_enabled}
    */
    readonly cspmEnabled?: boolean | cdktn.IResolvable;
    /**
    * Enable custom metrics for your organization. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_azure#custom_metrics_enabled IntegrationAzure#custom_metrics_enabled}
    */
    readonly customMetricsEnabled?: boolean | cdktn.IResolvable;
    /**
    * String of host tag(s) (in the form `key:value,key:value`) defines a filter that Datadog will use when collecting metrics from Azure. Limit the Azure instances that are pulled into Datadog by using tags. Only hosts that match one of the defined tags are imported into Datadog. e.x. `env:production,deploymentgroup:red` Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_azure#host_filters IntegrationAzure#host_filters}
    */
    readonly hostFilters?: string;
    /**
    * Enable Azure metrics for your organization. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_azure#metrics_enabled IntegrationAzure#metrics_enabled}
    */
    readonly metricsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Enable Azure metrics for your organization for resource providers where no resource provider config is specified. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_azure#metrics_enabled_default IntegrationAzure#metrics_enabled_default}
    */
    readonly metricsEnabledDefault?: boolean | cdktn.IResolvable;
    /**
    * When enabled, Datadog collects metadata and configuration info from cloud resources (such as compute instances, databases, and load balancers) monitored by this app registration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_azure#resource_collection_enabled IntegrationAzure#resource_collection_enabled}
    */
    readonly resourceCollectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Configuration settings applied to resources from the specified Azure resource providers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_azure#resource_provider_configs IntegrationAzure#resource_provider_configs}
    */
    readonly resourceProviderConfigs?: IntegrationAzureResourceProviderConfigs[] | cdktn.IResolvable;
    /**
    * Your Azure Active Directory ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_azure#tenant_name IntegrationAzure#tenant_name}
    */
    readonly tenantName: string;
    /**
    * Enable azure.usage metrics for your organization. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_azure#usage_metrics_enabled IntegrationAzure#usage_metrics_enabled}
    */
    readonly usageMetricsEnabled?: boolean | cdktn.IResolvable;
}
export interface IntegrationAzureResourceProviderConfigs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_azure#metrics_enabled IntegrationAzure#metrics_enabled}
    */
    readonly metricsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_azure#namespace IntegrationAzure#namespace}
    */
    readonly namespace?: string;
}
export declare function integrationAzureResourceProviderConfigsToTerraform(struct?: IntegrationAzureResourceProviderConfigs | cdktn.IResolvable): any;
export declare function integrationAzureResourceProviderConfigsToHclTerraform(struct?: IntegrationAzureResourceProviderConfigs | cdktn.IResolvable): any;
export declare class IntegrationAzureResourceProviderConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IntegrationAzureResourceProviderConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: IntegrationAzureResourceProviderConfigs | cdktn.IResolvable | undefined);
    private _metricsEnabled?;
    get metricsEnabled(): boolean | cdktn.IResolvable;
    set metricsEnabled(value: boolean | cdktn.IResolvable);
    resetMetricsEnabled(): void;
    get metricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export declare class IntegrationAzureResourceProviderConfigsList extends cdktn.ComplexList {
    internalValue?: IntegrationAzureResourceProviderConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IntegrationAzureResourceProviderConfigsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_azure datadog_integration_azure}
*/
export declare class IntegrationAzure extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_integration_azure";
    /**
    * Generates CDKTN code for importing a IntegrationAzure resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IntegrationAzure to import
    * @param importFromId The id of the existing IntegrationAzure that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_azure#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IntegrationAzure to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_azure datadog_integration_azure} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IntegrationAzureConfig
    */
    constructor(scope: Construct, id: string, config: IntegrationAzureConfig);
    private _appServicePlanFilters?;
    get appServicePlanFilters(): string;
    set appServicePlanFilters(value: string);
    resetAppServicePlanFilters(): void;
    get appServicePlanFiltersInput(): string | undefined;
    private _automute?;
    get automute(): boolean | cdktn.IResolvable;
    set automute(value: boolean | cdktn.IResolvable);
    resetAutomute(): void;
    get automuteInput(): boolean | cdktn.IResolvable | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    get clientSecretInput(): string | undefined;
    private _containerAppFilters?;
    get containerAppFilters(): string;
    set containerAppFilters(value: string);
    resetContainerAppFilters(): void;
    get containerAppFiltersInput(): string | undefined;
    private _cspmEnabled?;
    get cspmEnabled(): boolean | cdktn.IResolvable;
    set cspmEnabled(value: boolean | cdktn.IResolvable);
    resetCspmEnabled(): void;
    get cspmEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _customMetricsEnabled?;
    get customMetricsEnabled(): boolean | cdktn.IResolvable;
    set customMetricsEnabled(value: boolean | cdktn.IResolvable);
    resetCustomMetricsEnabled(): void;
    get customMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _hostFilters?;
    get hostFilters(): string;
    set hostFilters(value: string);
    resetHostFilters(): void;
    get hostFiltersInput(): string | undefined;
    get id(): string;
    private _metricsEnabled?;
    get metricsEnabled(): boolean | cdktn.IResolvable;
    set metricsEnabled(value: boolean | cdktn.IResolvable);
    resetMetricsEnabled(): void;
    get metricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _metricsEnabledDefault?;
    get metricsEnabledDefault(): boolean | cdktn.IResolvable;
    set metricsEnabledDefault(value: boolean | cdktn.IResolvable);
    resetMetricsEnabledDefault(): void;
    get metricsEnabledDefaultInput(): boolean | cdktn.IResolvable | undefined;
    private _resourceCollectionEnabled?;
    get resourceCollectionEnabled(): boolean | cdktn.IResolvable;
    set resourceCollectionEnabled(value: boolean | cdktn.IResolvable);
    resetResourceCollectionEnabled(): void;
    get resourceCollectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _resourceProviderConfigs;
    get resourceProviderConfigs(): IntegrationAzureResourceProviderConfigsList;
    putResourceProviderConfigs(value: IntegrationAzureResourceProviderConfigs[] | cdktn.IResolvable): void;
    resetResourceProviderConfigs(): void;
    get resourceProviderConfigsInput(): cdktn.IResolvable | IntegrationAzureResourceProviderConfigs[] | undefined;
    private _tenantName?;
    get tenantName(): string;
    set tenantName(value: string);
    get tenantNameInput(): string | undefined;
    private _usageMetricsEnabled?;
    get usageMetricsEnabled(): boolean | cdktn.IResolvable;
    set usageMetricsEnabled(value: boolean | cdktn.IResolvable);
    resetUsageMetricsEnabled(): void;
    get usageMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
