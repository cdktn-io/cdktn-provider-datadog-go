/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ActionConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Name of the connection
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection#name ActionConnection#name}
    */
    readonly name: string;
    /**
    * aws block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection#aws ActionConnection#aws}
    */
    readonly aws?: ActionConnectionAws;
    /**
    * http block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection#http ActionConnection#http}
    */
    readonly http?: ActionConnectionHttp;
}
export interface ActionConnectionAwsAssumeRole {
    /**
    * AWS account that the connection is created for. String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection#account_id ActionConnection#account_id}
    */
    readonly accountId?: string;
    /**
    * Role to assume. String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection#role ActionConnection#role}
    */
    readonly role?: string;
}
export declare function actionConnectionAwsAssumeRoleToTerraform(struct?: ActionConnectionAwsAssumeRole | cdktn.IResolvable): any;
export declare function actionConnectionAwsAssumeRoleToHclTerraform(struct?: ActionConnectionAwsAssumeRole | cdktn.IResolvable): any;
export declare class ActionConnectionAwsAssumeRoleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ActionConnectionAwsAssumeRole | cdktn.IResolvable | undefined;
    set internalValue(value: ActionConnectionAwsAssumeRole | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get externalId(): string;
    get principalId(): string;
    private _role?;
    get role(): string;
    set role(value: string);
    resetRole(): void;
    get roleInput(): string | undefined;
}
export interface ActionConnectionAws {
    /**
    * assume_role block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection#assume_role ActionConnection#assume_role}
    */
    readonly assumeRole?: ActionConnectionAwsAssumeRole;
}
export declare function actionConnectionAwsToTerraform(struct?: ActionConnectionAws | cdktn.IResolvable): any;
export declare function actionConnectionAwsToHclTerraform(struct?: ActionConnectionAws | cdktn.IResolvable): any;
export declare class ActionConnectionAwsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ActionConnectionAws | cdktn.IResolvable | undefined;
    set internalValue(value: ActionConnectionAws | cdktn.IResolvable | undefined);
    private _assumeRole;
    get assumeRole(): ActionConnectionAwsAssumeRoleOutputReference;
    putAssumeRole(value: ActionConnectionAwsAssumeRole): void;
    resetAssumeRole(): void;
    get assumeRoleInput(): ActionConnectionAwsAssumeRole | cdktn.IResolvable | undefined;
}
export interface ActionConnectionHttpTokenAuthBody {
    /**
    * Serialized body content. String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection#content ActionConnection#content}
    */
    readonly content?: string;
    /**
    * Content type of the body. String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection#content_type ActionConnection#content_type}
    */
    readonly contentType?: string;
}
export declare function actionConnectionHttpTokenAuthBodyToTerraform(struct?: ActionConnectionHttpTokenAuthBody | cdktn.IResolvable): any;
export declare function actionConnectionHttpTokenAuthBodyToHclTerraform(struct?: ActionConnectionHttpTokenAuthBody | cdktn.IResolvable): any;
export declare class ActionConnectionHttpTokenAuthBodyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ActionConnectionHttpTokenAuthBody | cdktn.IResolvable | undefined;
    set internalValue(value: ActionConnectionHttpTokenAuthBody | cdktn.IResolvable | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    private _contentType?;
    get contentType(): string;
    set contentType(value: string);
    resetContentType(): void;
    get contentTypeInput(): string | undefined;
}
export interface ActionConnectionHttpTokenAuthHeader {
    /**
    * Header name. String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection#name ActionConnection#name}
    */
    readonly name?: string;
    /**
    *  String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection#value ActionConnection#value}
    */
    readonly value?: string;
}
export declare function actionConnectionHttpTokenAuthHeaderToTerraform(struct?: ActionConnectionHttpTokenAuthHeader | cdktn.IResolvable): any;
export declare function actionConnectionHttpTokenAuthHeaderToHclTerraform(struct?: ActionConnectionHttpTokenAuthHeader | cdktn.IResolvable): any;
export declare class ActionConnectionHttpTokenAuthHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ActionConnectionHttpTokenAuthHeader | cdktn.IResolvable | undefined;
    set internalValue(value: ActionConnectionHttpTokenAuthHeader | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ActionConnectionHttpTokenAuthHeaderList extends cdktn.ComplexList {
    internalValue?: ActionConnectionHttpTokenAuthHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ActionConnectionHttpTokenAuthHeaderOutputReference;
}
export interface ActionConnectionHttpTokenAuthToken {
    /**
    * Token name. String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection#name ActionConnection#name}
    */
    readonly name?: string;
    /**
    * Token type Valid values are `SECRET`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection#type ActionConnection#type}
    */
    readonly type?: string;
    /**
    * Token value. String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection#value ActionConnection#value}
    */
    readonly value?: string;
}
export declare function actionConnectionHttpTokenAuthTokenToTerraform(struct?: ActionConnectionHttpTokenAuthToken | cdktn.IResolvable): any;
export declare function actionConnectionHttpTokenAuthTokenToHclTerraform(struct?: ActionConnectionHttpTokenAuthToken | cdktn.IResolvable): any;
export declare class ActionConnectionHttpTokenAuthTokenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ActionConnectionHttpTokenAuthToken | cdktn.IResolvable | undefined;
    set internalValue(value: ActionConnectionHttpTokenAuthToken | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ActionConnectionHttpTokenAuthTokenList extends cdktn.ComplexList {
    internalValue?: ActionConnectionHttpTokenAuthToken[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ActionConnectionHttpTokenAuthTokenOutputReference;
}
export interface ActionConnectionHttpTokenAuthUrlParameter {
    /**
    * URL parameter name. String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection#name ActionConnection#name}
    */
    readonly name?: string;
    /**
    * URL parameter value. String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection#value ActionConnection#value}
    */
    readonly value?: string;
}
export declare function actionConnectionHttpTokenAuthUrlParameterToTerraform(struct?: ActionConnectionHttpTokenAuthUrlParameter | cdktn.IResolvable): any;
export declare function actionConnectionHttpTokenAuthUrlParameterToHclTerraform(struct?: ActionConnectionHttpTokenAuthUrlParameter | cdktn.IResolvable): any;
export declare class ActionConnectionHttpTokenAuthUrlParameterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ActionConnectionHttpTokenAuthUrlParameter | cdktn.IResolvable | undefined;
    set internalValue(value: ActionConnectionHttpTokenAuthUrlParameter | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ActionConnectionHttpTokenAuthUrlParameterList extends cdktn.ComplexList {
    internalValue?: ActionConnectionHttpTokenAuthUrlParameter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ActionConnectionHttpTokenAuthUrlParameterOutputReference;
}
export interface ActionConnectionHttpTokenAuth {
    /**
    * body block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection#body ActionConnection#body}
    */
    readonly body?: ActionConnectionHttpTokenAuthBody;
    /**
    * header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection#header ActionConnection#header}
    */
    readonly header?: ActionConnectionHttpTokenAuthHeader[] | cdktn.IResolvable;
    /**
    * token block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection#token ActionConnection#token}
    */
    readonly token?: ActionConnectionHttpTokenAuthToken[] | cdktn.IResolvable;
    /**
    * url_parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection#url_parameter ActionConnection#url_parameter}
    */
    readonly urlParameter?: ActionConnectionHttpTokenAuthUrlParameter[] | cdktn.IResolvable;
}
export declare function actionConnectionHttpTokenAuthToTerraform(struct?: ActionConnectionHttpTokenAuth | cdktn.IResolvable): any;
export declare function actionConnectionHttpTokenAuthToHclTerraform(struct?: ActionConnectionHttpTokenAuth | cdktn.IResolvable): any;
export declare class ActionConnectionHttpTokenAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ActionConnectionHttpTokenAuth | cdktn.IResolvable | undefined;
    set internalValue(value: ActionConnectionHttpTokenAuth | cdktn.IResolvable | undefined);
    private _body;
    get body(): ActionConnectionHttpTokenAuthBodyOutputReference;
    putBody(value: ActionConnectionHttpTokenAuthBody): void;
    resetBody(): void;
    get bodyInput(): cdktn.IResolvable | ActionConnectionHttpTokenAuthBody | undefined;
    private _header;
    get header(): ActionConnectionHttpTokenAuthHeaderList;
    putHeader(value: ActionConnectionHttpTokenAuthHeader[] | cdktn.IResolvable): void;
    resetHeader(): void;
    get headerInput(): cdktn.IResolvable | ActionConnectionHttpTokenAuthHeader[] | undefined;
    private _token;
    get token(): ActionConnectionHttpTokenAuthTokenList;
    putToken(value: ActionConnectionHttpTokenAuthToken[] | cdktn.IResolvable): void;
    resetToken(): void;
    get tokenInput(): cdktn.IResolvable | ActionConnectionHttpTokenAuthToken[] | undefined;
    private _urlParameter;
    get urlParameter(): ActionConnectionHttpTokenAuthUrlParameterList;
    putUrlParameter(value: ActionConnectionHttpTokenAuthUrlParameter[] | cdktn.IResolvable): void;
    resetUrlParameter(): void;
    get urlParameterInput(): cdktn.IResolvable | ActionConnectionHttpTokenAuthUrlParameter[] | undefined;
}
export interface ActionConnectionHttp {
    /**
    * Base HTTP url for the integration. String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection#base_url ActionConnection#base_url}
    */
    readonly baseUrl?: string;
    /**
    * token_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection#token_auth ActionConnection#token_auth}
    */
    readonly tokenAuth?: ActionConnectionHttpTokenAuth;
}
export declare function actionConnectionHttpToTerraform(struct?: ActionConnectionHttp | cdktn.IResolvable): any;
export declare function actionConnectionHttpToHclTerraform(struct?: ActionConnectionHttp | cdktn.IResolvable): any;
export declare class ActionConnectionHttpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ActionConnectionHttp | cdktn.IResolvable | undefined;
    set internalValue(value: ActionConnectionHttp | cdktn.IResolvable | undefined);
    private _baseUrl?;
    get baseUrl(): string;
    set baseUrl(value: string);
    resetBaseUrl(): void;
    get baseUrlInput(): string | undefined;
    private _tokenAuth;
    get tokenAuth(): ActionConnectionHttpTokenAuthOutputReference;
    putTokenAuth(value: ActionConnectionHttpTokenAuth): void;
    resetTokenAuth(): void;
    get tokenAuthInput(): cdktn.IResolvable | ActionConnectionHttpTokenAuth | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection datadog_action_connection}
*/
export declare class ActionConnection extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_action_connection";
    /**
    * Generates CDKTN code for importing a ActionConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ActionConnection to import
    * @param importFromId The id of the existing ActionConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ActionConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/action_connection datadog_action_connection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ActionConnectionConfig
    */
    constructor(scope: Construct, id: string, config: ActionConnectionConfig);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _aws;
    get aws(): ActionConnectionAwsOutputReference;
    putAws(value: ActionConnectionAws): void;
    resetAws(): void;
    get awsInput(): ActionConnectionAws | cdktn.IResolvable | undefined;
    private _http;
    get http(): ActionConnectionHttpOutputReference;
    putHttp(value: ActionConnectionHttp): void;
    resetHttp(): void;
    get httpInput(): ActionConnectionHttp | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
