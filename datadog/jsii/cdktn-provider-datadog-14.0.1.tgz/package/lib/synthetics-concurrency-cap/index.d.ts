/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SyntheticsConcurrencyCapConfig extends cdktn.TerraformMetaArguments {
    /**
    * Value of the on-demand concurrency cap, customizing the number of Synthetic tests run in parallel. Value must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_concurrency_cap#on_demand_concurrency_cap SyntheticsConcurrencyCap#on_demand_concurrency_cap}
    */
    readonly onDemandConcurrencyCap: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_concurrency_cap datadog_synthetics_concurrency_cap}
*/
export declare class SyntheticsConcurrencyCap extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_synthetics_concurrency_cap";
    /**
    * Generates CDKTN code for importing a SyntheticsConcurrencyCap resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SyntheticsConcurrencyCap to import
    * @param importFromId The id of the existing SyntheticsConcurrencyCap that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_concurrency_cap#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SyntheticsConcurrencyCap to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_concurrency_cap datadog_synthetics_concurrency_cap} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SyntheticsConcurrencyCapConfig
    */
    constructor(scope: Construct, id: string, config: SyntheticsConcurrencyCapConfig);
    get id(): string;
    private _onDemandConcurrencyCap?;
    get onDemandConcurrencyCap(): number;
    set onDemandConcurrencyCap(value: number);
    get onDemandConcurrencyCapInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
