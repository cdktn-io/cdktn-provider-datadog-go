/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IncidentNotificationRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether the notification rule is enabled. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_notification_rule#enabled IncidentNotificationRule#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The notification handles (targets) for this rule. Examples: @team-email@company.com, @slack-channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_notification_rule#handles IncidentNotificationRule#handles}
    */
    readonly handles: string[];
    /**
    * The ID of the incident type this notification rule is associated with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_notification_rule#incident_type IncidentNotificationRule#incident_type}
    */
    readonly incidentType: string;
    /**
    * The ID of the notification template to use for this rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_notification_rule#notification_template IncidentNotificationRule#notification_template}
    */
    readonly notificationTemplate?: string;
    /**
    * List of incident fields that trigger re-notification when changed. Valid values are: status, severity, customer_impact, title, description, detected, root_cause, services, state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_notification_rule#renotify_on IncidentNotificationRule#renotify_on}
    */
    readonly renotifyOn?: string[];
    /**
    * The trigger event for this notification rule. Valid values are: incident_created_trigger, incident_saved_trigger.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_notification_rule#trigger IncidentNotificationRule#trigger}
    */
    readonly trigger: string;
    /**
    * The visibility of the notification rule. Valid values are: all, organization, private. Defaults to organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_notification_rule#visibility IncidentNotificationRule#visibility}
    */
    readonly visibility?: string;
    /**
    * conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_notification_rule#conditions IncidentNotificationRule#conditions}
    */
    readonly conditions?: IncidentNotificationRuleConditions[] | cdktn.IResolvable;
}
export interface IncidentNotificationRuleConditions {
    /**
    * The incident field to evaluate. Common values include: state, severity, services, teams. Custom fields are also supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_notification_rule#field IncidentNotificationRule#field}
    */
    readonly field: string;
    /**
    * The value(s) to compare against. Multiple values are ORed together.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_notification_rule#values IncidentNotificationRule#values}
    */
    readonly values: string[];
}
export declare function incidentNotificationRuleConditionsToTerraform(struct?: IncidentNotificationRuleConditions | cdktn.IResolvable): any;
export declare function incidentNotificationRuleConditionsToHclTerraform(struct?: IncidentNotificationRuleConditions | cdktn.IResolvable): any;
export declare class IncidentNotificationRuleConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IncidentNotificationRuleConditions | cdktn.IResolvable | undefined;
    set internalValue(value: IncidentNotificationRuleConditions | cdktn.IResolvable | undefined);
    private _field?;
    get field(): string;
    set field(value: string);
    get fieldInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class IncidentNotificationRuleConditionsList extends cdktn.ComplexList {
    internalValue?: IncidentNotificationRuleConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IncidentNotificationRuleConditionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_notification_rule datadog_incident_notification_rule}
*/
export declare class IncidentNotificationRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_incident_notification_rule";
    /**
    * Generates CDKTN code for importing a IncidentNotificationRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IncidentNotificationRule to import
    * @param importFromId The id of the existing IncidentNotificationRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_notification_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IncidentNotificationRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_notification_rule datadog_incident_notification_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IncidentNotificationRuleConfig
    */
    constructor(scope: Construct, id: string, config: IncidentNotificationRuleConfig);
    get created(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _handles?;
    get handles(): string[];
    set handles(value: string[]);
    get handlesInput(): string[] | undefined;
    get id(): string;
    private _incidentType?;
    get incidentType(): string;
    set incidentType(value: string);
    get incidentTypeInput(): string | undefined;
    get modified(): string;
    private _notificationTemplate?;
    get notificationTemplate(): string;
    set notificationTemplate(value: string);
    resetNotificationTemplate(): void;
    get notificationTemplateInput(): string | undefined;
    private _renotifyOn?;
    get renotifyOn(): string[];
    set renotifyOn(value: string[]);
    resetRenotifyOn(): void;
    get renotifyOnInput(): string[] | undefined;
    private _trigger?;
    get trigger(): string;
    set trigger(value: string);
    get triggerInput(): string | undefined;
    private _visibility?;
    get visibility(): string;
    set visibility(value: string);
    resetVisibility(): void;
    get visibilityInput(): string | undefined;
    private _conditions;
    get conditions(): IncidentNotificationRuleConditionsList;
    putConditions(value: IncidentNotificationRuleConditions[] | cdktn.IResolvable): void;
    resetConditions(): void;
    get conditionsInput(): cdktn.IResolvable | IncidentNotificationRuleConditions[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
