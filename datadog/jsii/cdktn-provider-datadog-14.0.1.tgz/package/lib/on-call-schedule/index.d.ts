/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OnCallScheduleConfig extends cdktn.TerraformMetaArguments {
    /**
    * A human-readable name for the new schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_schedule#name OnCallSchedule#name}
    */
    readonly name: string;
    /**
    * A list of team ids associated with the schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_schedule#teams OnCallSchedule#teams}
    */
    readonly teams?: string[];
    /**
    * The time zone in which the schedule is defined.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_schedule#time_zone OnCallSchedule#time_zone}
    */
    readonly timeZone: string;
    /**
    * layer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_schedule#layer OnCallSchedule#layer}
    */
    readonly layer?: OnCallScheduleLayer[] | cdktn.IResolvable;
}
export interface OnCallScheduleLayerInterval {
    /**
    * The number of full days in each rotation period.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_schedule#days OnCallSchedule#days}
    */
    readonly days?: number;
    /**
    * For intervals that are not expressible in whole days, this will be added to `days`. Defaults to `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_schedule#seconds OnCallSchedule#seconds}
    */
    readonly seconds?: number;
}
export declare function onCallScheduleLayerIntervalToTerraform(struct?: OnCallScheduleLayerInterval | cdktn.IResolvable): any;
export declare function onCallScheduleLayerIntervalToHclTerraform(struct?: OnCallScheduleLayerInterval | cdktn.IResolvable): any;
export declare class OnCallScheduleLayerIntervalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OnCallScheduleLayerInterval | cdktn.IResolvable | undefined;
    set internalValue(value: OnCallScheduleLayerInterval | cdktn.IResolvable | undefined);
    private _days?;
    get days(): number;
    set days(value: number);
    resetDays(): void;
    get daysInput(): number | undefined;
    private _seconds?;
    get seconds(): number;
    set seconds(value: number);
    resetSeconds(): void;
    get secondsInput(): number | undefined;
}
export interface OnCallScheduleLayerRestriction {
    /**
    * The weekday when the restriction period ends. Valid values are `monday`, `tuesday`, `wednesday`, `thursday`, `friday`, `saturday`, `sunday`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_schedule#end_day OnCallSchedule#end_day}
    */
    readonly endDay: string;
    /**
    * The time of day when the restriction ends (hh:mm:ss).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_schedule#end_time OnCallSchedule#end_time}
    */
    readonly endTime: string;
    /**
    * The weekday when the restriction period starts. Valid values are `monday`, `tuesday`, `wednesday`, `thursday`, `friday`, `saturday`, `sunday`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_schedule#start_day OnCallSchedule#start_day}
    */
    readonly startDay: string;
    /**
    * The time of day when the restriction begins (hh:mm:ss).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_schedule#start_time OnCallSchedule#start_time}
    */
    readonly startTime: string;
}
export declare function onCallScheduleLayerRestrictionToTerraform(struct?: OnCallScheduleLayerRestriction | cdktn.IResolvable): any;
export declare function onCallScheduleLayerRestrictionToHclTerraform(struct?: OnCallScheduleLayerRestriction | cdktn.IResolvable): any;
export declare class OnCallScheduleLayerRestrictionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OnCallScheduleLayerRestriction | cdktn.IResolvable | undefined;
    set internalValue(value: OnCallScheduleLayerRestriction | cdktn.IResolvable | undefined);
    private _endDay?;
    get endDay(): string;
    set endDay(value: string);
    get endDayInput(): string | undefined;
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    get endTimeInput(): string | undefined;
    private _startDay?;
    get startDay(): string;
    set startDay(value: string);
    get startDayInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    get startTimeInput(): string | undefined;
}
export declare class OnCallScheduleLayerRestrictionList extends cdktn.ComplexList {
    internalValue?: OnCallScheduleLayerRestriction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OnCallScheduleLayerRestrictionOutputReference;
}
export interface OnCallScheduleLayer {
    /**
    * The date/time when this layer should become active (in ISO 8601).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_schedule#effective_date OnCallSchedule#effective_date}
    */
    readonly effectiveDate: string;
    /**
    * The date/time after which this layer no longer applies (in ISO 8601).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_schedule#end_date OnCallSchedule#end_date}
    */
    readonly endDate?: string;
    /**
    * The name of this layer. Should be unique within the schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_schedule#name OnCallSchedule#name}
    */
    readonly name: string;
    /**
    * The date/time when the rotation for this layer starts (in ISO 8601).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_schedule#rotation_start OnCallSchedule#rotation_start}
    */
    readonly rotationStart: string;
    /**
    * The time zone for this layer. String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_schedule#time_zone OnCallSchedule#time_zone}
    */
    readonly timeZone?: string;
    /**
    * List of user IDs for the layer. Can either be a valid user id or `null` to represent No-one.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_schedule#users OnCallSchedule#users}
    */
    readonly users: string[];
    /**
    * interval block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_schedule#interval OnCallSchedule#interval}
    */
    readonly interval?: OnCallScheduleLayerInterval;
    /**
    * restriction block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_schedule#restriction OnCallSchedule#restriction}
    */
    readonly restriction?: OnCallScheduleLayerRestriction[] | cdktn.IResolvable;
}
export declare function onCallScheduleLayerToTerraform(struct?: OnCallScheduleLayer | cdktn.IResolvable): any;
export declare function onCallScheduleLayerToHclTerraform(struct?: OnCallScheduleLayer | cdktn.IResolvable): any;
export declare class OnCallScheduleLayerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OnCallScheduleLayer | cdktn.IResolvable | undefined;
    set internalValue(value: OnCallScheduleLayer | cdktn.IResolvable | undefined);
    private _effectiveDate?;
    get effectiveDate(): string;
    set effectiveDate(value: string);
    get effectiveDateInput(): string | undefined;
    private _endDate?;
    get endDate(): string;
    set endDate(value: string);
    resetEndDate(): void;
    get endDateInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _rotationStart?;
    get rotationStart(): string;
    set rotationStart(value: string);
    get rotationStartInput(): string | undefined;
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    resetTimeZone(): void;
    get timeZoneInput(): string | undefined;
    private _users?;
    get users(): string[];
    set users(value: string[]);
    get usersInput(): string[] | undefined;
    private _interval;
    get interval(): OnCallScheduleLayerIntervalOutputReference;
    putInterval(value: OnCallScheduleLayerInterval): void;
    resetInterval(): void;
    get intervalInput(): cdktn.IResolvable | OnCallScheduleLayerInterval | undefined;
    private _restriction;
    get restriction(): OnCallScheduleLayerRestrictionList;
    putRestriction(value: OnCallScheduleLayerRestriction[] | cdktn.IResolvable): void;
    resetRestriction(): void;
    get restrictionInput(): cdktn.IResolvable | OnCallScheduleLayerRestriction[] | undefined;
}
export declare class OnCallScheduleLayerList extends cdktn.ComplexList {
    internalValue?: OnCallScheduleLayer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OnCallScheduleLayerOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_schedule datadog_on_call_schedule}
*/
export declare class OnCallSchedule extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_on_call_schedule";
    /**
    * Generates CDKTN code for importing a OnCallSchedule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OnCallSchedule to import
    * @param importFromId The id of the existing OnCallSchedule that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_schedule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OnCallSchedule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_schedule datadog_on_call_schedule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OnCallScheduleConfig
    */
    constructor(scope: Construct, id: string, config: OnCallScheduleConfig);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _teams?;
    get teams(): string[];
    set teams(value: string[]);
    resetTeams(): void;
    get teamsInput(): string[] | undefined;
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    get timeZoneInput(): string | undefined;
    private _layer;
    get layer(): OnCallScheduleLayerList;
    putLayer(value: OnCallScheduleLayer[] | cdktn.IResolvable): void;
    resetLayer(): void;
    get layerInput(): cdktn.IResolvable | OnCallScheduleLayer[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
