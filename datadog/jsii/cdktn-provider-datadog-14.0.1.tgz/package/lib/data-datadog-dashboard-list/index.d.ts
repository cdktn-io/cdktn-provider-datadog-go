/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogDashboardListConfig extends cdktn.TerraformMetaArguments {
    /**
    * A dashboard list name to limit the search. String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/dashboard_list#name DataDatadogDashboardList#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/dashboard_list datadog_dashboard_list}
*/
export declare class DataDatadogDashboardList extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_dashboard_list";
    /**
    * Generates CDKTN code for importing a DataDatadogDashboardList resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogDashboardList to import
    * @param importFromId The id of the existing DataDatadogDashboardList that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/dashboard_list#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogDashboardList to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/dashboard_list datadog_dashboard_list} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogDashboardListConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogDashboardListConfig);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
