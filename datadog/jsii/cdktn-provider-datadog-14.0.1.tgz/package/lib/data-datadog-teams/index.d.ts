/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogTeamsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Search query. Can be team name, team handle, or email of team member.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/teams#filter_keyword DataDatadogTeams#filter_keyword}
    */
    readonly filterKeyword?: string;
    /**
    * When true, only returns teams the current user belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/teams#filter_me DataDatadogTeams#filter_me}
    */
    readonly filterMe?: boolean | cdktn.IResolvable;
    /**
    * teams block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/teams#teams DataDatadogTeams#teams}
    */
    readonly teams?: DataDatadogTeamsTeams[] | cdktn.IResolvable;
}
export interface DataDatadogTeamsTeams {
}
export declare function dataDatadogTeamsTeamsToTerraform(struct?: DataDatadogTeamsTeams | cdktn.IResolvable): any;
export declare function dataDatadogTeamsTeamsToHclTerraform(struct?: DataDatadogTeamsTeams | cdktn.IResolvable): any;
export declare class DataDatadogTeamsTeamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogTeamsTeams | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogTeamsTeams | cdktn.IResolvable | undefined);
    get description(): string;
    get handle(): string;
    get id(): string;
    get linkCount(): number;
    get name(): string;
    get summary(): string;
    get userCount(): number;
}
export declare class DataDatadogTeamsTeamsList extends cdktn.ComplexList {
    internalValue?: DataDatadogTeamsTeams[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogTeamsTeamsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/teams datadog_teams}
*/
export declare class DataDatadogTeams extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_teams";
    /**
    * Generates CDKTN code for importing a DataDatadogTeams resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogTeams to import
    * @param importFromId The id of the existing DataDatadogTeams that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/teams#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogTeams to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/teams datadog_teams} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogTeamsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogTeamsConfig);
    private _filterKeyword?;
    get filterKeyword(): string;
    set filterKeyword(value: string);
    resetFilterKeyword(): void;
    get filterKeywordInput(): string | undefined;
    private _filterMe?;
    get filterMe(): boolean | cdktn.IResolvable;
    set filterMe(value: boolean | cdktn.IResolvable);
    resetFilterMe(): void;
    get filterMeInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _teams;
    get teams(): DataDatadogTeamsTeamsList;
    putTeams(value: DataDatadogTeamsTeams[] | cdktn.IResolvable): void;
    resetTeams(): void;
    get teamsInput(): cdktn.IResolvable | DataDatadogTeamsTeams[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
