/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SecurityMonitoringSuppressionConfig extends cdktn.TerraformMetaArguments {
    /**
    * An exclusion query on the input data of the security rules, which could be logs, Agent events, or other types of data based on the security rule. Events matching this query are ignored by any detection rules referenced in the suppression rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_suppression#data_exclusion_query SecurityMonitoringSuppression#data_exclusion_query}
    */
    readonly dataExclusionQuery?: string;
    /**
    * A description for the suppression rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_suppression#description SecurityMonitoringSuppression#description}
    */
    readonly description?: string;
    /**
    * Whether the suppression rule is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_suppression#enabled SecurityMonitoringSuppression#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * A RFC3339 timestamp giving an expiration date for the suppression rule. After this date, it won't suppress signals anymore.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_suppression#expiration_date SecurityMonitoringSuppression#expiration_date}
    */
    readonly expirationDate?: string;
    /**
    * The name of the suppression rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_suppression#name SecurityMonitoringSuppression#name}
    */
    readonly name: string;
    /**
    * The rule query of the suppression rule, with the same syntax as the search bar for detection rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_suppression#rule_query SecurityMonitoringSuppression#rule_query}
    */
    readonly ruleQuery: string;
    /**
    * A RFC3339 timestamp giving a start date for the suppression rule. Before this date, it doesn't suppress signals.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_suppression#start_date SecurityMonitoringSuppression#start_date}
    */
    readonly startDate?: string;
    /**
    * The suppression query of the suppression rule. If a signal matches this query, it is suppressed and is not triggered. It uses the same syntax as the queries to search signals in the Signals Explorer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_suppression#suppression_query SecurityMonitoringSuppression#suppression_query}
    */
    readonly suppressionQuery?: string;
    /**
    * A list of tags associated with the suppression rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_suppression#tags SecurityMonitoringSuppression#tags}
    */
    readonly tags?: string[];
    /**
    * Whether to validate the suppression rule during `terraform plan`. When set to `true`, the rule is validated against Datadog's suppression validation endpoint. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_suppression#validate SecurityMonitoringSuppression#validate}
    */
    readonly validate?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_suppression datadog_security_monitoring_suppression}
*/
export declare class SecurityMonitoringSuppression extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_security_monitoring_suppression";
    /**
    * Generates CDKTN code for importing a SecurityMonitoringSuppression resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecurityMonitoringSuppression to import
    * @param importFromId The id of the existing SecurityMonitoringSuppression that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_suppression#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecurityMonitoringSuppression to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_suppression datadog_security_monitoring_suppression} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecurityMonitoringSuppressionConfig
    */
    constructor(scope: Construct, id: string, config: SecurityMonitoringSuppressionConfig);
    private _dataExclusionQuery?;
    get dataExclusionQuery(): string;
    set dataExclusionQuery(value: string);
    resetDataExclusionQuery(): void;
    get dataExclusionQueryInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _expirationDate?;
    get expirationDate(): string;
    set expirationDate(value: string);
    resetExpirationDate(): void;
    get expirationDateInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _ruleQuery?;
    get ruleQuery(): string;
    set ruleQuery(value: string);
    get ruleQueryInput(): string | undefined;
    private _startDate?;
    get startDate(): string;
    set startDate(value: string);
    resetStartDate(): void;
    get startDateInput(): string | undefined;
    private _suppressionQuery?;
    get suppressionQuery(): string;
    set suppressionQuery(value: string);
    resetSuppressionQuery(): void;
    get suppressionQueryInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _validate?;
    get validate(): boolean | cdktn.IResolvable;
    set validate(value: boolean | cdktn.IResolvable);
    resetValidate(): void;
    get validateInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
