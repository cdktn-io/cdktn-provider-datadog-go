/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogIntegrationAwsExternalIdConfig extends cdktn.TerraformMetaArguments {
    /**
    * The AWS account ID of the integration to retrieve the external ID from. Must be a valid 12 digits AWS account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/integration_aws_external_id#aws_account_id DataDatadogIntegrationAwsExternalId#aws_account_id}
    */
    readonly awsAccountId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/integration_aws_external_id datadog_integration_aws_external_id}
*/
export declare class DataDatadogIntegrationAwsExternalId extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_integration_aws_external_id";
    /**
    * Generates CDKTN code for importing a DataDatadogIntegrationAwsExternalId resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogIntegrationAwsExternalId to import
    * @param importFromId The id of the existing DataDatadogIntegrationAwsExternalId that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/integration_aws_external_id#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogIntegrationAwsExternalId to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/integration_aws_external_id datadog_integration_aws_external_id} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogIntegrationAwsExternalIdConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogIntegrationAwsExternalIdConfig);
    private _awsAccountId?;
    get awsAccountId(): string;
    set awsAccountId(value: string);
    get awsAccountIdInput(): string | undefined;
    get externalId(): string;
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
