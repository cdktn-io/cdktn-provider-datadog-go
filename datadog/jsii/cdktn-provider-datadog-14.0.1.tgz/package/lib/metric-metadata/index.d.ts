/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MetricMetadataConfig extends cdktn.TerraformMetaArguments {
    /**
    * A description of the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/metric_metadata#description MetricMetadata#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/metric_metadata#id MetricMetadata#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/metric_metadata#metric MetricMetadata#metric}
    */
    readonly metric: string;
    /**
    * Per unit of the metric such as `second` in `bytes per second`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/metric_metadata#per_unit MetricMetadata#per_unit}
    */
    readonly perUnit?: string;
    /**
    * A short name of the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/metric_metadata#short_name MetricMetadata#short_name}
    */
    readonly shortName?: string;
    /**
    * If applicable, statsd flush interval in seconds for the metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/metric_metadata#statsd_interval MetricMetadata#statsd_interval}
    */
    readonly statsdInterval?: number;
    /**
    * Metric type such as `count`, `gauge`, or `rate`. Updating a metric of type `distribution` is not supported. If you would like to see the `distribution` type returned, contact [Datadog support](https://docs.datadoghq.com/help/).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/metric_metadata#type MetricMetadata#type}
    */
    readonly type?: string;
    /**
    * Primary unit of the metric such as `byte` or `operation`. For a list of allowed units, refer to [Datadog metric unit documentation](https://docs.datadoghq.com/metrics/units/#unit-list).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/metric_metadata#unit MetricMetadata#unit}
    */
    readonly unit?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/metric_metadata datadog_metric_metadata}
*/
export declare class MetricMetadata extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_metric_metadata";
    /**
    * Generates CDKTN code for importing a MetricMetadata resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MetricMetadata to import
    * @param importFromId The id of the existing MetricMetadata that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/metric_metadata#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MetricMetadata to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/metric_metadata datadog_metric_metadata} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MetricMetadataConfig
    */
    constructor(scope: Construct, id: string, config: MetricMetadataConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _perUnit?;
    get perUnit(): string;
    set perUnit(value: string);
    resetPerUnit(): void;
    get perUnitInput(): string | undefined;
    private _shortName?;
    get shortName(): string;
    set shortName(value: string);
    resetShortName(): void;
    get shortNameInput(): string | undefined;
    private _statsdInterval?;
    get statsdInterval(): number;
    set statsdInterval(value: number);
    resetStatsdInterval(): void;
    get statsdIntervalInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
