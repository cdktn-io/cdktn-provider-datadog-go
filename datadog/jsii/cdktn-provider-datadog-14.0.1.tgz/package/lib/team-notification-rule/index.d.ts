/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TeamNotificationRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the team that this notification rule belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_notification_rule#team_id TeamNotificationRule#team_id}
    */
    readonly teamId: string;
    /**
    * email block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_notification_rule#email TeamNotificationRule#email}
    */
    readonly email?: TeamNotificationRuleEmail;
    /**
    * ms_teams block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_notification_rule#ms_teams TeamNotificationRule#ms_teams}
    */
    readonly msTeams?: TeamNotificationRuleMsTeams;
    /**
    * pagerduty block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_notification_rule#pagerduty TeamNotificationRule#pagerduty}
    */
    readonly pagerduty?: TeamNotificationRulePagerduty;
    /**
    * slack block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_notification_rule#slack TeamNotificationRule#slack}
    */
    readonly slack?: TeamNotificationRuleSlack;
}
export interface TeamNotificationRuleEmail {
    /**
    * Whether to send email notifications to team members when alerts are triggered.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_notification_rule#enabled TeamNotificationRule#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function teamNotificationRuleEmailToTerraform(struct?: TeamNotificationRuleEmail | cdktn.IResolvable): any;
export declare function teamNotificationRuleEmailToHclTerraform(struct?: TeamNotificationRuleEmail | cdktn.IResolvable): any;
export declare class TeamNotificationRuleEmailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamNotificationRuleEmail | cdktn.IResolvable | undefined;
    set internalValue(value: TeamNotificationRuleEmail | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface TeamNotificationRuleMsTeams {
    /**
    * MS Teams connector name used to route notifications to the appropriate channel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_notification_rule#connector_name TeamNotificationRule#connector_name}
    */
    readonly connectorName?: string;
}
export declare function teamNotificationRuleMsTeamsToTerraform(struct?: TeamNotificationRuleMsTeams | cdktn.IResolvable): any;
export declare function teamNotificationRuleMsTeamsToHclTerraform(struct?: TeamNotificationRuleMsTeams | cdktn.IResolvable): any;
export declare class TeamNotificationRuleMsTeamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamNotificationRuleMsTeams | cdktn.IResolvable | undefined;
    set internalValue(value: TeamNotificationRuleMsTeams | cdktn.IResolvable | undefined);
    private _connectorName?;
    get connectorName(): string;
    set connectorName(value: string);
    resetConnectorName(): void;
    get connectorNameInput(): string | undefined;
}
export interface TeamNotificationRulePagerduty {
    /**
    * PagerDuty service name to send incident notifications to. The service name can be found in your PagerDuty service settings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_notification_rule#service_name TeamNotificationRule#service_name}
    */
    readonly serviceName?: string;
}
export declare function teamNotificationRulePagerdutyToTerraform(struct?: TeamNotificationRulePagerduty | cdktn.IResolvable): any;
export declare function teamNotificationRulePagerdutyToHclTerraform(struct?: TeamNotificationRulePagerduty | cdktn.IResolvable): any;
export declare class TeamNotificationRulePagerdutyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamNotificationRulePagerduty | cdktn.IResolvable | undefined;
    set internalValue(value: TeamNotificationRulePagerduty | cdktn.IResolvable | undefined);
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    resetServiceName(): void;
    get serviceNameInput(): string | undefined;
}
export interface TeamNotificationRuleSlack {
    /**
    * Slack channel name for notifications (for example, #alerts or #team-notifications).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_notification_rule#channel TeamNotificationRule#channel}
    */
    readonly channel?: string;
    /**
    * Slack workspace name where the channel is located.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_notification_rule#workspace TeamNotificationRule#workspace}
    */
    readonly workspace?: string;
}
export declare function teamNotificationRuleSlackToTerraform(struct?: TeamNotificationRuleSlack | cdktn.IResolvable): any;
export declare function teamNotificationRuleSlackToHclTerraform(struct?: TeamNotificationRuleSlack | cdktn.IResolvable): any;
export declare class TeamNotificationRuleSlackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TeamNotificationRuleSlack | cdktn.IResolvable | undefined;
    set internalValue(value: TeamNotificationRuleSlack | cdktn.IResolvable | undefined);
    private _channel?;
    get channel(): string;
    set channel(value: string);
    resetChannel(): void;
    get channelInput(): string | undefined;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    resetWorkspace(): void;
    get workspaceInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_notification_rule datadog_team_notification_rule}
*/
export declare class TeamNotificationRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_team_notification_rule";
    /**
    * Generates CDKTN code for importing a TeamNotificationRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TeamNotificationRule to import
    * @param importFromId The id of the existing TeamNotificationRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_notification_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TeamNotificationRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_notification_rule datadog_team_notification_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TeamNotificationRuleConfig
    */
    constructor(scope: Construct, id: string, config: TeamNotificationRuleConfig);
    get id(): string;
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    get teamIdInput(): string | undefined;
    private _email;
    get email(): TeamNotificationRuleEmailOutputReference;
    putEmail(value: TeamNotificationRuleEmail): void;
    resetEmail(): void;
    get emailInput(): cdktn.IResolvable | TeamNotificationRuleEmail | undefined;
    private _msTeams;
    get msTeams(): TeamNotificationRuleMsTeamsOutputReference;
    putMsTeams(value: TeamNotificationRuleMsTeams): void;
    resetMsTeams(): void;
    get msTeamsInput(): cdktn.IResolvable | TeamNotificationRuleMsTeams | undefined;
    private _pagerduty;
    get pagerduty(): TeamNotificationRulePagerdutyOutputReference;
    putPagerduty(value: TeamNotificationRulePagerduty): void;
    resetPagerduty(): void;
    get pagerdutyInput(): cdktn.IResolvable | TeamNotificationRulePagerduty | undefined;
    private _slack;
    get slack(): TeamNotificationRuleSlackOutputReference;
    putSlack(value: TeamNotificationRuleSlack): void;
    resetSlack(): void;
    get slackInput(): cdktn.IResolvable | TeamNotificationRuleSlack | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
