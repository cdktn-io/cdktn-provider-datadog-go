/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogAppBuilderAppConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID for the App.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/app_builder_app#id DataDatadogAppBuilderApp#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/app_builder_app datadog_app_builder_app}
*/
export declare class DataDatadogAppBuilderApp extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_app_builder_app";
    /**
    * Generates CDKTN code for importing a DataDatadogAppBuilderApp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogAppBuilderApp to import
    * @param importFromId The id of the existing DataDatadogAppBuilderApp that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/app_builder_app#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogAppBuilderApp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/app_builder_app datadog_app_builder_app} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogAppBuilderAppConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogAppBuilderAppConfig);
    private _actionQueryNamesToConnectionIds;
    get actionQueryNamesToConnectionIds(): cdktn.StringMap;
    get appJson(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get name(): string;
    get published(): cdktn.IResolvable;
    get rootInstanceName(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
