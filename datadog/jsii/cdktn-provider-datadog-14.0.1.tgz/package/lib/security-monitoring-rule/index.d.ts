/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SecurityMonitoringRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether the rule is enabled. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#enabled SecurityMonitoringRule#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Additional grouping to perform on top of the query grouping.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#group_signals_by SecurityMonitoringRule#group_signals_by}
    */
    readonly groupSignalsBy?: string[];
    /**
    * Whether the notifications include the triggering group-by values in their title. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#has_extended_title SecurityMonitoringRule#has_extended_title}
    */
    readonly hasExtendedTitle?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#id SecurityMonitoringRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Message for generated signals.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#message SecurityMonitoringRule#message}
    */
    readonly message: string;
    /**
    * The name of the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#name SecurityMonitoringRule#name}
    */
    readonly name: string;
    /**
    * Tags for generated signals. Note: if default tags are present at provider level, they will be added to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#tags SecurityMonitoringRule#tags}
    */
    readonly tags?: string[];
    /**
    * The rule type. Valid values are `application_security`, `log_detection`, `workload_security`, `signal_correlation`. Defaults to `"log_detection"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#type SecurityMonitoringRule#type}
    */
    readonly type?: string;
    /**
    * Whether or not to validate the Rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#validate SecurityMonitoringRule#validate}
    */
    readonly validate?: boolean | cdktn.IResolvable;
    /**
    * calculated_field block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#calculated_field SecurityMonitoringRule#calculated_field}
    */
    readonly calculatedField?: SecurityMonitoringRuleCalculatedField[] | cdktn.IResolvable;
    /**
    * case block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#case SecurityMonitoringRule#case}
    */
    readonly case?: SecurityMonitoringRuleCase[] | cdktn.IResolvable;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#filter SecurityMonitoringRule#filter}
    */
    readonly filter?: SecurityMonitoringRuleFilter[] | cdktn.IResolvable;
    /**
    * options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#options SecurityMonitoringRule#options}
    */
    readonly options?: SecurityMonitoringRuleOptions;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#query SecurityMonitoringRule#query}
    */
    readonly query?: SecurityMonitoringRuleQuery[] | cdktn.IResolvable;
    /**
    * reference_tables block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#reference_tables SecurityMonitoringRule#reference_tables}
    */
    readonly referenceTables?: SecurityMonitoringRuleReferenceTables[] | cdktn.IResolvable;
    /**
    * scheduling_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#scheduling_options SecurityMonitoringRule#scheduling_options}
    */
    readonly schedulingOptions?: SecurityMonitoringRuleSchedulingOptions;
    /**
    * signal_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#signal_query SecurityMonitoringRule#signal_query}
    */
    readonly signalQuery?: SecurityMonitoringRuleSignalQuery[] | cdktn.IResolvable;
    /**
    * third_party_case block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#third_party_case SecurityMonitoringRule#third_party_case}
    */
    readonly thirdPartyCase?: SecurityMonitoringRuleThirdPartyCase[] | cdktn.IResolvable;
}
export interface SecurityMonitoringRuleCalculatedField {
    /**
    * Expression.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#expression SecurityMonitoringRule#expression}
    */
    readonly expression: string;
    /**
    * Field name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#name SecurityMonitoringRule#name}
    */
    readonly name: string;
}
export declare function securityMonitoringRuleCalculatedFieldToTerraform(struct?: SecurityMonitoringRuleCalculatedField | cdktn.IResolvable): any;
export declare function securityMonitoringRuleCalculatedFieldToHclTerraform(struct?: SecurityMonitoringRuleCalculatedField | cdktn.IResolvable): any;
export declare class SecurityMonitoringRuleCalculatedFieldOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SecurityMonitoringRuleCalculatedField | cdktn.IResolvable | undefined;
    set internalValue(value: SecurityMonitoringRuleCalculatedField | cdktn.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class SecurityMonitoringRuleCalculatedFieldList extends cdktn.ComplexList {
    internalValue?: SecurityMonitoringRuleCalculatedField[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SecurityMonitoringRuleCalculatedFieldOutputReference;
}
export interface SecurityMonitoringRuleCaseActionOptions {
    /**
    * Duration of the action in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#duration SecurityMonitoringRule#duration}
    */
    readonly duration?: number;
}
export declare function securityMonitoringRuleCaseActionOptionsToTerraform(struct?: SecurityMonitoringRuleCaseActionOptionsOutputReference | SecurityMonitoringRuleCaseActionOptions): any;
export declare function securityMonitoringRuleCaseActionOptionsToHclTerraform(struct?: SecurityMonitoringRuleCaseActionOptionsOutputReference | SecurityMonitoringRuleCaseActionOptions): any;
export declare class SecurityMonitoringRuleCaseActionOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SecurityMonitoringRuleCaseActionOptions | undefined;
    set internalValue(value: SecurityMonitoringRuleCaseActionOptions | undefined);
    private _duration?;
    get duration(): number;
    set duration(value: number);
    resetDuration(): void;
    get durationInput(): number | undefined;
}
export interface SecurityMonitoringRuleCaseAction {
    /**
    * Type of action to perform when the case triggers. Valid values are `block_ip`, `block_user`, `user_behavior`, `flag_ip`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#type SecurityMonitoringRule#type}
    */
    readonly type: string;
    /**
    * options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#options SecurityMonitoringRule#options}
    */
    readonly options?: SecurityMonitoringRuleCaseActionOptions;
}
export declare function securityMonitoringRuleCaseActionToTerraform(struct?: SecurityMonitoringRuleCaseAction | cdktn.IResolvable): any;
export declare function securityMonitoringRuleCaseActionToHclTerraform(struct?: SecurityMonitoringRuleCaseAction | cdktn.IResolvable): any;
export declare class SecurityMonitoringRuleCaseActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SecurityMonitoringRuleCaseAction | cdktn.IResolvable | undefined;
    set internalValue(value: SecurityMonitoringRuleCaseAction | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _options;
    get options(): SecurityMonitoringRuleCaseActionOptionsOutputReference;
    putOptions(value: SecurityMonitoringRuleCaseActionOptions): void;
    resetOptions(): void;
    get optionsInput(): SecurityMonitoringRuleCaseActionOptions | undefined;
}
export declare class SecurityMonitoringRuleCaseActionList extends cdktn.ComplexList {
    internalValue?: SecurityMonitoringRuleCaseAction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SecurityMonitoringRuleCaseActionOutputReference;
}
export interface SecurityMonitoringRuleCase {
    /**
    * A rule case contains logical operations (`>`,`>=`, `&&`, `||`) to determine if a signal should be generated based on the event counts in the previously defined queries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#condition SecurityMonitoringRule#condition}
    */
    readonly condition?: string;
    /**
    * Name of the case.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#name SecurityMonitoringRule#name}
    */
    readonly name?: string;
    /**
    * Notification targets for each rule case.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#notifications SecurityMonitoringRule#notifications}
    */
    readonly notifications?: string[];
    /**
    * Severity of the Security Signal. Valid values are `info`, `low`, `medium`, `high`, `critical`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#status SecurityMonitoringRule#status}
    */
    readonly status: string;
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#action SecurityMonitoringRule#action}
    */
    readonly action?: SecurityMonitoringRuleCaseAction[] | cdktn.IResolvable;
}
export declare function securityMonitoringRuleCaseToTerraform(struct?: SecurityMonitoringRuleCase | cdktn.IResolvable): any;
export declare function securityMonitoringRuleCaseToHclTerraform(struct?: SecurityMonitoringRuleCase | cdktn.IResolvable): any;
export declare class SecurityMonitoringRuleCaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SecurityMonitoringRuleCase | cdktn.IResolvable | undefined;
    set internalValue(value: SecurityMonitoringRuleCase | cdktn.IResolvable | undefined);
    private _condition?;
    get condition(): string;
    set condition(value: string);
    resetCondition(): void;
    get conditionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _notifications?;
    get notifications(): string[];
    set notifications(value: string[]);
    resetNotifications(): void;
    get notificationsInput(): string[] | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
    private _action;
    get action(): SecurityMonitoringRuleCaseActionList;
    putAction(value: SecurityMonitoringRuleCaseAction[] | cdktn.IResolvable): void;
    resetAction(): void;
    get actionInput(): cdktn.IResolvable | SecurityMonitoringRuleCaseAction[] | undefined;
}
export declare class SecurityMonitoringRuleCaseList extends cdktn.ComplexList {
    internalValue?: SecurityMonitoringRuleCase[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SecurityMonitoringRuleCaseOutputReference;
}
export interface SecurityMonitoringRuleFilter {
    /**
    * The type of filtering action. Valid values are `require`, `suppress`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#action SecurityMonitoringRule#action}
    */
    readonly action: string;
    /**
    * Query for selecting logs to apply the filtering action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#query SecurityMonitoringRule#query}
    */
    readonly query: string;
}
export declare function securityMonitoringRuleFilterToTerraform(struct?: SecurityMonitoringRuleFilter | cdktn.IResolvable): any;
export declare function securityMonitoringRuleFilterToHclTerraform(struct?: SecurityMonitoringRuleFilter | cdktn.IResolvable): any;
export declare class SecurityMonitoringRuleFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SecurityMonitoringRuleFilter | cdktn.IResolvable | undefined;
    set internalValue(value: SecurityMonitoringRuleFilter | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SecurityMonitoringRuleFilterList extends cdktn.ComplexList {
    internalValue?: SecurityMonitoringRuleFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SecurityMonitoringRuleFilterOutputReference;
}
export interface SecurityMonitoringRuleOptionsAnomalyDetectionOptions {
    /**
    * Duration in seconds of the time buckets used to aggregate events matched by the rule. Valid values are 300, 600, 900, 1800, 3600, 10800. Valid values are `300`, `600`, `900`, `1800`, `3600`, `10800`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#bucket_duration SecurityMonitoringRule#bucket_duration}
    */
    readonly bucketDuration?: number;
    /**
    * An optional parameter that sets how permissive anomaly detection is. Higher values require higher deviations before triggering a signal. Valid values are 1, 2, 3, 4, 5. Valid values are `1`, `2`, `3`, `4`, `5`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#detection_tolerance SecurityMonitoringRule#detection_tolerance}
    */
    readonly detectionTolerance?: number;
    /**
    * When set to true, Datadog uses previous values that fall within the defined learning window to construct the baseline, enabling the system to establish an accurate baseline more rapidly rather than relying solely on gradual learning over time. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#instantaneous_baseline SecurityMonitoringRule#instantaneous_baseline}
    */
    readonly instantaneousBaseline?: boolean | cdktn.IResolvable;
    /**
    * Learning duration in hours. Anomaly detection waits for at least this amount of historical data before it starts evaluating. Valid values are 1, 6, 12, 24, 48, 168, 336. Valid values are `1`, `6`, `12`, `24`, `48`, `168`, `336`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#learning_duration SecurityMonitoringRule#learning_duration}
    */
    readonly learningDuration?: number;
    /**
    * An optional override baseline to apply while the rule is in the learning period. Must be greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#learning_period_baseline SecurityMonitoringRule#learning_period_baseline}
    */
    readonly learningPeriodBaseline?: number;
}
export declare function securityMonitoringRuleOptionsAnomalyDetectionOptionsToTerraform(struct?: SecurityMonitoringRuleOptionsAnomalyDetectionOptionsOutputReference | SecurityMonitoringRuleOptionsAnomalyDetectionOptions): any;
export declare function securityMonitoringRuleOptionsAnomalyDetectionOptionsToHclTerraform(struct?: SecurityMonitoringRuleOptionsAnomalyDetectionOptionsOutputReference | SecurityMonitoringRuleOptionsAnomalyDetectionOptions): any;
export declare class SecurityMonitoringRuleOptionsAnomalyDetectionOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SecurityMonitoringRuleOptionsAnomalyDetectionOptions | undefined;
    set internalValue(value: SecurityMonitoringRuleOptionsAnomalyDetectionOptions | undefined);
    private _bucketDuration?;
    get bucketDuration(): number;
    set bucketDuration(value: number);
    resetBucketDuration(): void;
    get bucketDurationInput(): number | undefined;
    private _detectionTolerance?;
    get detectionTolerance(): number;
    set detectionTolerance(value: number);
    resetDetectionTolerance(): void;
    get detectionToleranceInput(): number | undefined;
    private _instantaneousBaseline?;
    get instantaneousBaseline(): boolean | cdktn.IResolvable;
    set instantaneousBaseline(value: boolean | cdktn.IResolvable);
    resetInstantaneousBaseline(): void;
    get instantaneousBaselineInput(): boolean | cdktn.IResolvable | undefined;
    private _learningDuration?;
    get learningDuration(): number;
    set learningDuration(value: number);
    resetLearningDuration(): void;
    get learningDurationInput(): number | undefined;
    private _learningPeriodBaseline?;
    get learningPeriodBaseline(): number;
    set learningPeriodBaseline(value: number);
    resetLearningPeriodBaseline(): void;
    get learningPeriodBaselineInput(): number | undefined;
}
export interface SecurityMonitoringRuleOptionsImpossibleTravelOptions {
    /**
    * If true, signals are suppressed for the first 24 hours. During that time, Datadog learns the user's regular access locations. This can be helpful to reduce noise and infer VPN usage or credentialed API access. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#baseline_user_locations SecurityMonitoringRule#baseline_user_locations}
    */
    readonly baselineUserLocations?: boolean | cdktn.IResolvable;
}
export declare function securityMonitoringRuleOptionsImpossibleTravelOptionsToTerraform(struct?: SecurityMonitoringRuleOptionsImpossibleTravelOptionsOutputReference | SecurityMonitoringRuleOptionsImpossibleTravelOptions): any;
export declare function securityMonitoringRuleOptionsImpossibleTravelOptionsToHclTerraform(struct?: SecurityMonitoringRuleOptionsImpossibleTravelOptionsOutputReference | SecurityMonitoringRuleOptionsImpossibleTravelOptions): any;
export declare class SecurityMonitoringRuleOptionsImpossibleTravelOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SecurityMonitoringRuleOptionsImpossibleTravelOptions | undefined;
    set internalValue(value: SecurityMonitoringRuleOptionsImpossibleTravelOptions | undefined);
    private _baselineUserLocations?;
    get baselineUserLocations(): boolean | cdktn.IResolvable;
    set baselineUserLocations(value: boolean | cdktn.IResolvable);
    resetBaselineUserLocations(): void;
    get baselineUserLocationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface SecurityMonitoringRuleOptionsNewValueOptions {
    /**
    * The duration in days after which a learned value is forgotten. Valid values are `1`, `2`, `7`, `14`, `21`, `28`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#forget_after SecurityMonitoringRule#forget_after}
    */
    readonly forgetAfter: number;
    /**
    * When set to true, Datadog uses previous values that fall within the defined learning window to construct the baseline, enabling the system to establish an accurate baseline more rapidly rather than relying solely on gradual learning over time. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#instantaneous_baseline SecurityMonitoringRule#instantaneous_baseline}
    */
    readonly instantaneousBaseline?: boolean | cdktn.IResolvable;
    /**
    * The duration in days during which values are learned, and after which signals will be generated for values that weren't learned. If set to 0, a signal will be generated for all new values after the first value is learned. Valid values are `0`, `1`, `7`. Defaults to `1`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#learning_duration SecurityMonitoringRule#learning_duration}
    */
    readonly learningDuration?: number;
    /**
    * The learning method used to determine when signals should be generated for values that weren't learned. Valid values are `duration`, `threshold`. Defaults to `"duration"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#learning_method SecurityMonitoringRule#learning_method}
    */
    readonly learningMethod?: string;
    /**
    * A number of occurrences after which signals are generated for values that weren't learned. Valid values are `0`, `1`. Defaults to `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#learning_threshold SecurityMonitoringRule#learning_threshold}
    */
    readonly learningThreshold?: number;
}
export declare function securityMonitoringRuleOptionsNewValueOptionsToTerraform(struct?: SecurityMonitoringRuleOptionsNewValueOptionsOutputReference | SecurityMonitoringRuleOptionsNewValueOptions): any;
export declare function securityMonitoringRuleOptionsNewValueOptionsToHclTerraform(struct?: SecurityMonitoringRuleOptionsNewValueOptionsOutputReference | SecurityMonitoringRuleOptionsNewValueOptions): any;
export declare class SecurityMonitoringRuleOptionsNewValueOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SecurityMonitoringRuleOptionsNewValueOptions | undefined;
    set internalValue(value: SecurityMonitoringRuleOptionsNewValueOptions | undefined);
    private _forgetAfter?;
    get forgetAfter(): number;
    set forgetAfter(value: number);
    get forgetAfterInput(): number | undefined;
    private _instantaneousBaseline?;
    get instantaneousBaseline(): boolean | cdktn.IResolvable;
    set instantaneousBaseline(value: boolean | cdktn.IResolvable);
    resetInstantaneousBaseline(): void;
    get instantaneousBaselineInput(): boolean | cdktn.IResolvable | undefined;
    private _learningDuration?;
    get learningDuration(): number;
    set learningDuration(value: number);
    resetLearningDuration(): void;
    get learningDurationInput(): number | undefined;
    private _learningMethod?;
    get learningMethod(): string;
    set learningMethod(value: string);
    resetLearningMethod(): void;
    get learningMethodInput(): string | undefined;
    private _learningThreshold?;
    get learningThreshold(): number;
    set learningThreshold(value: number);
    resetLearningThreshold(): void;
    get learningThresholdInput(): number | undefined;
}
export interface SecurityMonitoringRuleOptionsSequenceDetectionOptionsStepTransitions {
    /**
    * Child step name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#child SecurityMonitoringRule#child}
    */
    readonly child: string;
    /**
    * Maximum time allowed to transition from parent to child. Valid values are `0`, `60`, `300`, `600`, `900`, `1800`, `3600`, `7200`, `10800`, `21600`, `43200`, `86400`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#evaluation_window SecurityMonitoringRule#evaluation_window}
    */
    readonly evaluationWindow?: number;
    /**
    * Parent step name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#parent SecurityMonitoringRule#parent}
    */
    readonly parent: string;
}
export declare function securityMonitoringRuleOptionsSequenceDetectionOptionsStepTransitionsToTerraform(struct?: SecurityMonitoringRuleOptionsSequenceDetectionOptionsStepTransitions | cdktn.IResolvable): any;
export declare function securityMonitoringRuleOptionsSequenceDetectionOptionsStepTransitionsToHclTerraform(struct?: SecurityMonitoringRuleOptionsSequenceDetectionOptionsStepTransitions | cdktn.IResolvable): any;
export declare class SecurityMonitoringRuleOptionsSequenceDetectionOptionsStepTransitionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SecurityMonitoringRuleOptionsSequenceDetectionOptionsStepTransitions | cdktn.IResolvable | undefined;
    set internalValue(value: SecurityMonitoringRuleOptionsSequenceDetectionOptionsStepTransitions | cdktn.IResolvable | undefined);
    private _child?;
    get child(): string;
    set child(value: string);
    get childInput(): string | undefined;
    private _evaluationWindow?;
    get evaluationWindow(): number;
    set evaluationWindow(value: number);
    resetEvaluationWindow(): void;
    get evaluationWindowInput(): number | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
}
export declare class SecurityMonitoringRuleOptionsSequenceDetectionOptionsStepTransitionsList extends cdktn.ComplexList {
    internalValue?: SecurityMonitoringRuleOptionsSequenceDetectionOptionsStepTransitions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SecurityMonitoringRuleOptionsSequenceDetectionOptionsStepTransitionsOutputReference;
}
export interface SecurityMonitoringRuleOptionsSequenceDetectionOptionsSteps {
    /**
    * Condition for the step to match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#condition SecurityMonitoringRule#condition}
    */
    readonly condition: string;
    /**
    * Evaluation window for the step. Valid values are `0`, `60`, `300`, `600`, `900`, `1800`, `3600`, `7200`, `10800`, `21600`, `43200`, `86400`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#evaluation_window SecurityMonitoringRule#evaluation_window}
    */
    readonly evaluationWindow?: number;
    /**
    * Unique name of the step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#name SecurityMonitoringRule#name}
    */
    readonly name: string;
}
export declare function securityMonitoringRuleOptionsSequenceDetectionOptionsStepsToTerraform(struct?: SecurityMonitoringRuleOptionsSequenceDetectionOptionsSteps | cdktn.IResolvable): any;
export declare function securityMonitoringRuleOptionsSequenceDetectionOptionsStepsToHclTerraform(struct?: SecurityMonitoringRuleOptionsSequenceDetectionOptionsSteps | cdktn.IResolvable): any;
export declare class SecurityMonitoringRuleOptionsSequenceDetectionOptionsStepsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SecurityMonitoringRuleOptionsSequenceDetectionOptionsSteps | cdktn.IResolvable | undefined;
    set internalValue(value: SecurityMonitoringRuleOptionsSequenceDetectionOptionsSteps | cdktn.IResolvable | undefined);
    private _condition?;
    get condition(): string;
    set condition(value: string);
    get conditionInput(): string | undefined;
    private _evaluationWindow?;
    get evaluationWindow(): number;
    set evaluationWindow(value: number);
    resetEvaluationWindow(): void;
    get evaluationWindowInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class SecurityMonitoringRuleOptionsSequenceDetectionOptionsStepsList extends cdktn.ComplexList {
    internalValue?: SecurityMonitoringRuleOptionsSequenceDetectionOptionsSteps[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SecurityMonitoringRuleOptionsSequenceDetectionOptionsStepsOutputReference;
}
export interface SecurityMonitoringRuleOptionsSequenceDetectionOptions {
    /**
    * step_transitions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#step_transitions SecurityMonitoringRule#step_transitions}
    */
    readonly stepTransitions?: SecurityMonitoringRuleOptionsSequenceDetectionOptionsStepTransitions[] | cdktn.IResolvable;
    /**
    * steps block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#steps SecurityMonitoringRule#steps}
    */
    readonly steps?: SecurityMonitoringRuleOptionsSequenceDetectionOptionsSteps[] | cdktn.IResolvable;
}
export declare function securityMonitoringRuleOptionsSequenceDetectionOptionsToTerraform(struct?: SecurityMonitoringRuleOptionsSequenceDetectionOptionsOutputReference | SecurityMonitoringRuleOptionsSequenceDetectionOptions): any;
export declare function securityMonitoringRuleOptionsSequenceDetectionOptionsToHclTerraform(struct?: SecurityMonitoringRuleOptionsSequenceDetectionOptionsOutputReference | SecurityMonitoringRuleOptionsSequenceDetectionOptions): any;
export declare class SecurityMonitoringRuleOptionsSequenceDetectionOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SecurityMonitoringRuleOptionsSequenceDetectionOptions | undefined;
    set internalValue(value: SecurityMonitoringRuleOptionsSequenceDetectionOptions | undefined);
    private _stepTransitions;
    get stepTransitions(): SecurityMonitoringRuleOptionsSequenceDetectionOptionsStepTransitionsList;
    putStepTransitions(value: SecurityMonitoringRuleOptionsSequenceDetectionOptionsStepTransitions[] | cdktn.IResolvable): void;
    resetStepTransitions(): void;
    get stepTransitionsInput(): cdktn.IResolvable | SecurityMonitoringRuleOptionsSequenceDetectionOptionsStepTransitions[] | undefined;
    private _steps;
    get steps(): SecurityMonitoringRuleOptionsSequenceDetectionOptionsStepsList;
    putSteps(value: SecurityMonitoringRuleOptionsSequenceDetectionOptionsSteps[] | cdktn.IResolvable): void;
    resetSteps(): void;
    get stepsInput(): cdktn.IResolvable | SecurityMonitoringRuleOptionsSequenceDetectionOptionsSteps[] | undefined;
}
export interface SecurityMonitoringRuleOptionsThirdPartyRuleOptionsRootQuery {
    /**
    * Fields to group by. If empty, each log triggers a signal.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#group_by_fields SecurityMonitoringRule#group_by_fields}
    */
    readonly groupByFields?: string[];
    /**
    * Query to filter logs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#query SecurityMonitoringRule#query}
    */
    readonly query: string;
}
export declare function securityMonitoringRuleOptionsThirdPartyRuleOptionsRootQueryToTerraform(struct?: SecurityMonitoringRuleOptionsThirdPartyRuleOptionsRootQuery | cdktn.IResolvable): any;
export declare function securityMonitoringRuleOptionsThirdPartyRuleOptionsRootQueryToHclTerraform(struct?: SecurityMonitoringRuleOptionsThirdPartyRuleOptionsRootQuery | cdktn.IResolvable): any;
export declare class SecurityMonitoringRuleOptionsThirdPartyRuleOptionsRootQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SecurityMonitoringRuleOptionsThirdPartyRuleOptionsRootQuery | cdktn.IResolvable | undefined;
    set internalValue(value: SecurityMonitoringRuleOptionsThirdPartyRuleOptionsRootQuery | cdktn.IResolvable | undefined);
    private _groupByFields?;
    get groupByFields(): string[];
    set groupByFields(value: string[]);
    resetGroupByFields(): void;
    get groupByFieldsInput(): string[] | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SecurityMonitoringRuleOptionsThirdPartyRuleOptionsRootQueryList extends cdktn.ComplexList {
    internalValue?: SecurityMonitoringRuleOptionsThirdPartyRuleOptionsRootQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SecurityMonitoringRuleOptionsThirdPartyRuleOptionsRootQueryOutputReference;
}
export interface SecurityMonitoringRuleOptionsThirdPartyRuleOptions {
    /**
    * Notification targets for the default rule case, when none of the third-party cases match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#default_notifications SecurityMonitoringRule#default_notifications}
    */
    readonly defaultNotifications?: string[];
    /**
    * Severity of the default rule case, when none of the third-party cases match. Valid values are `info`, `low`, `medium`, `high`, `critical`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#default_status SecurityMonitoringRule#default_status}
    */
    readonly defaultStatus: string;
    /**
    * A template for the signal title; if omitted, the title is generated based on the case name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#signal_title_template SecurityMonitoringRule#signal_title_template}
    */
    readonly signalTitleTemplate?: string;
    /**
    * root_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#root_query SecurityMonitoringRule#root_query}
    */
    readonly rootQuery: SecurityMonitoringRuleOptionsThirdPartyRuleOptionsRootQuery[] | cdktn.IResolvable;
}
export declare function securityMonitoringRuleOptionsThirdPartyRuleOptionsToTerraform(struct?: SecurityMonitoringRuleOptionsThirdPartyRuleOptionsOutputReference | SecurityMonitoringRuleOptionsThirdPartyRuleOptions): any;
export declare function securityMonitoringRuleOptionsThirdPartyRuleOptionsToHclTerraform(struct?: SecurityMonitoringRuleOptionsThirdPartyRuleOptionsOutputReference | SecurityMonitoringRuleOptionsThirdPartyRuleOptions): any;
export declare class SecurityMonitoringRuleOptionsThirdPartyRuleOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SecurityMonitoringRuleOptionsThirdPartyRuleOptions | undefined;
    set internalValue(value: SecurityMonitoringRuleOptionsThirdPartyRuleOptions | undefined);
    private _defaultNotifications?;
    get defaultNotifications(): string[];
    set defaultNotifications(value: string[]);
    resetDefaultNotifications(): void;
    get defaultNotificationsInput(): string[] | undefined;
    private _defaultStatus?;
    get defaultStatus(): string;
    set defaultStatus(value: string);
    get defaultStatusInput(): string | undefined;
    private _signalTitleTemplate?;
    get signalTitleTemplate(): string;
    set signalTitleTemplate(value: string);
    resetSignalTitleTemplate(): void;
    get signalTitleTemplateInput(): string | undefined;
    private _rootQuery;
    get rootQuery(): SecurityMonitoringRuleOptionsThirdPartyRuleOptionsRootQueryList;
    putRootQuery(value: SecurityMonitoringRuleOptionsThirdPartyRuleOptionsRootQuery[] | cdktn.IResolvable): void;
    get rootQueryInput(): cdktn.IResolvable | SecurityMonitoringRuleOptionsThirdPartyRuleOptionsRootQuery[] | undefined;
}
export interface SecurityMonitoringRuleOptions {
    /**
    * If true, signals in non-production environments have a lower severity than what is defined by the rule case, which can reduce noise. The decrement is applied when the environment tag of the signal starts with `staging`, `test`, or `dev`. Only available when the rule type is `log_detection`. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#decrease_criticality_based_on_env SecurityMonitoringRule#decrease_criticality_based_on_env}
    */
    readonly decreaseCriticalityBasedOnEnv?: boolean | cdktn.IResolvable;
    /**
    * The detection method. Valid values are `threshold`, `new_value`, `anomaly_detection`, `impossible_travel`, `hardcoded`, `third_party`, `anomaly_threshold`, `sequence_detection`. Defaults to `"threshold"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#detection_method SecurityMonitoringRule#detection_method}
    */
    readonly detectionMethod?: string;
    /**
    * A time window is specified to match when at least one of the cases matches true. This is a sliding window and evaluates in real time. Valid values are `0`, `60`, `300`, `600`, `900`, `1800`, `3600`, `7200`, `10800`, `21600`, `43200`, `86400`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#evaluation_window SecurityMonitoringRule#evaluation_window}
    */
    readonly evaluationWindow?: number;
    /**
    * Once a signal is generated, the signal will remain “open” if a case is matched at least once within this keep alive window (in seconds). Valid values are `0`, `60`, `300`, `600`, `900`, `1800`, `3600`, `7200`, `10800`, `21600`, `43200`, `86400`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#keep_alive SecurityMonitoringRule#keep_alive}
    */
    readonly keepAlive?: number;
    /**
    * A signal will “close” regardless of the query being matched once the time exceeds the maximum duration (in seconds). This time is calculated from the first seen timestamp. Valid values are `0`, `60`, `300`, `600`, `900`, `1800`, `3600`, `7200`, `10800`, `21600`, `43200`, `86400`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#max_signal_duration SecurityMonitoringRule#max_signal_duration}
    */
    readonly maxSignalDuration?: number;
    /**
    * anomaly_detection_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#anomaly_detection_options SecurityMonitoringRule#anomaly_detection_options}
    */
    readonly anomalyDetectionOptions?: SecurityMonitoringRuleOptionsAnomalyDetectionOptions;
    /**
    * impossible_travel_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#impossible_travel_options SecurityMonitoringRule#impossible_travel_options}
    */
    readonly impossibleTravelOptions?: SecurityMonitoringRuleOptionsImpossibleTravelOptions;
    /**
    * new_value_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#new_value_options SecurityMonitoringRule#new_value_options}
    */
    readonly newValueOptions?: SecurityMonitoringRuleOptionsNewValueOptions;
    /**
    * sequence_detection_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#sequence_detection_options SecurityMonitoringRule#sequence_detection_options}
    */
    readonly sequenceDetectionOptions?: SecurityMonitoringRuleOptionsSequenceDetectionOptions;
    /**
    * third_party_rule_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#third_party_rule_options SecurityMonitoringRule#third_party_rule_options}
    */
    readonly thirdPartyRuleOptions?: SecurityMonitoringRuleOptionsThirdPartyRuleOptions;
}
export declare function securityMonitoringRuleOptionsToTerraform(struct?: SecurityMonitoringRuleOptionsOutputReference | SecurityMonitoringRuleOptions): any;
export declare function securityMonitoringRuleOptionsToHclTerraform(struct?: SecurityMonitoringRuleOptionsOutputReference | SecurityMonitoringRuleOptions): any;
export declare class SecurityMonitoringRuleOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SecurityMonitoringRuleOptions | undefined;
    set internalValue(value: SecurityMonitoringRuleOptions | undefined);
    private _decreaseCriticalityBasedOnEnv?;
    get decreaseCriticalityBasedOnEnv(): boolean | cdktn.IResolvable;
    set decreaseCriticalityBasedOnEnv(value: boolean | cdktn.IResolvable);
    resetDecreaseCriticalityBasedOnEnv(): void;
    get decreaseCriticalityBasedOnEnvInput(): boolean | cdktn.IResolvable | undefined;
    private _detectionMethod?;
    get detectionMethod(): string;
    set detectionMethod(value: string);
    resetDetectionMethod(): void;
    get detectionMethodInput(): string | undefined;
    private _evaluationWindow?;
    get evaluationWindow(): number;
    set evaluationWindow(value: number);
    resetEvaluationWindow(): void;
    get evaluationWindowInput(): number | undefined;
    private _keepAlive?;
    get keepAlive(): number;
    set keepAlive(value: number);
    resetKeepAlive(): void;
    get keepAliveInput(): number | undefined;
    private _maxSignalDuration?;
    get maxSignalDuration(): number;
    set maxSignalDuration(value: number);
    resetMaxSignalDuration(): void;
    get maxSignalDurationInput(): number | undefined;
    private _anomalyDetectionOptions;
    get anomalyDetectionOptions(): SecurityMonitoringRuleOptionsAnomalyDetectionOptionsOutputReference;
    putAnomalyDetectionOptions(value: SecurityMonitoringRuleOptionsAnomalyDetectionOptions): void;
    resetAnomalyDetectionOptions(): void;
    get anomalyDetectionOptionsInput(): SecurityMonitoringRuleOptionsAnomalyDetectionOptions | undefined;
    private _impossibleTravelOptions;
    get impossibleTravelOptions(): SecurityMonitoringRuleOptionsImpossibleTravelOptionsOutputReference;
    putImpossibleTravelOptions(value: SecurityMonitoringRuleOptionsImpossibleTravelOptions): void;
    resetImpossibleTravelOptions(): void;
    get impossibleTravelOptionsInput(): SecurityMonitoringRuleOptionsImpossibleTravelOptions | undefined;
    private _newValueOptions;
    get newValueOptions(): SecurityMonitoringRuleOptionsNewValueOptionsOutputReference;
    putNewValueOptions(value: SecurityMonitoringRuleOptionsNewValueOptions): void;
    resetNewValueOptions(): void;
    get newValueOptionsInput(): SecurityMonitoringRuleOptionsNewValueOptions | undefined;
    private _sequenceDetectionOptions;
    get sequenceDetectionOptions(): SecurityMonitoringRuleOptionsSequenceDetectionOptionsOutputReference;
    putSequenceDetectionOptions(value: SecurityMonitoringRuleOptionsSequenceDetectionOptions): void;
    resetSequenceDetectionOptions(): void;
    get sequenceDetectionOptionsInput(): SecurityMonitoringRuleOptionsSequenceDetectionOptions | undefined;
    private _thirdPartyRuleOptions;
    get thirdPartyRuleOptions(): SecurityMonitoringRuleOptionsThirdPartyRuleOptionsOutputReference;
    putThirdPartyRuleOptions(value: SecurityMonitoringRuleOptionsThirdPartyRuleOptions): void;
    resetThirdPartyRuleOptions(): void;
    get thirdPartyRuleOptionsInput(): SecurityMonitoringRuleOptionsThirdPartyRuleOptions | undefined;
}
export interface SecurityMonitoringRuleQueryAgentRule {
    /**
    * **Deprecated**. It won't be applied anymore.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#agent_rule_id SecurityMonitoringRule#agent_rule_id}
    */
    readonly agentRuleId: string;
    /**
    * **Deprecated**. It won't be applied anymore.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#expression SecurityMonitoringRule#expression}
    */
    readonly expression: string;
}
export declare function securityMonitoringRuleQueryAgentRuleToTerraform(struct?: SecurityMonitoringRuleQueryAgentRule | cdktn.IResolvable): any;
export declare function securityMonitoringRuleQueryAgentRuleToHclTerraform(struct?: SecurityMonitoringRuleQueryAgentRule | cdktn.IResolvable): any;
export declare class SecurityMonitoringRuleQueryAgentRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SecurityMonitoringRuleQueryAgentRule | cdktn.IResolvable | undefined;
    set internalValue(value: SecurityMonitoringRuleQueryAgentRule | cdktn.IResolvable | undefined);
    private _agentRuleId?;
    get agentRuleId(): string;
    set agentRuleId(value: string);
    get agentRuleIdInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
}
export declare class SecurityMonitoringRuleQueryAgentRuleList extends cdktn.ComplexList {
    internalValue?: SecurityMonitoringRuleQueryAgentRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SecurityMonitoringRuleQueryAgentRuleOutputReference;
}
export interface SecurityMonitoringRuleQuery {
    /**
    * The aggregation type. For Signal Correlation rules, it must be event_count. Valid values are `count`, `cardinality`, `sum`, `max`, `new_value`, `geo_data`, `event_count`, `none`. Defaults to `"count"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#aggregation SecurityMonitoringRule#aggregation}
    */
    readonly aggregation?: string;
    /**
    * Source of events. Valid values are `logs`, `audit`, `app_sec_spans`, `spans`, `security_runtime`, `network`, `events`. Defaults to `"logs"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#data_source SecurityMonitoringRule#data_source}
    */
    readonly dataSource?: string;
    /**
    * Field for which the cardinality is measured. Sent as an array.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#distinct_fields SecurityMonitoringRule#distinct_fields}
    */
    readonly distinctFields?: string[];
    /**
    * Fields to group by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#group_by_fields SecurityMonitoringRule#group_by_fields}
    */
    readonly groupByFields?: string[];
    /**
    * When false, events without a group-by value are ignored by the rule. When true, events with missing group-by fields are processed with `N/A`, replacing the missing values. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#has_optional_group_by_fields SecurityMonitoringRule#has_optional_group_by_fields}
    */
    readonly hasOptionalGroupByFields?: boolean | cdktn.IResolvable;
    /**
    * List of indexes to run the query on when the data source is `logs`. Supports only one element. Used only for scheduled rules (in other words, when `scheduling_options` is defined).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#indexes SecurityMonitoringRule#indexes}
    */
    readonly indexes?: string[];
    /**
    * The target field to aggregate over when using the `sum`, `max`, or `geo_data` aggregations. **Deprecated.** Configure `metrics` instead. This attribute will be removed in the next major version of the provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#metric SecurityMonitoringRule#metric}
    */
    readonly metric?: string;
    /**
    * Group of target fields to aggregate over when using the `sum`, `max`, `geo_data`, or `new_value` aggregations. The `sum`, `max`, and `geo_data` aggregations only accept one value in this list, whereas the `new_value` aggregation accepts up to five values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#metrics SecurityMonitoringRule#metrics}
    */
    readonly metrics?: string[];
    /**
    * Name of the query. Not compatible with `new_value` aggregations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#name SecurityMonitoringRule#name}
    */
    readonly name?: string;
    /**
    * Query to run on logs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#query SecurityMonitoringRule#query}
    */
    readonly query: string;
    /**
    * agent_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#agent_rule SecurityMonitoringRule#agent_rule}
    */
    readonly agentRule?: SecurityMonitoringRuleQueryAgentRule[] | cdktn.IResolvable;
}
export declare function securityMonitoringRuleQueryToTerraform(struct?: SecurityMonitoringRuleQuery | cdktn.IResolvable): any;
export declare function securityMonitoringRuleQueryToHclTerraform(struct?: SecurityMonitoringRuleQuery | cdktn.IResolvable): any;
export declare class SecurityMonitoringRuleQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SecurityMonitoringRuleQuery | cdktn.IResolvable | undefined;
    set internalValue(value: SecurityMonitoringRuleQuery | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    resetAggregation(): void;
    get aggregationInput(): string | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    resetDataSource(): void;
    get dataSourceInput(): string | undefined;
    private _distinctFields?;
    get distinctFields(): string[];
    set distinctFields(value: string[]);
    resetDistinctFields(): void;
    get distinctFieldsInput(): string[] | undefined;
    private _groupByFields?;
    get groupByFields(): string[];
    set groupByFields(value: string[]);
    resetGroupByFields(): void;
    get groupByFieldsInput(): string[] | undefined;
    private _hasOptionalGroupByFields?;
    get hasOptionalGroupByFields(): boolean | cdktn.IResolvable;
    set hasOptionalGroupByFields(value: boolean | cdktn.IResolvable);
    resetHasOptionalGroupByFields(): void;
    get hasOptionalGroupByFieldsInput(): boolean | cdktn.IResolvable | undefined;
    private _indexes?;
    get indexes(): string[];
    set indexes(value: string[]);
    resetIndexes(): void;
    get indexesInput(): string[] | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _metrics?;
    get metrics(): string[];
    set metrics(value: string[]);
    resetMetrics(): void;
    get metricsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _agentRule;
    get agentRule(): SecurityMonitoringRuleQueryAgentRuleList;
    putAgentRule(value: SecurityMonitoringRuleQueryAgentRule[] | cdktn.IResolvable): void;
    resetAgentRule(): void;
    get agentRuleInput(): cdktn.IResolvable | SecurityMonitoringRuleQueryAgentRule[] | undefined;
}
export declare class SecurityMonitoringRuleQueryList extends cdktn.ComplexList {
    internalValue?: SecurityMonitoringRuleQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SecurityMonitoringRuleQueryOutputReference;
}
export interface SecurityMonitoringRuleReferenceTables {
    /**
    * Whether to include or exclude logs that match the reference table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#check_presence SecurityMonitoringRule#check_presence}
    */
    readonly checkPresence: boolean | cdktn.IResolvable;
    /**
    * The name of the column in the reference table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#column_name SecurityMonitoringRule#column_name}
    */
    readonly columnName: string;
    /**
    * The field in the log that should be matched against the reference table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#log_field_path SecurityMonitoringRule#log_field_path}
    */
    readonly logFieldPath: string;
    /**
    * The name of the query to filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#rule_query_name SecurityMonitoringRule#rule_query_name}
    */
    readonly ruleQueryName: string;
    /**
    * The name of the reference table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#table_name SecurityMonitoringRule#table_name}
    */
    readonly tableName: string;
}
export declare function securityMonitoringRuleReferenceTablesToTerraform(struct?: SecurityMonitoringRuleReferenceTables | cdktn.IResolvable): any;
export declare function securityMonitoringRuleReferenceTablesToHclTerraform(struct?: SecurityMonitoringRuleReferenceTables | cdktn.IResolvable): any;
export declare class SecurityMonitoringRuleReferenceTablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SecurityMonitoringRuleReferenceTables | cdktn.IResolvable | undefined;
    set internalValue(value: SecurityMonitoringRuleReferenceTables | cdktn.IResolvable | undefined);
    private _checkPresence?;
    get checkPresence(): boolean | cdktn.IResolvable;
    set checkPresence(value: boolean | cdktn.IResolvable);
    get checkPresenceInput(): boolean | cdktn.IResolvable | undefined;
    private _columnName?;
    get columnName(): string;
    set columnName(value: string);
    get columnNameInput(): string | undefined;
    private _logFieldPath?;
    get logFieldPath(): string;
    set logFieldPath(value: string);
    get logFieldPathInput(): string | undefined;
    private _ruleQueryName?;
    get ruleQueryName(): string;
    set ruleQueryName(value: string);
    get ruleQueryNameInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
}
export declare class SecurityMonitoringRuleReferenceTablesList extends cdktn.ComplexList {
    internalValue?: SecurityMonitoringRuleReferenceTables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SecurityMonitoringRuleReferenceTablesOutputReference;
}
export interface SecurityMonitoringRuleSchedulingOptions {
    /**
    * Schedule for the rule queries, written in RRULE syntax. See [RFC](https://icalendar.org/iCalendar-RFC-5545/3-8-5-3-recurrence-rule.html) for syntax reference.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#rrule SecurityMonitoringRule#rrule}
    */
    readonly rrule: string;
    /**
    * Start date for the schedule, in ISO 8601 format without timezone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#start SecurityMonitoringRule#start}
    */
    readonly start: string;
    /**
    * Time zone of the start date, in the [tz database](https://en.wikipedia.org/wiki/List_of_tz_database_time_zones) format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#timezone SecurityMonitoringRule#timezone}
    */
    readonly timezone: string;
}
export declare function securityMonitoringRuleSchedulingOptionsToTerraform(struct?: SecurityMonitoringRuleSchedulingOptionsOutputReference | SecurityMonitoringRuleSchedulingOptions): any;
export declare function securityMonitoringRuleSchedulingOptionsToHclTerraform(struct?: SecurityMonitoringRuleSchedulingOptionsOutputReference | SecurityMonitoringRuleSchedulingOptions): any;
export declare class SecurityMonitoringRuleSchedulingOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SecurityMonitoringRuleSchedulingOptions | undefined;
    set internalValue(value: SecurityMonitoringRuleSchedulingOptions | undefined);
    private _rrule?;
    get rrule(): string;
    set rrule(value: string);
    get rruleInput(): string | undefined;
    private _start?;
    get start(): string;
    set start(value: string);
    get startInput(): string | undefined;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    get timezoneInput(): string | undefined;
}
export interface SecurityMonitoringRuleSignalQuery {
    /**
    * The aggregation type. For Signal Correlation rules, it must be event_count. Valid values are `count`, `cardinality`, `sum`, `max`, `new_value`, `geo_data`, `event_count`, `none`. Defaults to `"event_count"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#aggregation SecurityMonitoringRule#aggregation}
    */
    readonly aggregation?: string;
    /**
    * Fields to correlate by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#correlated_by_fields SecurityMonitoringRule#correlated_by_fields}
    */
    readonly correlatedByFields?: string[];
    /**
    * Index of the rule query used to retrieve the correlated field. An empty string applies correlation on the non-projected per query attributes of the rule. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#correlated_query_index SecurityMonitoringRule#correlated_query_index}
    */
    readonly correlatedQueryIndex?: string;
    /**
    * Default Rule ID of the signal to correlate. This value is READ-ONLY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#default_rule_id SecurityMonitoringRule#default_rule_id}
    */
    readonly defaultRuleId?: string;
    /**
    * Name of the query. Not compatible with `new_value` aggregations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#name SecurityMonitoringRule#name}
    */
    readonly name?: string;
    /**
    * Rule ID of the signal to correlate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#rule_id SecurityMonitoringRule#rule_id}
    */
    readonly ruleId: string;
}
export declare function securityMonitoringRuleSignalQueryToTerraform(struct?: SecurityMonitoringRuleSignalQuery | cdktn.IResolvable): any;
export declare function securityMonitoringRuleSignalQueryToHclTerraform(struct?: SecurityMonitoringRuleSignalQuery | cdktn.IResolvable): any;
export declare class SecurityMonitoringRuleSignalQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SecurityMonitoringRuleSignalQuery | cdktn.IResolvable | undefined;
    set internalValue(value: SecurityMonitoringRuleSignalQuery | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    resetAggregation(): void;
    get aggregationInput(): string | undefined;
    private _correlatedByFields?;
    get correlatedByFields(): string[];
    set correlatedByFields(value: string[]);
    resetCorrelatedByFields(): void;
    get correlatedByFieldsInput(): string[] | undefined;
    private _correlatedQueryIndex?;
    get correlatedQueryIndex(): string;
    set correlatedQueryIndex(value: string);
    resetCorrelatedQueryIndex(): void;
    get correlatedQueryIndexInput(): string | undefined;
    private _defaultRuleId?;
    get defaultRuleId(): string;
    set defaultRuleId(value: string);
    resetDefaultRuleId(): void;
    get defaultRuleIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _ruleId?;
    get ruleId(): string;
    set ruleId(value: string);
    get ruleIdInput(): string | undefined;
}
export declare class SecurityMonitoringRuleSignalQueryList extends cdktn.ComplexList {
    internalValue?: SecurityMonitoringRuleSignalQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SecurityMonitoringRuleSignalQueryOutputReference;
}
export interface SecurityMonitoringRuleThirdPartyCase {
    /**
    * Name of the case.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#name SecurityMonitoringRule#name}
    */
    readonly name?: string;
    /**
    * Notification targets for each rule case.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#notifications SecurityMonitoringRule#notifications}
    */
    readonly notifications?: string[];
    /**
    * A query to associate a third-party event to this case.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#query SecurityMonitoringRule#query}
    */
    readonly query?: string;
    /**
    * Severity of the Security Signal. Valid values are `info`, `low`, `medium`, `high`, `critical`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#status SecurityMonitoringRule#status}
    */
    readonly status: string;
}
export declare function securityMonitoringRuleThirdPartyCaseToTerraform(struct?: SecurityMonitoringRuleThirdPartyCase | cdktn.IResolvable): any;
export declare function securityMonitoringRuleThirdPartyCaseToHclTerraform(struct?: SecurityMonitoringRuleThirdPartyCase | cdktn.IResolvable): any;
export declare class SecurityMonitoringRuleThirdPartyCaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SecurityMonitoringRuleThirdPartyCase | cdktn.IResolvable | undefined;
    set internalValue(value: SecurityMonitoringRuleThirdPartyCase | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _notifications?;
    get notifications(): string[];
    set notifications(value: string[]);
    resetNotifications(): void;
    get notificationsInput(): string[] | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
}
export declare class SecurityMonitoringRuleThirdPartyCaseList extends cdktn.ComplexList {
    internalValue?: SecurityMonitoringRuleThirdPartyCase[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SecurityMonitoringRuleThirdPartyCaseOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule datadog_security_monitoring_rule}
*/
export declare class SecurityMonitoringRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_security_monitoring_rule";
    /**
    * Generates CDKTN code for importing a SecurityMonitoringRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecurityMonitoringRule to import
    * @param importFromId The id of the existing SecurityMonitoringRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecurityMonitoringRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule datadog_security_monitoring_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecurityMonitoringRuleConfig
    */
    constructor(scope: Construct, id: string, config: SecurityMonitoringRuleConfig);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _groupSignalsBy?;
    get groupSignalsBy(): string[];
    set groupSignalsBy(value: string[]);
    resetGroupSignalsBy(): void;
    get groupSignalsByInput(): string[] | undefined;
    private _hasExtendedTitle?;
    get hasExtendedTitle(): boolean | cdktn.IResolvable;
    set hasExtendedTitle(value: boolean | cdktn.IResolvable);
    resetHasExtendedTitle(): void;
    get hasExtendedTitleInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _message?;
    get message(): string;
    set message(value: string);
    get messageInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _validate?;
    get validate(): boolean | cdktn.IResolvable;
    set validate(value: boolean | cdktn.IResolvable);
    resetValidate(): void;
    get validateInput(): boolean | cdktn.IResolvable | undefined;
    private _calculatedField;
    get calculatedField(): SecurityMonitoringRuleCalculatedFieldList;
    putCalculatedField(value: SecurityMonitoringRuleCalculatedField[] | cdktn.IResolvable): void;
    resetCalculatedField(): void;
    get calculatedFieldInput(): cdktn.IResolvable | SecurityMonitoringRuleCalculatedField[] | undefined;
    private _case;
    get case(): SecurityMonitoringRuleCaseList;
    putCase(value: SecurityMonitoringRuleCase[] | cdktn.IResolvable): void;
    resetCase(): void;
    get caseInput(): cdktn.IResolvable | SecurityMonitoringRuleCase[] | undefined;
    private _filter;
    get filter(): SecurityMonitoringRuleFilterList;
    putFilter(value: SecurityMonitoringRuleFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | SecurityMonitoringRuleFilter[] | undefined;
    private _options;
    get options(): SecurityMonitoringRuleOptionsOutputReference;
    putOptions(value: SecurityMonitoringRuleOptions): void;
    resetOptions(): void;
    get optionsInput(): SecurityMonitoringRuleOptions | undefined;
    private _query;
    get query(): SecurityMonitoringRuleQueryList;
    putQuery(value: SecurityMonitoringRuleQuery[] | cdktn.IResolvable): void;
    resetQuery(): void;
    get queryInput(): cdktn.IResolvable | SecurityMonitoringRuleQuery[] | undefined;
    private _referenceTables;
    get referenceTables(): SecurityMonitoringRuleReferenceTablesList;
    putReferenceTables(value: SecurityMonitoringRuleReferenceTables[] | cdktn.IResolvable): void;
    resetReferenceTables(): void;
    get referenceTablesInput(): cdktn.IResolvable | SecurityMonitoringRuleReferenceTables[] | undefined;
    private _schedulingOptions;
    get schedulingOptions(): SecurityMonitoringRuleSchedulingOptionsOutputReference;
    putSchedulingOptions(value: SecurityMonitoringRuleSchedulingOptions): void;
    resetSchedulingOptions(): void;
    get schedulingOptionsInput(): SecurityMonitoringRuleSchedulingOptions | undefined;
    private _signalQuery;
    get signalQuery(): SecurityMonitoringRuleSignalQueryList;
    putSignalQuery(value: SecurityMonitoringRuleSignalQuery[] | cdktn.IResolvable): void;
    resetSignalQuery(): void;
    get signalQueryInput(): cdktn.IResolvable | SecurityMonitoringRuleSignalQuery[] | undefined;
    private _thirdPartyCase;
    get thirdPartyCase(): SecurityMonitoringRuleThirdPartyCaseList;
    putThirdPartyCase(value: SecurityMonitoringRuleThirdPartyCase[] | cdktn.IResolvable): void;
    resetThirdPartyCase(): void;
    get thirdPartyCaseInput(): cdktn.IResolvable | SecurityMonitoringRuleThirdPartyCase[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
