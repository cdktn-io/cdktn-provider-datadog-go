/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogCsmThreatsPoliciesConfig extends cdktn.TerraformMetaArguments {
}
export interface DataDatadogCsmThreatsPoliciesPolicies {
}
export declare function dataDatadogCsmThreatsPoliciesPoliciesToTerraform(struct?: DataDatadogCsmThreatsPoliciesPolicies): any;
export declare function dataDatadogCsmThreatsPoliciesPoliciesToHclTerraform(struct?: DataDatadogCsmThreatsPoliciesPolicies): any;
export declare class DataDatadogCsmThreatsPoliciesPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogCsmThreatsPoliciesPolicies | undefined;
    set internalValue(value: DataDatadogCsmThreatsPoliciesPolicies | undefined);
    get description(): string;
    get enabled(): cdktn.IResolvable;
    private _hostTagsLists;
    get hostTagsLists(): cdktn.StringListList;
    get id(): string;
    get name(): string;
    get tags(): string[];
}
export declare class DataDatadogCsmThreatsPoliciesPoliciesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogCsmThreatsPoliciesPoliciesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/csm_threats_policies datadog_csm_threats_policies}
*/
export declare class DataDatadogCsmThreatsPolicies extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_csm_threats_policies";
    /**
    * Generates CDKTN code for importing a DataDatadogCsmThreatsPolicies resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogCsmThreatsPolicies to import
    * @param importFromId The id of the existing DataDatadogCsmThreatsPolicies that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/csm_threats_policies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogCsmThreatsPolicies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/csm_threats_policies datadog_csm_threats_policies} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogCsmThreatsPoliciesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogCsmThreatsPoliciesConfig);
    get id(): string;
    private _policies;
    get policies(): DataDatadogCsmThreatsPoliciesPoliciesList;
    get policyIds(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
