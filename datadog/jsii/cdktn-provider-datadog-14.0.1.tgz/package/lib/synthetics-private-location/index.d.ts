/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SyntheticsPrivateLocationConfig extends cdktn.TerraformMetaArguments {
    /**
    * API key used to generate the private location configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_private_location#api_key SyntheticsPrivateLocation#api_key}
    */
    readonly apiKey?: string;
    /**
    * Description of the private location. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_private_location#description SyntheticsPrivateLocation#description}
    */
    readonly description?: string;
    /**
    * Synthetics private location name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_private_location#name SyntheticsPrivateLocation#name}
    */
    readonly name: string;
    /**
    * A list of tags to associate with your synthetics private location.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_private_location#tags SyntheticsPrivateLocation#tags}
    */
    readonly tags?: string[];
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_private_location#metadata SyntheticsPrivateLocation#metadata}
    */
    readonly metadata?: SyntheticsPrivateLocationMetadata[] | cdktn.IResolvable;
}
export interface SyntheticsPrivateLocationMetadata {
    /**
    * A set of role identifiers pulled from the Roles API to restrict read and write access. **Deprecated.** This field is no longer supported by the Datadog API. Please use `datadog_restriction_policy` instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_private_location#restricted_roles SyntheticsPrivateLocation#restricted_roles}
    */
    readonly restrictedRoles?: string[];
}
export declare function syntheticsPrivateLocationMetadataToTerraform(struct?: SyntheticsPrivateLocationMetadata | cdktn.IResolvable): any;
export declare function syntheticsPrivateLocationMetadataToHclTerraform(struct?: SyntheticsPrivateLocationMetadata | cdktn.IResolvable): any;
export declare class SyntheticsPrivateLocationMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsPrivateLocationMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsPrivateLocationMetadata | cdktn.IResolvable | undefined);
    private _restrictedRoles?;
    get restrictedRoles(): string[];
    set restrictedRoles(value: string[]);
    resetRestrictedRoles(): void;
    get restrictedRolesInput(): string[] | undefined;
}
export declare class SyntheticsPrivateLocationMetadataList extends cdktn.ComplexList {
    internalValue?: SyntheticsPrivateLocationMetadata[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsPrivateLocationMetadataOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_private_location datadog_synthetics_private_location}
*/
export declare class SyntheticsPrivateLocation extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_synthetics_private_location";
    /**
    * Generates CDKTN code for importing a SyntheticsPrivateLocation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SyntheticsPrivateLocation to import
    * @param importFromId The id of the existing SyntheticsPrivateLocation that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_private_location#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SyntheticsPrivateLocation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_private_location datadog_synthetics_private_location} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SyntheticsPrivateLocationConfig
    */
    constructor(scope: Construct, id: string, config: SyntheticsPrivateLocationConfig);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
    get config(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get restrictionPolicyResourceId(): string;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _metadata;
    get metadata(): SyntheticsPrivateLocationMetadataList;
    putMetadata(value: SyntheticsPrivateLocationMetadata[] | cdktn.IResolvable): void;
    resetMetadata(): void;
    get metadataInput(): cdktn.IResolvable | SyntheticsPrivateLocationMetadata[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
