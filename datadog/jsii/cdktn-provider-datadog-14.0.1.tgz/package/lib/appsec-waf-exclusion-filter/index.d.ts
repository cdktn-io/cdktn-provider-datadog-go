/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppsecWafExclusionFilterConfig extends cdktn.TerraformMetaArguments {
    /**
    * A description for the exclusion filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_exclusion_filter#description AppsecWafExclusionFilter#description}
    */
    readonly description: string;
    /**
    * Indicates whether the exclusion filter is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_exclusion_filter#enabled AppsecWafExclusionFilter#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * The event query matched by the legacy exclusion filter. Cannot be created nor updated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_exclusion_filter#event_query AppsecWafExclusionFilter#event_query}
    */
    readonly eventQuery?: string;
    /**
    * The client IP addresses matched by the exclusion filter (CIDR notation is supported).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_exclusion_filter#ip_list AppsecWafExclusionFilter#ip_list}
    */
    readonly ipList?: string[];
    /**
    * The action taken when the exclusion filter matches. When set to `monitor`, security traces are emitted but the requests are not blocked. By default, security traces are not emitted and the requests are not blocked.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_exclusion_filter#on_match AppsecWafExclusionFilter#on_match}
    */
    readonly onMatch?: string;
    /**
    * A list of parameters matched by the exclusion filter in the HTTP query string and HTTP request body. Nested parameters can be matched by joining fields with a dot character.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_exclusion_filter#parameters AppsecWafExclusionFilter#parameters}
    */
    readonly parameters?: string[];
    /**
    * The HTTP path glob expression matched by the exclusion filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_exclusion_filter#path_glob AppsecWafExclusionFilter#path_glob}
    */
    readonly pathGlob?: string;
    /**
    * rules_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_exclusion_filter#rules_target AppsecWafExclusionFilter#rules_target}
    */
    readonly rulesTarget?: AppsecWafExclusionFilterRulesTarget[] | cdktn.IResolvable;
    /**
    * scope block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_exclusion_filter#scope AppsecWafExclusionFilter#scope}
    */
    readonly scope?: AppsecWafExclusionFilterScope[] | cdktn.IResolvable;
}
export interface AppsecWafExclusionFilterRulesTargetTags {
    /**
    * The category of the targeted WAF rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_exclusion_filter#category AppsecWafExclusionFilter#category}
    */
    readonly category?: string;
    /**
    * The type of the targeted WAF rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_exclusion_filter#type AppsecWafExclusionFilter#type}
    */
    readonly type?: string;
}
export declare function appsecWafExclusionFilterRulesTargetTagsToTerraform(struct?: AppsecWafExclusionFilterRulesTargetTags | cdktn.IResolvable): any;
export declare function appsecWafExclusionFilterRulesTargetTagsToHclTerraform(struct?: AppsecWafExclusionFilterRulesTargetTags | cdktn.IResolvable): any;
export declare class AppsecWafExclusionFilterRulesTargetTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsecWafExclusionFilterRulesTargetTags | cdktn.IResolvable | undefined;
    set internalValue(value: AppsecWafExclusionFilterRulesTargetTags | cdktn.IResolvable | undefined);
    private _category?;
    get category(): string;
    set category(value: string);
    resetCategory(): void;
    get categoryInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface AppsecWafExclusionFilterRulesTarget {
    /**
    * Target a single WAF rule based on its identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_exclusion_filter#rule_id AppsecWafExclusionFilter#rule_id}
    */
    readonly ruleId?: string;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_exclusion_filter#tags AppsecWafExclusionFilter#tags}
    */
    readonly tags?: AppsecWafExclusionFilterRulesTargetTags;
}
export declare function appsecWafExclusionFilterRulesTargetToTerraform(struct?: AppsecWafExclusionFilterRulesTarget | cdktn.IResolvable): any;
export declare function appsecWafExclusionFilterRulesTargetToHclTerraform(struct?: AppsecWafExclusionFilterRulesTarget | cdktn.IResolvable): any;
export declare class AppsecWafExclusionFilterRulesTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsecWafExclusionFilterRulesTarget | cdktn.IResolvable | undefined;
    set internalValue(value: AppsecWafExclusionFilterRulesTarget | cdktn.IResolvable | undefined);
    private _ruleId?;
    get ruleId(): string;
    set ruleId(value: string);
    resetRuleId(): void;
    get ruleIdInput(): string | undefined;
    private _tags;
    get tags(): AppsecWafExclusionFilterRulesTargetTagsOutputReference;
    putTags(value: AppsecWafExclusionFilterRulesTargetTags): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AppsecWafExclusionFilterRulesTargetTags | undefined;
}
export declare class AppsecWafExclusionFilterRulesTargetList extends cdktn.ComplexList {
    internalValue?: AppsecWafExclusionFilterRulesTarget[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsecWafExclusionFilterRulesTargetOutputReference;
}
export interface AppsecWafExclusionFilterScope {
    /**
    * Deploy on this environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_exclusion_filter#env AppsecWafExclusionFilter#env}
    */
    readonly env?: string;
    /**
    * Deploy on this service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_exclusion_filter#service AppsecWafExclusionFilter#service}
    */
    readonly service?: string;
}
export declare function appsecWafExclusionFilterScopeToTerraform(struct?: AppsecWafExclusionFilterScope | cdktn.IResolvable): any;
export declare function appsecWafExclusionFilterScopeToHclTerraform(struct?: AppsecWafExclusionFilterScope | cdktn.IResolvable): any;
export declare class AppsecWafExclusionFilterScopeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsecWafExclusionFilterScope | cdktn.IResolvable | undefined;
    set internalValue(value: AppsecWafExclusionFilterScope | cdktn.IResolvable | undefined);
    private _env?;
    get env(): string;
    set env(value: string);
    resetEnv(): void;
    get envInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
}
export declare class AppsecWafExclusionFilterScopeList extends cdktn.ComplexList {
    internalValue?: AppsecWafExclusionFilterScope[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsecWafExclusionFilterScopeOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_exclusion_filter datadog_appsec_waf_exclusion_filter}
*/
export declare class AppsecWafExclusionFilter extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_appsec_waf_exclusion_filter";
    /**
    * Generates CDKTN code for importing a AppsecWafExclusionFilter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppsecWafExclusionFilter to import
    * @param importFromId The id of the existing AppsecWafExclusionFilter that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_exclusion_filter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppsecWafExclusionFilter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/appsec_waf_exclusion_filter datadog_appsec_waf_exclusion_filter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppsecWafExclusionFilterConfig
    */
    constructor(scope: Construct, id: string, config: AppsecWafExclusionFilterConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _eventQuery?;
    get eventQuery(): string;
    set eventQuery(value: string);
    resetEventQuery(): void;
    get eventQueryInput(): string | undefined;
    get id(): string;
    private _ipList?;
    get ipList(): string[];
    set ipList(value: string[]);
    resetIpList(): void;
    get ipListInput(): string[] | undefined;
    private _onMatch?;
    get onMatch(): string;
    set onMatch(value: string);
    resetOnMatch(): void;
    get onMatchInput(): string | undefined;
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
    private _pathGlob?;
    get pathGlob(): string;
    set pathGlob(value: string);
    resetPathGlob(): void;
    get pathGlobInput(): string | undefined;
    private _rulesTarget;
    get rulesTarget(): AppsecWafExclusionFilterRulesTargetList;
    putRulesTarget(value: AppsecWafExclusionFilterRulesTarget[] | cdktn.IResolvable): void;
    resetRulesTarget(): void;
    get rulesTargetInput(): cdktn.IResolvable | AppsecWafExclusionFilterRulesTarget[] | undefined;
    private _scope;
    get scope(): AppsecWafExclusionFilterScopeList;
    putScope(value: AppsecWafExclusionFilterScope[] | cdktn.IResolvable): void;
    resetScope(): void;
    get scopeInput(): cdktn.IResolvable | AppsecWafExclusionFilterScope[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
