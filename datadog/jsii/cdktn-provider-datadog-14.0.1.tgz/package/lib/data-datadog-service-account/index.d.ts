/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogServiceAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * When true, `filter` string is exact matched against the user's `email`, followed by `name` attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_account#exact_match DataDatadogServiceAccount#exact_match}
    */
    readonly exactMatch?: boolean | cdktn.IResolvable;
    /**
    * Filter all users and service accounts by name, email, or role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_account#filter DataDatadogServiceAccount#filter}
    */
    readonly filter?: string;
    /**
    * Filter on status attribute. Comma separated list, with possible values `Active`, `Pending`, and `Disabled`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_account#filter_status DataDatadogServiceAccount#filter_status}
    */
    readonly filterStatus?: string;
    /**
    * The service account's ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_account#id DataDatadogServiceAccount#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_account datadog_service_account}
*/
export declare class DataDatadogServiceAccount extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_service_account";
    /**
    * Generates CDKTN code for importing a DataDatadogServiceAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogServiceAccount to import
    * @param importFromId The id of the existing DataDatadogServiceAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogServiceAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_account datadog_service_account} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogServiceAccountConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogServiceAccountConfig);
    get disabled(): cdktn.IResolvable;
    get email(): string;
    private _exactMatch?;
    get exactMatch(): boolean | cdktn.IResolvable;
    set exactMatch(value: boolean | cdktn.IResolvable);
    resetExactMatch(): void;
    get exactMatchInput(): boolean | cdktn.IResolvable | undefined;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _filterStatus?;
    get filterStatus(): string;
    set filterStatus(value: string);
    resetFilterStatus(): void;
    get filterStatusInput(): string | undefined;
    get handle(): string;
    get icon(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    get roles(): string[];
    get status(): string;
    get title(): string;
    get verified(): cdktn.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
