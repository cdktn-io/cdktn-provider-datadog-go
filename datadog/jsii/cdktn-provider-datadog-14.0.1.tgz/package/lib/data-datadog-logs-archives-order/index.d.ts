/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogLogsArchivesOrderConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/logs_archives_order#id DataDatadogLogsArchivesOrder#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/logs_archives_order datadog_logs_archives_order}
*/
export declare class DataDatadogLogsArchivesOrder extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_logs_archives_order";
    /**
    * Generates CDKTN code for importing a DataDatadogLogsArchivesOrder resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogLogsArchivesOrder to import
    * @param importFromId The id of the existing DataDatadogLogsArchivesOrder that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/logs_archives_order#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogLogsArchivesOrder to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/logs_archives_order datadog_logs_archives_order} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogLogsArchivesOrderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogLogsArchivesOrderConfig);
    get archiveIds(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
