/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GcpUcConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Google Cloud account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/gcp_uc_config#billing_account_id GcpUcConfig#billing_account_id}
    */
    readonly billingAccountId: string;
    /**
    * The Google Cloud bucket name used to store the Usage Cost export.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/gcp_uc_config#bucket_name GcpUcConfig#bucket_name}
    */
    readonly bucketName: string;
    /**
    * The export dataset name used for the Google Cloud Usage Cost report.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/gcp_uc_config#export_dataset_name GcpUcConfig#export_dataset_name}
    */
    readonly exportDatasetName: string;
    /**
    * The export prefix used for the Google Cloud Usage Cost report.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/gcp_uc_config#export_prefix GcpUcConfig#export_prefix}
    */
    readonly exportPrefix?: string;
    /**
    * The name of the Google Cloud Usage Cost report.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/gcp_uc_config#export_project_name GcpUcConfig#export_project_name}
    */
    readonly exportProjectName: string;
    /**
    * The unique Google Cloud service account email.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/gcp_uc_config#service_account GcpUcConfig#service_account}
    */
    readonly serviceAccount: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/gcp_uc_config datadog_gcp_uc_config}
*/
export declare class GcpUcConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_gcp_uc_config";
    /**
    * Generates CDKTN code for importing a GcpUcConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GcpUcConfig to import
    * @param importFromId The id of the existing GcpUcConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/gcp_uc_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GcpUcConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/gcp_uc_config datadog_gcp_uc_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GcpUcConfigConfig
    */
    constructor(scope: Construct, id: string, config: GcpUcConfigConfig);
    private _billingAccountId?;
    get billingAccountId(): string;
    set billingAccountId(value: string);
    get billingAccountIdInput(): string | undefined;
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    get bucketNameInput(): string | undefined;
    get createdAt(): string;
    get dataset(): string;
    get errorMessages(): string[];
    private _exportDatasetName?;
    get exportDatasetName(): string;
    set exportDatasetName(value: string);
    get exportDatasetNameInput(): string | undefined;
    private _exportPrefix?;
    get exportPrefix(): string;
    set exportPrefix(value: string);
    resetExportPrefix(): void;
    get exportPrefixInput(): string | undefined;
    private _exportProjectName?;
    get exportProjectName(): string;
    set exportProjectName(value: string);
    get exportProjectNameInput(): string | undefined;
    get id(): string;
    get months(): number;
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    get serviceAccountInput(): string | undefined;
    get status(): string;
    get statusUpdatedAt(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
