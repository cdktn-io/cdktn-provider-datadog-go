/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OnCallTeamRoutingRulesConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the team to associate the routing rules with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules#id OnCallTeamRoutingRules#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules#rule OnCallTeamRoutingRules#rule}
    */
    readonly rule?: OnCallTeamRoutingRulesRule[] | cdktn.IResolvable;
}
export interface OnCallTeamRoutingRulesRuleActionSendSlackMessage {
    /**
    * Slack channel ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules#channel OnCallTeamRoutingRules#channel}
    */
    readonly channel?: string;
    /**
    * Slack workspace ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules#workspace OnCallTeamRoutingRules#workspace}
    */
    readonly workspace?: string;
}
export declare function onCallTeamRoutingRulesRuleActionSendSlackMessageToTerraform(struct?: OnCallTeamRoutingRulesRuleActionSendSlackMessage | cdktn.IResolvable): any;
export declare function onCallTeamRoutingRulesRuleActionSendSlackMessageToHclTerraform(struct?: OnCallTeamRoutingRulesRuleActionSendSlackMessage | cdktn.IResolvable): any;
export declare class OnCallTeamRoutingRulesRuleActionSendSlackMessageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OnCallTeamRoutingRulesRuleActionSendSlackMessage | cdktn.IResolvable | undefined;
    set internalValue(value: OnCallTeamRoutingRulesRuleActionSendSlackMessage | cdktn.IResolvable | undefined);
    private _channel?;
    get channel(): string;
    set channel(value: string);
    resetChannel(): void;
    get channelInput(): string | undefined;
    private _workspace?;
    get workspace(): string;
    set workspace(value: string);
    resetWorkspace(): void;
    get workspaceInput(): string | undefined;
}
export interface OnCallTeamRoutingRulesRuleActionSendTeamsMessage {
    /**
    * Teams channel ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules#channel OnCallTeamRoutingRules#channel}
    */
    readonly channel?: string;
    /**
    * Teams team ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules#team OnCallTeamRoutingRules#team}
    */
    readonly team?: string;
    /**
    * Teams tenant ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules#tenant OnCallTeamRoutingRules#tenant}
    */
    readonly tenant?: string;
}
export declare function onCallTeamRoutingRulesRuleActionSendTeamsMessageToTerraform(struct?: OnCallTeamRoutingRulesRuleActionSendTeamsMessage | cdktn.IResolvable): any;
export declare function onCallTeamRoutingRulesRuleActionSendTeamsMessageToHclTerraform(struct?: OnCallTeamRoutingRulesRuleActionSendTeamsMessage | cdktn.IResolvable): any;
export declare class OnCallTeamRoutingRulesRuleActionSendTeamsMessageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OnCallTeamRoutingRulesRuleActionSendTeamsMessage | cdktn.IResolvable | undefined;
    set internalValue(value: OnCallTeamRoutingRulesRuleActionSendTeamsMessage | cdktn.IResolvable | undefined);
    private _channel?;
    get channel(): string;
    set channel(value: string);
    resetChannel(): void;
    get channelInput(): string | undefined;
    private _team?;
    get team(): string;
    set team(value: string);
    resetTeam(): void;
    get teamInput(): string | undefined;
    private _tenant?;
    get tenant(): string;
    set tenant(value: string);
    resetTenant(): void;
    get tenantInput(): string | undefined;
}
export interface OnCallTeamRoutingRulesRuleAction {
    /**
    * send_slack_message block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules#send_slack_message OnCallTeamRoutingRules#send_slack_message}
    */
    readonly sendSlackMessage?: OnCallTeamRoutingRulesRuleActionSendSlackMessage;
    /**
    * send_teams_message block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules#send_teams_message OnCallTeamRoutingRules#send_teams_message}
    */
    readonly sendTeamsMessage?: OnCallTeamRoutingRulesRuleActionSendTeamsMessage;
}
export declare function onCallTeamRoutingRulesRuleActionToTerraform(struct?: OnCallTeamRoutingRulesRuleAction | cdktn.IResolvable): any;
export declare function onCallTeamRoutingRulesRuleActionToHclTerraform(struct?: OnCallTeamRoutingRulesRuleAction | cdktn.IResolvable): any;
export declare class OnCallTeamRoutingRulesRuleActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OnCallTeamRoutingRulesRuleAction | cdktn.IResolvable | undefined;
    set internalValue(value: OnCallTeamRoutingRulesRuleAction | cdktn.IResolvable | undefined);
    private _sendSlackMessage;
    get sendSlackMessage(): OnCallTeamRoutingRulesRuleActionSendSlackMessageOutputReference;
    putSendSlackMessage(value: OnCallTeamRoutingRulesRuleActionSendSlackMessage): void;
    resetSendSlackMessage(): void;
    get sendSlackMessageInput(): cdktn.IResolvable | OnCallTeamRoutingRulesRuleActionSendSlackMessage | undefined;
    private _sendTeamsMessage;
    get sendTeamsMessage(): OnCallTeamRoutingRulesRuleActionSendTeamsMessageOutputReference;
    putSendTeamsMessage(value: OnCallTeamRoutingRulesRuleActionSendTeamsMessage): void;
    resetSendTeamsMessage(): void;
    get sendTeamsMessageInput(): cdktn.IResolvable | OnCallTeamRoutingRulesRuleActionSendTeamsMessage | undefined;
}
export declare class OnCallTeamRoutingRulesRuleActionList extends cdktn.ComplexList {
    internalValue?: OnCallTeamRoutingRulesRuleAction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OnCallTeamRoutingRulesRuleActionOutputReference;
}
export interface OnCallTeamRoutingRulesRuleTimeRestrictionsRestriction {
    /**
    * The weekday when the restriction period ends. Valid values are `monday`, `tuesday`, `wednesday`, `thursday`, `friday`, `saturday`, `sunday`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules#end_day OnCallTeamRoutingRules#end_day}
    */
    readonly endDay?: string;
    /**
    * The time of day when the restriction ends (hh:mm:ss).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules#end_time OnCallTeamRoutingRules#end_time}
    */
    readonly endTime?: string;
    /**
    * The weekday when the restriction period starts. Valid values are `monday`, `tuesday`, `wednesday`, `thursday`, `friday`, `saturday`, `sunday`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules#start_day OnCallTeamRoutingRules#start_day}
    */
    readonly startDay?: string;
    /**
    * The time of day when the restriction begins (hh:mm:ss).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules#start_time OnCallTeamRoutingRules#start_time}
    */
    readonly startTime?: string;
}
export declare function onCallTeamRoutingRulesRuleTimeRestrictionsRestrictionToTerraform(struct?: OnCallTeamRoutingRulesRuleTimeRestrictionsRestriction | cdktn.IResolvable): any;
export declare function onCallTeamRoutingRulesRuleTimeRestrictionsRestrictionToHclTerraform(struct?: OnCallTeamRoutingRulesRuleTimeRestrictionsRestriction | cdktn.IResolvable): any;
export declare class OnCallTeamRoutingRulesRuleTimeRestrictionsRestrictionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OnCallTeamRoutingRulesRuleTimeRestrictionsRestriction | cdktn.IResolvable | undefined;
    set internalValue(value: OnCallTeamRoutingRulesRuleTimeRestrictionsRestriction | cdktn.IResolvable | undefined);
    private _endDay?;
    get endDay(): string;
    set endDay(value: string);
    resetEndDay(): void;
    get endDayInput(): string | undefined;
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    resetEndTime(): void;
    get endTimeInput(): string | undefined;
    private _startDay?;
    get startDay(): string;
    set startDay(value: string);
    resetStartDay(): void;
    get startDayInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
}
export declare class OnCallTeamRoutingRulesRuleTimeRestrictionsRestrictionList extends cdktn.ComplexList {
    internalValue?: OnCallTeamRoutingRulesRuleTimeRestrictionsRestriction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OnCallTeamRoutingRulesRuleTimeRestrictionsRestrictionOutputReference;
}
export interface OnCallTeamRoutingRulesRuleTimeRestrictions {
    /**
    * Specifies the time zone applicable to the restrictions, e.g. `America/New_York`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules#time_zone OnCallTeamRoutingRules#time_zone}
    */
    readonly timeZone?: string;
    /**
    * restriction block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules#restriction OnCallTeamRoutingRules#restriction}
    */
    readonly restriction?: OnCallTeamRoutingRulesRuleTimeRestrictionsRestriction[] | cdktn.IResolvable;
}
export declare function onCallTeamRoutingRulesRuleTimeRestrictionsToTerraform(struct?: OnCallTeamRoutingRulesRuleTimeRestrictions | cdktn.IResolvable): any;
export declare function onCallTeamRoutingRulesRuleTimeRestrictionsToHclTerraform(struct?: OnCallTeamRoutingRulesRuleTimeRestrictions | cdktn.IResolvable): any;
export declare class OnCallTeamRoutingRulesRuleTimeRestrictionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OnCallTeamRoutingRulesRuleTimeRestrictions | cdktn.IResolvable | undefined;
    set internalValue(value: OnCallTeamRoutingRulesRuleTimeRestrictions | cdktn.IResolvable | undefined);
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    resetTimeZone(): void;
    get timeZoneInput(): string | undefined;
    private _restriction;
    get restriction(): OnCallTeamRoutingRulesRuleTimeRestrictionsRestrictionList;
    putRestriction(value: OnCallTeamRoutingRulesRuleTimeRestrictionsRestriction[] | cdktn.IResolvable): void;
    resetRestriction(): void;
    get restrictionInput(): cdktn.IResolvable | OnCallTeamRoutingRulesRuleTimeRestrictionsRestriction[] | undefined;
}
export interface OnCallTeamRoutingRulesRule {
    /**
    * ID of the policy to be applied when this routing rule matches.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules#escalation_policy OnCallTeamRoutingRules#escalation_policy}
    */
    readonly escalationPolicy?: string;
    /**
    * Defines the query or condition that triggers this routing rule. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules#query OnCallTeamRoutingRules#query}
    */
    readonly query?: string;
    /**
    * Defines the urgency for pages created via this rule. Only valid if `escalation_policy` is set. Valid values are `high`, `low`, `dynamic`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules#urgency OnCallTeamRoutingRules#urgency}
    */
    readonly urgency?: string;
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules#action OnCallTeamRoutingRules#action}
    */
    readonly action?: OnCallTeamRoutingRulesRuleAction[] | cdktn.IResolvable;
    /**
    * time_restrictions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules#time_restrictions OnCallTeamRoutingRules#time_restrictions}
    */
    readonly timeRestrictions?: OnCallTeamRoutingRulesRuleTimeRestrictions;
}
export declare function onCallTeamRoutingRulesRuleToTerraform(struct?: OnCallTeamRoutingRulesRule | cdktn.IResolvable): any;
export declare function onCallTeamRoutingRulesRuleToHclTerraform(struct?: OnCallTeamRoutingRulesRule | cdktn.IResolvable): any;
export declare class OnCallTeamRoutingRulesRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OnCallTeamRoutingRulesRule | cdktn.IResolvable | undefined;
    set internalValue(value: OnCallTeamRoutingRulesRule | cdktn.IResolvable | undefined);
    private _escalationPolicy?;
    get escalationPolicy(): string;
    set escalationPolicy(value: string);
    resetEscalationPolicy(): void;
    get escalationPolicyInput(): string | undefined;
    get id(): string;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
    private _urgency?;
    get urgency(): string;
    set urgency(value: string);
    resetUrgency(): void;
    get urgencyInput(): string | undefined;
    private _action;
    get action(): OnCallTeamRoutingRulesRuleActionList;
    putAction(value: OnCallTeamRoutingRulesRuleAction[] | cdktn.IResolvable): void;
    resetAction(): void;
    get actionInput(): cdktn.IResolvable | OnCallTeamRoutingRulesRuleAction[] | undefined;
    private _timeRestrictions;
    get timeRestrictions(): OnCallTeamRoutingRulesRuleTimeRestrictionsOutputReference;
    putTimeRestrictions(value: OnCallTeamRoutingRulesRuleTimeRestrictions): void;
    resetTimeRestrictions(): void;
    get timeRestrictionsInput(): cdktn.IResolvable | OnCallTeamRoutingRulesRuleTimeRestrictions | undefined;
}
export declare class OnCallTeamRoutingRulesRuleList extends cdktn.ComplexList {
    internalValue?: OnCallTeamRoutingRulesRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OnCallTeamRoutingRulesRuleOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules datadog_on_call_team_routing_rules}
*/
export declare class OnCallTeamRoutingRules extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_on_call_team_routing_rules";
    /**
    * Generates CDKTN code for importing a OnCallTeamRoutingRules resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OnCallTeamRoutingRules to import
    * @param importFromId The id of the existing OnCallTeamRoutingRules that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OnCallTeamRoutingRules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_team_routing_rules datadog_on_call_team_routing_rules} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OnCallTeamRoutingRulesConfig
    */
    constructor(scope: Construct, id: string, config: OnCallTeamRoutingRulesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _rule;
    get rule(): OnCallTeamRoutingRulesRuleList;
    putRule(value: OnCallTeamRoutingRulesRule[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | OnCallTeamRoutingRulesRule[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
