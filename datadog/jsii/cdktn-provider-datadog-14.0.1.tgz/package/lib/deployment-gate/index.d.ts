/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DeploymentGateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Enable Dry Run to test gate behavior without impacting deployments. The evaluation of a dry run gate always responds with a pass status, but the in-app result is the real status based on rules evaluation. This is particularly useful when performing an initial evaluation of the gate behavior without impacting the deployment pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/deployment_gate#dry_run DeploymentGate#dry_run}
    */
    readonly dryRun?: boolean | cdktn.IResolvable;
    /**
    * The target environment (example: dev).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/deployment_gate#env DeploymentGate#env}
    */
    readonly env: string;
    /**
    * Unique name for multiple gates on the same service/environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/deployment_gate#identifier DeploymentGate#identifier}
    */
    readonly identifier?: string;
    /**
    * The service name (example: transaction-backend).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/deployment_gate#service DeploymentGate#service}
    */
    readonly service: string;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/deployment_gate#rule DeploymentGate#rule}
    */
    readonly rule?: DeploymentGateRule[] | cdktn.IResolvable;
}
export interface DeploymentGateRuleOptions {
    /**
    * The duration for the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/deployment_gate#duration DeploymentGate#duration}
    */
    readonly duration?: number;
    /**
    * Resources to exclude from faulty deployment detection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/deployment_gate#excluded_resources DeploymentGate#excluded_resources}
    */
    readonly excludedResources?: string[];
    /**
    * The query for monitor rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/deployment_gate#query DeploymentGate#query}
    */
    readonly query?: string;
}
export declare function deploymentGateRuleOptionsToTerraform(struct?: DeploymentGateRuleOptions | cdktn.IResolvable): any;
export declare function deploymentGateRuleOptionsToHclTerraform(struct?: DeploymentGateRuleOptions | cdktn.IResolvable): any;
export declare class DeploymentGateRuleOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DeploymentGateRuleOptions | cdktn.IResolvable | undefined;
    set internalValue(value: DeploymentGateRuleOptions | cdktn.IResolvable | undefined);
    private _duration?;
    get duration(): number;
    set duration(value: number);
    resetDuration(): void;
    get durationInput(): number | undefined;
    private _excludedResources?;
    get excludedResources(): string[];
    set excludedResources(value: string[]);
    resetExcludedResources(): void;
    get excludedResourcesInput(): string[] | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
}
export interface DeploymentGateRule {
    /**
    * Whether the rule is in dry run mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/deployment_gate#dry_run DeploymentGate#dry_run}
    */
    readonly dryRun?: boolean | cdktn.IResolvable;
    /**
    * The rule name. Must be unique within the deployment gate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/deployment_gate#name DeploymentGate#name}
    */
    readonly name: string;
    /**
    * The rule type (e.g., 'faulty_deployment_detection', 'monitor').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/deployment_gate#type DeploymentGate#type}
    */
    readonly type: string;
    /**
    * options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/deployment_gate#options DeploymentGate#options}
    */
    readonly options?: DeploymentGateRuleOptions;
}
export declare function deploymentGateRuleToTerraform(struct?: DeploymentGateRule | cdktn.IResolvable): any;
export declare function deploymentGateRuleToHclTerraform(struct?: DeploymentGateRule | cdktn.IResolvable): any;
export declare class DeploymentGateRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DeploymentGateRule | cdktn.IResolvable | undefined;
    set internalValue(value: DeploymentGateRule | cdktn.IResolvable | undefined);
    private _dryRun?;
    get dryRun(): boolean | cdktn.IResolvable;
    set dryRun(value: boolean | cdktn.IResolvable);
    resetDryRun(): void;
    get dryRunInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _options;
    get options(): DeploymentGateRuleOptionsOutputReference;
    putOptions(value: DeploymentGateRuleOptions): void;
    resetOptions(): void;
    get optionsInput(): cdktn.IResolvable | DeploymentGateRuleOptions | undefined;
}
export declare class DeploymentGateRuleList extends cdktn.ComplexList {
    internalValue?: DeploymentGateRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DeploymentGateRuleOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/deployment_gate datadog_deployment_gate}
*/
export declare class DeploymentGate extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_deployment_gate";
    /**
    * Generates CDKTN code for importing a DeploymentGate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DeploymentGate to import
    * @param importFromId The id of the existing DeploymentGate that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/deployment_gate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DeploymentGate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/deployment_gate datadog_deployment_gate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DeploymentGateConfig
    */
    constructor(scope: Construct, id: string, config: DeploymentGateConfig);
    get createdAt(): string;
    private _dryRun?;
    get dryRun(): boolean | cdktn.IResolvable;
    set dryRun(value: boolean | cdktn.IResolvable);
    resetDryRun(): void;
    get dryRunInput(): boolean | cdktn.IResolvable | undefined;
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    get id(): string;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    resetIdentifier(): void;
    get identifierInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    get updatedAt(): string;
    private _rule;
    get rule(): DeploymentGateRuleList;
    putRule(value: DeploymentGateRule[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | DeploymentGateRule[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
