/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ServiceLevelObjectiveConfig extends cdktn.TerraformMetaArguments {
    /**
    * A description of this service level objective.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#description ServiceLevelObjective#description}
    */
    readonly description?: string;
    /**
    * A boolean indicating whether this monitor can be deleted even if it's referenced by other resources (for example, dashboards).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#force_delete ServiceLevelObjective#force_delete}
    */
    readonly forceDelete?: boolean | cdktn.IResolvable;
    /**
    * A static set of groups to filter monitor-based SLOs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#groups ServiceLevelObjective#groups}
    */
    readonly groups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#id ServiceLevelObjective#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A static set of monitor IDs to use as part of the SLO
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#monitor_ids ServiceLevelObjective#monitor_ids}
    */
    readonly monitorIds?: number[];
    /**
    * Name of Datadog service level objective
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#name ServiceLevelObjective#name}
    */
    readonly name: string;
    /**
    * A list of tags to associate with your service level objective. This can help you categorize and filter service level objectives in the service level objectives page of the UI. **Note**: it's not currently possible to filter by these tags when querying via the API. If default tags are present at the provider level, they will be added to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#tags ServiceLevelObjective#tags}
    */
    readonly tags?: string[];
    /**
    * The objective's target in `(0,100)`. This must match the corresponding thresholds of the primary time frame.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#target_threshold ServiceLevelObjective#target_threshold}
    */
    readonly targetThreshold?: number;
    /**
    * The primary time frame for the objective. The mapping from these types to the types found in the Datadog Web UI can be found in the Datadog API documentation page. Valid values are `7d`, `30d`, `90d`, `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#timeframe ServiceLevelObjective#timeframe}
    */
    readonly timeframe?: string;
    /**
    * The type of the service level objective. The mapping from these types to the types found in the Datadog Web UI can be found in the Datadog API [documentation page](https://docs.datadoghq.com/api/v1/service-level-objectives/#create-a-slo-object). Valid values are `metric`, `monitor`, `time_slice`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#type ServiceLevelObjective#type}
    */
    readonly type: string;
    /**
    * Whether or not to validate the SLO. It checks if monitors added to a monitor SLO already exist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#validate ServiceLevelObjective#validate}
    */
    readonly validate?: boolean | cdktn.IResolvable;
    /**
    * The objective's warning value in `(0,100)`. This must be greater than the target value and match the corresponding thresholds of the primary time frame.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#warning_threshold ServiceLevelObjective#warning_threshold}
    */
    readonly warningThreshold?: number;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#query ServiceLevelObjective#query}
    */
    readonly query?: ServiceLevelObjectiveQuery;
    /**
    * sli_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#sli_specification ServiceLevelObjective#sli_specification}
    */
    readonly sliSpecification?: ServiceLevelObjectiveSliSpecification;
    /**
    * thresholds block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#thresholds ServiceLevelObjective#thresholds}
    */
    readonly thresholds: ServiceLevelObjectiveThresholds[] | cdktn.IResolvable;
}
export interface ServiceLevelObjectiveQuery {
    /**
    * The sum of the `total` events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#denominator ServiceLevelObjective#denominator}
    */
    readonly denominator: string;
    /**
    * The sum of all the `good` events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#numerator ServiceLevelObjective#numerator}
    */
    readonly numerator: string;
}
export declare function serviceLevelObjectiveQueryToTerraform(struct?: ServiceLevelObjectiveQueryOutputReference | ServiceLevelObjectiveQuery): any;
export declare function serviceLevelObjectiveQueryToHclTerraform(struct?: ServiceLevelObjectiveQueryOutputReference | ServiceLevelObjectiveQuery): any;
export declare class ServiceLevelObjectiveQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceLevelObjectiveQuery | undefined;
    set internalValue(value: ServiceLevelObjectiveQuery | undefined);
    private _denominator?;
    get denominator(): string;
    set denominator(value: string);
    get denominatorInput(): string | undefined;
    private _numerator?;
    get numerator(): string;
    set numerator(value: string);
    get numeratorInput(): string | undefined;
}
export interface ServiceLevelObjectiveSliSpecificationCountQueriesMetricQuery {
    /**
    * The data source for metrics queries. Defaults to `"metrics"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#data_source ServiceLevelObjective#data_source}
    */
    readonly dataSource?: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#name ServiceLevelObjective#name}
    */
    readonly name: string;
    /**
    * The metrics query definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#query ServiceLevelObjective#query}
    */
    readonly query: string;
}
export declare function serviceLevelObjectiveSliSpecificationCountQueriesMetricQueryToTerraform(struct?: ServiceLevelObjectiveSliSpecificationCountQueriesMetricQueryOutputReference | ServiceLevelObjectiveSliSpecificationCountQueriesMetricQuery): any;
export declare function serviceLevelObjectiveSliSpecificationCountQueriesMetricQueryToHclTerraform(struct?: ServiceLevelObjectiveSliSpecificationCountQueriesMetricQueryOutputReference | ServiceLevelObjectiveSliSpecificationCountQueriesMetricQuery): any;
export declare class ServiceLevelObjectiveSliSpecificationCountQueriesMetricQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceLevelObjectiveSliSpecificationCountQueriesMetricQuery | undefined;
    set internalValue(value: ServiceLevelObjectiveSliSpecificationCountQueriesMetricQuery | undefined);
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    resetDataSource(): void;
    get dataSourceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface ServiceLevelObjectiveSliSpecificationCountQueries {
    /**
    * metric_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#metric_query ServiceLevelObjective#metric_query}
    */
    readonly metricQuery?: ServiceLevelObjectiveSliSpecificationCountQueriesMetricQuery;
}
export declare function serviceLevelObjectiveSliSpecificationCountQueriesToTerraform(struct?: ServiceLevelObjectiveSliSpecificationCountQueries | cdktn.IResolvable): any;
export declare function serviceLevelObjectiveSliSpecificationCountQueriesToHclTerraform(struct?: ServiceLevelObjectiveSliSpecificationCountQueries | cdktn.IResolvable): any;
export declare class ServiceLevelObjectiveSliSpecificationCountQueriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceLevelObjectiveSliSpecificationCountQueries | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceLevelObjectiveSliSpecificationCountQueries | cdktn.IResolvable | undefined);
    private _metricQuery;
    get metricQuery(): ServiceLevelObjectiveSliSpecificationCountQueriesMetricQueryOutputReference;
    putMetricQuery(value: ServiceLevelObjectiveSliSpecificationCountQueriesMetricQuery): void;
    resetMetricQuery(): void;
    get metricQueryInput(): ServiceLevelObjectiveSliSpecificationCountQueriesMetricQuery | undefined;
}
export declare class ServiceLevelObjectiveSliSpecificationCountQueriesList extends cdktn.ComplexList {
    internalValue?: ServiceLevelObjectiveSliSpecificationCountQueries[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceLevelObjectiveSliSpecificationCountQueriesOutputReference;
}
export interface ServiceLevelObjectiveSliSpecificationCount {
    /**
    * The formula that specifies how to compute the good events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#good_events_formula ServiceLevelObjective#good_events_formula}
    */
    readonly goodEventsFormula: string;
    /**
    * The formula that specifies how to compute the total events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#total_events_formula ServiceLevelObjective#total_events_formula}
    */
    readonly totalEventsFormula: string;
    /**
    * queries block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#queries ServiceLevelObjective#queries}
    */
    readonly queries: ServiceLevelObjectiveSliSpecificationCountQueries[] | cdktn.IResolvable;
}
export declare function serviceLevelObjectiveSliSpecificationCountToTerraform(struct?: ServiceLevelObjectiveSliSpecificationCountOutputReference | ServiceLevelObjectiveSliSpecificationCount): any;
export declare function serviceLevelObjectiveSliSpecificationCountToHclTerraform(struct?: ServiceLevelObjectiveSliSpecificationCountOutputReference | ServiceLevelObjectiveSliSpecificationCount): any;
export declare class ServiceLevelObjectiveSliSpecificationCountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceLevelObjectiveSliSpecificationCount | undefined;
    set internalValue(value: ServiceLevelObjectiveSliSpecificationCount | undefined);
    private _goodEventsFormula?;
    get goodEventsFormula(): string;
    set goodEventsFormula(value: string);
    get goodEventsFormulaInput(): string | undefined;
    private _totalEventsFormula?;
    get totalEventsFormula(): string;
    set totalEventsFormula(value: string);
    get totalEventsFormulaInput(): string | undefined;
    private _queries;
    get queries(): ServiceLevelObjectiveSliSpecificationCountQueriesList;
    putQueries(value: ServiceLevelObjectiveSliSpecificationCountQueries[] | cdktn.IResolvable): void;
    get queriesInput(): cdktn.IResolvable | ServiceLevelObjectiveSliSpecificationCountQueries[] | undefined;
}
export interface ServiceLevelObjectiveSliSpecificationTimeSliceQueryFormula {
    /**
    * The formula string, which is an expression involving named queries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#formula_expression ServiceLevelObjective#formula_expression}
    */
    readonly formulaExpression: string;
}
export declare function serviceLevelObjectiveSliSpecificationTimeSliceQueryFormulaToTerraform(struct?: ServiceLevelObjectiveSliSpecificationTimeSliceQueryFormulaOutputReference | ServiceLevelObjectiveSliSpecificationTimeSliceQueryFormula): any;
export declare function serviceLevelObjectiveSliSpecificationTimeSliceQueryFormulaToHclTerraform(struct?: ServiceLevelObjectiveSliSpecificationTimeSliceQueryFormulaOutputReference | ServiceLevelObjectiveSliSpecificationTimeSliceQueryFormula): any;
export declare class ServiceLevelObjectiveSliSpecificationTimeSliceQueryFormulaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceLevelObjectiveSliSpecificationTimeSliceQueryFormula | undefined;
    set internalValue(value: ServiceLevelObjectiveSliSpecificationTimeSliceQueryFormula | undefined);
    private _formulaExpression?;
    get formulaExpression(): string;
    set formulaExpression(value: string);
    get formulaExpressionInput(): string | undefined;
}
export interface ServiceLevelObjectiveSliSpecificationTimeSliceQueryQueryMetricQuery {
    /**
    * The data source for metrics queries. Defaults to `"metrics"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#data_source ServiceLevelObjective#data_source}
    */
    readonly dataSource?: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#name ServiceLevelObjective#name}
    */
    readonly name: string;
    /**
    * The metrics query definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#query ServiceLevelObjective#query}
    */
    readonly query: string;
}
export declare function serviceLevelObjectiveSliSpecificationTimeSliceQueryQueryMetricQueryToTerraform(struct?: ServiceLevelObjectiveSliSpecificationTimeSliceQueryQueryMetricQueryOutputReference | ServiceLevelObjectiveSliSpecificationTimeSliceQueryQueryMetricQuery): any;
export declare function serviceLevelObjectiveSliSpecificationTimeSliceQueryQueryMetricQueryToHclTerraform(struct?: ServiceLevelObjectiveSliSpecificationTimeSliceQueryQueryMetricQueryOutputReference | ServiceLevelObjectiveSliSpecificationTimeSliceQueryQueryMetricQuery): any;
export declare class ServiceLevelObjectiveSliSpecificationTimeSliceQueryQueryMetricQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceLevelObjectiveSliSpecificationTimeSliceQueryQueryMetricQuery | undefined;
    set internalValue(value: ServiceLevelObjectiveSliSpecificationTimeSliceQueryQueryMetricQuery | undefined);
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    resetDataSource(): void;
    get dataSourceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface ServiceLevelObjectiveSliSpecificationTimeSliceQueryQuery {
    /**
    * metric_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#metric_query ServiceLevelObjective#metric_query}
    */
    readonly metricQuery?: ServiceLevelObjectiveSliSpecificationTimeSliceQueryQueryMetricQuery;
}
export declare function serviceLevelObjectiveSliSpecificationTimeSliceQueryQueryToTerraform(struct?: ServiceLevelObjectiveSliSpecificationTimeSliceQueryQuery | cdktn.IResolvable): any;
export declare function serviceLevelObjectiveSliSpecificationTimeSliceQueryQueryToHclTerraform(struct?: ServiceLevelObjectiveSliSpecificationTimeSliceQueryQuery | cdktn.IResolvable): any;
export declare class ServiceLevelObjectiveSliSpecificationTimeSliceQueryQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceLevelObjectiveSliSpecificationTimeSliceQueryQuery | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceLevelObjectiveSliSpecificationTimeSliceQueryQuery | cdktn.IResolvable | undefined);
    private _metricQuery;
    get metricQuery(): ServiceLevelObjectiveSliSpecificationTimeSliceQueryQueryMetricQueryOutputReference;
    putMetricQuery(value: ServiceLevelObjectiveSliSpecificationTimeSliceQueryQueryMetricQuery): void;
    resetMetricQuery(): void;
    get metricQueryInput(): ServiceLevelObjectiveSliSpecificationTimeSliceQueryQueryMetricQuery | undefined;
}
export declare class ServiceLevelObjectiveSliSpecificationTimeSliceQueryQueryList extends cdktn.ComplexList {
    internalValue?: ServiceLevelObjectiveSliSpecificationTimeSliceQueryQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceLevelObjectiveSliSpecificationTimeSliceQueryQueryOutputReference;
}
export interface ServiceLevelObjectiveSliSpecificationTimeSliceQuery {
    /**
    * formula block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#formula ServiceLevelObjective#formula}
    */
    readonly formula: ServiceLevelObjectiveSliSpecificationTimeSliceQueryFormula;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#query ServiceLevelObjective#query}
    */
    readonly query: ServiceLevelObjectiveSliSpecificationTimeSliceQueryQuery[] | cdktn.IResolvable;
}
export declare function serviceLevelObjectiveSliSpecificationTimeSliceQueryToTerraform(struct?: ServiceLevelObjectiveSliSpecificationTimeSliceQueryOutputReference | ServiceLevelObjectiveSliSpecificationTimeSliceQuery): any;
export declare function serviceLevelObjectiveSliSpecificationTimeSliceQueryToHclTerraform(struct?: ServiceLevelObjectiveSliSpecificationTimeSliceQueryOutputReference | ServiceLevelObjectiveSliSpecificationTimeSliceQuery): any;
export declare class ServiceLevelObjectiveSliSpecificationTimeSliceQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceLevelObjectiveSliSpecificationTimeSliceQuery | undefined;
    set internalValue(value: ServiceLevelObjectiveSliSpecificationTimeSliceQuery | undefined);
    private _formula;
    get formula(): ServiceLevelObjectiveSliSpecificationTimeSliceQueryFormulaOutputReference;
    putFormula(value: ServiceLevelObjectiveSliSpecificationTimeSliceQueryFormula): void;
    get formulaInput(): ServiceLevelObjectiveSliSpecificationTimeSliceQueryFormula | undefined;
    private _query;
    get query(): ServiceLevelObjectiveSliSpecificationTimeSliceQueryQueryList;
    putQuery(value: ServiceLevelObjectiveSliSpecificationTimeSliceQueryQuery[] | cdktn.IResolvable): void;
    get queryInput(): cdktn.IResolvable | ServiceLevelObjectiveSliSpecificationTimeSliceQueryQuery[] | undefined;
}
export interface ServiceLevelObjectiveSliSpecificationTimeSlice {
    /**
    * The comparator used to compare the SLI value to the threshold. Valid values are `>`, `>=`, `<`, `<=`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#comparator ServiceLevelObjective#comparator}
    */
    readonly comparator: string;
    /**
    * The interval used when querying data, which defines the size of a time slice. Valid values are `60`, `300`. Defaults to `300`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#query_interval_seconds ServiceLevelObjective#query_interval_seconds}
    */
    readonly queryIntervalSeconds?: number;
    /**
    * The threshold value to which each SLI value will be compared.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#threshold ServiceLevelObjective#threshold}
    */
    readonly threshold: number;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#query ServiceLevelObjective#query}
    */
    readonly query: ServiceLevelObjectiveSliSpecificationTimeSliceQuery;
}
export declare function serviceLevelObjectiveSliSpecificationTimeSliceToTerraform(struct?: ServiceLevelObjectiveSliSpecificationTimeSliceOutputReference | ServiceLevelObjectiveSliSpecificationTimeSlice): any;
export declare function serviceLevelObjectiveSliSpecificationTimeSliceToHclTerraform(struct?: ServiceLevelObjectiveSliSpecificationTimeSliceOutputReference | ServiceLevelObjectiveSliSpecificationTimeSlice): any;
export declare class ServiceLevelObjectiveSliSpecificationTimeSliceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceLevelObjectiveSliSpecificationTimeSlice | undefined;
    set internalValue(value: ServiceLevelObjectiveSliSpecificationTimeSlice | undefined);
    private _comparator?;
    get comparator(): string;
    set comparator(value: string);
    get comparatorInput(): string | undefined;
    private _queryIntervalSeconds?;
    get queryIntervalSeconds(): number;
    set queryIntervalSeconds(value: number);
    resetQueryIntervalSeconds(): void;
    get queryIntervalSecondsInput(): number | undefined;
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    get thresholdInput(): number | undefined;
    private _query;
    get query(): ServiceLevelObjectiveSliSpecificationTimeSliceQueryOutputReference;
    putQuery(value: ServiceLevelObjectiveSliSpecificationTimeSliceQuery): void;
    get queryInput(): ServiceLevelObjectiveSliSpecificationTimeSliceQuery | undefined;
}
export interface ServiceLevelObjectiveSliSpecification {
    /**
    * count block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#count ServiceLevelObjective#count}
    */
    readonly count?: ServiceLevelObjectiveSliSpecificationCount;
    /**
    * time_slice block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#time_slice ServiceLevelObjective#time_slice}
    */
    readonly timeSlice?: ServiceLevelObjectiveSliSpecificationTimeSlice;
}
export declare function serviceLevelObjectiveSliSpecificationToTerraform(struct?: ServiceLevelObjectiveSliSpecificationOutputReference | ServiceLevelObjectiveSliSpecification): any;
export declare function serviceLevelObjectiveSliSpecificationToHclTerraform(struct?: ServiceLevelObjectiveSliSpecificationOutputReference | ServiceLevelObjectiveSliSpecification): any;
export declare class ServiceLevelObjectiveSliSpecificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServiceLevelObjectiveSliSpecification | undefined;
    set internalValue(value: ServiceLevelObjectiveSliSpecification | undefined);
    private _count;
    get count(): ServiceLevelObjectiveSliSpecificationCountOutputReference;
    putCount(value: ServiceLevelObjectiveSliSpecificationCount): void;
    resetCount(): void;
    get countInput(): ServiceLevelObjectiveSliSpecificationCount | undefined;
    private _timeSlice;
    get timeSlice(): ServiceLevelObjectiveSliSpecificationTimeSliceOutputReference;
    putTimeSlice(value: ServiceLevelObjectiveSliSpecificationTimeSlice): void;
    resetTimeSlice(): void;
    get timeSliceInput(): ServiceLevelObjectiveSliSpecificationTimeSlice | undefined;
}
export interface ServiceLevelObjectiveThresholds {
    /**
    * The objective's target in `(0,100)`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#target ServiceLevelObjective#target}
    */
    readonly target: number;
    /**
    * The time frame for the objective. The mapping from these types to the types found in the Datadog Web UI can be found in the Datadog API documentation page. Valid values are `7d`, `30d`, `90d`, `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#timeframe ServiceLevelObjective#timeframe}
    */
    readonly timeframe: string;
    /**
    * The objective's warning value in `(0,100)`. This must be greater than the target value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#warning ServiceLevelObjective#warning}
    */
    readonly warning?: number;
}
export declare function serviceLevelObjectiveThresholdsToTerraform(struct?: ServiceLevelObjectiveThresholds | cdktn.IResolvable): any;
export declare function serviceLevelObjectiveThresholdsToHclTerraform(struct?: ServiceLevelObjectiveThresholds | cdktn.IResolvable): any;
export declare class ServiceLevelObjectiveThresholdsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ServiceLevelObjectiveThresholds | cdktn.IResolvable | undefined;
    set internalValue(value: ServiceLevelObjectiveThresholds | cdktn.IResolvable | undefined);
    private _target?;
    get target(): number;
    set target(value: number);
    get targetInput(): number | undefined;
    get targetDisplay(): string;
    private _timeframe?;
    get timeframe(): string;
    set timeframe(value: string);
    get timeframeInput(): string | undefined;
    private _warning?;
    get warning(): number;
    set warning(value: number);
    resetWarning(): void;
    get warningInput(): number | undefined;
    get warningDisplay(): string;
}
export declare class ServiceLevelObjectiveThresholdsList extends cdktn.ComplexList {
    internalValue?: ServiceLevelObjectiveThresholds[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ServiceLevelObjectiveThresholdsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective datadog_service_level_objective}
*/
export declare class ServiceLevelObjective extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_service_level_objective";
    /**
    * Generates CDKTN code for importing a ServiceLevelObjective resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServiceLevelObjective to import
    * @param importFromId The id of the existing ServiceLevelObjective that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServiceLevelObjective to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_level_objective datadog_service_level_objective} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServiceLevelObjectiveConfig
    */
    constructor(scope: Construct, id: string, config: ServiceLevelObjectiveConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _forceDelete?;
    get forceDelete(): boolean | cdktn.IResolvable;
    set forceDelete(value: boolean | cdktn.IResolvable);
    resetForceDelete(): void;
    get forceDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _groups?;
    get groups(): string[];
    set groups(value: string[]);
    resetGroups(): void;
    get groupsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _monitorIds?;
    get monitorIds(): number[];
    set monitorIds(value: number[]);
    resetMonitorIds(): void;
    get monitorIdsInput(): number[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _targetThreshold?;
    get targetThreshold(): number;
    set targetThreshold(value: number);
    resetTargetThreshold(): void;
    get targetThresholdInput(): number | undefined;
    private _timeframe?;
    get timeframe(): string;
    set timeframe(value: string);
    resetTimeframe(): void;
    get timeframeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _validate?;
    get validate(): boolean | cdktn.IResolvable;
    set validate(value: boolean | cdktn.IResolvable);
    resetValidate(): void;
    get validateInput(): boolean | cdktn.IResolvable | undefined;
    private _warningThreshold?;
    get warningThreshold(): number;
    set warningThreshold(value: number);
    resetWarningThreshold(): void;
    get warningThresholdInput(): number | undefined;
    private _query;
    get query(): ServiceLevelObjectiveQueryOutputReference;
    putQuery(value: ServiceLevelObjectiveQuery): void;
    resetQuery(): void;
    get queryInput(): ServiceLevelObjectiveQuery | undefined;
    private _sliSpecification;
    get sliSpecification(): ServiceLevelObjectiveSliSpecificationOutputReference;
    putSliSpecification(value: ServiceLevelObjectiveSliSpecification): void;
    resetSliSpecification(): void;
    get sliSpecificationInput(): ServiceLevelObjectiveSliSpecification | undefined;
    private _thresholds;
    get thresholds(): ServiceLevelObjectiveThresholdsList;
    putThresholds(value: ServiceLevelObjectiveThresholds[] | cdktn.IResolvable): void;
    get thresholdsInput(): cdktn.IResolvable | ServiceLevelObjectiveThresholds[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
