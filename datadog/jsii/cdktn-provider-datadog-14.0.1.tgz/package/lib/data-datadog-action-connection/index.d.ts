/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogActionConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID for Connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/action_connection#id DataDatadogActionConnection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * http block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/action_connection#http DataDatadogActionConnection#http}
    */
    readonly http?: DataDatadogActionConnectionHttp;
}
export interface DataDatadogActionConnectionAwsAssumeRole {
}
export declare function dataDatadogActionConnectionAwsAssumeRoleToTerraform(struct?: DataDatadogActionConnectionAwsAssumeRole | cdktn.IResolvable): any;
export declare function dataDatadogActionConnectionAwsAssumeRoleToHclTerraform(struct?: DataDatadogActionConnectionAwsAssumeRole | cdktn.IResolvable): any;
export declare class DataDatadogActionConnectionAwsAssumeRoleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogActionConnectionAwsAssumeRole | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogActionConnectionAwsAssumeRole | cdktn.IResolvable | undefined);
    get accountId(): string;
    get externalId(): string;
    get principalId(): string;
    get role(): string;
}
export interface DataDatadogActionConnectionAws {
}
export declare function dataDatadogActionConnectionAwsToTerraform(struct?: DataDatadogActionConnectionAws | cdktn.IResolvable): any;
export declare function dataDatadogActionConnectionAwsToHclTerraform(struct?: DataDatadogActionConnectionAws | cdktn.IResolvable): any;
export declare class DataDatadogActionConnectionAwsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogActionConnectionAws | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogActionConnectionAws | cdktn.IResolvable | undefined);
    private _assumeRole;
    get assumeRole(): DataDatadogActionConnectionAwsAssumeRoleOutputReference;
}
export interface DataDatadogActionConnectionHttpTokenAuthBody {
}
export declare function dataDatadogActionConnectionHttpTokenAuthBodyToTerraform(struct?: DataDatadogActionConnectionHttpTokenAuthBody | cdktn.IResolvable): any;
export declare function dataDatadogActionConnectionHttpTokenAuthBodyToHclTerraform(struct?: DataDatadogActionConnectionHttpTokenAuthBody | cdktn.IResolvable): any;
export declare class DataDatadogActionConnectionHttpTokenAuthBodyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogActionConnectionHttpTokenAuthBody | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogActionConnectionHttpTokenAuthBody | cdktn.IResolvable | undefined);
    get content(): string;
    get contentType(): string;
}
export interface DataDatadogActionConnectionHttpTokenAuthHeader {
}
export declare function dataDatadogActionConnectionHttpTokenAuthHeaderToTerraform(struct?: DataDatadogActionConnectionHttpTokenAuthHeader | cdktn.IResolvable): any;
export declare function dataDatadogActionConnectionHttpTokenAuthHeaderToHclTerraform(struct?: DataDatadogActionConnectionHttpTokenAuthHeader | cdktn.IResolvable): any;
export declare class DataDatadogActionConnectionHttpTokenAuthHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogActionConnectionHttpTokenAuthHeader | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogActionConnectionHttpTokenAuthHeader | cdktn.IResolvable | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataDatadogActionConnectionHttpTokenAuthHeaderList extends cdktn.ComplexList {
    internalValue?: DataDatadogActionConnectionHttpTokenAuthHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogActionConnectionHttpTokenAuthHeaderOutputReference;
}
export interface DataDatadogActionConnectionHttpTokenAuthToken {
}
export declare function dataDatadogActionConnectionHttpTokenAuthTokenToTerraform(struct?: DataDatadogActionConnectionHttpTokenAuthToken | cdktn.IResolvable): any;
export declare function dataDatadogActionConnectionHttpTokenAuthTokenToHclTerraform(struct?: DataDatadogActionConnectionHttpTokenAuthToken | cdktn.IResolvable): any;
export declare class DataDatadogActionConnectionHttpTokenAuthTokenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogActionConnectionHttpTokenAuthToken | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogActionConnectionHttpTokenAuthToken | cdktn.IResolvable | undefined);
    get name(): string;
    get type(): string;
    get value(): string;
}
export declare class DataDatadogActionConnectionHttpTokenAuthTokenList extends cdktn.ComplexList {
    internalValue?: DataDatadogActionConnectionHttpTokenAuthToken[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogActionConnectionHttpTokenAuthTokenOutputReference;
}
export interface DataDatadogActionConnectionHttpTokenAuthUrlParameter {
}
export declare function dataDatadogActionConnectionHttpTokenAuthUrlParameterToTerraform(struct?: DataDatadogActionConnectionHttpTokenAuthUrlParameter | cdktn.IResolvable): any;
export declare function dataDatadogActionConnectionHttpTokenAuthUrlParameterToHclTerraform(struct?: DataDatadogActionConnectionHttpTokenAuthUrlParameter | cdktn.IResolvable): any;
export declare class DataDatadogActionConnectionHttpTokenAuthUrlParameterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogActionConnectionHttpTokenAuthUrlParameter | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogActionConnectionHttpTokenAuthUrlParameter | cdktn.IResolvable | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataDatadogActionConnectionHttpTokenAuthUrlParameterList extends cdktn.ComplexList {
    internalValue?: DataDatadogActionConnectionHttpTokenAuthUrlParameter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogActionConnectionHttpTokenAuthUrlParameterOutputReference;
}
export interface DataDatadogActionConnectionHttpTokenAuth {
    /**
    * header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/action_connection#header DataDatadogActionConnection#header}
    */
    readonly header?: DataDatadogActionConnectionHttpTokenAuthHeader[] | cdktn.IResolvable;
    /**
    * token block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/action_connection#token DataDatadogActionConnection#token}
    */
    readonly token?: DataDatadogActionConnectionHttpTokenAuthToken[] | cdktn.IResolvable;
    /**
    * url_parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/action_connection#url_parameter DataDatadogActionConnection#url_parameter}
    */
    readonly urlParameter?: DataDatadogActionConnectionHttpTokenAuthUrlParameter[] | cdktn.IResolvable;
}
export declare function dataDatadogActionConnectionHttpTokenAuthToTerraform(struct?: DataDatadogActionConnectionHttpTokenAuth | cdktn.IResolvable): any;
export declare function dataDatadogActionConnectionHttpTokenAuthToHclTerraform(struct?: DataDatadogActionConnectionHttpTokenAuth | cdktn.IResolvable): any;
export declare class DataDatadogActionConnectionHttpTokenAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogActionConnectionHttpTokenAuth | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogActionConnectionHttpTokenAuth | cdktn.IResolvable | undefined);
    private _body;
    get body(): DataDatadogActionConnectionHttpTokenAuthBodyOutputReference;
    private _header;
    get header(): DataDatadogActionConnectionHttpTokenAuthHeaderList;
    putHeader(value: DataDatadogActionConnectionHttpTokenAuthHeader[] | cdktn.IResolvable): void;
    resetHeader(): void;
    get headerInput(): cdktn.IResolvable | DataDatadogActionConnectionHttpTokenAuthHeader[] | undefined;
    private _token;
    get token(): DataDatadogActionConnectionHttpTokenAuthTokenList;
    putToken(value: DataDatadogActionConnectionHttpTokenAuthToken[] | cdktn.IResolvable): void;
    resetToken(): void;
    get tokenInput(): cdktn.IResolvable | DataDatadogActionConnectionHttpTokenAuthToken[] | undefined;
    private _urlParameter;
    get urlParameter(): DataDatadogActionConnectionHttpTokenAuthUrlParameterList;
    putUrlParameter(value: DataDatadogActionConnectionHttpTokenAuthUrlParameter[] | cdktn.IResolvable): void;
    resetUrlParameter(): void;
    get urlParameterInput(): cdktn.IResolvable | DataDatadogActionConnectionHttpTokenAuthUrlParameter[] | undefined;
}
export interface DataDatadogActionConnectionHttp {
    /**
    * token_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/action_connection#token_auth DataDatadogActionConnection#token_auth}
    */
    readonly tokenAuth?: DataDatadogActionConnectionHttpTokenAuth;
}
export declare function dataDatadogActionConnectionHttpToTerraform(struct?: DataDatadogActionConnectionHttp | cdktn.IResolvable): any;
export declare function dataDatadogActionConnectionHttpToHclTerraform(struct?: DataDatadogActionConnectionHttp | cdktn.IResolvable): any;
export declare class DataDatadogActionConnectionHttpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogActionConnectionHttp | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogActionConnectionHttp | cdktn.IResolvable | undefined);
    get baseUrl(): string;
    private _tokenAuth;
    get tokenAuth(): DataDatadogActionConnectionHttpTokenAuthOutputReference;
    putTokenAuth(value: DataDatadogActionConnectionHttpTokenAuth): void;
    resetTokenAuth(): void;
    get tokenAuthInput(): cdktn.IResolvable | DataDatadogActionConnectionHttpTokenAuth | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/action_connection datadog_action_connection}
*/
export declare class DataDatadogActionConnection extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_action_connection";
    /**
    * Generates CDKTN code for importing a DataDatadogActionConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogActionConnection to import
    * @param importFromId The id of the existing DataDatadogActionConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/action_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogActionConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/action_connection datadog_action_connection} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogActionConnectionConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogActionConnectionConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get name(): string;
    private _aws;
    get aws(): DataDatadogActionConnectionAwsOutputReference;
    private _http;
    get http(): DataDatadogActionConnectionHttpOutputReference;
    putHttp(value: DataDatadogActionConnectionHttp): void;
    resetHttp(): void;
    get httpInput(): cdktn.IResolvable | DataDatadogActionConnectionHttp | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
