/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SecurityMonitoringRuleJsonConfig extends cdktn.TerraformMetaArguments {
    /**
    * The JSON definition of the Security Monitoring Rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule_json#json SecurityMonitoringRuleJson#json}
    */
    readonly json: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule_json datadog_security_monitoring_rule_json}
*/
export declare class SecurityMonitoringRuleJson extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_security_monitoring_rule_json";
    /**
    * Generates CDKTN code for importing a SecurityMonitoringRuleJson resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecurityMonitoringRuleJson to import
    * @param importFromId The id of the existing SecurityMonitoringRuleJson that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule_json#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecurityMonitoringRuleJson to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_rule_json datadog_security_monitoring_rule_json} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecurityMonitoringRuleJsonConfig
    */
    constructor(scope: Construct, id: string, config: SecurityMonitoringRuleJsonConfig);
    get id(): string;
    private _json?;
    get json(): string;
    set json(value: string);
    get jsonInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
