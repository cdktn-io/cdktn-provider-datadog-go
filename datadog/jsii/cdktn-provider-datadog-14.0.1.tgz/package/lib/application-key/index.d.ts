/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApplicationKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Name for Application Key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/application_key#name ApplicationKey#name}
    */
    readonly name: string;
    /**
    * Authorization scopes for the Application Key. Application Keys configured with no scopes have full access.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/application_key#scopes ApplicationKey#scopes}
    */
    readonly scopes?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/application_key datadog_application_key}
*/
export declare class ApplicationKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_application_key";
    /**
    * Generates CDKTN code for importing a ApplicationKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationKey to import
    * @param importFromId The id of the existing ApplicationKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/application_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/application_key datadog_application_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationKeyConfig
    */
    constructor(scope: Construct, id: string, config: ApplicationKeyConfig);
    get id(): string;
    get key(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
