/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogTeamMembershipsConfig extends cdktn.TerraformMetaArguments {
    /**
    * When true, `filter_keyword` string is exact matched against the user's `email`, followed by `name`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team_memberships#exact_match DataDatadogTeamMemberships#exact_match}
    */
    readonly exactMatch?: boolean | cdktn.IResolvable;
    /**
    * Search query, can be user email or name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team_memberships#filter_keyword DataDatadogTeamMemberships#filter_keyword}
    */
    readonly filterKeyword?: string;
    /**
    * The team's identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team_memberships#team_id DataDatadogTeamMemberships#team_id}
    */
    readonly teamId: string;
}
export interface DataDatadogTeamMembershipsTeamMemberships {
}
export declare function dataDatadogTeamMembershipsTeamMembershipsToTerraform(struct?: DataDatadogTeamMembershipsTeamMemberships): any;
export declare function dataDatadogTeamMembershipsTeamMembershipsToHclTerraform(struct?: DataDatadogTeamMembershipsTeamMemberships): any;
export declare class DataDatadogTeamMembershipsTeamMembershipsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogTeamMembershipsTeamMemberships | undefined;
    set internalValue(value: DataDatadogTeamMembershipsTeamMemberships | undefined);
    get id(): string;
    get role(): string;
    get teamId(): string;
    get userId(): string;
}
export declare class DataDatadogTeamMembershipsTeamMembershipsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogTeamMembershipsTeamMembershipsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team_memberships datadog_team_memberships}
*/
export declare class DataDatadogTeamMemberships extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_team_memberships";
    /**
    * Generates CDKTN code for importing a DataDatadogTeamMemberships resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogTeamMemberships to import
    * @param importFromId The id of the existing DataDatadogTeamMemberships that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team_memberships#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogTeamMemberships to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team_memberships datadog_team_memberships} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogTeamMembershipsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogTeamMembershipsConfig);
    private _exactMatch?;
    get exactMatch(): boolean | cdktn.IResolvable;
    set exactMatch(value: boolean | cdktn.IResolvable);
    resetExactMatch(): void;
    get exactMatchInput(): boolean | cdktn.IResolvable | undefined;
    private _filterKeyword?;
    get filterKeyword(): string;
    set filterKeyword(value: string);
    resetFilterKeyword(): void;
    get filterKeywordInput(): string | undefined;
    get id(): string;
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    get teamIdInput(): string | undefined;
    private _teamMemberships;
    get teamMemberships(): DataDatadogTeamMembershipsTeamMembershipsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
