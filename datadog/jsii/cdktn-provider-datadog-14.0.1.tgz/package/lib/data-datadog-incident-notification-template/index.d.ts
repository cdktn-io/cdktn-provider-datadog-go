/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogIncidentNotificationTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the incident notification template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/incident_notification_template#id DataDatadogIncidentNotificationTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the notification template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/incident_notification_template#name DataDatadogIncidentNotificationTemplate#name}
    */
    readonly name?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/incident_notification_template datadog_incident_notification_template}
*/
export declare class DataDatadogIncidentNotificationTemplate extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_incident_notification_template";
    /**
    * Generates CDKTN code for importing a DataDatadogIncidentNotificationTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogIncidentNotificationTemplate to import
    * @param importFromId The id of the existing DataDatadogIncidentNotificationTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/incident_notification_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogIncidentNotificationTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/incident_notification_template datadog_incident_notification_template} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogIncidentNotificationTemplateConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogIncidentNotificationTemplateConfig);
    get category(): string;
    get content(): string;
    get created(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get incidentType(): string;
    get modified(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get subject(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
