/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudInventorySyncConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * The cloud provider type. Valid values are `aws`, `azure`, `gcp`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_inventory_sync_config#cloud_provider CloudInventorySyncConfig#cloud_provider}
    */
    readonly cloudProvider: string;
    /**
    * aws block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_inventory_sync_config#aws CloudInventorySyncConfig#aws}
    */
    readonly aws?: CloudInventorySyncConfigAws;
    /**
    * azure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_inventory_sync_config#azure CloudInventorySyncConfig#azure}
    */
    readonly azure?: CloudInventorySyncConfigAzure;
    /**
    * gcp block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_inventory_sync_config#gcp CloudInventorySyncConfig#gcp}
    */
    readonly gcp?: CloudInventorySyncConfigGcp;
}
export interface CloudInventorySyncConfigAws {
    /**
    * AWS Account ID of the account holding the bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_inventory_sync_config#aws_account_id CloudInventorySyncConfig#aws_account_id}
    */
    readonly awsAccountId?: string;
    /**
    * Name of the S3 bucket holding the inventory files.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_inventory_sync_config#destination_bucket_name CloudInventorySyncConfig#destination_bucket_name}
    */
    readonly destinationBucketName?: string;
    /**
    * AWS Region of the bucket holding the inventory files.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_inventory_sync_config#destination_bucket_region CloudInventorySyncConfig#destination_bucket_region}
    */
    readonly destinationBucketRegion?: string;
    /**
    * Prefix path within the bucket for inventory files.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_inventory_sync_config#destination_prefix CloudInventorySyncConfig#destination_prefix}
    */
    readonly destinationPrefix?: string;
}
export declare function cloudInventorySyncConfigAwsToTerraform(struct?: CloudInventorySyncConfigAws | cdktn.IResolvable): any;
export declare function cloudInventorySyncConfigAwsToHclTerraform(struct?: CloudInventorySyncConfigAws | cdktn.IResolvable): any;
export declare class CloudInventorySyncConfigAwsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudInventorySyncConfigAws | cdktn.IResolvable | undefined;
    set internalValue(value: CloudInventorySyncConfigAws | cdktn.IResolvable | undefined);
    private _awsAccountId?;
    get awsAccountId(): string;
    set awsAccountId(value: string);
    resetAwsAccountId(): void;
    get awsAccountIdInput(): string | undefined;
    private _destinationBucketName?;
    get destinationBucketName(): string;
    set destinationBucketName(value: string);
    resetDestinationBucketName(): void;
    get destinationBucketNameInput(): string | undefined;
    private _destinationBucketRegion?;
    get destinationBucketRegion(): string;
    set destinationBucketRegion(value: string);
    resetDestinationBucketRegion(): void;
    get destinationBucketRegionInput(): string | undefined;
    private _destinationPrefix?;
    get destinationPrefix(): string;
    set destinationPrefix(value: string);
    resetDestinationPrefix(): void;
    get destinationPrefixInput(): string | undefined;
}
export interface CloudInventorySyncConfigAzure {
    /**
    * Azure Client ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_inventory_sync_config#client_id CloudInventorySyncConfig#client_id}
    */
    readonly clientId?: string;
    /**
    * Azure Storage Container name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_inventory_sync_config#container CloudInventorySyncConfig#container}
    */
    readonly container?: string;
    /**
    * Azure Resource Group name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_inventory_sync_config#resource_group CloudInventorySyncConfig#resource_group}
    */
    readonly resourceGroup?: string;
    /**
    * Azure Storage Account name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_inventory_sync_config#storage_account CloudInventorySyncConfig#storage_account}
    */
    readonly storageAccount?: string;
    /**
    * Azure Subscription ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_inventory_sync_config#subscription_id CloudInventorySyncConfig#subscription_id}
    */
    readonly subscriptionId?: string;
    /**
    * Azure Tenant ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_inventory_sync_config#tenant_id CloudInventorySyncConfig#tenant_id}
    */
    readonly tenantId?: string;
}
export declare function cloudInventorySyncConfigAzureToTerraform(struct?: CloudInventorySyncConfigAzure | cdktn.IResolvable): any;
export declare function cloudInventorySyncConfigAzureToHclTerraform(struct?: CloudInventorySyncConfigAzure | cdktn.IResolvable): any;
export declare class CloudInventorySyncConfigAzureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudInventorySyncConfigAzure | cdktn.IResolvable | undefined;
    set internalValue(value: CloudInventorySyncConfigAzure | cdktn.IResolvable | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _container?;
    get container(): string;
    set container(value: string);
    resetContainer(): void;
    get containerInput(): string | undefined;
    private _resourceGroup?;
    get resourceGroup(): string;
    set resourceGroup(value: string);
    resetResourceGroup(): void;
    get resourceGroupInput(): string | undefined;
    private _storageAccount?;
    get storageAccount(): string;
    set storageAccount(value: string);
    resetStorageAccount(): void;
    get storageAccountInput(): string | undefined;
    private _subscriptionId?;
    get subscriptionId(): string;
    set subscriptionId(value: string);
    resetSubscriptionId(): void;
    get subscriptionIdInput(): string | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    resetTenantId(): void;
    get tenantIdInput(): string | undefined;
}
export interface CloudInventorySyncConfigGcp {
    /**
    * Name of the GCS bucket holding the inventory files.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_inventory_sync_config#destination_bucket_name CloudInventorySyncConfig#destination_bucket_name}
    */
    readonly destinationBucketName?: string;
    /**
    * GCP Project ID of the project holding the bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_inventory_sync_config#project_id CloudInventorySyncConfig#project_id}
    */
    readonly projectId?: string;
    /**
    * Service account email used for reading the bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_inventory_sync_config#service_account_email CloudInventorySyncConfig#service_account_email}
    */
    readonly serviceAccountEmail?: string;
    /**
    * Name of the source bucket the inventory report is generated for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_inventory_sync_config#source_bucket_name CloudInventorySyncConfig#source_bucket_name}
    */
    readonly sourceBucketName?: string;
}
export declare function cloudInventorySyncConfigGcpToTerraform(struct?: CloudInventorySyncConfigGcp | cdktn.IResolvable): any;
export declare function cloudInventorySyncConfigGcpToHclTerraform(struct?: CloudInventorySyncConfigGcp | cdktn.IResolvable): any;
export declare class CloudInventorySyncConfigGcpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudInventorySyncConfigGcp | cdktn.IResolvable | undefined;
    set internalValue(value: CloudInventorySyncConfigGcp | cdktn.IResolvable | undefined);
    private _destinationBucketName?;
    get destinationBucketName(): string;
    set destinationBucketName(value: string);
    resetDestinationBucketName(): void;
    get destinationBucketNameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    resetServiceAccountEmail(): void;
    get serviceAccountEmailInput(): string | undefined;
    private _sourceBucketName?;
    get sourceBucketName(): string;
    set sourceBucketName(value: string);
    resetSourceBucketName(): void;
    get sourceBucketNameInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_inventory_sync_config datadog_cloud_inventory_sync_config}
*/
export declare class CloudInventorySyncConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_cloud_inventory_sync_config";
    /**
    * Generates CDKTN code for importing a CloudInventorySyncConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudInventorySyncConfig to import
    * @param importFromId The id of the existing CloudInventorySyncConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_inventory_sync_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudInventorySyncConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_inventory_sync_config datadog_cloud_inventory_sync_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudInventorySyncConfigConfig
    */
    constructor(scope: Construct, id: string, config: CloudInventorySyncConfigConfig);
    private _cloudProvider?;
    get cloudProvider(): string;
    set cloudProvider(value: string);
    get cloudProviderInput(): string | undefined;
    get id(): string;
    private _aws;
    get aws(): CloudInventorySyncConfigAwsOutputReference;
    putAws(value: CloudInventorySyncConfigAws): void;
    resetAws(): void;
    get awsInput(): cdktn.IResolvable | CloudInventorySyncConfigAws | undefined;
    private _azure;
    get azure(): CloudInventorySyncConfigAzureOutputReference;
    putAzure(value: CloudInventorySyncConfigAzure): void;
    resetAzure(): void;
    get azureInput(): cdktn.IResolvable | CloudInventorySyncConfigAzure | undefined;
    private _gcp;
    get gcp(): CloudInventorySyncConfigGcpOutputReference;
    putGcp(value: CloudInventorySyncConfigGcp): void;
    resetGcp(): void;
    get gcpInput(): cdktn.IResolvable | CloudInventorySyncConfigGcp | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
