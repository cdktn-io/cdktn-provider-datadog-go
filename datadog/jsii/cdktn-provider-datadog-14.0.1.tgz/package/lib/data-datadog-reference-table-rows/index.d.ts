/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogReferenceTableRowsConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of primary key values (row IDs) to retrieve. These are the values of the table's primary key field(s). Maximum 250 IDs per request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/reference_table_rows#row_ids DataDatadogReferenceTableRows#row_ids}
    */
    readonly rowIds: string[];
    /**
    * The UUID of the reference table to query rows from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/reference_table_rows#table_id DataDatadogReferenceTableRows#table_id}
    */
    readonly tableId: string;
    /**
    * rows block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/reference_table_rows#rows DataDatadogReferenceTableRows#rows}
    */
    readonly rows?: DataDatadogReferenceTableRowsRows[] | cdktn.IResolvable;
}
export interface DataDatadogReferenceTableRowsRows {
}
export declare function dataDatadogReferenceTableRowsRowsToTerraform(struct?: DataDatadogReferenceTableRowsRows | cdktn.IResolvable): any;
export declare function dataDatadogReferenceTableRowsRowsToHclTerraform(struct?: DataDatadogReferenceTableRowsRows | cdktn.IResolvable): any;
export declare class DataDatadogReferenceTableRowsRowsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogReferenceTableRowsRows | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogReferenceTableRowsRows | cdktn.IResolvable | undefined);
    get id(): string;
    private _values;
    get values(): cdktn.StringMap;
}
export declare class DataDatadogReferenceTableRowsRowsList extends cdktn.ComplexList {
    internalValue?: DataDatadogReferenceTableRowsRows[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogReferenceTableRowsRowsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/reference_table_rows datadog_reference_table_rows}
*/
export declare class DataDatadogReferenceTableRows extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_reference_table_rows";
    /**
    * Generates CDKTN code for importing a DataDatadogReferenceTableRows resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogReferenceTableRows to import
    * @param importFromId The id of the existing DataDatadogReferenceTableRows that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/reference_table_rows#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogReferenceTableRows to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/reference_table_rows datadog_reference_table_rows} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogReferenceTableRowsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogReferenceTableRowsConfig);
    private _rowIds?;
    get rowIds(): string[];
    set rowIds(value: string[]);
    get rowIdsInput(): string[] | undefined;
    private _tableId?;
    get tableId(): string;
    set tableId(value: string);
    get tableIdInput(): string | undefined;
    private _rows;
    get rows(): DataDatadogReferenceTableRowsRowsList;
    putRows(value: DataDatadogReferenceTableRowsRows[] | cdktn.IResolvable): void;
    resetRows(): void;
    get rowsInput(): cdktn.IResolvable | DataDatadogReferenceTableRowsRows[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
