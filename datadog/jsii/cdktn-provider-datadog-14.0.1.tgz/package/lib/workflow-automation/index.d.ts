/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WorkflowAutomationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Description of the workflow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/workflow_automation#description WorkflowAutomation#description}
    */
    readonly description: string;
    /**
    * Name of the workflow. String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/workflow_automation#name WorkflowAutomation#name}
    */
    readonly name: string;
    /**
    * Set the workflow to published or unpublished. Workflows in an unpublished state are only executable through manual runs. Automatic triggers such as Schedule do not execute the workflow until it is published.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/workflow_automation#published WorkflowAutomation#published}
    */
    readonly published: boolean | cdktn.IResolvable;
    /**
    * The spec defines what the workflow does.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/workflow_automation#spec_json WorkflowAutomation#spec_json}
    */
    readonly specJson: string;
    /**
    * Tags of the workflow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/workflow_automation#tags WorkflowAutomation#tags}
    */
    readonly tags: string[];
    /**
    * If a webhook trigger is defined on this workflow, a webhookSecret is required and should be provided here. String length must be at least 16.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/workflow_automation#webhook_secret WorkflowAutomation#webhook_secret}
    */
    readonly webhookSecret?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/workflow_automation datadog_workflow_automation}
*/
export declare class WorkflowAutomation extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_workflow_automation";
    /**
    * Generates CDKTN code for importing a WorkflowAutomation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WorkflowAutomation to import
    * @param importFromId The id of the existing WorkflowAutomation that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/workflow_automation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WorkflowAutomation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/workflow_automation datadog_workflow_automation} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkflowAutomationConfig
    */
    constructor(scope: Construct, id: string, config: WorkflowAutomationConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _published?;
    get published(): boolean | cdktn.IResolvable;
    set published(value: boolean | cdktn.IResolvable);
    get publishedInput(): boolean | cdktn.IResolvable | undefined;
    private _specJson?;
    get specJson(): string;
    set specJson(value: string);
    get specJsonInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    get tagsInput(): string[] | undefined;
    private _webhookSecret?;
    get webhookSecret(): string;
    set webhookSecret(value: string);
    resetWebhookSecret(): void;
    get webhookSecretInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
