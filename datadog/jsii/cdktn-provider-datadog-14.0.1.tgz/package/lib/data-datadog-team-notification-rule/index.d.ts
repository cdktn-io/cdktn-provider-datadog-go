/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogTeamNotificationRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The notification rule ID to fetch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team_notification_rule#rule_id DataDatadogTeamNotificationRule#rule_id}
    */
    readonly ruleId: string;
    /**
    * The team ID to fetch the notification rule for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team_notification_rule#team_id DataDatadogTeamNotificationRule#team_id}
    */
    readonly teamId: string;
}
export interface DataDatadogTeamNotificationRuleEmail {
}
export declare function dataDatadogTeamNotificationRuleEmailToTerraform(struct?: DataDatadogTeamNotificationRuleEmail | cdktn.IResolvable): any;
export declare function dataDatadogTeamNotificationRuleEmailToHclTerraform(struct?: DataDatadogTeamNotificationRuleEmail | cdktn.IResolvable): any;
export declare class DataDatadogTeamNotificationRuleEmailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogTeamNotificationRuleEmail | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogTeamNotificationRuleEmail | cdktn.IResolvable | undefined);
    get enabled(): cdktn.IResolvable;
}
export interface DataDatadogTeamNotificationRuleMsTeams {
}
export declare function dataDatadogTeamNotificationRuleMsTeamsToTerraform(struct?: DataDatadogTeamNotificationRuleMsTeams | cdktn.IResolvable): any;
export declare function dataDatadogTeamNotificationRuleMsTeamsToHclTerraform(struct?: DataDatadogTeamNotificationRuleMsTeams | cdktn.IResolvable): any;
export declare class DataDatadogTeamNotificationRuleMsTeamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogTeamNotificationRuleMsTeams | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogTeamNotificationRuleMsTeams | cdktn.IResolvable | undefined);
    get connectorName(): string;
}
export interface DataDatadogTeamNotificationRulePagerduty {
}
export declare function dataDatadogTeamNotificationRulePagerdutyToTerraform(struct?: DataDatadogTeamNotificationRulePagerduty | cdktn.IResolvable): any;
export declare function dataDatadogTeamNotificationRulePagerdutyToHclTerraform(struct?: DataDatadogTeamNotificationRulePagerduty | cdktn.IResolvable): any;
export declare class DataDatadogTeamNotificationRulePagerdutyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogTeamNotificationRulePagerduty | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogTeamNotificationRulePagerduty | cdktn.IResolvable | undefined);
    get serviceName(): string;
}
export interface DataDatadogTeamNotificationRuleSlack {
}
export declare function dataDatadogTeamNotificationRuleSlackToTerraform(struct?: DataDatadogTeamNotificationRuleSlack | cdktn.IResolvable): any;
export declare function dataDatadogTeamNotificationRuleSlackToHclTerraform(struct?: DataDatadogTeamNotificationRuleSlack | cdktn.IResolvable): any;
export declare class DataDatadogTeamNotificationRuleSlackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogTeamNotificationRuleSlack | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogTeamNotificationRuleSlack | cdktn.IResolvable | undefined);
    get channel(): string;
    get workspace(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team_notification_rule datadog_team_notification_rule}
*/
export declare class DataDatadogTeamNotificationRule extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_team_notification_rule";
    /**
    * Generates CDKTN code for importing a DataDatadogTeamNotificationRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogTeamNotificationRule to import
    * @param importFromId The id of the existing DataDatadogTeamNotificationRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team_notification_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogTeamNotificationRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team_notification_rule datadog_team_notification_rule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogTeamNotificationRuleConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogTeamNotificationRuleConfig);
    get id(): string;
    private _ruleId?;
    get ruleId(): string;
    set ruleId(value: string);
    get ruleIdInput(): string | undefined;
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    get teamIdInput(): string | undefined;
    private _email;
    get email(): DataDatadogTeamNotificationRuleEmailOutputReference;
    private _msTeams;
    get msTeams(): DataDatadogTeamNotificationRuleMsTeamsOutputReference;
    private _pagerduty;
    get pagerduty(): DataDatadogTeamNotificationRulePagerdutyOutputReference;
    private _slack;
    get slack(): DataDatadogTeamNotificationRuleSlackOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
