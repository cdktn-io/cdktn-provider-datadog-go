/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IncidentTypeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Description of the incident type. The description can have a maximum of 512 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_type#description IncidentType#description}
    */
    readonly description?: string;
    /**
    * Whether this incident type is the default type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_type#is_default IncidentType#is_default}
    */
    readonly isDefault?: boolean | cdktn.IResolvable;
    /**
    * Name of the incident type. Must be between 1 and 50 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_type#name IncidentType#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_type datadog_incident_type}
*/
export declare class IncidentType extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_incident_type";
    /**
    * Generates CDKTN code for importing a IncidentType resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IncidentType to import
    * @param importFromId The id of the existing IncidentType that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_type#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IncidentType to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/incident_type datadog_incident_type} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IncidentTypeConfig
    */
    constructor(scope: Construct, id: string, config: IncidentTypeConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _isDefault?;
    get isDefault(): boolean | cdktn.IResolvable;
    set isDefault(value: boolean | cdktn.IResolvable);
    resetIsDefault(): void;
    get isDefaultInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
