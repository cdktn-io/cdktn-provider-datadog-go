/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogCostBudgetConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the budget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/cost_budget#id DataDatadogCostBudget#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * budget_line block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/cost_budget#budget_line DataDatadogCostBudget#budget_line}
    */
    readonly budgetLine?: DataDatadogCostBudgetBudgetLine[] | cdktn.IResolvable;
    /**
    * entries block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/cost_budget#entries DataDatadogCostBudget#entries}
    */
    readonly entries?: DataDatadogCostBudgetEntries[] | cdktn.IResolvable;
}
export interface DataDatadogCostBudgetBudgetLineChildTagFilters {
}
export declare function dataDatadogCostBudgetBudgetLineChildTagFiltersToTerraform(struct?: DataDatadogCostBudgetBudgetLineChildTagFilters | cdktn.IResolvable): any;
export declare function dataDatadogCostBudgetBudgetLineChildTagFiltersToHclTerraform(struct?: DataDatadogCostBudgetBudgetLineChildTagFilters | cdktn.IResolvable): any;
export declare class DataDatadogCostBudgetBudgetLineChildTagFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogCostBudgetBudgetLineChildTagFilters | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogCostBudgetBudgetLineChildTagFilters | cdktn.IResolvable | undefined);
    get tagKey(): string;
    get tagValue(): string;
}
export declare class DataDatadogCostBudgetBudgetLineChildTagFiltersList extends cdktn.ComplexList {
    internalValue?: DataDatadogCostBudgetBudgetLineChildTagFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogCostBudgetBudgetLineChildTagFiltersOutputReference;
}
export interface DataDatadogCostBudgetBudgetLineParentTagFilters {
}
export declare function dataDatadogCostBudgetBudgetLineParentTagFiltersToTerraform(struct?: DataDatadogCostBudgetBudgetLineParentTagFilters | cdktn.IResolvable): any;
export declare function dataDatadogCostBudgetBudgetLineParentTagFiltersToHclTerraform(struct?: DataDatadogCostBudgetBudgetLineParentTagFilters | cdktn.IResolvable): any;
export declare class DataDatadogCostBudgetBudgetLineParentTagFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogCostBudgetBudgetLineParentTagFilters | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogCostBudgetBudgetLineParentTagFilters | cdktn.IResolvable | undefined);
    get tagKey(): string;
    get tagValue(): string;
}
export declare class DataDatadogCostBudgetBudgetLineParentTagFiltersList extends cdktn.ComplexList {
    internalValue?: DataDatadogCostBudgetBudgetLineParentTagFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogCostBudgetBudgetLineParentTagFiltersOutputReference;
}
export interface DataDatadogCostBudgetBudgetLineTagFilters {
}
export declare function dataDatadogCostBudgetBudgetLineTagFiltersToTerraform(struct?: DataDatadogCostBudgetBudgetLineTagFilters | cdktn.IResolvable): any;
export declare function dataDatadogCostBudgetBudgetLineTagFiltersToHclTerraform(struct?: DataDatadogCostBudgetBudgetLineTagFilters | cdktn.IResolvable): any;
export declare class DataDatadogCostBudgetBudgetLineTagFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogCostBudgetBudgetLineTagFilters | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogCostBudgetBudgetLineTagFilters | cdktn.IResolvable | undefined);
    get tagKey(): string;
    get tagValue(): string;
}
export declare class DataDatadogCostBudgetBudgetLineTagFiltersList extends cdktn.ComplexList {
    internalValue?: DataDatadogCostBudgetBudgetLineTagFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogCostBudgetBudgetLineTagFiltersOutputReference;
}
export interface DataDatadogCostBudgetBudgetLine {
    /**
    * child_tag_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/cost_budget#child_tag_filters DataDatadogCostBudget#child_tag_filters}
    */
    readonly childTagFilters?: DataDatadogCostBudgetBudgetLineChildTagFilters[] | cdktn.IResolvable;
    /**
    * parent_tag_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/cost_budget#parent_tag_filters DataDatadogCostBudget#parent_tag_filters}
    */
    readonly parentTagFilters?: DataDatadogCostBudgetBudgetLineParentTagFilters[] | cdktn.IResolvable;
    /**
    * tag_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/cost_budget#tag_filters DataDatadogCostBudget#tag_filters}
    */
    readonly tagFilters?: DataDatadogCostBudgetBudgetLineTagFilters[] | cdktn.IResolvable;
}
export declare function dataDatadogCostBudgetBudgetLineToTerraform(struct?: DataDatadogCostBudgetBudgetLine | cdktn.IResolvable): any;
export declare function dataDatadogCostBudgetBudgetLineToHclTerraform(struct?: DataDatadogCostBudgetBudgetLine | cdktn.IResolvable): any;
export declare class DataDatadogCostBudgetBudgetLineOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogCostBudgetBudgetLine | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogCostBudgetBudgetLine | cdktn.IResolvable | undefined);
    private _amounts;
    get amounts(): cdktn.NumberMap;
    private _childTagFilters;
    get childTagFilters(): DataDatadogCostBudgetBudgetLineChildTagFiltersList;
    putChildTagFilters(value: DataDatadogCostBudgetBudgetLineChildTagFilters[] | cdktn.IResolvable): void;
    resetChildTagFilters(): void;
    get childTagFiltersInput(): cdktn.IResolvable | DataDatadogCostBudgetBudgetLineChildTagFilters[] | undefined;
    private _parentTagFilters;
    get parentTagFilters(): DataDatadogCostBudgetBudgetLineParentTagFiltersList;
    putParentTagFilters(value: DataDatadogCostBudgetBudgetLineParentTagFilters[] | cdktn.IResolvable): void;
    resetParentTagFilters(): void;
    get parentTagFiltersInput(): cdktn.IResolvable | DataDatadogCostBudgetBudgetLineParentTagFilters[] | undefined;
    private _tagFilters;
    get tagFilters(): DataDatadogCostBudgetBudgetLineTagFiltersList;
    putTagFilters(value: DataDatadogCostBudgetBudgetLineTagFilters[] | cdktn.IResolvable): void;
    resetTagFilters(): void;
    get tagFiltersInput(): cdktn.IResolvable | DataDatadogCostBudgetBudgetLineTagFilters[] | undefined;
}
export declare class DataDatadogCostBudgetBudgetLineList extends cdktn.ComplexList {
    internalValue?: DataDatadogCostBudgetBudgetLine[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogCostBudgetBudgetLineOutputReference;
}
export interface DataDatadogCostBudgetEntriesTagFilters {
}
export declare function dataDatadogCostBudgetEntriesTagFiltersToTerraform(struct?: DataDatadogCostBudgetEntriesTagFilters | cdktn.IResolvable): any;
export declare function dataDatadogCostBudgetEntriesTagFiltersToHclTerraform(struct?: DataDatadogCostBudgetEntriesTagFilters | cdktn.IResolvable): any;
export declare class DataDatadogCostBudgetEntriesTagFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogCostBudgetEntriesTagFilters | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogCostBudgetEntriesTagFilters | cdktn.IResolvable | undefined);
    get tagKey(): string;
    get tagValue(): string;
}
export declare class DataDatadogCostBudgetEntriesTagFiltersList extends cdktn.ComplexList {
    internalValue?: DataDatadogCostBudgetEntriesTagFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogCostBudgetEntriesTagFiltersOutputReference;
}
export interface DataDatadogCostBudgetEntries {
    /**
    * tag_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/cost_budget#tag_filters DataDatadogCostBudget#tag_filters}
    */
    readonly tagFilters?: DataDatadogCostBudgetEntriesTagFilters[] | cdktn.IResolvable;
}
export declare function dataDatadogCostBudgetEntriesToTerraform(struct?: DataDatadogCostBudgetEntries | cdktn.IResolvable): any;
export declare function dataDatadogCostBudgetEntriesToHclTerraform(struct?: DataDatadogCostBudgetEntries | cdktn.IResolvable): any;
export declare class DataDatadogCostBudgetEntriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogCostBudgetEntries | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogCostBudgetEntries | cdktn.IResolvable | undefined);
    get amount(): number;
    get month(): number;
    private _tagFilters;
    get tagFilters(): DataDatadogCostBudgetEntriesTagFiltersList;
    putTagFilters(value: DataDatadogCostBudgetEntriesTagFilters[] | cdktn.IResolvable): void;
    resetTagFilters(): void;
    get tagFiltersInput(): cdktn.IResolvable | DataDatadogCostBudgetEntriesTagFilters[] | undefined;
}
export declare class DataDatadogCostBudgetEntriesList extends cdktn.ComplexList {
    internalValue?: DataDatadogCostBudgetEntries[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogCostBudgetEntriesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/cost_budget datadog_cost_budget}
*/
export declare class DataDatadogCostBudget extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_cost_budget";
    /**
    * Generates CDKTN code for importing a DataDatadogCostBudget resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogCostBudget to import
    * @param importFromId The id of the existing DataDatadogCostBudget that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/cost_budget#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogCostBudget to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/cost_budget datadog_cost_budget} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogCostBudgetConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogCostBudgetConfig);
    get endMonth(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get metricsQuery(): string;
    get name(): string;
    get startMonth(): number;
    get totalAmount(): number;
    private _budgetLine;
    get budgetLine(): DataDatadogCostBudgetBudgetLineList;
    putBudgetLine(value: DataDatadogCostBudgetBudgetLine[] | cdktn.IResolvable): void;
    resetBudgetLine(): void;
    get budgetLineInput(): cdktn.IResolvable | DataDatadogCostBudgetBudgetLine[] | undefined;
    private _entries;
    get entries(): DataDatadogCostBudgetEntriesList;
    putEntries(value: DataDatadogCostBudgetEntries[] | cdktn.IResolvable): void;
    resetEntries(): void;
    get entriesInput(): cdktn.IResolvable | DataDatadogCostBudgetEntries[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
