/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IpAllowlistConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether the IP Allowlist is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/ip_allowlist#enabled IpAllowlist#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * entry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/ip_allowlist#entry IpAllowlist#entry}
    */
    readonly entry?: IpAllowlistEntry[] | cdktn.IResolvable;
}
export interface IpAllowlistEntry {
    /**
    * IP address or range of addresses. String must be a valid CIDR block or IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/ip_allowlist#cidr_block IpAllowlist#cidr_block}
    */
    readonly cidrBlock: string;
    /**
    * Note accompanying IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/ip_allowlist#note IpAllowlist#note}
    */
    readonly note?: string;
}
export declare function ipAllowlistEntryToTerraform(struct?: IpAllowlistEntry | cdktn.IResolvable): any;
export declare function ipAllowlistEntryToHclTerraform(struct?: IpAllowlistEntry | cdktn.IResolvable): any;
export declare class IpAllowlistEntryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IpAllowlistEntry | cdktn.IResolvable | undefined;
    set internalValue(value: IpAllowlistEntry | cdktn.IResolvable | undefined);
    private _cidrBlock?;
    get cidrBlock(): string;
    set cidrBlock(value: string);
    get cidrBlockInput(): string | undefined;
    private _note?;
    get note(): string;
    set note(value: string);
    resetNote(): void;
    get noteInput(): string | undefined;
}
export declare class IpAllowlistEntryList extends cdktn.ComplexList {
    internalValue?: IpAllowlistEntry[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IpAllowlistEntryOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/ip_allowlist datadog_ip_allowlist}
*/
export declare class IpAllowlist extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_ip_allowlist";
    /**
    * Generates CDKTN code for importing a IpAllowlist resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IpAllowlist to import
    * @param importFromId The id of the existing IpAllowlist that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/ip_allowlist#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IpAllowlist to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/ip_allowlist datadog_ip_allowlist} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IpAllowlistConfig
    */
    constructor(scope: Construct, id: string, config: IpAllowlistConfig);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _entry;
    get entry(): IpAllowlistEntryList;
    putEntry(value: IpAllowlistEntry[] | cdktn.IResolvable): void;
    resetEntry(): void;
    get entryInput(): cdktn.IResolvable | IpAllowlistEntry[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
