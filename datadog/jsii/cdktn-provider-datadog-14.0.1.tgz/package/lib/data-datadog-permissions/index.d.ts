/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogPermissionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/permissions#id DataDatadogPermissions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Whether to include restricted permissions. Restricted permissions are granted by default to all users of a Datadog org, and cannot be manually granted or revoked. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/permissions#include_restricted DataDatadogPermissions#include_restricted}
    */
    readonly includeRestricted?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/permissions datadog_permissions}
*/
export declare class DataDatadogPermissions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_permissions";
    /**
    * Generates CDKTN code for importing a DataDatadogPermissions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogPermissions to import
    * @param importFromId The id of the existing DataDatadogPermissions that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/permissions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogPermissions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/permissions datadog_permissions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogPermissionsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogPermissionsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _includeRestricted?;
    get includeRestricted(): boolean | cdktn.IResolvable;
    set includeRestricted(value: boolean | cdktn.IResolvable);
    resetIncludeRestricted(): void;
    get includeRestrictedInput(): boolean | cdktn.IResolvable | undefined;
    private _permissions;
    get permissions(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
