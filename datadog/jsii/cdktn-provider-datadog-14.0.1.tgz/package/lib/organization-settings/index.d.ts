/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OrganizationSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/organization_settings#id OrganizationSettings#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name for Organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/organization_settings#name OrganizationSettings#name}
    */
    readonly name?: string;
    /**
    * List of emails used for security event notifications from the organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/organization_settings#security_contacts OrganizationSettings#security_contacts}
    */
    readonly securityContacts?: string[];
    /**
    * settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/organization_settings#settings OrganizationSettings#settings}
    */
    readonly settings?: OrganizationSettingsSettings;
}
export interface OrganizationSettingsSettingsSaml {
    /**
    * Whether or not SAML is enabled for this organization. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/organization_settings#enabled OrganizationSettings#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function organizationSettingsSettingsSamlToTerraform(struct?: OrganizationSettingsSettingsSamlOutputReference | OrganizationSettingsSettingsSaml): any;
export declare function organizationSettingsSettingsSamlToHclTerraform(struct?: OrganizationSettingsSettingsSamlOutputReference | OrganizationSettingsSettingsSaml): any;
export declare class OrganizationSettingsSettingsSamlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OrganizationSettingsSettingsSaml | undefined;
    set internalValue(value: OrganizationSettingsSettingsSaml | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface OrganizationSettingsSettingsSamlAutocreateUsersDomains {
    /**
    * List of domains where the SAML automated user creation is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/organization_settings#domains OrganizationSettings#domains}
    */
    readonly domains?: string[];
    /**
    * Whether or not the automated user creation based on SAML domain is enabled. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/organization_settings#enabled OrganizationSettings#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function organizationSettingsSettingsSamlAutocreateUsersDomainsToTerraform(struct?: OrganizationSettingsSettingsSamlAutocreateUsersDomainsOutputReference | OrganizationSettingsSettingsSamlAutocreateUsersDomains): any;
export declare function organizationSettingsSettingsSamlAutocreateUsersDomainsToHclTerraform(struct?: OrganizationSettingsSettingsSamlAutocreateUsersDomainsOutputReference | OrganizationSettingsSettingsSamlAutocreateUsersDomains): any;
export declare class OrganizationSettingsSettingsSamlAutocreateUsersDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OrganizationSettingsSettingsSamlAutocreateUsersDomains | undefined;
    set internalValue(value: OrganizationSettingsSettingsSamlAutocreateUsersDomains | undefined);
    private _domains?;
    get domains(): string[];
    set domains(value: string[]);
    resetDomains(): void;
    get domainsInput(): string[] | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface OrganizationSettingsSettingsSamlIdpInitiatedLogin {
    /**
    * Whether or not a SAML identity provider metadata file was provided to the Datadog organization. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/organization_settings#enabled OrganizationSettings#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function organizationSettingsSettingsSamlIdpInitiatedLoginToTerraform(struct?: OrganizationSettingsSettingsSamlIdpInitiatedLoginOutputReference | OrganizationSettingsSettingsSamlIdpInitiatedLogin): any;
export declare function organizationSettingsSettingsSamlIdpInitiatedLoginToHclTerraform(struct?: OrganizationSettingsSettingsSamlIdpInitiatedLoginOutputReference | OrganizationSettingsSettingsSamlIdpInitiatedLogin): any;
export declare class OrganizationSettingsSettingsSamlIdpInitiatedLoginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OrganizationSettingsSettingsSamlIdpInitiatedLogin | undefined;
    set internalValue(value: OrganizationSettingsSettingsSamlIdpInitiatedLogin | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface OrganizationSettingsSettingsSamlStrictMode {
    /**
    * Whether or not the SAML strict mode is enabled. If true, all users must log in with SAML. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/organization_settings#enabled OrganizationSettings#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function organizationSettingsSettingsSamlStrictModeToTerraform(struct?: OrganizationSettingsSettingsSamlStrictModeOutputReference | OrganizationSettingsSettingsSamlStrictMode): any;
export declare function organizationSettingsSettingsSamlStrictModeToHclTerraform(struct?: OrganizationSettingsSettingsSamlStrictModeOutputReference | OrganizationSettingsSettingsSamlStrictMode): any;
export declare class OrganizationSettingsSettingsSamlStrictModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OrganizationSettingsSettingsSamlStrictMode | undefined;
    set internalValue(value: OrganizationSettingsSettingsSamlStrictMode | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface OrganizationSettingsSettings {
    /**
    * Whether or not the organization users can share widgets outside of Datadog. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/organization_settings#private_widget_share OrganizationSettings#private_widget_share}
    */
    readonly privateWidgetShare?: boolean | cdktn.IResolvable;
    /**
    * The access role of the user. Options are `st` (standard user), `adm` (admin user), or `ro` (read-only user). Allowed enum values: `st`, `adm` , `ro`, `ERROR` Defaults to `"st"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/organization_settings#saml_autocreate_access_role OrganizationSettings#saml_autocreate_access_role}
    */
    readonly samlAutocreateAccessRole?: string;
    /**
    * saml block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/organization_settings#saml OrganizationSettings#saml}
    */
    readonly saml: OrganizationSettingsSettingsSaml;
    /**
    * saml_autocreate_users_domains block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/organization_settings#saml_autocreate_users_domains OrganizationSettings#saml_autocreate_users_domains}
    */
    readonly samlAutocreateUsersDomains: OrganizationSettingsSettingsSamlAutocreateUsersDomains;
    /**
    * saml_idp_initiated_login block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/organization_settings#saml_idp_initiated_login OrganizationSettings#saml_idp_initiated_login}
    */
    readonly samlIdpInitiatedLogin: OrganizationSettingsSettingsSamlIdpInitiatedLogin;
    /**
    * saml_strict_mode block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/organization_settings#saml_strict_mode OrganizationSettings#saml_strict_mode}
    */
    readonly samlStrictMode: OrganizationSettingsSettingsSamlStrictMode;
}
export declare function organizationSettingsSettingsToTerraform(struct?: OrganizationSettingsSettingsOutputReference | OrganizationSettingsSettings): any;
export declare function organizationSettingsSettingsToHclTerraform(struct?: OrganizationSettingsSettingsOutputReference | OrganizationSettingsSettings): any;
export declare class OrganizationSettingsSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OrganizationSettingsSettings | undefined;
    set internalValue(value: OrganizationSettingsSettings | undefined);
    private _privateWidgetShare?;
    get privateWidgetShare(): boolean | cdktn.IResolvable;
    set privateWidgetShare(value: boolean | cdktn.IResolvable);
    resetPrivateWidgetShare(): void;
    get privateWidgetShareInput(): boolean | cdktn.IResolvable | undefined;
    private _samlAutocreateAccessRole?;
    get samlAutocreateAccessRole(): string;
    set samlAutocreateAccessRole(value: string);
    resetSamlAutocreateAccessRole(): void;
    get samlAutocreateAccessRoleInput(): string | undefined;
    get samlCanBeEnabled(): cdktn.IResolvable;
    get samlIdpEndpoint(): string;
    get samlIdpMetadataUploaded(): cdktn.IResolvable;
    get samlLoginUrl(): string;
    private _saml;
    get saml(): OrganizationSettingsSettingsSamlOutputReference;
    putSaml(value: OrganizationSettingsSettingsSaml): void;
    get samlInput(): OrganizationSettingsSettingsSaml | undefined;
    private _samlAutocreateUsersDomains;
    get samlAutocreateUsersDomains(): OrganizationSettingsSettingsSamlAutocreateUsersDomainsOutputReference;
    putSamlAutocreateUsersDomains(value: OrganizationSettingsSettingsSamlAutocreateUsersDomains): void;
    get samlAutocreateUsersDomainsInput(): OrganizationSettingsSettingsSamlAutocreateUsersDomains | undefined;
    private _samlIdpInitiatedLogin;
    get samlIdpInitiatedLogin(): OrganizationSettingsSettingsSamlIdpInitiatedLoginOutputReference;
    putSamlIdpInitiatedLogin(value: OrganizationSettingsSettingsSamlIdpInitiatedLogin): void;
    get samlIdpInitiatedLoginInput(): OrganizationSettingsSettingsSamlIdpInitiatedLogin | undefined;
    private _samlStrictMode;
    get samlStrictMode(): OrganizationSettingsSettingsSamlStrictModeOutputReference;
    putSamlStrictMode(value: OrganizationSettingsSettingsSamlStrictMode): void;
    get samlStrictModeInput(): OrganizationSettingsSettingsSamlStrictMode | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/organization_settings datadog_organization_settings}
*/
export declare class OrganizationSettings extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_organization_settings";
    /**
    * Generates CDKTN code for importing a OrganizationSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OrganizationSettings to import
    * @param importFromId The id of the existing OrganizationSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/organization_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OrganizationSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/organization_settings datadog_organization_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OrganizationSettingsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: OrganizationSettingsConfig);
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get publicId(): string;
    private _securityContacts?;
    get securityContacts(): string[];
    set securityContacts(value: string[]);
    resetSecurityContacts(): void;
    get securityContactsInput(): string[] | undefined;
    private _settings;
    get settings(): OrganizationSettingsSettingsOutputReference;
    putSettings(value: OrganizationSettingsSettings): void;
    resetSettings(): void;
    get settingsInput(): OrganizationSettingsSettings | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
