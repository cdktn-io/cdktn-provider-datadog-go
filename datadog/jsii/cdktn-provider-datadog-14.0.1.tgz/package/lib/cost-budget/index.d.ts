/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CostBudgetConfig extends cdktn.TerraformMetaArguments {
    /**
    * The month when the budget ends (YYYYMM).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#end_month CostBudget#end_month}
    */
    readonly endMonth: number;
    /**
    * The ID of the budget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#id CostBudget#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The cost query used to track against the budget. **Note:** For hierarchical budgets using `by {tag1,tag2}`, the order of tags determines the UI hierarchy (parent, child).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#metrics_query CostBudget#metrics_query}
    */
    readonly metricsQuery: string;
    /**
    * The name of the budget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#name CostBudget#name}
    */
    readonly name: string;
    /**
    * The month when the budget starts (YYYYMM).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#start_month CostBudget#start_month}
    */
    readonly startMonth: number;
    /**
    * budget_line block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#budget_line CostBudget#budget_line}
    */
    readonly budgetLine?: CostBudgetBudgetLine[] | cdktn.IResolvable;
    /**
    * entries block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#entries CostBudget#entries}
    */
    readonly entries?: CostBudgetEntries[] | cdktn.IResolvable;
}
export interface CostBudgetBudgetLineChildTagFilters {
    /**
    * Must be one of the tags from the `metrics_query`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#tag_key CostBudget#tag_key}
    */
    readonly tagKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#tag_value CostBudget#tag_value}
    */
    readonly tagValue: string;
}
export declare function costBudgetBudgetLineChildTagFiltersToTerraform(struct?: CostBudgetBudgetLineChildTagFilters | cdktn.IResolvable): any;
export declare function costBudgetBudgetLineChildTagFiltersToHclTerraform(struct?: CostBudgetBudgetLineChildTagFilters | cdktn.IResolvable): any;
export declare class CostBudgetBudgetLineChildTagFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CostBudgetBudgetLineChildTagFilters | cdktn.IResolvable | undefined;
    set internalValue(value: CostBudgetBudgetLineChildTagFilters | cdktn.IResolvable | undefined);
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    get tagValueInput(): string | undefined;
}
export declare class CostBudgetBudgetLineChildTagFiltersList extends cdktn.ComplexList {
    internalValue?: CostBudgetBudgetLineChildTagFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CostBudgetBudgetLineChildTagFiltersOutputReference;
}
export interface CostBudgetBudgetLineParentTagFilters {
    /**
    * Must be one of the tags from the `metrics_query`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#tag_key CostBudget#tag_key}
    */
    readonly tagKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#tag_value CostBudget#tag_value}
    */
    readonly tagValue: string;
}
export declare function costBudgetBudgetLineParentTagFiltersToTerraform(struct?: CostBudgetBudgetLineParentTagFilters | cdktn.IResolvable): any;
export declare function costBudgetBudgetLineParentTagFiltersToHclTerraform(struct?: CostBudgetBudgetLineParentTagFilters | cdktn.IResolvable): any;
export declare class CostBudgetBudgetLineParentTagFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CostBudgetBudgetLineParentTagFilters | cdktn.IResolvable | undefined;
    set internalValue(value: CostBudgetBudgetLineParentTagFilters | cdktn.IResolvable | undefined);
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    get tagValueInput(): string | undefined;
}
export declare class CostBudgetBudgetLineParentTagFiltersList extends cdktn.ComplexList {
    internalValue?: CostBudgetBudgetLineParentTagFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CostBudgetBudgetLineParentTagFiltersOutputReference;
}
export interface CostBudgetBudgetLineTagFilters {
    /**
    * Must be one of the tags from the `metrics_query`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#tag_key CostBudget#tag_key}
    */
    readonly tagKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#tag_value CostBudget#tag_value}
    */
    readonly tagValue: string;
}
export declare function costBudgetBudgetLineTagFiltersToTerraform(struct?: CostBudgetBudgetLineTagFilters | cdktn.IResolvable): any;
export declare function costBudgetBudgetLineTagFiltersToHclTerraform(struct?: CostBudgetBudgetLineTagFilters | cdktn.IResolvable): any;
export declare class CostBudgetBudgetLineTagFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CostBudgetBudgetLineTagFilters | cdktn.IResolvable | undefined;
    set internalValue(value: CostBudgetBudgetLineTagFilters | cdktn.IResolvable | undefined);
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    get tagValueInput(): string | undefined;
}
export declare class CostBudgetBudgetLineTagFiltersList extends cdktn.ComplexList {
    internalValue?: CostBudgetBudgetLineTagFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CostBudgetBudgetLineTagFiltersOutputReference;
}
export interface CostBudgetBudgetLine {
    /**
    * Map of month (YYYYMM) to budget amount. Example: {"202601": 1000.0, "202602": 1200.0}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#amounts CostBudget#amounts}
    */
    readonly amounts: {
        [key: string]: number;
    };
    /**
    * child_tag_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#child_tag_filters CostBudget#child_tag_filters}
    */
    readonly childTagFilters?: CostBudgetBudgetLineChildTagFilters[] | cdktn.IResolvable;
    /**
    * parent_tag_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#parent_tag_filters CostBudget#parent_tag_filters}
    */
    readonly parentTagFilters?: CostBudgetBudgetLineParentTagFilters[] | cdktn.IResolvable;
    /**
    * tag_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#tag_filters CostBudget#tag_filters}
    */
    readonly tagFilters?: CostBudgetBudgetLineTagFilters[] | cdktn.IResolvable;
}
export declare function costBudgetBudgetLineToTerraform(struct?: CostBudgetBudgetLine | cdktn.IResolvable): any;
export declare function costBudgetBudgetLineToHclTerraform(struct?: CostBudgetBudgetLine | cdktn.IResolvable): any;
export declare class CostBudgetBudgetLineOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CostBudgetBudgetLine | cdktn.IResolvable | undefined;
    set internalValue(value: CostBudgetBudgetLine | cdktn.IResolvable | undefined);
    private _amounts?;
    get amounts(): {
        [key: string]: number;
    };
    set amounts(value: {
        [key: string]: number;
    });
    get amountsInput(): {
        [key: string]: number;
    } | undefined;
    private _childTagFilters;
    get childTagFilters(): CostBudgetBudgetLineChildTagFiltersList;
    putChildTagFilters(value: CostBudgetBudgetLineChildTagFilters[] | cdktn.IResolvable): void;
    resetChildTagFilters(): void;
    get childTagFiltersInput(): cdktn.IResolvable | CostBudgetBudgetLineChildTagFilters[] | undefined;
    private _parentTagFilters;
    get parentTagFilters(): CostBudgetBudgetLineParentTagFiltersList;
    putParentTagFilters(value: CostBudgetBudgetLineParentTagFilters[] | cdktn.IResolvable): void;
    resetParentTagFilters(): void;
    get parentTagFiltersInput(): cdktn.IResolvable | CostBudgetBudgetLineParentTagFilters[] | undefined;
    private _tagFilters;
    get tagFilters(): CostBudgetBudgetLineTagFiltersList;
    putTagFilters(value: CostBudgetBudgetLineTagFilters[] | cdktn.IResolvable): void;
    resetTagFilters(): void;
    get tagFiltersInput(): cdktn.IResolvable | CostBudgetBudgetLineTagFilters[] | undefined;
}
export declare class CostBudgetBudgetLineList extends cdktn.ComplexList {
    internalValue?: CostBudgetBudgetLine[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CostBudgetBudgetLineOutputReference;
}
export interface CostBudgetEntriesTagFilters {
    /**
    * **Note:** Must be one of the tags from the `metrics_query`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#tag_key CostBudget#tag_key}
    */
    readonly tagKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#tag_value CostBudget#tag_value}
    */
    readonly tagValue: string;
}
export declare function costBudgetEntriesTagFiltersToTerraform(struct?: CostBudgetEntriesTagFilters | cdktn.IResolvable): any;
export declare function costBudgetEntriesTagFiltersToHclTerraform(struct?: CostBudgetEntriesTagFilters | cdktn.IResolvable): any;
export declare class CostBudgetEntriesTagFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CostBudgetEntriesTagFilters | cdktn.IResolvable | undefined;
    set internalValue(value: CostBudgetEntriesTagFilters | cdktn.IResolvable | undefined);
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    get tagValueInput(): string | undefined;
}
export declare class CostBudgetEntriesTagFiltersList extends cdktn.ComplexList {
    internalValue?: CostBudgetEntriesTagFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CostBudgetEntriesTagFiltersOutputReference;
}
export interface CostBudgetEntries {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#amount CostBudget#amount}
    */
    readonly amount: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#month CostBudget#month}
    */
    readonly month: number;
    /**
    * tag_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#tag_filters CostBudget#tag_filters}
    */
    readonly tagFilters?: CostBudgetEntriesTagFilters[] | cdktn.IResolvable;
}
export declare function costBudgetEntriesToTerraform(struct?: CostBudgetEntries | cdktn.IResolvable): any;
export declare function costBudgetEntriesToHclTerraform(struct?: CostBudgetEntries | cdktn.IResolvable): any;
export declare class CostBudgetEntriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CostBudgetEntries | cdktn.IResolvable | undefined;
    set internalValue(value: CostBudgetEntries | cdktn.IResolvable | undefined);
    private _amount?;
    get amount(): number;
    set amount(value: number);
    get amountInput(): number | undefined;
    private _month?;
    get month(): number;
    set month(value: number);
    get monthInput(): number | undefined;
    private _tagFilters;
    get tagFilters(): CostBudgetEntriesTagFiltersList;
    putTagFilters(value: CostBudgetEntriesTagFilters[] | cdktn.IResolvable): void;
    resetTagFilters(): void;
    get tagFiltersInput(): cdktn.IResolvable | CostBudgetEntriesTagFilters[] | undefined;
}
export declare class CostBudgetEntriesList extends cdktn.ComplexList {
    internalValue?: CostBudgetEntries[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CostBudgetEntriesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget datadog_cost_budget}
*/
export declare class CostBudget extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_cost_budget";
    /**
    * Generates CDKTN code for importing a CostBudget resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CostBudget to import
    * @param importFromId The id of the existing CostBudget that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CostBudget to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cost_budget datadog_cost_budget} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CostBudgetConfig
    */
    constructor(scope: Construct, id: string, config: CostBudgetConfig);
    private _endMonth?;
    get endMonth(): number;
    set endMonth(value: number);
    get endMonthInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metricsQuery?;
    get metricsQuery(): string;
    set metricsQuery(value: string);
    get metricsQueryInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _startMonth?;
    get startMonth(): number;
    set startMonth(value: number);
    get startMonthInput(): number | undefined;
    get totalAmount(): number;
    private _budgetLine;
    get budgetLine(): CostBudgetBudgetLineList;
    putBudgetLine(value: CostBudgetBudgetLine[] | cdktn.IResolvable): void;
    resetBudgetLine(): void;
    get budgetLineInput(): cdktn.IResolvable | CostBudgetBudgetLine[] | undefined;
    private _entries;
    get entries(): CostBudgetEntriesList;
    putEntries(value: CostBudgetEntries[] | cdktn.IResolvable): void;
    resetEntries(): void;
    get entriesInput(): cdktn.IResolvable | CostBudgetEntries[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
