/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AgentlessScanningGcpScanOptionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The GCP project ID for which agentless scanning is configured. Must be a valid GCP project ID: 6–30 characters, start with a lowercase letter, and include only lowercase letters, digits, or hyphens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/agentless_scanning_gcp_scan_options#gcp_project_id AgentlessScanningGcpScanOptions#gcp_project_id}
    */
    readonly gcpProjectId: string;
    /**
    * Indicates if scanning for vulnerabilities in containers is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/agentless_scanning_gcp_scan_options#vuln_containers_os AgentlessScanningGcpScanOptions#vuln_containers_os}
    */
    readonly vulnContainersOs: boolean | cdktn.IResolvable;
    /**
    * Indicates if scanning for vulnerabilities in hosts is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/agentless_scanning_gcp_scan_options#vuln_host_os AgentlessScanningGcpScanOptions#vuln_host_os}
    */
    readonly vulnHostOs: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/agentless_scanning_gcp_scan_options datadog_agentless_scanning_gcp_scan_options}
*/
export declare class AgentlessScanningGcpScanOptions extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_agentless_scanning_gcp_scan_options";
    /**
    * Generates CDKTN code for importing a AgentlessScanningGcpScanOptions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AgentlessScanningGcpScanOptions to import
    * @param importFromId The id of the existing AgentlessScanningGcpScanOptions that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/agentless_scanning_gcp_scan_options#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AgentlessScanningGcpScanOptions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/agentless_scanning_gcp_scan_options datadog_agentless_scanning_gcp_scan_options} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AgentlessScanningGcpScanOptionsConfig
    */
    constructor(scope: Construct, id: string, config: AgentlessScanningGcpScanOptionsConfig);
    private _gcpProjectId?;
    get gcpProjectId(): string;
    set gcpProjectId(value: string);
    get gcpProjectIdInput(): string | undefined;
    get id(): string;
    private _vulnContainersOs?;
    get vulnContainersOs(): boolean | cdktn.IResolvable;
    set vulnContainersOs(value: boolean | cdktn.IResolvable);
    get vulnContainersOsInput(): boolean | cdktn.IResolvable | undefined;
    private _vulnHostOs?;
    get vulnHostOs(): boolean | cdktn.IResolvable;
    set vulnHostOs(value: boolean | cdktn.IResolvable);
    get vulnHostOsInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
