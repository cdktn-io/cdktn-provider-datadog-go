/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogSecurityMonitoringRulesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Limit the search to default rules
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/security_monitoring_rules#default_only_filter DataDatadogSecurityMonitoringRules#default_only_filter}
    */
    readonly defaultOnlyFilter?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/security_monitoring_rules#id DataDatadogSecurityMonitoringRules#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A rule name to limit the search
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/security_monitoring_rules#name_filter DataDatadogSecurityMonitoringRules#name_filter}
    */
    readonly nameFilter?: string;
    /**
    * A list of tags to limit the search
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/security_monitoring_rules#tags_filter DataDatadogSecurityMonitoringRules#tags_filter}
    */
    readonly tagsFilter?: string[];
    /**
    * Limit the search to user rules
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/security_monitoring_rules#user_only_filter DataDatadogSecurityMonitoringRules#user_only_filter}
    */
    readonly userOnlyFilter?: boolean | cdktn.IResolvable;
}
export interface DataDatadogSecurityMonitoringRulesRulesCalculatedField {
}
export declare function dataDatadogSecurityMonitoringRulesRulesCalculatedFieldToTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesCalculatedField): any;
export declare function dataDatadogSecurityMonitoringRulesRulesCalculatedFieldToHclTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesCalculatedField): any;
export declare class DataDatadogSecurityMonitoringRulesRulesCalculatedFieldOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringRulesRulesCalculatedField | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringRulesRulesCalculatedField | undefined);
    get expression(): string;
    get name(): string;
}
export declare class DataDatadogSecurityMonitoringRulesRulesCalculatedFieldList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringRulesRulesCalculatedFieldOutputReference;
}
export interface DataDatadogSecurityMonitoringRulesRulesCaseActionOptions {
}
export declare function dataDatadogSecurityMonitoringRulesRulesCaseActionOptionsToTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesCaseActionOptions): any;
export declare function dataDatadogSecurityMonitoringRulesRulesCaseActionOptionsToHclTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesCaseActionOptions): any;
export declare class DataDatadogSecurityMonitoringRulesRulesCaseActionOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringRulesRulesCaseActionOptions | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringRulesRulesCaseActionOptions | undefined);
    get duration(): number;
}
export declare class DataDatadogSecurityMonitoringRulesRulesCaseActionOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringRulesRulesCaseActionOptionsOutputReference;
}
export interface DataDatadogSecurityMonitoringRulesRulesCaseAction {
}
export declare function dataDatadogSecurityMonitoringRulesRulesCaseActionToTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesCaseAction): any;
export declare function dataDatadogSecurityMonitoringRulesRulesCaseActionToHclTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesCaseAction): any;
export declare class DataDatadogSecurityMonitoringRulesRulesCaseActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringRulesRulesCaseAction | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringRulesRulesCaseAction | undefined);
    private _options;
    get options(): DataDatadogSecurityMonitoringRulesRulesCaseActionOptionsList;
    get type(): string;
}
export declare class DataDatadogSecurityMonitoringRulesRulesCaseActionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringRulesRulesCaseActionOutputReference;
}
export interface DataDatadogSecurityMonitoringRulesRulesCase {
}
export declare function dataDatadogSecurityMonitoringRulesRulesCaseToTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesCase): any;
export declare function dataDatadogSecurityMonitoringRulesRulesCaseToHclTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesCase): any;
export declare class DataDatadogSecurityMonitoringRulesRulesCaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringRulesRulesCase | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringRulesRulesCase | undefined);
    private _action;
    get action(): DataDatadogSecurityMonitoringRulesRulesCaseActionList;
    get condition(): string;
    get name(): string;
    get notifications(): string[];
    get status(): string;
}
export declare class DataDatadogSecurityMonitoringRulesRulesCaseList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringRulesRulesCaseOutputReference;
}
export interface DataDatadogSecurityMonitoringRulesRulesFilter {
}
export declare function dataDatadogSecurityMonitoringRulesRulesFilterToTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesFilter): any;
export declare function dataDatadogSecurityMonitoringRulesRulesFilterToHclTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesFilter): any;
export declare class DataDatadogSecurityMonitoringRulesRulesFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringRulesRulesFilter | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringRulesRulesFilter | undefined);
    get action(): string;
    get query(): string;
}
export declare class DataDatadogSecurityMonitoringRulesRulesFilterList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringRulesRulesFilterOutputReference;
}
export interface DataDatadogSecurityMonitoringRulesRulesOptionsAnomalyDetectionOptions {
}
export declare function dataDatadogSecurityMonitoringRulesRulesOptionsAnomalyDetectionOptionsToTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesOptionsAnomalyDetectionOptions): any;
export declare function dataDatadogSecurityMonitoringRulesRulesOptionsAnomalyDetectionOptionsToHclTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesOptionsAnomalyDetectionOptions): any;
export declare class DataDatadogSecurityMonitoringRulesRulesOptionsAnomalyDetectionOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringRulesRulesOptionsAnomalyDetectionOptions | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringRulesRulesOptionsAnomalyDetectionOptions | undefined);
    get bucketDuration(): number;
    get detectionTolerance(): number;
    get instantaneousBaseline(): cdktn.IResolvable;
    get learningDuration(): number;
    get learningPeriodBaseline(): number;
}
export declare class DataDatadogSecurityMonitoringRulesRulesOptionsAnomalyDetectionOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringRulesRulesOptionsAnomalyDetectionOptionsOutputReference;
}
export interface DataDatadogSecurityMonitoringRulesRulesOptionsImpossibleTravelOptions {
}
export declare function dataDatadogSecurityMonitoringRulesRulesOptionsImpossibleTravelOptionsToTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesOptionsImpossibleTravelOptions): any;
export declare function dataDatadogSecurityMonitoringRulesRulesOptionsImpossibleTravelOptionsToHclTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesOptionsImpossibleTravelOptions): any;
export declare class DataDatadogSecurityMonitoringRulesRulesOptionsImpossibleTravelOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringRulesRulesOptionsImpossibleTravelOptions | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringRulesRulesOptionsImpossibleTravelOptions | undefined);
    get baselineUserLocations(): cdktn.IResolvable;
}
export declare class DataDatadogSecurityMonitoringRulesRulesOptionsImpossibleTravelOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringRulesRulesOptionsImpossibleTravelOptionsOutputReference;
}
export interface DataDatadogSecurityMonitoringRulesRulesOptionsNewValueOptions {
}
export declare function dataDatadogSecurityMonitoringRulesRulesOptionsNewValueOptionsToTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesOptionsNewValueOptions): any;
export declare function dataDatadogSecurityMonitoringRulesRulesOptionsNewValueOptionsToHclTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesOptionsNewValueOptions): any;
export declare class DataDatadogSecurityMonitoringRulesRulesOptionsNewValueOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringRulesRulesOptionsNewValueOptions | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringRulesRulesOptionsNewValueOptions | undefined);
    get forgetAfter(): number;
    get instantaneousBaseline(): cdktn.IResolvable;
    get learningDuration(): number;
    get learningMethod(): string;
    get learningThreshold(): number;
}
export declare class DataDatadogSecurityMonitoringRulesRulesOptionsNewValueOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringRulesRulesOptionsNewValueOptionsOutputReference;
}
export interface DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsStepTransitions {
}
export declare function dataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsStepTransitionsToTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsStepTransitions): any;
export declare function dataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsStepTransitionsToHclTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsStepTransitions): any;
export declare class DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsStepTransitionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsStepTransitions | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsStepTransitions | undefined);
    get child(): string;
    get evaluationWindow(): number;
    get parent(): string;
}
export declare class DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsStepTransitionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsStepTransitionsOutputReference;
}
export interface DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsSteps {
}
export declare function dataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsStepsToTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsSteps): any;
export declare function dataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsStepsToHclTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsSteps): any;
export declare class DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsStepsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsSteps | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsSteps | undefined);
    get condition(): string;
    get evaluationWindow(): number;
    get name(): string;
}
export declare class DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsStepsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsStepsOutputReference;
}
export interface DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptions {
}
export declare function dataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsToTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptions): any;
export declare function dataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsToHclTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptions): any;
export declare class DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptions | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptions | undefined);
    private _stepTransitions;
    get stepTransitions(): DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsStepTransitionsList;
    private _steps;
    get steps(): DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsStepsList;
}
export declare class DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsOutputReference;
}
export interface DataDatadogSecurityMonitoringRulesRulesOptionsThirdPartyRuleOptionsRootQuery {
}
export declare function dataDatadogSecurityMonitoringRulesRulesOptionsThirdPartyRuleOptionsRootQueryToTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesOptionsThirdPartyRuleOptionsRootQuery): any;
export declare function dataDatadogSecurityMonitoringRulesRulesOptionsThirdPartyRuleOptionsRootQueryToHclTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesOptionsThirdPartyRuleOptionsRootQuery): any;
export declare class DataDatadogSecurityMonitoringRulesRulesOptionsThirdPartyRuleOptionsRootQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringRulesRulesOptionsThirdPartyRuleOptionsRootQuery | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringRulesRulesOptionsThirdPartyRuleOptionsRootQuery | undefined);
    get groupByFields(): string[];
    get query(): string;
}
export declare class DataDatadogSecurityMonitoringRulesRulesOptionsThirdPartyRuleOptionsRootQueryList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringRulesRulesOptionsThirdPartyRuleOptionsRootQueryOutputReference;
}
export interface DataDatadogSecurityMonitoringRulesRulesOptionsThirdPartyRuleOptions {
}
export declare function dataDatadogSecurityMonitoringRulesRulesOptionsThirdPartyRuleOptionsToTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesOptionsThirdPartyRuleOptions): any;
export declare function dataDatadogSecurityMonitoringRulesRulesOptionsThirdPartyRuleOptionsToHclTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesOptionsThirdPartyRuleOptions): any;
export declare class DataDatadogSecurityMonitoringRulesRulesOptionsThirdPartyRuleOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringRulesRulesOptionsThirdPartyRuleOptions | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringRulesRulesOptionsThirdPartyRuleOptions | undefined);
    get defaultNotifications(): string[];
    get defaultStatus(): string;
    private _rootQuery;
    get rootQuery(): DataDatadogSecurityMonitoringRulesRulesOptionsThirdPartyRuleOptionsRootQueryList;
    get signalTitleTemplate(): string;
}
export declare class DataDatadogSecurityMonitoringRulesRulesOptionsThirdPartyRuleOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringRulesRulesOptionsThirdPartyRuleOptionsOutputReference;
}
export interface DataDatadogSecurityMonitoringRulesRulesOptions {
}
export declare function dataDatadogSecurityMonitoringRulesRulesOptionsToTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesOptions): any;
export declare function dataDatadogSecurityMonitoringRulesRulesOptionsToHclTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesOptions): any;
export declare class DataDatadogSecurityMonitoringRulesRulesOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringRulesRulesOptions | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringRulesRulesOptions | undefined);
    private _anomalyDetectionOptions;
    get anomalyDetectionOptions(): DataDatadogSecurityMonitoringRulesRulesOptionsAnomalyDetectionOptionsList;
    get decreaseCriticalityBasedOnEnv(): cdktn.IResolvable;
    get detectionMethod(): string;
    get evaluationWindow(): number;
    private _impossibleTravelOptions;
    get impossibleTravelOptions(): DataDatadogSecurityMonitoringRulesRulesOptionsImpossibleTravelOptionsList;
    get keepAlive(): number;
    get maxSignalDuration(): number;
    private _newValueOptions;
    get newValueOptions(): DataDatadogSecurityMonitoringRulesRulesOptionsNewValueOptionsList;
    private _sequenceDetectionOptions;
    get sequenceDetectionOptions(): DataDatadogSecurityMonitoringRulesRulesOptionsSequenceDetectionOptionsList;
    private _thirdPartyRuleOptions;
    get thirdPartyRuleOptions(): DataDatadogSecurityMonitoringRulesRulesOptionsThirdPartyRuleOptionsList;
}
export declare class DataDatadogSecurityMonitoringRulesRulesOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringRulesRulesOptionsOutputReference;
}
export interface DataDatadogSecurityMonitoringRulesRulesQueryAgentRule {
}
export declare function dataDatadogSecurityMonitoringRulesRulesQueryAgentRuleToTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesQueryAgentRule): any;
export declare function dataDatadogSecurityMonitoringRulesRulesQueryAgentRuleToHclTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesQueryAgentRule): any;
export declare class DataDatadogSecurityMonitoringRulesRulesQueryAgentRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringRulesRulesQueryAgentRule | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringRulesRulesQueryAgentRule | undefined);
    get agentRuleId(): string;
    get expression(): string;
}
export declare class DataDatadogSecurityMonitoringRulesRulesQueryAgentRuleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringRulesRulesQueryAgentRuleOutputReference;
}
export interface DataDatadogSecurityMonitoringRulesRulesQuery {
}
export declare function dataDatadogSecurityMonitoringRulesRulesQueryToTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesQuery): any;
export declare function dataDatadogSecurityMonitoringRulesRulesQueryToHclTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesQuery): any;
export declare class DataDatadogSecurityMonitoringRulesRulesQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringRulesRulesQuery | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringRulesRulesQuery | undefined);
    private _agentRule;
    get agentRule(): DataDatadogSecurityMonitoringRulesRulesQueryAgentRuleList;
    get aggregation(): string;
    get dataSource(): string;
    get distinctFields(): string[];
    get groupByFields(): string[];
    get hasOptionalGroupByFields(): cdktn.IResolvable;
    get indexes(): string[];
    get metric(): string;
    get metrics(): string[];
    get name(): string;
    get query(): string;
}
export declare class DataDatadogSecurityMonitoringRulesRulesQueryList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringRulesRulesQueryOutputReference;
}
export interface DataDatadogSecurityMonitoringRulesRulesReferenceTables {
}
export declare function dataDatadogSecurityMonitoringRulesRulesReferenceTablesToTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesReferenceTables): any;
export declare function dataDatadogSecurityMonitoringRulesRulesReferenceTablesToHclTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesReferenceTables): any;
export declare class DataDatadogSecurityMonitoringRulesRulesReferenceTablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringRulesRulesReferenceTables | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringRulesRulesReferenceTables | undefined);
    get checkPresence(): cdktn.IResolvable;
    get columnName(): string;
    get logFieldPath(): string;
    get ruleQueryName(): string;
    get tableName(): string;
}
export declare class DataDatadogSecurityMonitoringRulesRulesReferenceTablesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringRulesRulesReferenceTablesOutputReference;
}
export interface DataDatadogSecurityMonitoringRulesRulesSchedulingOptions {
}
export declare function dataDatadogSecurityMonitoringRulesRulesSchedulingOptionsToTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesSchedulingOptions): any;
export declare function dataDatadogSecurityMonitoringRulesRulesSchedulingOptionsToHclTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesSchedulingOptions): any;
export declare class DataDatadogSecurityMonitoringRulesRulesSchedulingOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringRulesRulesSchedulingOptions | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringRulesRulesSchedulingOptions | undefined);
    get rrule(): string;
    get start(): string;
    get timezone(): string;
}
export declare class DataDatadogSecurityMonitoringRulesRulesSchedulingOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringRulesRulesSchedulingOptionsOutputReference;
}
export interface DataDatadogSecurityMonitoringRulesRulesSignalQuery {
}
export declare function dataDatadogSecurityMonitoringRulesRulesSignalQueryToTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesSignalQuery): any;
export declare function dataDatadogSecurityMonitoringRulesRulesSignalQueryToHclTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesSignalQuery): any;
export declare class DataDatadogSecurityMonitoringRulesRulesSignalQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringRulesRulesSignalQuery | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringRulesRulesSignalQuery | undefined);
    get aggregation(): string;
    get correlatedByFields(): string[];
    get correlatedQueryIndex(): string;
    get defaultRuleId(): string;
    get name(): string;
    get ruleId(): string;
}
export declare class DataDatadogSecurityMonitoringRulesRulesSignalQueryList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringRulesRulesSignalQueryOutputReference;
}
export interface DataDatadogSecurityMonitoringRulesRulesThirdPartyCase {
}
export declare function dataDatadogSecurityMonitoringRulesRulesThirdPartyCaseToTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesThirdPartyCase): any;
export declare function dataDatadogSecurityMonitoringRulesRulesThirdPartyCaseToHclTerraform(struct?: DataDatadogSecurityMonitoringRulesRulesThirdPartyCase): any;
export declare class DataDatadogSecurityMonitoringRulesRulesThirdPartyCaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringRulesRulesThirdPartyCase | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringRulesRulesThirdPartyCase | undefined);
    get name(): string;
    get notifications(): string[];
    get query(): string;
    get status(): string;
}
export declare class DataDatadogSecurityMonitoringRulesRulesThirdPartyCaseList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringRulesRulesThirdPartyCaseOutputReference;
}
export interface DataDatadogSecurityMonitoringRulesRules {
}
export declare function dataDatadogSecurityMonitoringRulesRulesToTerraform(struct?: DataDatadogSecurityMonitoringRulesRules): any;
export declare function dataDatadogSecurityMonitoringRulesRulesToHclTerraform(struct?: DataDatadogSecurityMonitoringRulesRules): any;
export declare class DataDatadogSecurityMonitoringRulesRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringRulesRules | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringRulesRules | undefined);
    private _calculatedField;
    get calculatedField(): DataDatadogSecurityMonitoringRulesRulesCalculatedFieldList;
    private _case;
    get case(): DataDatadogSecurityMonitoringRulesRulesCaseList;
    get enabled(): cdktn.IResolvable;
    private _filter;
    get filter(): DataDatadogSecurityMonitoringRulesRulesFilterList;
    get groupSignalsBy(): string[];
    get hasExtendedTitle(): cdktn.IResolvable;
    get message(): string;
    get name(): string;
    private _options;
    get options(): DataDatadogSecurityMonitoringRulesRulesOptionsList;
    private _query;
    get query(): DataDatadogSecurityMonitoringRulesRulesQueryList;
    private _referenceTables;
    get referenceTables(): DataDatadogSecurityMonitoringRulesRulesReferenceTablesList;
    private _schedulingOptions;
    get schedulingOptions(): DataDatadogSecurityMonitoringRulesRulesSchedulingOptionsList;
    private _signalQuery;
    get signalQuery(): DataDatadogSecurityMonitoringRulesRulesSignalQueryList;
    get tags(): string[];
    private _thirdPartyCase;
    get thirdPartyCase(): DataDatadogSecurityMonitoringRulesRulesThirdPartyCaseList;
    get type(): string;
}
export declare class DataDatadogSecurityMonitoringRulesRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringRulesRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/security_monitoring_rules datadog_security_monitoring_rules}
*/
export declare class DataDatadogSecurityMonitoringRules extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_security_monitoring_rules";
    /**
    * Generates CDKTN code for importing a DataDatadogSecurityMonitoringRules resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogSecurityMonitoringRules to import
    * @param importFromId The id of the existing DataDatadogSecurityMonitoringRules that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/security_monitoring_rules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogSecurityMonitoringRules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/security_monitoring_rules datadog_security_monitoring_rules} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogSecurityMonitoringRulesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogSecurityMonitoringRulesConfig);
    private _defaultOnlyFilter?;
    get defaultOnlyFilter(): boolean | cdktn.IResolvable;
    set defaultOnlyFilter(value: boolean | cdktn.IResolvable);
    resetDefaultOnlyFilter(): void;
    get defaultOnlyFilterInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _nameFilter?;
    get nameFilter(): string;
    set nameFilter(value: string);
    resetNameFilter(): void;
    get nameFilterInput(): string | undefined;
    get ruleIds(): string[];
    private _rules;
    get rules(): DataDatadogSecurityMonitoringRulesRulesList;
    private _tagsFilter?;
    get tagsFilter(): string[];
    set tagsFilter(value: string[]);
    resetTagsFilter(): void;
    get tagsFilterInput(): string[] | undefined;
    private _userOnlyFilter?;
    get userOnlyFilter(): boolean | cdktn.IResolvable;
    set userOnlyFilter(value: boolean | cdktn.IResolvable);
    resetUserOnlyFilter(): void;
    get userOnlyFilterInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
