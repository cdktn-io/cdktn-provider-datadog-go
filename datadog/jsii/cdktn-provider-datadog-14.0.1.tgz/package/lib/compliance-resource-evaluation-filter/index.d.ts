/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComplianceResourceEvaluationFilterConfig extends cdktn.TerraformMetaArguments {
    /**
    * The cloud provider of the filter's targeted resource. Only `aws`, `gcp`, or `azure` are considered valid cloud providers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/compliance_resource_evaluation_filter#cloud_provider ComplianceResourceEvaluationFilter#cloud_provider}
    */
    readonly cloudProvider: string;
    /**
    * The ID of the of the filter's targeted resource. Different cloud providers target different resource IDs:
    *   - `aws`: account ID
    *   - `gcp`: project ID
    *   - `azure`: subscription ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/compliance_resource_evaluation_filter#resource_id ComplianceResourceEvaluationFilter#resource_id}
    */
    readonly resourceId: string;
    /**
    * List of tags to filter misconfiguration detections. Each entry should follow the format: "key":"value".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/compliance_resource_evaluation_filter#tags ComplianceResourceEvaluationFilter#tags}
    */
    readonly tags: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/compliance_resource_evaluation_filter datadog_compliance_resource_evaluation_filter}
*/
export declare class ComplianceResourceEvaluationFilter extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_compliance_resource_evaluation_filter";
    /**
    * Generates CDKTN code for importing a ComplianceResourceEvaluationFilter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComplianceResourceEvaluationFilter to import
    * @param importFromId The id of the existing ComplianceResourceEvaluationFilter that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/compliance_resource_evaluation_filter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComplianceResourceEvaluationFilter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/compliance_resource_evaluation_filter datadog_compliance_resource_evaluation_filter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComplianceResourceEvaluationFilterConfig
    */
    constructor(scope: Construct, id: string, config: ComplianceResourceEvaluationFilterConfig);
    private _cloudProvider?;
    get cloudProvider(): string;
    set cloudProvider(value: string);
    get cloudProviderInput(): string | undefined;
    get id(): string;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    get tagsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
