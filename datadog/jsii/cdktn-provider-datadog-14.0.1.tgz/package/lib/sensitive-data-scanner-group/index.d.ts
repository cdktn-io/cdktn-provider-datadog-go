/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SensitiveDataScannerGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Description of the Datadog scanning group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_group#description SensitiveDataScannerGroup#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_group#id SensitiveDataScannerGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Whether or not the scanning group is enabled. If the group doesn't contain any rule or if all the rules in it are disabled, the group is force-disabled by our backend
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_group#is_enabled SensitiveDataScannerGroup#is_enabled}
    */
    readonly isEnabled: boolean | cdktn.IResolvable;
    /**
    * Name of the Datadog scanning group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_group#name SensitiveDataScannerGroup#name}
    */
    readonly name: string;
    /**
    * List of products the scanning group applies. Valid values are `logs`, `rum`, `events`, `apm`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_group#product_list SensitiveDataScannerGroup#product_list}
    */
    readonly productList: string[];
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_group#filter SensitiveDataScannerGroup#filter}
    */
    readonly filter: SensitiveDataScannerGroupFilter;
    /**
    * samplings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_group#samplings SensitiveDataScannerGroup#samplings}
    */
    readonly samplings?: SensitiveDataScannerGroupSamplings[] | cdktn.IResolvable;
}
export interface SensitiveDataScannerGroupFilter {
    /**
    * Query to filter the events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_group#query SensitiveDataScannerGroup#query}
    */
    readonly query: string;
}
export declare function sensitiveDataScannerGroupFilterToTerraform(struct?: SensitiveDataScannerGroupFilterOutputReference | SensitiveDataScannerGroupFilter): any;
export declare function sensitiveDataScannerGroupFilterToHclTerraform(struct?: SensitiveDataScannerGroupFilterOutputReference | SensitiveDataScannerGroupFilter): any;
export declare class SensitiveDataScannerGroupFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SensitiveDataScannerGroupFilter | undefined;
    set internalValue(value: SensitiveDataScannerGroupFilter | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface SensitiveDataScannerGroupSamplings {
    /**
    * Product that the sampling rate applies to. Valid values are `logs`, `rum`, `events`, `apm`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_group#product SensitiveDataScannerGroup#product}
    */
    readonly product: string;
    /**
    * Percentage rate at which data for the product type is scanned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_group#rate SensitiveDataScannerGroup#rate}
    */
    readonly rate: number;
}
export declare function sensitiveDataScannerGroupSamplingsToTerraform(struct?: SensitiveDataScannerGroupSamplings | cdktn.IResolvable): any;
export declare function sensitiveDataScannerGroupSamplingsToHclTerraform(struct?: SensitiveDataScannerGroupSamplings | cdktn.IResolvable): any;
export declare class SensitiveDataScannerGroupSamplingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SensitiveDataScannerGroupSamplings | cdktn.IResolvable | undefined;
    set internalValue(value: SensitiveDataScannerGroupSamplings | cdktn.IResolvable | undefined);
    private _product?;
    get product(): string;
    set product(value: string);
    get productInput(): string | undefined;
    private _rate?;
    get rate(): number;
    set rate(value: number);
    get rateInput(): number | undefined;
}
export declare class SensitiveDataScannerGroupSamplingsList extends cdktn.ComplexList {
    internalValue?: SensitiveDataScannerGroupSamplings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SensitiveDataScannerGroupSamplingsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_group datadog_sensitive_data_scanner_group}
*/
export declare class SensitiveDataScannerGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_sensitive_data_scanner_group";
    /**
    * Generates CDKTN code for importing a SensitiveDataScannerGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SensitiveDataScannerGroup to import
    * @param importFromId The id of the existing SensitiveDataScannerGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SensitiveDataScannerGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/sensitive_data_scanner_group datadog_sensitive_data_scanner_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SensitiveDataScannerGroupConfig
    */
    constructor(scope: Construct, id: string, config: SensitiveDataScannerGroupConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _productList?;
    get productList(): string[];
    set productList(value: string[]);
    get productListInput(): string[] | undefined;
    private _filter;
    get filter(): SensitiveDataScannerGroupFilterOutputReference;
    putFilter(value: SensitiveDataScannerGroupFilter): void;
    get filterInput(): SensitiveDataScannerGroupFilter | undefined;
    private _samplings;
    get samplings(): SensitiveDataScannerGroupSamplingsList;
    putSamplings(value: SensitiveDataScannerGroupSamplings[] | cdktn.IResolvable): void;
    resetSamplings(): void;
    get samplingsInput(): cdktn.IResolvable | SensitiveDataScannerGroupSamplings[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
