/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TagPipelineRulesetsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether to override UI-defined rulesets. When set to true, any rulesets created via the UI that are not defined in Terraform will be deleted and Terraform will be used as the source of truth for rules and their ordering. When set to false, any rulesets created via the UI that are at the end of order will be kept but will be warned, otherwise an error will be thrown in terraform plan phase. Default is false
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_rulesets#override_ui_defined_resources TagPipelineRulesets#override_ui_defined_resources}
    */
    readonly overrideUiDefinedResources?: boolean | cdktn.IResolvable;
    /**
    * The list of Tag Pipeline Ruleset IDs, in order. Rulesets are executed in the order specified in this list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_rulesets#ruleset_ids TagPipelineRulesets#ruleset_ids}
    */
    readonly rulesetIds: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_rulesets datadog_tag_pipeline_rulesets}
*/
export declare class TagPipelineRulesets extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_tag_pipeline_rulesets";
    /**
    * Generates CDKTN code for importing a TagPipelineRulesets resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TagPipelineRulesets to import
    * @param importFromId The id of the existing TagPipelineRulesets that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_rulesets#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TagPipelineRulesets to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_rulesets datadog_tag_pipeline_rulesets} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TagPipelineRulesetsConfig
    */
    constructor(scope: Construct, id: string, config: TagPipelineRulesetsConfig);
    get id(): string;
    private _overrideUiDefinedResources?;
    get overrideUiDefinedResources(): boolean | cdktn.IResolvable;
    set overrideUiDefinedResources(value: boolean | cdktn.IResolvable);
    resetOverrideUiDefinedResources(): void;
    get overrideUiDefinedResourcesInput(): boolean | cdktn.IResolvable | undefined;
    private _rulesetIds?;
    get rulesetIds(): string[];
    set rulesetIds(value: string[]);
    get rulesetIdsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
