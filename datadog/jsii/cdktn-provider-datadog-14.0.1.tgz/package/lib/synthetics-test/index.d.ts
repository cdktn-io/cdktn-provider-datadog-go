/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SyntheticsTestConfig extends cdktn.TerraformMetaArguments {
    /**
    * Initial application arguments for the mobile test.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#config_initial_application_arguments SyntheticsTest#config_initial_application_arguments}
    */
    readonly configInitialApplicationArguments?: {
        [key: string]: string;
    };
    /**
    * Required if `type = "browser"`. Array with the different device IDs used to run the test.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#device_ids SyntheticsTest#device_ids}
    */
    readonly deviceIds?: string[];
    /**
    * A boolean indicating whether this synthetics test can be deleted even if it's referenced by other resources (for example, SLOs and composite monitors).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#force_delete_dependencies SyntheticsTest#force_delete_dependencies}
    */
    readonly forceDeleteDependencies?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#id SyntheticsTest#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Array of locations used to run the test. Refer to [the Datadog Synthetics location data source](https://registry.terraform.io/providers/DataDog/datadog/latest/docs/data-sources/synthetics_locations) to retrieve the list of locations or find the possible values listed in [this API response](https://app.datadoghq.com/api/v1/synthetics/locations?only_public=true).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#locations SyntheticsTest#locations}
    */
    readonly locations: string[];
    /**
    * A message to include with notifications for this synthetics test. Email notifications can be sent to specific users by using the same `@username` notation as events. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#message SyntheticsTest#message}
    */
    readonly message?: string;
    /**
    * Name of Datadog synthetics test.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#name SyntheticsTest#name}
    */
    readonly name: string;
    /**
    * Header name and value map.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#request_headers SyntheticsTest#request_headers}
    */
    readonly requestHeaders?: {
        [key: string]: string;
    };
    /**
    * Metadata to include when performing the gRPC request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#request_metadata SyntheticsTest#request_metadata}
    */
    readonly requestMetadata?: {
        [key: string]: string;
    };
    /**
    * Query arguments name and value map.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#request_query SyntheticsTest#request_query}
    */
    readonly requestQuery?: {
        [key: string]: string;
    };
    /**
    * Cookies to be used for a browser test request, using the [Set-Cookie](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Set-Cookie) syntax.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#set_cookie SyntheticsTest#set_cookie}
    */
    readonly setCookie?: string;
    /**
    * Define whether you want to start (`live`) or pause (`paused`) a Synthetic test. Valid values are `live`, `paused`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#status SyntheticsTest#status}
    */
    readonly status: string;
    /**
    * The subtype for API or Network Path tests. For API tests, defaults to `http`. For Network Path tests, only `tcp`, `udp`, `icmp` are available. Valid values are `http`, `ssl`, `tcp`, `dns`, `multi`, `icmp`, `udp`, `websocket`, `grpc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#subtype SyntheticsTest#subtype}
    */
    readonly subtype?: string;
    /**
    * A list of tags to associate with your synthetics test. This can help you categorize and filter tests in the manage synthetics page of the UI. Default is an empty list (`[]`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#tags SyntheticsTest#tags}
    */
    readonly tags?: string[];
    /**
    * The type of Synthetics test. Valid values are `api`, `browser`, `mobile`, `network`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#type SyntheticsTest#type}
    */
    readonly type: string;
    /**
    * Variables defined from JavaScript code for API HTTP tests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#variables_from_script SyntheticsTest#variables_from_script}
    */
    readonly variablesFromScript?: string;
    /**
    * api_step block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#api_step SyntheticsTest#api_step}
    */
    readonly apiStep?: SyntheticsTestApiStep[] | cdktn.IResolvable;
    /**
    * assertion block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#assertion SyntheticsTest#assertion}
    */
    readonly assertion?: SyntheticsTestAssertion[] | cdktn.IResolvable;
    /**
    * browser_step block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#browser_step SyntheticsTest#browser_step}
    */
    readonly browserStep?: SyntheticsTestBrowserStep[] | cdktn.IResolvable;
    /**
    * browser_variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#browser_variable SyntheticsTest#browser_variable}
    */
    readonly browserVariable?: SyntheticsTestBrowserVariable[] | cdktn.IResolvable;
    /**
    * config_variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#config_variable SyntheticsTest#config_variable}
    */
    readonly configVariable?: SyntheticsTestConfigVariable[] | cdktn.IResolvable;
    /**
    * mobile_options_list block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#mobile_options_list SyntheticsTest#mobile_options_list}
    */
    readonly mobileOptionsList?: SyntheticsTestMobileOptionsListStruct;
    /**
    * mobile_step block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#mobile_step SyntheticsTest#mobile_step}
    */
    readonly mobileStep?: SyntheticsTestMobileStep[] | cdktn.IResolvable;
    /**
    * options_list block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#options_list SyntheticsTest#options_list}
    */
    readonly optionsList?: SyntheticsTestOptionsListStruct;
    /**
    * request_basicauth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#request_basicauth SyntheticsTest#request_basicauth}
    */
    readonly requestBasicauth?: SyntheticsTestRequestBasicauth;
    /**
    * request_client_certificate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#request_client_certificate SyntheticsTest#request_client_certificate}
    */
    readonly requestClientCertificate?: SyntheticsTestRequestClientCertificate;
    /**
    * request_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#request_definition SyntheticsTest#request_definition}
    */
    readonly requestDefinition?: SyntheticsTestRequestDefinition;
    /**
    * request_file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#request_file SyntheticsTest#request_file}
    */
    readonly requestFile?: SyntheticsTestRequestFile[] | cdktn.IResolvable;
    /**
    * request_proxy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#request_proxy SyntheticsTest#request_proxy}
    */
    readonly requestProxy?: SyntheticsTestRequestProxy;
}
export interface SyntheticsTestApiStepAssertionTargetjsonpath {
    /**
    * The element from the list of results to assert on. Select from `firstElementMatches` (the first element in the list), `everyElementMatches` (every element in the list), `atLeastOneElementMatches` (at least one element in the list), or `serializationMatches` (the serialized value of the list). Defaults to `"firstElementMatches"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#elementsoperator SyntheticsTest#elementsoperator}
    */
    readonly elementsoperator?: string;
    /**
    * The JSON path to assert.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#jsonpath SyntheticsTest#jsonpath}
    */
    readonly jsonpath: string;
    /**
    * The specific operator to use on the path.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#operator SyntheticsTest#operator}
    */
    readonly operator: string;
    /**
    * Expected matching value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#targetvalue SyntheticsTest#targetvalue}
    */
    readonly targetvalue?: string;
}
export declare function syntheticsTestApiStepAssertionTargetjsonpathToTerraform(struct?: SyntheticsTestApiStepAssertionTargetjsonpathOutputReference | SyntheticsTestApiStepAssertionTargetjsonpath): any;
export declare function syntheticsTestApiStepAssertionTargetjsonpathToHclTerraform(struct?: SyntheticsTestApiStepAssertionTargetjsonpathOutputReference | SyntheticsTestApiStepAssertionTargetjsonpath): any;
export declare class SyntheticsTestApiStepAssertionTargetjsonpathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestApiStepAssertionTargetjsonpath | undefined;
    set internalValue(value: SyntheticsTestApiStepAssertionTargetjsonpath | undefined);
    private _elementsoperator?;
    get elementsoperator(): string;
    set elementsoperator(value: string);
    resetElementsoperator(): void;
    get elementsoperatorInput(): string | undefined;
    private _jsonpath?;
    get jsonpath(): string;
    set jsonpath(value: string);
    get jsonpathInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _targetvalue?;
    get targetvalue(): string;
    set targetvalue(value: string);
    resetTargetvalue(): void;
    get targetvalueInput(): string | undefined;
}
export interface SyntheticsTestApiStepAssertionTargetjsonschema {
    /**
    * The JSON Schema to validate the body against.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#jsonschema SyntheticsTest#jsonschema}
    */
    readonly jsonschema: string;
    /**
    * The meta schema to use for the JSON Schema. Defaults to `"draft-07"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#metaschema SyntheticsTest#metaschema}
    */
    readonly metaschema?: string;
}
export declare function syntheticsTestApiStepAssertionTargetjsonschemaToTerraform(struct?: SyntheticsTestApiStepAssertionTargetjsonschemaOutputReference | SyntheticsTestApiStepAssertionTargetjsonschema): any;
export declare function syntheticsTestApiStepAssertionTargetjsonschemaToHclTerraform(struct?: SyntheticsTestApiStepAssertionTargetjsonschemaOutputReference | SyntheticsTestApiStepAssertionTargetjsonschema): any;
export declare class SyntheticsTestApiStepAssertionTargetjsonschemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestApiStepAssertionTargetjsonschema | undefined;
    set internalValue(value: SyntheticsTestApiStepAssertionTargetjsonschema | undefined);
    private _jsonschema?;
    get jsonschema(): string;
    set jsonschema(value: string);
    get jsonschemaInput(): string | undefined;
    private _metaschema?;
    get metaschema(): string;
    set metaschema(value: string);
    resetMetaschema(): void;
    get metaschemaInput(): string | undefined;
}
export interface SyntheticsTestApiStepAssertionTargetxpath {
    /**
    * The specific operator to use on the path.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#operator SyntheticsTest#operator}
    */
    readonly operator: string;
    /**
    * Expected matching value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#targetvalue SyntheticsTest#targetvalue}
    */
    readonly targetvalue?: string;
    /**
    * The xpath to assert.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#xpath SyntheticsTest#xpath}
    */
    readonly xpath: string;
}
export declare function syntheticsTestApiStepAssertionTargetxpathToTerraform(struct?: SyntheticsTestApiStepAssertionTargetxpathOutputReference | SyntheticsTestApiStepAssertionTargetxpath): any;
export declare function syntheticsTestApiStepAssertionTargetxpathToHclTerraform(struct?: SyntheticsTestApiStepAssertionTargetxpathOutputReference | SyntheticsTestApiStepAssertionTargetxpath): any;
export declare class SyntheticsTestApiStepAssertionTargetxpathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestApiStepAssertionTargetxpath | undefined;
    set internalValue(value: SyntheticsTestApiStepAssertionTargetxpath | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _targetvalue?;
    get targetvalue(): string;
    set targetvalue(value: string);
    resetTargetvalue(): void;
    get targetvalueInput(): string | undefined;
    private _xpath?;
    get xpath(): string;
    set xpath(value: string);
    get xpathInput(): string | undefined;
}
export interface SyntheticsTestApiStepAssertion {
    /**
    * If assertion type is `javascript`, this is the JavaScript code that performs the assertions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#code SyntheticsTest#code}
    */
    readonly code?: string;
    /**
    * Assertion operator. **Note:** Only some combinations of `type` and `operator` are valid. Refer to `config.assertions` in the [Datadog API reference](https://docs.datadoghq.com/api/latest/synthetics/#create-an-api-test). Valid values are `contains`, `doesNotContain`, `is`, `isNot`, `lessThan`, `lessThanOrEqual`, `moreThan`, `moreThanOrEqual`, `matches`, `doesNotMatch`, `validates`, `isInMoreThan`, `isInLessThan`, `doesNotExist`, `isUndefined`, `validatesJSONPath`, `validatesJSONSchema`, `validatesXPath`, `md5`, `sha1`, `sha256`, `is`, `isNot`, `lessThan`, `lessThanOrEqual`, `moreThan`, `moreThanOrEqual`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#operator SyntheticsTest#operator}
    */
    readonly operator?: string;
    /**
    * If assertion type is `header` or `grpcMetadata`, this is the header name. For other assertion types, this is an aggregation property: `avg`, `min`, `max`, or `stddev`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#property SyntheticsTest#property}
    */
    readonly property?: string;
    /**
    * Expected value. **Note:** Depends on the assertion type. Refer to `config.assertions` in the [Datadog API reference](https://docs.datadoghq.com/api/latest/synthetics/#create-an-api-test).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#target SyntheticsTest#target}
    */
    readonly target?: string;
    /**
    * Timings scope for response time assertions. Valid values are `all`, `withoutDNS`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#timings_scope SyntheticsTest#timings_scope}
    */
    readonly timingsScope?: string;
    /**
    * Type of assertion. **Note:** Only some combinations of `type` and `operator` are valid. For API tests, refer to `config.assertions` in the [Datadog API reference](https://docs.datadoghq.com/api/latest/synthetics/#create-an-api-test). For Network Path tests, refer to `config.assertions` in the [Datadog API reference](https://docs.datadoghq.com/api/latest/synthetics/#create-a-network-path-test). Valid values are `body`, `header`, `statusCode`, `certificate`, `responseTime`, `property`, `recordEvery`, `recordSome`, `tlsVersion`, `minTlsVersion`, `latency`, `packetLossPercentage`, `packetsReceived`, `networkHop`, `receivedMessage`, `grpcHealthcheckStatus`, `grpcMetadata`, `grpcProto`, `connection`, `multiNetworkHop`, `jitter`, `bodyHash`, `javascript`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#type SyntheticsTest#type}
    */
    readonly type: string;
    /**
    * targetjsonpath block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#targetjsonpath SyntheticsTest#targetjsonpath}
    */
    readonly targetjsonpath?: SyntheticsTestApiStepAssertionTargetjsonpath;
    /**
    * targetjsonschema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#targetjsonschema SyntheticsTest#targetjsonschema}
    */
    readonly targetjsonschema?: SyntheticsTestApiStepAssertionTargetjsonschema;
    /**
    * targetxpath block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#targetxpath SyntheticsTest#targetxpath}
    */
    readonly targetxpath?: SyntheticsTestApiStepAssertionTargetxpath;
}
export declare function syntheticsTestApiStepAssertionToTerraform(struct?: SyntheticsTestApiStepAssertion | cdktn.IResolvable): any;
export declare function syntheticsTestApiStepAssertionToHclTerraform(struct?: SyntheticsTestApiStepAssertion | cdktn.IResolvable): any;
export declare class SyntheticsTestApiStepAssertionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsTestApiStepAssertion | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsTestApiStepAssertion | cdktn.IResolvable | undefined);
    private _code?;
    get code(): string;
    set code(value: string);
    resetCode(): void;
    get codeInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _property?;
    get property(): string;
    set property(value: string);
    resetProperty(): void;
    get propertyInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    resetTarget(): void;
    get targetInput(): string | undefined;
    private _timingsScope?;
    get timingsScope(): string;
    set timingsScope(value: string);
    resetTimingsScope(): void;
    get timingsScopeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _targetjsonpath;
    get targetjsonpath(): SyntheticsTestApiStepAssertionTargetjsonpathOutputReference;
    putTargetjsonpath(value: SyntheticsTestApiStepAssertionTargetjsonpath): void;
    resetTargetjsonpath(): void;
    get targetjsonpathInput(): SyntheticsTestApiStepAssertionTargetjsonpath | undefined;
    private _targetjsonschema;
    get targetjsonschema(): SyntheticsTestApiStepAssertionTargetjsonschemaOutputReference;
    putTargetjsonschema(value: SyntheticsTestApiStepAssertionTargetjsonschema): void;
    resetTargetjsonschema(): void;
    get targetjsonschemaInput(): SyntheticsTestApiStepAssertionTargetjsonschema | undefined;
    private _targetxpath;
    get targetxpath(): SyntheticsTestApiStepAssertionTargetxpathOutputReference;
    putTargetxpath(value: SyntheticsTestApiStepAssertionTargetxpath): void;
    resetTargetxpath(): void;
    get targetxpathInput(): SyntheticsTestApiStepAssertionTargetxpath | undefined;
}
export declare class SyntheticsTestApiStepAssertionList extends cdktn.ComplexList {
    internalValue?: SyntheticsTestApiStepAssertion[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsTestApiStepAssertionOutputReference;
}
export interface SyntheticsTestApiStepExtractedValueParser {
    /**
    * Type of parser for a Synthetics global variable from a synthetics test. Valid values are `raw`, `json_path`, `regex`, `x_path`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#type SyntheticsTest#type}
    */
    readonly type: string;
    /**
    * Regex or JSON path used for the parser. Not used with type `raw`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#value SyntheticsTest#value}
    */
    readonly value?: string;
}
export declare function syntheticsTestApiStepExtractedValueParserToTerraform(struct?: SyntheticsTestApiStepExtractedValueParserOutputReference | SyntheticsTestApiStepExtractedValueParser): any;
export declare function syntheticsTestApiStepExtractedValueParserToHclTerraform(struct?: SyntheticsTestApiStepExtractedValueParserOutputReference | SyntheticsTestApiStepExtractedValueParser): any;
export declare class SyntheticsTestApiStepExtractedValueParserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestApiStepExtractedValueParser | undefined;
    set internalValue(value: SyntheticsTestApiStepExtractedValueParser | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface SyntheticsTestApiStepExtractedValue {
    /**
    * When type is `http_header` or `grpc_metadata`, name of the header or metadatum to extract.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#field SyntheticsTest#field}
    */
    readonly field?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#name SyntheticsTest#name}
    */
    readonly name: string;
    /**
    * Determines whether or not the extracted value will be obfuscated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#secure SyntheticsTest#secure}
    */
    readonly secure?: boolean | cdktn.IResolvable;
    /**
    * Property of the Synthetics Test Response to use for the variable. Valid values are `grpc_message`, `grpc_metadata`, `http_body`, `http_header`, `http_status_code`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#type SyntheticsTest#type}
    */
    readonly type: string;
    /**
    * parser block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#parser SyntheticsTest#parser}
    */
    readonly parser: SyntheticsTestApiStepExtractedValueParser;
}
export declare function syntheticsTestApiStepExtractedValueToTerraform(struct?: SyntheticsTestApiStepExtractedValue | cdktn.IResolvable): any;
export declare function syntheticsTestApiStepExtractedValueToHclTerraform(struct?: SyntheticsTestApiStepExtractedValue | cdktn.IResolvable): any;
export declare class SyntheticsTestApiStepExtractedValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsTestApiStepExtractedValue | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsTestApiStepExtractedValue | cdktn.IResolvable | undefined);
    private _field?;
    get field(): string;
    set field(value: string);
    resetField(): void;
    get fieldInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _secure?;
    get secure(): boolean | cdktn.IResolvable;
    set secure(value: boolean | cdktn.IResolvable);
    resetSecure(): void;
    get secureInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _parser;
    get parser(): SyntheticsTestApiStepExtractedValueParserOutputReference;
    putParser(value: SyntheticsTestApiStepExtractedValueParser): void;
    get parserInput(): SyntheticsTestApiStepExtractedValueParser | undefined;
}
export declare class SyntheticsTestApiStepExtractedValueList extends cdktn.ComplexList {
    internalValue?: SyntheticsTestApiStepExtractedValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsTestApiStepExtractedValueOutputReference;
}
export interface SyntheticsTestApiStepRequestBasicauth {
    /**
    * Access key for `SIGV4` authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#access_key SyntheticsTest#access_key}
    */
    readonly accessKey?: string;
    /**
    * Access token url for `oauth-client` or `oauth-rop` authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#access_token_url SyntheticsTest#access_token_url}
    */
    readonly accessTokenUrl?: string;
    /**
    * Audience for `oauth-client` or `oauth-rop` authentication. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#audience SyntheticsTest#audience}
    */
    readonly audience?: string;
    /**
    * Client ID for `oauth-client` or `oauth-rop` authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#client_id SyntheticsTest#client_id}
    */
    readonly clientId?: string;
    /**
    * Client secret for `oauth-client` or `oauth-rop` authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#client_secret SyntheticsTest#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * Domain for `ntlm` authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#domain SyntheticsTest#domain}
    */
    readonly domain?: string;
    /**
    * Password for authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#password SyntheticsTest#password}
    */
    readonly password?: string;
    /**
    * Region for `SIGV4` authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#region SyntheticsTest#region}
    */
    readonly region?: string;
    /**
    * Resource for `oauth-client` or `oauth-rop` authentication. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#resource SyntheticsTest#resource}
    */
    readonly resource?: string;
    /**
    * Scope for `oauth-client` or `oauth-rop` authentication. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#scope SyntheticsTest#scope}
    */
    readonly scope?: string;
    /**
    * Secret key for `SIGV4` authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#secret_key SyntheticsTest#secret_key}
    */
    readonly secretKey?: string;
    /**
    * Service name for `SIGV4` authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#service_name SyntheticsTest#service_name}
    */
    readonly serviceName?: string;
    /**
    * Session token for `SIGV4` authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#session_token SyntheticsTest#session_token}
    */
    readonly sessionToken?: string;
    /**
    * Token API Authentication for `oauth-client` or `oauth-rop` authentication. Valid values are `header`, `body`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#token_api_authentication SyntheticsTest#token_api_authentication}
    */
    readonly tokenApiAuthentication?: string;
    /**
    * Type of basic authentication to use when performing the test. Defaults to `"web"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#type SyntheticsTest#type}
    */
    readonly type?: string;
    /**
    * Username for authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#username SyntheticsTest#username}
    */
    readonly username?: string;
    /**
    * Workstation for `ntlm` authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#workstation SyntheticsTest#workstation}
    */
    readonly workstation?: string;
}
export declare function syntheticsTestApiStepRequestBasicauthToTerraform(struct?: SyntheticsTestApiStepRequestBasicauthOutputReference | SyntheticsTestApiStepRequestBasicauth): any;
export declare function syntheticsTestApiStepRequestBasicauthToHclTerraform(struct?: SyntheticsTestApiStepRequestBasicauthOutputReference | SyntheticsTestApiStepRequestBasicauth): any;
export declare class SyntheticsTestApiStepRequestBasicauthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestApiStepRequestBasicauth | undefined;
    set internalValue(value: SyntheticsTestApiStepRequestBasicauth | undefined);
    private _accessKey?;
    get accessKey(): string;
    set accessKey(value: string);
    resetAccessKey(): void;
    get accessKeyInput(): string | undefined;
    private _accessTokenUrl?;
    get accessTokenUrl(): string;
    set accessTokenUrl(value: string);
    resetAccessTokenUrl(): void;
    get accessTokenUrlInput(): string | undefined;
    private _audience?;
    get audience(): string;
    set audience(value: string);
    resetAudience(): void;
    get audienceInput(): string | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    resetDomain(): void;
    get domainInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    resetResource(): void;
    get resourceInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
    private _secretKey?;
    get secretKey(): string;
    set secretKey(value: string);
    resetSecretKey(): void;
    get secretKeyInput(): string | undefined;
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    resetServiceName(): void;
    get serviceNameInput(): string | undefined;
    private _sessionToken?;
    get sessionToken(): string;
    set sessionToken(value: string);
    resetSessionToken(): void;
    get sessionTokenInput(): string | undefined;
    private _tokenApiAuthentication?;
    get tokenApiAuthentication(): string;
    set tokenApiAuthentication(value: string);
    resetTokenApiAuthentication(): void;
    get tokenApiAuthenticationInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _workstation?;
    get workstation(): string;
    set workstation(value: string);
    resetWorkstation(): void;
    get workstationInput(): string | undefined;
}
export interface SyntheticsTestApiStepRequestClientCertificateCert {
    /**
    * Content of the certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#content SyntheticsTest#content}
    */
    readonly content?: string;
    /**
    * File name for the certificate. Defaults to `"Provided in Terraform config"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#filename SyntheticsTest#filename}
    */
    readonly filename?: string;
}
export declare function syntheticsTestApiStepRequestClientCertificateCertToTerraform(struct?: SyntheticsTestApiStepRequestClientCertificateCertOutputReference | SyntheticsTestApiStepRequestClientCertificateCert): any;
export declare function syntheticsTestApiStepRequestClientCertificateCertToHclTerraform(struct?: SyntheticsTestApiStepRequestClientCertificateCertOutputReference | SyntheticsTestApiStepRequestClientCertificateCert): any;
export declare class SyntheticsTestApiStepRequestClientCertificateCertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestApiStepRequestClientCertificateCert | undefined;
    set internalValue(value: SyntheticsTestApiStepRequestClientCertificateCert | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    private _filename?;
    get filename(): string;
    set filename(value: string);
    resetFilename(): void;
    get filenameInput(): string | undefined;
}
export interface SyntheticsTestApiStepRequestClientCertificateKey {
    /**
    * Content of the certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#content SyntheticsTest#content}
    */
    readonly content?: string;
    /**
    * File name for the certificate. Defaults to `"Provided in Terraform config"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#filename SyntheticsTest#filename}
    */
    readonly filename?: string;
}
export declare function syntheticsTestApiStepRequestClientCertificateKeyToTerraform(struct?: SyntheticsTestApiStepRequestClientCertificateKeyOutputReference | SyntheticsTestApiStepRequestClientCertificateKey): any;
export declare function syntheticsTestApiStepRequestClientCertificateKeyToHclTerraform(struct?: SyntheticsTestApiStepRequestClientCertificateKeyOutputReference | SyntheticsTestApiStepRequestClientCertificateKey): any;
export declare class SyntheticsTestApiStepRequestClientCertificateKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestApiStepRequestClientCertificateKey | undefined;
    set internalValue(value: SyntheticsTestApiStepRequestClientCertificateKey | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    private _filename?;
    get filename(): string;
    set filename(value: string);
    resetFilename(): void;
    get filenameInput(): string | undefined;
}
export interface SyntheticsTestApiStepRequestClientCertificate {
    /**
    * cert block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#cert SyntheticsTest#cert}
    */
    readonly cert: SyntheticsTestApiStepRequestClientCertificateCert;
    /**
    * key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#key SyntheticsTest#key}
    */
    readonly key: SyntheticsTestApiStepRequestClientCertificateKey;
}
export declare function syntheticsTestApiStepRequestClientCertificateToTerraform(struct?: SyntheticsTestApiStepRequestClientCertificateOutputReference | SyntheticsTestApiStepRequestClientCertificate): any;
export declare function syntheticsTestApiStepRequestClientCertificateToHclTerraform(struct?: SyntheticsTestApiStepRequestClientCertificateOutputReference | SyntheticsTestApiStepRequestClientCertificate): any;
export declare class SyntheticsTestApiStepRequestClientCertificateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestApiStepRequestClientCertificate | undefined;
    set internalValue(value: SyntheticsTestApiStepRequestClientCertificate | undefined);
    private _cert;
    get cert(): SyntheticsTestApiStepRequestClientCertificateCertOutputReference;
    putCert(value: SyntheticsTestApiStepRequestClientCertificateCert): void;
    get certInput(): SyntheticsTestApiStepRequestClientCertificateCert | undefined;
    private _key;
    get key(): SyntheticsTestApiStepRequestClientCertificateKeyOutputReference;
    putKey(value: SyntheticsTestApiStepRequestClientCertificateKey): void;
    get keyInput(): SyntheticsTestApiStepRequestClientCertificateKey | undefined;
}
export interface SyntheticsTestApiStepRequestDefinition {
    /**
    * For SSL tests, whether or not the test should allow self signed certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#accept_self_signed SyntheticsTest#accept_self_signed}
    */
    readonly acceptSelfSigned?: boolean | cdktn.IResolvable;
    /**
    * Allows loading insecure content for a request in an API test or in a multistep API test step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#allow_insecure SyntheticsTest#allow_insecure}
    */
    readonly allowInsecure?: boolean | cdktn.IResolvable;
    /**
    * The request body.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#body SyntheticsTest#body}
    */
    readonly body?: string;
    /**
    * Type of the request body. Valid values are `text/plain`, `application/json`, `text/xml`, `text/html`, `application/x-www-form-urlencoded`, `graphql`, `application/octet-stream`, `multipart/form-data`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#body_type SyntheticsTest#body_type}
    */
    readonly bodyType?: string;
    /**
    * The type of gRPC call to perform. Valid values are `healthcheck`, `unary`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#call_type SyntheticsTest#call_type}
    */
    readonly callType?: string;
    /**
    * By default, the client certificate is applied on the domain of the starting URL for browser tests. If you want your client certificate to be applied on other domains instead, add them in `certificate_domains`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#certificate_domains SyntheticsTest#certificate_domains}
    */
    readonly certificateDomains?: string[];
    /**
    * For SSL tests, whether or not the test should fail on revoked certificate in stapled OCSP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#check_certificate_revocation SyntheticsTest#check_certificate_revocation}
    */
    readonly checkCertificateRevocation?: boolean | cdktn.IResolvable;
    /**
    * For Network Path tests, an optional label displayed for the destination host in the Network Path visualization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#destination_service SyntheticsTest#destination_service}
    */
    readonly destinationService?: string;
    /**
    * For SSL tests, whether or not the test should disable fetching intermediate certificates from AIA
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#disable_aia_intermediate_fetching SyntheticsTest#disable_aia_intermediate_fetching}
    */
    readonly disableAiaIntermediateFetching?: boolean | cdktn.IResolvable;
    /**
    * DNS server to use for DNS tests (`subtype = "dns"`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#dns_server SyntheticsTest#dns_server}
    */
    readonly dnsServer?: string;
    /**
    * DNS server port to use for DNS tests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#dns_server_port SyntheticsTest#dns_server_port}
    */
    readonly dnsServerPort?: string;
    /**
    * For Network Path tests, the number of packets sent to probe the destination to measure packet loss, latency, and jitter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#e2e_queries SyntheticsTest#e2e_queries}
    */
    readonly e2EQueries?: number;
    /**
    * Determines whether or not the API HTTP test should follow redirects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#follow_redirects SyntheticsTest#follow_redirects}
    */
    readonly followRedirects?: boolean | cdktn.IResolvable;
    /**
    * Form data to be sent when `body_type` is `multipart/form-data`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#form SyntheticsTest#form}
    */
    readonly form?: {
        [key: string]: string;
    };
    /**
    * Host name to perform the test with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#host SyntheticsTest#host}
    */
    readonly host?: string;
    /**
    * HTTP version to use for an HTTP request in an API test or step. Valid values are `http1`, `http2`, `any`. Defaults to `"any"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#http_version SyntheticsTest#http_version}
    */
    readonly httpVersion?: string;
    /**
    * For Websocket tests, whether the message is treated as a base64-encoded string in the server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#is_message_base64_encoded SyntheticsTest#is_message_base64_encoded}
    */
    readonly isMessageBase64Encoded?: boolean | cdktn.IResolvable;
    /**
    * For Network Path tests, the maximum time-to-live (max number of hops) used in outgoing probe packets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#max_ttl SyntheticsTest#max_ttl}
    */
    readonly maxTtl?: number;
    /**
    * For gRPC, UDP, and Websocket tests, message to send with the request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#message SyntheticsTest#message}
    */
    readonly message?: string;
    /**
    * Either the HTTP method/verb to use or a gRPC method available on the service set in the `service` field. Required if `subtype` is `HTTP` or if `subtype` is `grpc` and `callType` is `unary`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#method SyntheticsTest#method}
    */
    readonly method?: string;
    /**
    * Determines whether or not to save the response body.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#no_saving_response_body SyntheticsTest#no_saving_response_body}
    */
    readonly noSavingResponseBody?: boolean | cdktn.IResolvable;
    /**
    * Number of pings to use per test for ICMP tests (`subtype = "icmp"`) between 0 and 10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#number_of_packets SyntheticsTest#number_of_packets}
    */
    readonly numberOfPackets?: number;
    /**
    * Persist cookies across redirects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#persist_cookies SyntheticsTest#persist_cookies}
    */
    readonly persistCookies?: boolean | cdktn.IResolvable;
    /**
    * The content of a proto file as a string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#plain_proto_file SyntheticsTest#plain_proto_file}
    */
    readonly plainProtoFile?: string;
    /**
    * Port to use when performing the test.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#port SyntheticsTest#port}
    */
    readonly port?: string;
    /**
    * A protobuf JSON descriptor. **Deprecated.** Use `plain_proto_file` instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#proto_json_descriptor SyntheticsTest#proto_json_descriptor}
    */
    readonly protoJsonDescriptor?: string;
    /**
    * For SSL tests, it specifies on which server you want to initiate the TLS handshake, allowing the server to present one of multiple possible certificates on the same IP address and TCP port number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#servername SyntheticsTest#servername}
    */
    readonly servername?: string;
    /**
    * The gRPC service on which you want to perform the gRPC call.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#service SyntheticsTest#service}
    */
    readonly service?: string;
    /**
    * This will turn on a traceroute probe to discover all gateways along the path to the host destination. For ICMP tests (`subtype = "icmp"`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#should_track_hops SyntheticsTest#should_track_hops}
    */
    readonly shouldTrackHops?: boolean | cdktn.IResolvable;
    /**
    * For Network Path tests, an optional label displayed for the source host in the Network Path visualization
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#source_service SyntheticsTest#source_service}
    */
    readonly sourceService?: string;
    /**
    * For TCP Network Path tests, the TCP traceroute strategy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#tcp_method SyntheticsTest#tcp_method}
    */
    readonly tcpMethod?: string;
    /**
    * Timeout in seconds for the test.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#timeout SyntheticsTest#timeout}
    */
    readonly timeout?: number;
    /**
    * For Network Path tests, the number of traceroute path tracings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#traceroute_queries SyntheticsTest#traceroute_queries}
    */
    readonly tracerouteQueries?: number;
    /**
    * The URL to send the request to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#url SyntheticsTest#url}
    */
    readonly url?: string;
}
export declare function syntheticsTestApiStepRequestDefinitionToTerraform(struct?: SyntheticsTestApiStepRequestDefinitionOutputReference | SyntheticsTestApiStepRequestDefinition): any;
export declare function syntheticsTestApiStepRequestDefinitionToHclTerraform(struct?: SyntheticsTestApiStepRequestDefinitionOutputReference | SyntheticsTestApiStepRequestDefinition): any;
export declare class SyntheticsTestApiStepRequestDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestApiStepRequestDefinition | undefined;
    set internalValue(value: SyntheticsTestApiStepRequestDefinition | undefined);
    private _acceptSelfSigned?;
    get acceptSelfSigned(): boolean | cdktn.IResolvable;
    set acceptSelfSigned(value: boolean | cdktn.IResolvable);
    resetAcceptSelfSigned(): void;
    get acceptSelfSignedInput(): boolean | cdktn.IResolvable | undefined;
    private _allowInsecure?;
    get allowInsecure(): boolean | cdktn.IResolvable;
    set allowInsecure(value: boolean | cdktn.IResolvable);
    resetAllowInsecure(): void;
    get allowInsecureInput(): boolean | cdktn.IResolvable | undefined;
    private _body?;
    get body(): string;
    set body(value: string);
    resetBody(): void;
    get bodyInput(): string | undefined;
    private _bodyType?;
    get bodyType(): string;
    set bodyType(value: string);
    resetBodyType(): void;
    get bodyTypeInput(): string | undefined;
    private _callType?;
    get callType(): string;
    set callType(value: string);
    resetCallType(): void;
    get callTypeInput(): string | undefined;
    private _certificateDomains?;
    get certificateDomains(): string[];
    set certificateDomains(value: string[]);
    resetCertificateDomains(): void;
    get certificateDomainsInput(): string[] | undefined;
    private _checkCertificateRevocation?;
    get checkCertificateRevocation(): boolean | cdktn.IResolvable;
    set checkCertificateRevocation(value: boolean | cdktn.IResolvable);
    resetCheckCertificateRevocation(): void;
    get checkCertificateRevocationInput(): boolean | cdktn.IResolvable | undefined;
    private _destinationService?;
    get destinationService(): string;
    set destinationService(value: string);
    resetDestinationService(): void;
    get destinationServiceInput(): string | undefined;
    private _disableAiaIntermediateFetching?;
    get disableAiaIntermediateFetching(): boolean | cdktn.IResolvable;
    set disableAiaIntermediateFetching(value: boolean | cdktn.IResolvable);
    resetDisableAiaIntermediateFetching(): void;
    get disableAiaIntermediateFetchingInput(): boolean | cdktn.IResolvable | undefined;
    private _dnsServer?;
    get dnsServer(): string;
    set dnsServer(value: string);
    resetDnsServer(): void;
    get dnsServerInput(): string | undefined;
    private _dnsServerPort?;
    get dnsServerPort(): string;
    set dnsServerPort(value: string);
    resetDnsServerPort(): void;
    get dnsServerPortInput(): string | undefined;
    private _e2EQueries?;
    get e2EQueries(): number;
    set e2EQueries(value: number);
    resetE2EQueries(): void;
    get e2EQueriesInput(): number | undefined;
    private _followRedirects?;
    get followRedirects(): boolean | cdktn.IResolvable;
    set followRedirects(value: boolean | cdktn.IResolvable);
    resetFollowRedirects(): void;
    get followRedirectsInput(): boolean | cdktn.IResolvable | undefined;
    private _form?;
    get form(): {
        [key: string]: string;
    };
    set form(value: {
        [key: string]: string;
    });
    resetForm(): void;
    get formInput(): {
        [key: string]: string;
    } | undefined;
    private _host?;
    get host(): string;
    set host(value: string);
    resetHost(): void;
    get hostInput(): string | undefined;
    private _httpVersion?;
    get httpVersion(): string;
    set httpVersion(value: string);
    resetHttpVersion(): void;
    get httpVersionInput(): string | undefined;
    private _isMessageBase64Encoded?;
    get isMessageBase64Encoded(): boolean | cdktn.IResolvable;
    set isMessageBase64Encoded(value: boolean | cdktn.IResolvable);
    resetIsMessageBase64Encoded(): void;
    get isMessageBase64EncodedInput(): boolean | cdktn.IResolvable | undefined;
    private _maxTtl?;
    get maxTtl(): number;
    set maxTtl(value: number);
    resetMaxTtl(): void;
    get maxTtlInput(): number | undefined;
    private _message?;
    get message(): string;
    set message(value: string);
    resetMessage(): void;
    get messageInput(): string | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _noSavingResponseBody?;
    get noSavingResponseBody(): boolean | cdktn.IResolvable;
    set noSavingResponseBody(value: boolean | cdktn.IResolvable);
    resetNoSavingResponseBody(): void;
    get noSavingResponseBodyInput(): boolean | cdktn.IResolvable | undefined;
    private _numberOfPackets?;
    get numberOfPackets(): number;
    set numberOfPackets(value: number);
    resetNumberOfPackets(): void;
    get numberOfPacketsInput(): number | undefined;
    private _persistCookies?;
    get persistCookies(): boolean | cdktn.IResolvable;
    set persistCookies(value: boolean | cdktn.IResolvable);
    resetPersistCookies(): void;
    get persistCookiesInput(): boolean | cdktn.IResolvable | undefined;
    private _plainProtoFile?;
    get plainProtoFile(): string;
    set plainProtoFile(value: string);
    resetPlainProtoFile(): void;
    get plainProtoFileInput(): string | undefined;
    private _port?;
    get port(): string;
    set port(value: string);
    resetPort(): void;
    get portInput(): string | undefined;
    private _protoJsonDescriptor?;
    get protoJsonDescriptor(): string;
    set protoJsonDescriptor(value: string);
    resetProtoJsonDescriptor(): void;
    get protoJsonDescriptorInput(): string | undefined;
    private _servername?;
    get servername(): string;
    set servername(value: string);
    resetServername(): void;
    get servernameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
    private _shouldTrackHops?;
    get shouldTrackHops(): boolean | cdktn.IResolvable;
    set shouldTrackHops(value: boolean | cdktn.IResolvable);
    resetShouldTrackHops(): void;
    get shouldTrackHopsInput(): boolean | cdktn.IResolvable | undefined;
    private _sourceService?;
    get sourceService(): string;
    set sourceService(value: string);
    resetSourceService(): void;
    get sourceServiceInput(): string | undefined;
    private _tcpMethod?;
    get tcpMethod(): string;
    set tcpMethod(value: string);
    resetTcpMethod(): void;
    get tcpMethodInput(): string | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _tracerouteQueries?;
    get tracerouteQueries(): number;
    set tracerouteQueries(value: number);
    resetTracerouteQueries(): void;
    get tracerouteQueriesInput(): number | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
}
export interface SyntheticsTestApiStepRequestFile {
    /**
    * Content of the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#content SyntheticsTest#content}
    */
    readonly content?: string;
    /**
    * Name of the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#name SyntheticsTest#name}
    */
    readonly name: string;
    /**
    * Original name of the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#original_file_name SyntheticsTest#original_file_name}
    */
    readonly originalFileName?: string;
    /**
    * Size of the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#size SyntheticsTest#size}
    */
    readonly size: number;
    /**
    * Type of the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#type SyntheticsTest#type}
    */
    readonly type: string;
}
export declare function syntheticsTestApiStepRequestFileToTerraform(struct?: SyntheticsTestApiStepRequestFile | cdktn.IResolvable): any;
export declare function syntheticsTestApiStepRequestFileToHclTerraform(struct?: SyntheticsTestApiStepRequestFile | cdktn.IResolvable): any;
export declare class SyntheticsTestApiStepRequestFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsTestApiStepRequestFile | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsTestApiStepRequestFile | cdktn.IResolvable | undefined);
    get bucketKey(): string;
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _originalFileName?;
    get originalFileName(): string;
    set originalFileName(value: string);
    resetOriginalFileName(): void;
    get originalFileNameInput(): string | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    get sizeInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class SyntheticsTestApiStepRequestFileList extends cdktn.ComplexList {
    internalValue?: SyntheticsTestApiStepRequestFile[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsTestApiStepRequestFileOutputReference;
}
export interface SyntheticsTestApiStepRequestProxy {
    /**
    * Header name and value map.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#headers SyntheticsTest#headers}
    */
    readonly headers?: {
        [key: string]: string;
    };
    /**
    * URL of the proxy to perform the test.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#url SyntheticsTest#url}
    */
    readonly url: string;
}
export declare function syntheticsTestApiStepRequestProxyToTerraform(struct?: SyntheticsTestApiStepRequestProxyOutputReference | SyntheticsTestApiStepRequestProxy): any;
export declare function syntheticsTestApiStepRequestProxyToHclTerraform(struct?: SyntheticsTestApiStepRequestProxyOutputReference | SyntheticsTestApiStepRequestProxy): any;
export declare class SyntheticsTestApiStepRequestProxyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestApiStepRequestProxy | undefined;
    set internalValue(value: SyntheticsTestApiStepRequestProxy | undefined);
    private _headers?;
    get headers(): {
        [key: string]: string;
    };
    set headers(value: {
        [key: string]: string;
    });
    resetHeaders(): void;
    get headersInput(): {
        [key: string]: string;
    } | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface SyntheticsTestApiStepRetry {
    /**
    * Number of retries needed to consider a location as failed before sending a notification alert. Maximum value: `3` for `api` tests, `2` for `browser` and `mobile` tests. Defaults to `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#count SyntheticsTest#count}
    */
    readonly count?: number;
    /**
    * Interval between a failed test and the next retry in milliseconds. Maximum value: `5000`. Defaults to `300`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#interval SyntheticsTest#interval}
    */
    readonly interval?: number;
}
export declare function syntheticsTestApiStepRetryToTerraform(struct?: SyntheticsTestApiStepRetryOutputReference | SyntheticsTestApiStepRetry): any;
export declare function syntheticsTestApiStepRetryToHclTerraform(struct?: SyntheticsTestApiStepRetryOutputReference | SyntheticsTestApiStepRetry): any;
export declare class SyntheticsTestApiStepRetryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestApiStepRetry | undefined;
    set internalValue(value: SyntheticsTestApiStepRetry | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    resetCount(): void;
    get countInput(): number | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface SyntheticsTestApiStep {
    /**
    * Determines whether or not to continue with test if this step fails.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#allow_failure SyntheticsTest#allow_failure}
    */
    readonly allowFailure?: boolean | cdktn.IResolvable;
    /**
    * Determines whether or not to exit the test if the step succeeds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#exit_if_succeed SyntheticsTest#exit_if_succeed}
    */
    readonly exitIfSucceed?: boolean | cdktn.IResolvable;
    /**
    * Generate variables using JavaScript.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#extracted_values_from_script SyntheticsTest#extracted_values_from_script}
    */
    readonly extractedValuesFromScript?: string;
    /**
    * Determines whether or not to consider the entire test as failed if this step fails. Can be used only if `allow_failure` is `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#is_critical SyntheticsTest#is_critical}
    */
    readonly isCritical?: boolean | cdktn.IResolvable;
    /**
    * The name of the step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#name SyntheticsTest#name}
    */
    readonly name: string;
    /**
    * Header name and value map.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#request_headers SyntheticsTest#request_headers}
    */
    readonly requestHeaders?: {
        [key: string]: string;
    };
    /**
    * Metadata to include when performing the gRPC request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#request_metadata SyntheticsTest#request_metadata}
    */
    readonly requestMetadata?: {
        [key: string]: string;
    };
    /**
    * Query arguments name and value map.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#request_query SyntheticsTest#request_query}
    */
    readonly requestQuery?: {
        [key: string]: string;
    };
    /**
    * Public ID of the test to be played as part of a `playSubTest` step type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#subtest_public_id SyntheticsTest#subtest_public_id}
    */
    readonly subtestPublicId?: string;
    /**
    * The subtype of the Synthetic multistep API test step. Valid values are `http`, `grpc`, `ssl`, `dns`, `tcp`, `udp`, `icmp`, `websocket`, `wait`, `playSubTest`. Defaults to `"http"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#subtype SyntheticsTest#subtype}
    */
    readonly subtype?: string;
    /**
    * The time to wait in seconds. Minimum value: 0. Maximum value: 180.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#value SyntheticsTest#value}
    */
    readonly value?: number;
    /**
    * assertion block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#assertion SyntheticsTest#assertion}
    */
    readonly assertion?: SyntheticsTestApiStepAssertion[] | cdktn.IResolvable;
    /**
    * extracted_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#extracted_value SyntheticsTest#extracted_value}
    */
    readonly extractedValue?: SyntheticsTestApiStepExtractedValue[] | cdktn.IResolvable;
    /**
    * request_basicauth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#request_basicauth SyntheticsTest#request_basicauth}
    */
    readonly requestBasicauth?: SyntheticsTestApiStepRequestBasicauth;
    /**
    * request_client_certificate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#request_client_certificate SyntheticsTest#request_client_certificate}
    */
    readonly requestClientCertificate?: SyntheticsTestApiStepRequestClientCertificate;
    /**
    * request_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#request_definition SyntheticsTest#request_definition}
    */
    readonly requestDefinition?: SyntheticsTestApiStepRequestDefinition;
    /**
    * request_file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#request_file SyntheticsTest#request_file}
    */
    readonly requestFile?: SyntheticsTestApiStepRequestFile[] | cdktn.IResolvable;
    /**
    * request_proxy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#request_proxy SyntheticsTest#request_proxy}
    */
    readonly requestProxy?: SyntheticsTestApiStepRequestProxy;
    /**
    * retry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#retry SyntheticsTest#retry}
    */
    readonly retry?: SyntheticsTestApiStepRetry;
}
export declare function syntheticsTestApiStepToTerraform(struct?: SyntheticsTestApiStep | cdktn.IResolvable): any;
export declare function syntheticsTestApiStepToHclTerraform(struct?: SyntheticsTestApiStep | cdktn.IResolvable): any;
export declare class SyntheticsTestApiStepOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsTestApiStep | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsTestApiStep | cdktn.IResolvable | undefined);
    private _allowFailure?;
    get allowFailure(): boolean | cdktn.IResolvable;
    set allowFailure(value: boolean | cdktn.IResolvable);
    resetAllowFailure(): void;
    get allowFailureInput(): boolean | cdktn.IResolvable | undefined;
    private _exitIfSucceed?;
    get exitIfSucceed(): boolean | cdktn.IResolvable;
    set exitIfSucceed(value: boolean | cdktn.IResolvable);
    resetExitIfSucceed(): void;
    get exitIfSucceedInput(): boolean | cdktn.IResolvable | undefined;
    private _extractedValuesFromScript?;
    get extractedValuesFromScript(): string;
    set extractedValuesFromScript(value: string);
    resetExtractedValuesFromScript(): void;
    get extractedValuesFromScriptInput(): string | undefined;
    get id(): string;
    private _isCritical?;
    get isCritical(): boolean | cdktn.IResolvable;
    set isCritical(value: boolean | cdktn.IResolvable);
    resetIsCritical(): void;
    get isCriticalInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _requestHeaders?;
    get requestHeaders(): {
        [key: string]: string;
    };
    set requestHeaders(value: {
        [key: string]: string;
    });
    resetRequestHeaders(): void;
    get requestHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _requestMetadata?;
    get requestMetadata(): {
        [key: string]: string;
    };
    set requestMetadata(value: {
        [key: string]: string;
    });
    resetRequestMetadata(): void;
    get requestMetadataInput(): {
        [key: string]: string;
    } | undefined;
    private _requestQuery?;
    get requestQuery(): {
        [key: string]: string;
    };
    set requestQuery(value: {
        [key: string]: string;
    });
    resetRequestQuery(): void;
    get requestQueryInput(): {
        [key: string]: string;
    } | undefined;
    private _subtestPublicId?;
    get subtestPublicId(): string;
    set subtestPublicId(value: string);
    resetSubtestPublicId(): void;
    get subtestPublicIdInput(): string | undefined;
    private _subtype?;
    get subtype(): string;
    set subtype(value: string);
    resetSubtype(): void;
    get subtypeInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
    private _assertion;
    get assertion(): SyntheticsTestApiStepAssertionList;
    putAssertion(value: SyntheticsTestApiStepAssertion[] | cdktn.IResolvable): void;
    resetAssertion(): void;
    get assertionInput(): cdktn.IResolvable | SyntheticsTestApiStepAssertion[] | undefined;
    private _extractedValue;
    get extractedValue(): SyntheticsTestApiStepExtractedValueList;
    putExtractedValue(value: SyntheticsTestApiStepExtractedValue[] | cdktn.IResolvable): void;
    resetExtractedValue(): void;
    get extractedValueInput(): cdktn.IResolvable | SyntheticsTestApiStepExtractedValue[] | undefined;
    private _requestBasicauth;
    get requestBasicauth(): SyntheticsTestApiStepRequestBasicauthOutputReference;
    putRequestBasicauth(value: SyntheticsTestApiStepRequestBasicauth): void;
    resetRequestBasicauth(): void;
    get requestBasicauthInput(): SyntheticsTestApiStepRequestBasicauth | undefined;
    private _requestClientCertificate;
    get requestClientCertificate(): SyntheticsTestApiStepRequestClientCertificateOutputReference;
    putRequestClientCertificate(value: SyntheticsTestApiStepRequestClientCertificate): void;
    resetRequestClientCertificate(): void;
    get requestClientCertificateInput(): SyntheticsTestApiStepRequestClientCertificate | undefined;
    private _requestDefinition;
    get requestDefinition(): SyntheticsTestApiStepRequestDefinitionOutputReference;
    putRequestDefinition(value: SyntheticsTestApiStepRequestDefinition): void;
    resetRequestDefinition(): void;
    get requestDefinitionInput(): SyntheticsTestApiStepRequestDefinition | undefined;
    private _requestFile;
    get requestFile(): SyntheticsTestApiStepRequestFileList;
    putRequestFile(value: SyntheticsTestApiStepRequestFile[] | cdktn.IResolvable): void;
    resetRequestFile(): void;
    get requestFileInput(): cdktn.IResolvable | SyntheticsTestApiStepRequestFile[] | undefined;
    private _requestProxy;
    get requestProxy(): SyntheticsTestApiStepRequestProxyOutputReference;
    putRequestProxy(value: SyntheticsTestApiStepRequestProxy): void;
    resetRequestProxy(): void;
    get requestProxyInput(): SyntheticsTestApiStepRequestProxy | undefined;
    private _retry;
    get retry(): SyntheticsTestApiStepRetryOutputReference;
    putRetry(value: SyntheticsTestApiStepRetry): void;
    resetRetry(): void;
    get retryInput(): SyntheticsTestApiStepRetry | undefined;
}
export declare class SyntheticsTestApiStepList extends cdktn.ComplexList {
    internalValue?: SyntheticsTestApiStep[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsTestApiStepOutputReference;
}
export interface SyntheticsTestAssertionTargetjsonpath {
    /**
    * The element from the list of results to assert on. Select from `firstElementMatches` (the first element in the list), `everyElementMatches` (every element in the list), `atLeastOneElementMatches` (at least one element in the list), or `serializationMatches` (the serialized value of the list). Defaults to `"firstElementMatches"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#elementsoperator SyntheticsTest#elementsoperator}
    */
    readonly elementsoperator?: string;
    /**
    * The JSON path to assert.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#jsonpath SyntheticsTest#jsonpath}
    */
    readonly jsonpath: string;
    /**
    * The specific operator to use on the path.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#operator SyntheticsTest#operator}
    */
    readonly operator: string;
    /**
    * Expected matching value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#targetvalue SyntheticsTest#targetvalue}
    */
    readonly targetvalue?: string;
}
export declare function syntheticsTestAssertionTargetjsonpathToTerraform(struct?: SyntheticsTestAssertionTargetjsonpathOutputReference | SyntheticsTestAssertionTargetjsonpath): any;
export declare function syntheticsTestAssertionTargetjsonpathToHclTerraform(struct?: SyntheticsTestAssertionTargetjsonpathOutputReference | SyntheticsTestAssertionTargetjsonpath): any;
export declare class SyntheticsTestAssertionTargetjsonpathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestAssertionTargetjsonpath | undefined;
    set internalValue(value: SyntheticsTestAssertionTargetjsonpath | undefined);
    private _elementsoperator?;
    get elementsoperator(): string;
    set elementsoperator(value: string);
    resetElementsoperator(): void;
    get elementsoperatorInput(): string | undefined;
    private _jsonpath?;
    get jsonpath(): string;
    set jsonpath(value: string);
    get jsonpathInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _targetvalue?;
    get targetvalue(): string;
    set targetvalue(value: string);
    resetTargetvalue(): void;
    get targetvalueInput(): string | undefined;
}
export interface SyntheticsTestAssertionTargetjsonschema {
    /**
    * The JSON Schema to validate the body against.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#jsonschema SyntheticsTest#jsonschema}
    */
    readonly jsonschema: string;
    /**
    * The meta schema to use for the JSON Schema. Defaults to `"draft-07"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#metaschema SyntheticsTest#metaschema}
    */
    readonly metaschema?: string;
}
export declare function syntheticsTestAssertionTargetjsonschemaToTerraform(struct?: SyntheticsTestAssertionTargetjsonschemaOutputReference | SyntheticsTestAssertionTargetjsonschema): any;
export declare function syntheticsTestAssertionTargetjsonschemaToHclTerraform(struct?: SyntheticsTestAssertionTargetjsonschemaOutputReference | SyntheticsTestAssertionTargetjsonschema): any;
export declare class SyntheticsTestAssertionTargetjsonschemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestAssertionTargetjsonschema | undefined;
    set internalValue(value: SyntheticsTestAssertionTargetjsonschema | undefined);
    private _jsonschema?;
    get jsonschema(): string;
    set jsonschema(value: string);
    get jsonschemaInput(): string | undefined;
    private _metaschema?;
    get metaschema(): string;
    set metaschema(value: string);
    resetMetaschema(): void;
    get metaschemaInput(): string | undefined;
}
export interface SyntheticsTestAssertionTargetxpath {
    /**
    * The specific operator to use on the path.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#operator SyntheticsTest#operator}
    */
    readonly operator: string;
    /**
    * Expected matching value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#targetvalue SyntheticsTest#targetvalue}
    */
    readonly targetvalue?: string;
    /**
    * The xpath to assert.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#xpath SyntheticsTest#xpath}
    */
    readonly xpath: string;
}
export declare function syntheticsTestAssertionTargetxpathToTerraform(struct?: SyntheticsTestAssertionTargetxpathOutputReference | SyntheticsTestAssertionTargetxpath): any;
export declare function syntheticsTestAssertionTargetxpathToHclTerraform(struct?: SyntheticsTestAssertionTargetxpathOutputReference | SyntheticsTestAssertionTargetxpath): any;
export declare class SyntheticsTestAssertionTargetxpathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestAssertionTargetxpath | undefined;
    set internalValue(value: SyntheticsTestAssertionTargetxpath | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _targetvalue?;
    get targetvalue(): string;
    set targetvalue(value: string);
    resetTargetvalue(): void;
    get targetvalueInput(): string | undefined;
    private _xpath?;
    get xpath(): string;
    set xpath(value: string);
    get xpathInput(): string | undefined;
}
export interface SyntheticsTestAssertion {
    /**
    * If assertion type is `javascript`, this is the JavaScript code that performs the assertions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#code SyntheticsTest#code}
    */
    readonly code?: string;
    /**
    * Assertion operator. **Note:** Only some combinations of `type` and `operator` are valid. Refer to `config.assertions` in the [Datadog API reference](https://docs.datadoghq.com/api/latest/synthetics/#create-an-api-test). Valid values are `contains`, `doesNotContain`, `is`, `isNot`, `lessThan`, `lessThanOrEqual`, `moreThan`, `moreThanOrEqual`, `matches`, `doesNotMatch`, `validates`, `isInMoreThan`, `isInLessThan`, `doesNotExist`, `isUndefined`, `validatesJSONPath`, `validatesJSONSchema`, `validatesXPath`, `md5`, `sha1`, `sha256`, `is`, `isNot`, `lessThan`, `lessThanOrEqual`, `moreThan`, `moreThanOrEqual`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#operator SyntheticsTest#operator}
    */
    readonly operator?: string;
    /**
    * If assertion type is `header` or `grpcMetadata`, this is the header name. For other assertion types, this is an aggregation property: `avg`, `min`, `max`, or `stddev`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#property SyntheticsTest#property}
    */
    readonly property?: string;
    /**
    * Expected value. **Note:** Depends on the assertion type. Refer to `config.assertions` in the [Datadog API reference](https://docs.datadoghq.com/api/latest/synthetics/#create-an-api-test).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#target SyntheticsTest#target}
    */
    readonly target?: string;
    /**
    * Timings scope for response time assertions. Valid values are `all`, `withoutDNS`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#timings_scope SyntheticsTest#timings_scope}
    */
    readonly timingsScope?: string;
    /**
    * Type of assertion. **Note:** Only some combinations of `type` and `operator` are valid. For API tests, refer to `config.assertions` in the [Datadog API reference](https://docs.datadoghq.com/api/latest/synthetics/#create-an-api-test). For Network Path tests, refer to `config.assertions` in the [Datadog API reference](https://docs.datadoghq.com/api/latest/synthetics/#create-a-network-path-test). Valid values are `body`, `header`, `statusCode`, `certificate`, `responseTime`, `property`, `recordEvery`, `recordSome`, `tlsVersion`, `minTlsVersion`, `latency`, `packetLossPercentage`, `packetsReceived`, `networkHop`, `receivedMessage`, `grpcHealthcheckStatus`, `grpcMetadata`, `grpcProto`, `connection`, `multiNetworkHop`, `jitter`, `bodyHash`, `javascript`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#type SyntheticsTest#type}
    */
    readonly type: string;
    /**
    * targetjsonpath block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#targetjsonpath SyntheticsTest#targetjsonpath}
    */
    readonly targetjsonpath?: SyntheticsTestAssertionTargetjsonpath;
    /**
    * targetjsonschema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#targetjsonschema SyntheticsTest#targetjsonschema}
    */
    readonly targetjsonschema?: SyntheticsTestAssertionTargetjsonschema;
    /**
    * targetxpath block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#targetxpath SyntheticsTest#targetxpath}
    */
    readonly targetxpath?: SyntheticsTestAssertionTargetxpath;
}
export declare function syntheticsTestAssertionToTerraform(struct?: SyntheticsTestAssertion | cdktn.IResolvable): any;
export declare function syntheticsTestAssertionToHclTerraform(struct?: SyntheticsTestAssertion | cdktn.IResolvable): any;
export declare class SyntheticsTestAssertionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsTestAssertion | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsTestAssertion | cdktn.IResolvable | undefined);
    private _code?;
    get code(): string;
    set code(value: string);
    resetCode(): void;
    get codeInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _property?;
    get property(): string;
    set property(value: string);
    resetProperty(): void;
    get propertyInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    resetTarget(): void;
    get targetInput(): string | undefined;
    private _timingsScope?;
    get timingsScope(): string;
    set timingsScope(value: string);
    resetTimingsScope(): void;
    get timingsScopeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _targetjsonpath;
    get targetjsonpath(): SyntheticsTestAssertionTargetjsonpathOutputReference;
    putTargetjsonpath(value: SyntheticsTestAssertionTargetjsonpath): void;
    resetTargetjsonpath(): void;
    get targetjsonpathInput(): SyntheticsTestAssertionTargetjsonpath | undefined;
    private _targetjsonschema;
    get targetjsonschema(): SyntheticsTestAssertionTargetjsonschemaOutputReference;
    putTargetjsonschema(value: SyntheticsTestAssertionTargetjsonschema): void;
    resetTargetjsonschema(): void;
    get targetjsonschemaInput(): SyntheticsTestAssertionTargetjsonschema | undefined;
    private _targetxpath;
    get targetxpath(): SyntheticsTestAssertionTargetxpathOutputReference;
    putTargetxpath(value: SyntheticsTestAssertionTargetxpath): void;
    resetTargetxpath(): void;
    get targetxpathInput(): SyntheticsTestAssertionTargetxpath | undefined;
}
export declare class SyntheticsTestAssertionList extends cdktn.ComplexList {
    internalValue?: SyntheticsTestAssertion[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsTestAssertionOutputReference;
}
export interface SyntheticsTestBrowserStepParamsElementUserLocatorValue {
    /**
    * Defaults to `"css"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#type SyntheticsTest#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#value SyntheticsTest#value}
    */
    readonly value: string;
}
export declare function syntheticsTestBrowserStepParamsElementUserLocatorValueToTerraform(struct?: SyntheticsTestBrowserStepParamsElementUserLocatorValueOutputReference | SyntheticsTestBrowserStepParamsElementUserLocatorValue): any;
export declare function syntheticsTestBrowserStepParamsElementUserLocatorValueToHclTerraform(struct?: SyntheticsTestBrowserStepParamsElementUserLocatorValueOutputReference | SyntheticsTestBrowserStepParamsElementUserLocatorValue): any;
export declare class SyntheticsTestBrowserStepParamsElementUserLocatorValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestBrowserStepParamsElementUserLocatorValue | undefined;
    set internalValue(value: SyntheticsTestBrowserStepParamsElementUserLocatorValue | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export interface SyntheticsTestBrowserStepParamsElementUserLocator {
    /**
    * Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#fail_test_on_cannot_locate SyntheticsTest#fail_test_on_cannot_locate}
    */
    readonly failTestOnCannotLocate?: boolean | cdktn.IResolvable;
    /**
    * value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#value SyntheticsTest#value}
    */
    readonly value: SyntheticsTestBrowserStepParamsElementUserLocatorValue;
}
export declare function syntheticsTestBrowserStepParamsElementUserLocatorToTerraform(struct?: SyntheticsTestBrowserStepParamsElementUserLocatorOutputReference | SyntheticsTestBrowserStepParamsElementUserLocator): any;
export declare function syntheticsTestBrowserStepParamsElementUserLocatorToHclTerraform(struct?: SyntheticsTestBrowserStepParamsElementUserLocatorOutputReference | SyntheticsTestBrowserStepParamsElementUserLocator): any;
export declare class SyntheticsTestBrowserStepParamsElementUserLocatorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestBrowserStepParamsElementUserLocator | undefined;
    set internalValue(value: SyntheticsTestBrowserStepParamsElementUserLocator | undefined);
    private _failTestOnCannotLocate?;
    get failTestOnCannotLocate(): boolean | cdktn.IResolvable;
    set failTestOnCannotLocate(value: boolean | cdktn.IResolvable);
    resetFailTestOnCannotLocate(): void;
    get failTestOnCannotLocateInput(): boolean | cdktn.IResolvable | undefined;
    private _value;
    get value(): SyntheticsTestBrowserStepParamsElementUserLocatorValueOutputReference;
    putValue(value: SyntheticsTestBrowserStepParamsElementUserLocatorValue): void;
    get valueInput(): SyntheticsTestBrowserStepParamsElementUserLocatorValue | undefined;
}
export interface SyntheticsTestBrowserStepParamsPattern {
    /**
    * Type of pattern to use for the step. Valid values are `regex`, `x_path`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#type SyntheticsTest#type}
    */
    readonly type?: string;
    /**
    * Pattern to use for the step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#value SyntheticsTest#value}
    */
    readonly value?: string;
}
export declare function syntheticsTestBrowserStepParamsPatternToTerraform(struct?: SyntheticsTestBrowserStepParamsPatternOutputReference | SyntheticsTestBrowserStepParamsPattern): any;
export declare function syntheticsTestBrowserStepParamsPatternToHclTerraform(struct?: SyntheticsTestBrowserStepParamsPatternOutputReference | SyntheticsTestBrowserStepParamsPattern): any;
export declare class SyntheticsTestBrowserStepParamsPatternOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestBrowserStepParamsPattern | undefined;
    set internalValue(value: SyntheticsTestBrowserStepParamsPattern | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface SyntheticsTestBrowserStepParamsVariable {
    /**
    * Example of the extracted variable. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#example SyntheticsTest#example}
    */
    readonly example?: string;
    /**
    * Name of the extracted variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#name SyntheticsTest#name}
    */
    readonly name?: string;
    /**
    * Whether the value of this variable will be obfuscated in test results. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#secure SyntheticsTest#secure}
    */
    readonly secure?: boolean | cdktn.IResolvable;
}
export declare function syntheticsTestBrowserStepParamsVariableToTerraform(struct?: SyntheticsTestBrowserStepParamsVariableOutputReference | SyntheticsTestBrowserStepParamsVariable): any;
export declare function syntheticsTestBrowserStepParamsVariableToHclTerraform(struct?: SyntheticsTestBrowserStepParamsVariableOutputReference | SyntheticsTestBrowserStepParamsVariable): any;
export declare class SyntheticsTestBrowserStepParamsVariableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestBrowserStepParamsVariable | undefined;
    set internalValue(value: SyntheticsTestBrowserStepParamsVariable | undefined);
    private _example?;
    get example(): string;
    set example(value: string);
    resetExample(): void;
    get exampleInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _secure?;
    get secure(): boolean | cdktn.IResolvable;
    set secure(value: boolean | cdktn.IResolvable);
    resetSecure(): void;
    get secureInput(): boolean | cdktn.IResolvable | undefined;
}
export interface SyntheticsTestBrowserStepParams {
    /**
    * Whether to append the `value` to existing text input content for a "typeText" step. By default, content is cleared before text input.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#append_to_content SyntheticsTest#append_to_content}
    */
    readonly appendToContent?: boolean | cdktn.IResolvable;
    /**
    * Name of the attribute to use for an "assert attribute" step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#attribute SyntheticsTest#attribute}
    */
    readonly attribute?: string;
    /**
    * Check type to use for an assertion step. Valid values are `equals`, `notEquals`, `contains`, `notContains`, `startsWith`, `notStartsWith`, `greater`, `lower`, `greaterEquals`, `lowerEquals`, `matchRegex`, `between`, `isEmpty`, `notIsEmpty`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#check SyntheticsTest#check}
    */
    readonly check?: string;
    /**
    * Type of click to use for a "click" step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#click_type SyntheticsTest#click_type}
    */
    readonly clickType?: string;
    /**
    * Whether to use `element.click()` for a "click" step. This is a more reliable way to interact with elements but does not emulate a real user interaction.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#click_with_javascript SyntheticsTest#click_with_javascript}
    */
    readonly clickWithJavascript?: boolean | cdktn.IResolvable;
    /**
    * Javascript code to use for the step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#code SyntheticsTest#code}
    */
    readonly code?: string;
    /**
    * Delay between each key stroke for a "type test" step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#delay SyntheticsTest#delay}
    */
    readonly delay?: number;
    /**
    * Element to use for the step, JSON encoded string. Refer to the examples for a usage example showing the schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#element SyntheticsTest#element}
    */
    readonly element?: string;
    /**
    * Details of the email for an "assert email" step, JSON encoded string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#email SyntheticsTest#email}
    */
    readonly email?: string;
    /**
    * JSON encoded string used for an "assert download" step. Refer to the examples for a usage example showing the schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#file SyntheticsTest#file}
    */
    readonly file?: string;
    /**
    * Details of the files for an "upload files" step, JSON encoded string. Refer to the examples for a usage example showing the schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#files SyntheticsTest#files}
    */
    readonly files?: string;
    /**
    * Modifier to use for a "press key" step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#modifiers SyntheticsTest#modifiers}
    */
    readonly modifiers?: string[];
    /**
    * ID of the tab to play the subtest.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#playing_tab_id SyntheticsTest#playing_tab_id}
    */
    readonly playingTabId?: string;
    /**
    * Request for an API step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#request SyntheticsTest#request}
    */
    readonly request?: string;
    /**
    * Details of the requests for an "assert request" step, JSON encoded string. Refer to the examples for a usage example showing the schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#requests SyntheticsTest#requests}
    */
    readonly requests?: string;
    /**
    * ID of the Synthetics test to use as subtest.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#subtest_public_id SyntheticsTest#subtest_public_id}
    */
    readonly subtestPublicId?: string;
    /**
    * Value of the step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#value SyntheticsTest#value}
    */
    readonly value?: string;
    /**
    * For "file upload" steps.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#with_click SyntheticsTest#with_click}
    */
    readonly withClick?: boolean | cdktn.IResolvable;
    /**
    * X coordinates for a "scroll step".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#x SyntheticsTest#x}
    */
    readonly x?: number;
    /**
    * Y coordinates for a "scroll step".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#y SyntheticsTest#y}
    */
    readonly y?: number;
    /**
    * element_user_locator block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#element_user_locator SyntheticsTest#element_user_locator}
    */
    readonly elementUserLocator?: SyntheticsTestBrowserStepParamsElementUserLocator;
    /**
    * pattern block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#pattern SyntheticsTest#pattern}
    */
    readonly pattern?: SyntheticsTestBrowserStepParamsPattern;
    /**
    * variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#variable SyntheticsTest#variable}
    */
    readonly variable?: SyntheticsTestBrowserStepParamsVariable;
}
export declare function syntheticsTestBrowserStepParamsToTerraform(struct?: SyntheticsTestBrowserStepParamsOutputReference | SyntheticsTestBrowserStepParams): any;
export declare function syntheticsTestBrowserStepParamsToHclTerraform(struct?: SyntheticsTestBrowserStepParamsOutputReference | SyntheticsTestBrowserStepParams): any;
export declare class SyntheticsTestBrowserStepParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestBrowserStepParams | undefined;
    set internalValue(value: SyntheticsTestBrowserStepParams | undefined);
    private _appendToContent?;
    get appendToContent(): boolean | cdktn.IResolvable;
    set appendToContent(value: boolean | cdktn.IResolvable);
    resetAppendToContent(): void;
    get appendToContentInput(): boolean | cdktn.IResolvable | undefined;
    private _attribute?;
    get attribute(): string;
    set attribute(value: string);
    resetAttribute(): void;
    get attributeInput(): string | undefined;
    private _check?;
    get check(): string;
    set check(value: string);
    resetCheck(): void;
    get checkInput(): string | undefined;
    private _clickType?;
    get clickType(): string;
    set clickType(value: string);
    resetClickType(): void;
    get clickTypeInput(): string | undefined;
    private _clickWithJavascript?;
    get clickWithJavascript(): boolean | cdktn.IResolvable;
    set clickWithJavascript(value: boolean | cdktn.IResolvable);
    resetClickWithJavascript(): void;
    get clickWithJavascriptInput(): boolean | cdktn.IResolvable | undefined;
    private _code?;
    get code(): string;
    set code(value: string);
    resetCode(): void;
    get codeInput(): string | undefined;
    private _delay?;
    get delay(): number;
    set delay(value: number);
    resetDelay(): void;
    get delayInput(): number | undefined;
    private _element?;
    get element(): string;
    set element(value: string);
    resetElement(): void;
    get elementInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _file?;
    get file(): string;
    set file(value: string);
    resetFile(): void;
    get fileInput(): string | undefined;
    private _files?;
    get files(): string;
    set files(value: string);
    resetFiles(): void;
    get filesInput(): string | undefined;
    private _modifiers?;
    get modifiers(): string[];
    set modifiers(value: string[]);
    resetModifiers(): void;
    get modifiersInput(): string[] | undefined;
    private _playingTabId?;
    get playingTabId(): string;
    set playingTabId(value: string);
    resetPlayingTabId(): void;
    get playingTabIdInput(): string | undefined;
    private _request?;
    get request(): string;
    set request(value: string);
    resetRequest(): void;
    get requestInput(): string | undefined;
    private _requests?;
    get requests(): string;
    set requests(value: string);
    resetRequests(): void;
    get requestsInput(): string | undefined;
    private _subtestPublicId?;
    get subtestPublicId(): string;
    set subtestPublicId(value: string);
    resetSubtestPublicId(): void;
    get subtestPublicIdInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _withClick?;
    get withClick(): boolean | cdktn.IResolvable;
    set withClick(value: boolean | cdktn.IResolvable);
    resetWithClick(): void;
    get withClickInput(): boolean | cdktn.IResolvable | undefined;
    private _x?;
    get x(): number;
    set x(value: number);
    resetX(): void;
    get xInput(): number | undefined;
    private _y?;
    get y(): number;
    set y(value: number);
    resetY(): void;
    get yInput(): number | undefined;
    private _elementUserLocator;
    get elementUserLocator(): SyntheticsTestBrowserStepParamsElementUserLocatorOutputReference;
    putElementUserLocator(value: SyntheticsTestBrowserStepParamsElementUserLocator): void;
    resetElementUserLocator(): void;
    get elementUserLocatorInput(): SyntheticsTestBrowserStepParamsElementUserLocator | undefined;
    private _pattern;
    get pattern(): SyntheticsTestBrowserStepParamsPatternOutputReference;
    putPattern(value: SyntheticsTestBrowserStepParamsPattern): void;
    resetPattern(): void;
    get patternInput(): SyntheticsTestBrowserStepParamsPattern | undefined;
    private _variable;
    get variable(): SyntheticsTestBrowserStepParamsVariableOutputReference;
    putVariable(value: SyntheticsTestBrowserStepParamsVariable): void;
    resetVariable(): void;
    get variableInput(): SyntheticsTestBrowserStepParamsVariable | undefined;
}
export interface SyntheticsTestBrowserStep {
    /**
    * Determines if the step should be allowed to fail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#allow_failure SyntheticsTest#allow_failure}
    */
    readonly allowFailure?: boolean | cdktn.IResolvable;
    /**
    * Determines whether or not to always execute this step even if the previous step failed or was skipped.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#always_execute SyntheticsTest#always_execute}
    */
    readonly alwaysExecute?: boolean | cdktn.IResolvable;
    /**
    * Determines whether or not to exit the test if the step succeeds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#exit_if_succeed SyntheticsTest#exit_if_succeed}
    */
    readonly exitIfSucceed?: boolean | cdktn.IResolvable;
    /**
    * Force update of the "element" parameter for the step
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#force_element_update SyntheticsTest#force_element_update}
    */
    readonly forceElementUpdate?: boolean | cdktn.IResolvable;
    /**
    * Determines whether or not to consider the entire test as failed if this step fails. Can be used only if `allow_failure` is `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#is_critical SyntheticsTest#is_critical}
    */
    readonly isCritical?: boolean | cdktn.IResolvable;
    /**
    * A unique identifier used to track steps after reordering.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#local_key SyntheticsTest#local_key}
    */
    readonly localKey?: string;
    /**
    * Name of the step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#name SyntheticsTest#name}
    */
    readonly name: string;
    /**
    * Prevents saving screenshots of the step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#no_screenshot SyntheticsTest#no_screenshot}
    */
    readonly noScreenshot?: boolean | cdktn.IResolvable;
    /**
    * Used to override the default timeout of a step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#timeout SyntheticsTest#timeout}
    */
    readonly timeout?: number;
    /**
    * Type of the step. Valid values are `assertCurrentUrl`, `assertElementAttribute`, `assertElementContent`, `assertElementPresent`, `assertEmail`, `assertFileDownload`, `assertFromJavascript`, `assertPageContains`, `assertPageLacks`, `assertRequests`, `click`, `extractFromJavascript`, `extractFromEmailBody`, `extractVariable`, `goToEmailLink`, `goToUrl`, `goToUrlAndMeasureTti`, `hover`, `playSubTest`, `pressKey`, `refresh`, `runApiTest`, `scroll`, `selectOption`, `typeText`, `uploadFiles`, `wait`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#type SyntheticsTest#type}
    */
    readonly type: string;
    /**
    * params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#params SyntheticsTest#params}
    */
    readonly params: SyntheticsTestBrowserStepParams;
}
export declare function syntheticsTestBrowserStepToTerraform(struct?: SyntheticsTestBrowserStep | cdktn.IResolvable): any;
export declare function syntheticsTestBrowserStepToHclTerraform(struct?: SyntheticsTestBrowserStep | cdktn.IResolvable): any;
export declare class SyntheticsTestBrowserStepOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsTestBrowserStep | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsTestBrowserStep | cdktn.IResolvable | undefined);
    private _allowFailure?;
    get allowFailure(): boolean | cdktn.IResolvable;
    set allowFailure(value: boolean | cdktn.IResolvable);
    resetAllowFailure(): void;
    get allowFailureInput(): boolean | cdktn.IResolvable | undefined;
    private _alwaysExecute?;
    get alwaysExecute(): boolean | cdktn.IResolvable;
    set alwaysExecute(value: boolean | cdktn.IResolvable);
    resetAlwaysExecute(): void;
    get alwaysExecuteInput(): boolean | cdktn.IResolvable | undefined;
    private _exitIfSucceed?;
    get exitIfSucceed(): boolean | cdktn.IResolvable;
    set exitIfSucceed(value: boolean | cdktn.IResolvable);
    resetExitIfSucceed(): void;
    get exitIfSucceedInput(): boolean | cdktn.IResolvable | undefined;
    private _forceElementUpdate?;
    get forceElementUpdate(): boolean | cdktn.IResolvable;
    set forceElementUpdate(value: boolean | cdktn.IResolvable);
    resetForceElementUpdate(): void;
    get forceElementUpdateInput(): boolean | cdktn.IResolvable | undefined;
    private _isCritical?;
    get isCritical(): boolean | cdktn.IResolvable;
    set isCritical(value: boolean | cdktn.IResolvable);
    resetIsCritical(): void;
    get isCriticalInput(): boolean | cdktn.IResolvable | undefined;
    private _localKey?;
    get localKey(): string;
    set localKey(value: string);
    resetLocalKey(): void;
    get localKeyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _noScreenshot?;
    get noScreenshot(): boolean | cdktn.IResolvable;
    set noScreenshot(value: boolean | cdktn.IResolvable);
    resetNoScreenshot(): void;
    get noScreenshotInput(): boolean | cdktn.IResolvable | undefined;
    get publicId(): string;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _params;
    get params(): SyntheticsTestBrowserStepParamsOutputReference;
    putParams(value: SyntheticsTestBrowserStepParams): void;
    get paramsInput(): SyntheticsTestBrowserStepParams | undefined;
}
export declare class SyntheticsTestBrowserStepList extends cdktn.ComplexList {
    internalValue?: SyntheticsTestBrowserStep[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsTestBrowserStepOutputReference;
}
export interface SyntheticsTestBrowserVariable {
    /**
    * Example for the variable. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#example SyntheticsTest#example}
    */
    readonly example?: string;
    /**
    * ID of the global variable to use. This is actually only used (and required) in the case of using a variable of type `global`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#id SyntheticsTest#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#name SyntheticsTest#name}
    */
    readonly name: string;
    /**
    * Pattern of the variable. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#pattern SyntheticsTest#pattern}
    */
    readonly pattern?: string;
    /**
    * Determines whether or not the browser test variable is obfuscated. Can only be used with a browser variable of type `text`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#secure SyntheticsTest#secure}
    */
    readonly secure?: boolean | cdktn.IResolvable;
    /**
    * Type of browser test variable. Valid values are `element`, `email`, `global`, `text`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#type SyntheticsTest#type}
    */
    readonly type: string;
}
export declare function syntheticsTestBrowserVariableToTerraform(struct?: SyntheticsTestBrowserVariable | cdktn.IResolvable): any;
export declare function syntheticsTestBrowserVariableToHclTerraform(struct?: SyntheticsTestBrowserVariable | cdktn.IResolvable): any;
export declare class SyntheticsTestBrowserVariableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsTestBrowserVariable | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsTestBrowserVariable | cdktn.IResolvable | undefined);
    private _example?;
    get example(): string;
    set example(value: string);
    resetExample(): void;
    get exampleInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    resetPattern(): void;
    get patternInput(): string | undefined;
    private _secure?;
    get secure(): boolean | cdktn.IResolvable;
    set secure(value: boolean | cdktn.IResolvable);
    resetSecure(): void;
    get secureInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class SyntheticsTestBrowserVariableList extends cdktn.ComplexList {
    internalValue?: SyntheticsTestBrowserVariable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsTestBrowserVariableOutputReference;
}
export interface SyntheticsTestConfigVariable {
    /**
    * Example for the variable. This value is not returned by the API when `secure = true`. Avoid drift by only making updates to this value from within Terraform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#example SyntheticsTest#example}
    */
    readonly example?: string;
    /**
    * When type = `global`, ID of the global variable to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#id SyntheticsTest#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#name SyntheticsTest#name}
    */
    readonly name: string;
    /**
    * Pattern of the variable. This value is not returned by the API when `secure = true`. Avoid drift by only making updates to this value from within Terraform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#pattern SyntheticsTest#pattern}
    */
    readonly pattern?: string;
    /**
    * Whether the value of this variable will be obfuscated in test results. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#secure SyntheticsTest#secure}
    */
    readonly secure?: boolean | cdktn.IResolvable;
    /**
    * Type of test configuration variable. Valid values are `global`, `text`, `email`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#type SyntheticsTest#type}
    */
    readonly type: string;
}
export declare function syntheticsTestConfigVariableToTerraform(struct?: SyntheticsTestConfigVariable | cdktn.IResolvable): any;
export declare function syntheticsTestConfigVariableToHclTerraform(struct?: SyntheticsTestConfigVariable | cdktn.IResolvable): any;
export declare class SyntheticsTestConfigVariableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsTestConfigVariable | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsTestConfigVariable | cdktn.IResolvable | undefined);
    private _example?;
    get example(): string;
    set example(value: string);
    resetExample(): void;
    get exampleInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    resetPattern(): void;
    get patternInput(): string | undefined;
    private _secure?;
    get secure(): boolean | cdktn.IResolvable;
    set secure(value: boolean | cdktn.IResolvable);
    resetSecure(): void;
    get secureInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class SyntheticsTestConfigVariableList extends cdktn.ComplexList {
    internalValue?: SyntheticsTestConfigVariable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsTestConfigVariableOutputReference;
}
export interface SyntheticsTestMobileOptionsListBindings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#principals SyntheticsTest#principals}
    */
    readonly principals?: string[];
    /**
    * Valid values are `editor`, `viewer`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#relation SyntheticsTest#relation}
    */
    readonly relation?: string;
}
export declare function syntheticsTestMobileOptionsListBindingsToTerraform(struct?: SyntheticsTestMobileOptionsListBindings | cdktn.IResolvable): any;
export declare function syntheticsTestMobileOptionsListBindingsToHclTerraform(struct?: SyntheticsTestMobileOptionsListBindings | cdktn.IResolvable): any;
export declare class SyntheticsTestMobileOptionsListBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsTestMobileOptionsListBindings | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsTestMobileOptionsListBindings | cdktn.IResolvable | undefined);
    private _principals?;
    get principals(): string[];
    set principals(value: string[]);
    resetPrincipals(): void;
    get principalsInput(): string[] | undefined;
    private _relation?;
    get relation(): string;
    set relation(value: string);
    resetRelation(): void;
    get relationInput(): string | undefined;
}
export declare class SyntheticsTestMobileOptionsListBindingsList extends cdktn.ComplexList {
    internalValue?: SyntheticsTestMobileOptionsListBindings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsTestMobileOptionsListBindingsOutputReference;
}
export interface SyntheticsTestMobileOptionsListCi {
    /**
    * Execution rule for a Synthetics test. Valid values are `blocking`, `non_blocking`, `skipped`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#execution_rule SyntheticsTest#execution_rule}
    */
    readonly executionRule: string;
}
export declare function syntheticsTestMobileOptionsListCiToTerraform(struct?: SyntheticsTestMobileOptionsListCiOutputReference | SyntheticsTestMobileOptionsListCi): any;
export declare function syntheticsTestMobileOptionsListCiToHclTerraform(struct?: SyntheticsTestMobileOptionsListCiOutputReference | SyntheticsTestMobileOptionsListCi): any;
export declare class SyntheticsTestMobileOptionsListCiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestMobileOptionsListCi | undefined;
    set internalValue(value: SyntheticsTestMobileOptionsListCi | undefined);
    private _executionRule?;
    get executionRule(): string;
    set executionRule(value: string);
    get executionRuleInput(): string | undefined;
}
export interface SyntheticsTestMobileOptionsListMobileApplication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#application_id SyntheticsTest#application_id}
    */
    readonly applicationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#reference_id SyntheticsTest#reference_id}
    */
    readonly referenceId: string;
    /**
    * Valid values are `latest`, `version`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#reference_type SyntheticsTest#reference_type}
    */
    readonly referenceType: string;
}
export declare function syntheticsTestMobileOptionsListMobileApplicationToTerraform(struct?: SyntheticsTestMobileOptionsListMobileApplicationOutputReference | SyntheticsTestMobileOptionsListMobileApplication): any;
export declare function syntheticsTestMobileOptionsListMobileApplicationToHclTerraform(struct?: SyntheticsTestMobileOptionsListMobileApplicationOutputReference | SyntheticsTestMobileOptionsListMobileApplication): any;
export declare class SyntheticsTestMobileOptionsListMobileApplicationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestMobileOptionsListMobileApplication | undefined;
    set internalValue(value: SyntheticsTestMobileOptionsListMobileApplication | undefined);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _referenceId?;
    get referenceId(): string;
    set referenceId(value: string);
    get referenceIdInput(): string | undefined;
    private _referenceType?;
    get referenceType(): string;
    set referenceType(value: string);
    get referenceTypeInput(): string | undefined;
}
export interface SyntheticsTestMobileOptionsListMonitorOptions {
    /**
    * A message to include with a re-notification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#escalation_message SyntheticsTest#escalation_message}
    */
    readonly escalationMessage?: string;
    /**
    * The name of the preset for the notification for the monitor. Valid values are `show_all`, `hide_all`, `hide_query`, `hide_handles`, `hide_query_and_handles`, `show_only_snapshot`, `hide_handles_and_footer`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#notification_preset_name SyntheticsTest#notification_preset_name}
    */
    readonly notificationPresetName?: string;
    /**
    * Specify a renotification frequency in minutes. Values available by default are `0`, `10`, `20`, `30`, `40`, `50`, `60`, `90`, `120`, `180`, `240`, `300`, `360`, `720`, `1440`. Defaults to `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#renotify_interval SyntheticsTest#renotify_interval}
    */
    readonly renotifyInterval?: number;
    /**
    * The number of times a monitor renotifies. It can only be set if `renotify_interval` is set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#renotify_occurrences SyntheticsTest#renotify_occurrences}
    */
    readonly renotifyOccurrences?: number;
}
export declare function syntheticsTestMobileOptionsListMonitorOptionsToTerraform(struct?: SyntheticsTestMobileOptionsListMonitorOptionsOutputReference | SyntheticsTestMobileOptionsListMonitorOptions): any;
export declare function syntheticsTestMobileOptionsListMonitorOptionsToHclTerraform(struct?: SyntheticsTestMobileOptionsListMonitorOptionsOutputReference | SyntheticsTestMobileOptionsListMonitorOptions): any;
export declare class SyntheticsTestMobileOptionsListMonitorOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestMobileOptionsListMonitorOptions | undefined;
    set internalValue(value: SyntheticsTestMobileOptionsListMonitorOptions | undefined);
    private _escalationMessage?;
    get escalationMessage(): string;
    set escalationMessage(value: string);
    resetEscalationMessage(): void;
    get escalationMessageInput(): string | undefined;
    private _notificationPresetName?;
    get notificationPresetName(): string;
    set notificationPresetName(value: string);
    resetNotificationPresetName(): void;
    get notificationPresetNameInput(): string | undefined;
    private _renotifyInterval?;
    get renotifyInterval(): number;
    set renotifyInterval(value: number);
    resetRenotifyInterval(): void;
    get renotifyIntervalInput(): number | undefined;
    private _renotifyOccurrences?;
    get renotifyOccurrences(): number;
    set renotifyOccurrences(value: number);
    resetRenotifyOccurrences(): void;
    get renotifyOccurrencesInput(): number | undefined;
}
export interface SyntheticsTestMobileOptionsListRetry {
    /**
    * Number of retries needed to consider a location as failed before sending a notification alert. Maximum value: `3` for `api` tests, `2` for `browser` and `mobile` tests. Defaults to `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#count SyntheticsTest#count}
    */
    readonly count?: number;
    /**
    * Interval between a failed test and the next retry in milliseconds. Maximum value: `5000`. Defaults to `300`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#interval SyntheticsTest#interval}
    */
    readonly interval?: number;
}
export declare function syntheticsTestMobileOptionsListRetryToTerraform(struct?: SyntheticsTestMobileOptionsListRetryOutputReference | SyntheticsTestMobileOptionsListRetry): any;
export declare function syntheticsTestMobileOptionsListRetryToHclTerraform(struct?: SyntheticsTestMobileOptionsListRetryOutputReference | SyntheticsTestMobileOptionsListRetry): any;
export declare class SyntheticsTestMobileOptionsListRetryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestMobileOptionsListRetry | undefined;
    set internalValue(value: SyntheticsTestMobileOptionsListRetry | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    resetCount(): void;
    get countInput(): number | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface SyntheticsTestMobileOptionsListSchedulingTimeframes {
    /**
    * Number representing the day of the week
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#day SyntheticsTest#day}
    */
    readonly day: number;
    /**
    * The hour of the day on which scheduling starts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#from SyntheticsTest#from}
    */
    readonly from: string;
    /**
    * The hour of the day on which scheduling ends.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#to SyntheticsTest#to}
    */
    readonly to: string;
}
export declare function syntheticsTestMobileOptionsListSchedulingTimeframesToTerraform(struct?: SyntheticsTestMobileOptionsListSchedulingTimeframes | cdktn.IResolvable): any;
export declare function syntheticsTestMobileOptionsListSchedulingTimeframesToHclTerraform(struct?: SyntheticsTestMobileOptionsListSchedulingTimeframes | cdktn.IResolvable): any;
export declare class SyntheticsTestMobileOptionsListSchedulingTimeframesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsTestMobileOptionsListSchedulingTimeframes | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsTestMobileOptionsListSchedulingTimeframes | cdktn.IResolvable | undefined);
    private _day?;
    get day(): number;
    set day(value: number);
    get dayInput(): number | undefined;
    private _from?;
    get from(): string;
    set from(value: string);
    get fromInput(): string | undefined;
    private _to?;
    get to(): string;
    set to(value: string);
    get toInput(): string | undefined;
}
export declare class SyntheticsTestMobileOptionsListSchedulingTimeframesList extends cdktn.ComplexList {
    internalValue?: SyntheticsTestMobileOptionsListSchedulingTimeframes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsTestMobileOptionsListSchedulingTimeframesOutputReference;
}
export interface SyntheticsTestMobileOptionsListScheduling {
    /**
    * Timezone in which the timeframe is based.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#timezone SyntheticsTest#timezone}
    */
    readonly timezone: string;
    /**
    * timeframes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#timeframes SyntheticsTest#timeframes}
    */
    readonly timeframes: SyntheticsTestMobileOptionsListSchedulingTimeframes[] | cdktn.IResolvable;
}
export declare function syntheticsTestMobileOptionsListSchedulingToTerraform(struct?: SyntheticsTestMobileOptionsListSchedulingOutputReference | SyntheticsTestMobileOptionsListScheduling): any;
export declare function syntheticsTestMobileOptionsListSchedulingToHclTerraform(struct?: SyntheticsTestMobileOptionsListSchedulingOutputReference | SyntheticsTestMobileOptionsListScheduling): any;
export declare class SyntheticsTestMobileOptionsListSchedulingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestMobileOptionsListScheduling | undefined;
    set internalValue(value: SyntheticsTestMobileOptionsListScheduling | undefined);
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    get timezoneInput(): string | undefined;
    private _timeframes;
    get timeframes(): SyntheticsTestMobileOptionsListSchedulingTimeframesList;
    putTimeframes(value: SyntheticsTestMobileOptionsListSchedulingTimeframes[] | cdktn.IResolvable): void;
    get timeframesInput(): cdktn.IResolvable | SyntheticsTestMobileOptionsListSchedulingTimeframes[] | undefined;
}
export interface SyntheticsTestMobileOptionsListStruct {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#allow_application_crash SyntheticsTest#allow_application_crash}
    */
    readonly allowApplicationCrash?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#default_step_timeout SyntheticsTest#default_step_timeout}
    */
    readonly defaultStepTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#device_ids SyntheticsTest#device_ids}
    */
    readonly deviceIds: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#disable_auto_accept_alert SyntheticsTest#disable_auto_accept_alert}
    */
    readonly disableAutoAcceptAlert?: boolean | cdktn.IResolvable;
    /**
    * Minimum amount of time in failure required to trigger an alert (in seconds). Default is `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#min_failure_duration SyntheticsTest#min_failure_duration}
    */
    readonly minFailureDuration?: number;
    /**
    * The monitor name is used for the alert title as well as for all monitor dashboard widgets and SLOs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#monitor_name SyntheticsTest#monitor_name}
    */
    readonly monitorName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#monitor_priority SyntheticsTest#monitor_priority}
    */
    readonly monitorPriority?: number;
    /**
    * Prevents saving screenshots of the steps.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#no_screenshot SyntheticsTest#no_screenshot}
    */
    readonly noScreenshot?: boolean | cdktn.IResolvable;
    /**
    * A list of role identifiers pulled from the Roles API to restrict read and write access. **Deprecated.** This field is no longer supported by the Datadog API. Please use `datadog_restriction_policy` instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#restricted_roles SyntheticsTest#restricted_roles}
    */
    readonly restrictedRoles?: string[];
    /**
    * How often the test should run (in seconds). Valid range is `300-604800` for mobile tests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#tick_every SyntheticsTest#tick_every}
    */
    readonly tickEvery: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#verbosity SyntheticsTest#verbosity}
    */
    readonly verbosity?: number;
    /**
    * bindings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#bindings SyntheticsTest#bindings}
    */
    readonly bindings?: SyntheticsTestMobileOptionsListBindings[] | cdktn.IResolvable;
    /**
    * ci block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#ci SyntheticsTest#ci}
    */
    readonly ci?: SyntheticsTestMobileOptionsListCi;
    /**
    * mobile_application block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#mobile_application SyntheticsTest#mobile_application}
    */
    readonly mobileApplication: SyntheticsTestMobileOptionsListMobileApplication;
    /**
    * monitor_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#monitor_options SyntheticsTest#monitor_options}
    */
    readonly monitorOptions?: SyntheticsTestMobileOptionsListMonitorOptions;
    /**
    * retry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#retry SyntheticsTest#retry}
    */
    readonly retry?: SyntheticsTestMobileOptionsListRetry;
    /**
    * scheduling block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#scheduling SyntheticsTest#scheduling}
    */
    readonly scheduling?: SyntheticsTestMobileOptionsListScheduling;
}
export declare function syntheticsTestMobileOptionsListStructToTerraform(struct?: SyntheticsTestMobileOptionsListStructOutputReference | SyntheticsTestMobileOptionsListStruct): any;
export declare function syntheticsTestMobileOptionsListStructToHclTerraform(struct?: SyntheticsTestMobileOptionsListStructOutputReference | SyntheticsTestMobileOptionsListStruct): any;
export declare class SyntheticsTestMobileOptionsListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestMobileOptionsListStruct | undefined;
    set internalValue(value: SyntheticsTestMobileOptionsListStruct | undefined);
    private _allowApplicationCrash?;
    get allowApplicationCrash(): boolean | cdktn.IResolvable;
    set allowApplicationCrash(value: boolean | cdktn.IResolvable);
    resetAllowApplicationCrash(): void;
    get allowApplicationCrashInput(): boolean | cdktn.IResolvable | undefined;
    private _defaultStepTimeout?;
    get defaultStepTimeout(): number;
    set defaultStepTimeout(value: number);
    resetDefaultStepTimeout(): void;
    get defaultStepTimeoutInput(): number | undefined;
    private _deviceIds?;
    get deviceIds(): string[];
    set deviceIds(value: string[]);
    get deviceIdsInput(): string[] | undefined;
    private _disableAutoAcceptAlert?;
    get disableAutoAcceptAlert(): boolean | cdktn.IResolvable;
    set disableAutoAcceptAlert(value: boolean | cdktn.IResolvable);
    resetDisableAutoAcceptAlert(): void;
    get disableAutoAcceptAlertInput(): boolean | cdktn.IResolvable | undefined;
    private _minFailureDuration?;
    get minFailureDuration(): number;
    set minFailureDuration(value: number);
    resetMinFailureDuration(): void;
    get minFailureDurationInput(): number | undefined;
    private _monitorName?;
    get monitorName(): string;
    set monitorName(value: string);
    resetMonitorName(): void;
    get monitorNameInput(): string | undefined;
    private _monitorPriority?;
    get monitorPriority(): number;
    set monitorPriority(value: number);
    resetMonitorPriority(): void;
    get monitorPriorityInput(): number | undefined;
    private _noScreenshot?;
    get noScreenshot(): boolean | cdktn.IResolvable;
    set noScreenshot(value: boolean | cdktn.IResolvable);
    resetNoScreenshot(): void;
    get noScreenshotInput(): boolean | cdktn.IResolvable | undefined;
    private _restrictedRoles?;
    get restrictedRoles(): string[];
    set restrictedRoles(value: string[]);
    resetRestrictedRoles(): void;
    get restrictedRolesInput(): string[] | undefined;
    private _tickEvery?;
    get tickEvery(): number;
    set tickEvery(value: number);
    get tickEveryInput(): number | undefined;
    private _verbosity?;
    get verbosity(): number;
    set verbosity(value: number);
    resetVerbosity(): void;
    get verbosityInput(): number | undefined;
    private _bindings;
    get bindings(): SyntheticsTestMobileOptionsListBindingsList;
    putBindings(value: SyntheticsTestMobileOptionsListBindings[] | cdktn.IResolvable): void;
    resetBindings(): void;
    get bindingsInput(): cdktn.IResolvable | SyntheticsTestMobileOptionsListBindings[] | undefined;
    private _ci;
    get ci(): SyntheticsTestMobileOptionsListCiOutputReference;
    putCi(value: SyntheticsTestMobileOptionsListCi): void;
    resetCi(): void;
    get ciInput(): SyntheticsTestMobileOptionsListCi | undefined;
    private _mobileApplication;
    get mobileApplication(): SyntheticsTestMobileOptionsListMobileApplicationOutputReference;
    putMobileApplication(value: SyntheticsTestMobileOptionsListMobileApplication): void;
    get mobileApplicationInput(): SyntheticsTestMobileOptionsListMobileApplication | undefined;
    private _monitorOptions;
    get monitorOptions(): SyntheticsTestMobileOptionsListMonitorOptionsOutputReference;
    putMonitorOptions(value: SyntheticsTestMobileOptionsListMonitorOptions): void;
    resetMonitorOptions(): void;
    get monitorOptionsInput(): SyntheticsTestMobileOptionsListMonitorOptions | undefined;
    private _retry;
    get retry(): SyntheticsTestMobileOptionsListRetryOutputReference;
    putRetry(value: SyntheticsTestMobileOptionsListRetry): void;
    resetRetry(): void;
    get retryInput(): SyntheticsTestMobileOptionsListRetry | undefined;
    private _scheduling;
    get scheduling(): SyntheticsTestMobileOptionsListSchedulingOutputReference;
    putScheduling(value: SyntheticsTestMobileOptionsListScheduling): void;
    resetScheduling(): void;
    get schedulingInput(): SyntheticsTestMobileOptionsListScheduling | undefined;
}
export interface SyntheticsTestMobileStepParamsElementRelativePosition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#x SyntheticsTest#x}
    */
    readonly x?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#y SyntheticsTest#y}
    */
    readonly y?: number;
}
export declare function syntheticsTestMobileStepParamsElementRelativePositionToTerraform(struct?: SyntheticsTestMobileStepParamsElementRelativePositionOutputReference | SyntheticsTestMobileStepParamsElementRelativePosition): any;
export declare function syntheticsTestMobileStepParamsElementRelativePositionToHclTerraform(struct?: SyntheticsTestMobileStepParamsElementRelativePositionOutputReference | SyntheticsTestMobileStepParamsElementRelativePosition): any;
export declare class SyntheticsTestMobileStepParamsElementRelativePositionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestMobileStepParamsElementRelativePosition | undefined;
    set internalValue(value: SyntheticsTestMobileStepParamsElementRelativePosition | undefined);
    private _x?;
    get x(): number;
    set x(value: number);
    resetX(): void;
    get xInput(): number | undefined;
    private _y?;
    get y(): number;
    set y(value: number);
    resetY(): void;
    get yInput(): number | undefined;
}
export interface SyntheticsTestMobileStepParamsElementUserLocatorValues {
    /**
    * Valid values are `accessibility-id`, `id`, `ios-predicate-string`, `ios-class-chain`, `xpath`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#type SyntheticsTest#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#value SyntheticsTest#value}
    */
    readonly value?: string;
}
export declare function syntheticsTestMobileStepParamsElementUserLocatorValuesToTerraform(struct?: SyntheticsTestMobileStepParamsElementUserLocatorValues | cdktn.IResolvable): any;
export declare function syntheticsTestMobileStepParamsElementUserLocatorValuesToHclTerraform(struct?: SyntheticsTestMobileStepParamsElementUserLocatorValues | cdktn.IResolvable): any;
export declare class SyntheticsTestMobileStepParamsElementUserLocatorValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsTestMobileStepParamsElementUserLocatorValues | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsTestMobileStepParamsElementUserLocatorValues | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class SyntheticsTestMobileStepParamsElementUserLocatorValuesList extends cdktn.ComplexList {
    internalValue?: SyntheticsTestMobileStepParamsElementUserLocatorValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsTestMobileStepParamsElementUserLocatorValuesOutputReference;
}
export interface SyntheticsTestMobileStepParamsElementUserLocator {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#fail_test_on_cannot_locate SyntheticsTest#fail_test_on_cannot_locate}
    */
    readonly failTestOnCannotLocate?: boolean | cdktn.IResolvable;
    /**
    * values block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#values SyntheticsTest#values}
    */
    readonly values?: SyntheticsTestMobileStepParamsElementUserLocatorValues[] | cdktn.IResolvable;
}
export declare function syntheticsTestMobileStepParamsElementUserLocatorToTerraform(struct?: SyntheticsTestMobileStepParamsElementUserLocatorOutputReference | SyntheticsTestMobileStepParamsElementUserLocator): any;
export declare function syntheticsTestMobileStepParamsElementUserLocatorToHclTerraform(struct?: SyntheticsTestMobileStepParamsElementUserLocatorOutputReference | SyntheticsTestMobileStepParamsElementUserLocator): any;
export declare class SyntheticsTestMobileStepParamsElementUserLocatorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestMobileStepParamsElementUserLocator | undefined;
    set internalValue(value: SyntheticsTestMobileStepParamsElementUserLocator | undefined);
    private _failTestOnCannotLocate?;
    get failTestOnCannotLocate(): boolean | cdktn.IResolvable;
    set failTestOnCannotLocate(value: boolean | cdktn.IResolvable);
    resetFailTestOnCannotLocate(): void;
    get failTestOnCannotLocateInput(): boolean | cdktn.IResolvable | undefined;
    private _values;
    get values(): SyntheticsTestMobileStepParamsElementUserLocatorValuesList;
    putValues(value: SyntheticsTestMobileStepParamsElementUserLocatorValues[] | cdktn.IResolvable): void;
    resetValues(): void;
    get valuesInput(): cdktn.IResolvable | SyntheticsTestMobileStepParamsElementUserLocatorValues[] | undefined;
}
export interface SyntheticsTestMobileStepParamsElement {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#context SyntheticsTest#context}
    */
    readonly context?: string;
    /**
    * Valid values are `native`, `web`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#context_type SyntheticsTest#context_type}
    */
    readonly contextType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#element_description SyntheticsTest#element_description}
    */
    readonly elementDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#multi_locator SyntheticsTest#multi_locator}
    */
    readonly multiLocator?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#text_content SyntheticsTest#text_content}
    */
    readonly textContent?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#view_name SyntheticsTest#view_name}
    */
    readonly viewName?: string;
    /**
    * relative_position block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#relative_position SyntheticsTest#relative_position}
    */
    readonly relativePosition?: SyntheticsTestMobileStepParamsElementRelativePosition;
    /**
    * user_locator block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#user_locator SyntheticsTest#user_locator}
    */
    readonly userLocator?: SyntheticsTestMobileStepParamsElementUserLocator;
}
export declare function syntheticsTestMobileStepParamsElementToTerraform(struct?: SyntheticsTestMobileStepParamsElementOutputReference | SyntheticsTestMobileStepParamsElement): any;
export declare function syntheticsTestMobileStepParamsElementToHclTerraform(struct?: SyntheticsTestMobileStepParamsElementOutputReference | SyntheticsTestMobileStepParamsElement): any;
export declare class SyntheticsTestMobileStepParamsElementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestMobileStepParamsElement | undefined;
    set internalValue(value: SyntheticsTestMobileStepParamsElement | undefined);
    private _context?;
    get context(): string;
    set context(value: string);
    resetContext(): void;
    get contextInput(): string | undefined;
    private _contextType?;
    get contextType(): string;
    set contextType(value: string);
    resetContextType(): void;
    get contextTypeInput(): string | undefined;
    private _elementDescription?;
    get elementDescription(): string;
    set elementDescription(value: string);
    resetElementDescription(): void;
    get elementDescriptionInput(): string | undefined;
    private _multiLocator?;
    get multiLocator(): {
        [key: string]: string;
    };
    set multiLocator(value: {
        [key: string]: string;
    });
    resetMultiLocator(): void;
    get multiLocatorInput(): {
        [key: string]: string;
    } | undefined;
    private _textContent?;
    get textContent(): string;
    set textContent(value: string);
    resetTextContent(): void;
    get textContentInput(): string | undefined;
    private _viewName?;
    get viewName(): string;
    set viewName(value: string);
    resetViewName(): void;
    get viewNameInput(): string | undefined;
    private _relativePosition;
    get relativePosition(): SyntheticsTestMobileStepParamsElementRelativePositionOutputReference;
    putRelativePosition(value: SyntheticsTestMobileStepParamsElementRelativePosition): void;
    resetRelativePosition(): void;
    get relativePositionInput(): SyntheticsTestMobileStepParamsElementRelativePosition | undefined;
    private _userLocator;
    get userLocator(): SyntheticsTestMobileStepParamsElementUserLocatorOutputReference;
    putUserLocator(value: SyntheticsTestMobileStepParamsElementUserLocator): void;
    resetUserLocator(): void;
    get userLocatorInput(): SyntheticsTestMobileStepParamsElementUserLocator | undefined;
}
export interface SyntheticsTestMobileStepParamsPositions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#x SyntheticsTest#x}
    */
    readonly x?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#y SyntheticsTest#y}
    */
    readonly y?: number;
}
export declare function syntheticsTestMobileStepParamsPositionsToTerraform(struct?: SyntheticsTestMobileStepParamsPositions | cdktn.IResolvable): any;
export declare function syntheticsTestMobileStepParamsPositionsToHclTerraform(struct?: SyntheticsTestMobileStepParamsPositions | cdktn.IResolvable): any;
export declare class SyntheticsTestMobileStepParamsPositionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsTestMobileStepParamsPositions | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsTestMobileStepParamsPositions | cdktn.IResolvable | undefined);
    private _x?;
    get x(): number;
    set x(value: number);
    resetX(): void;
    get xInput(): number | undefined;
    private _y?;
    get y(): number;
    set y(value: number);
    resetY(): void;
    get yInput(): number | undefined;
}
export declare class SyntheticsTestMobileStepParamsPositionsList extends cdktn.ComplexList {
    internalValue?: SyntheticsTestMobileStepParamsPositions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsTestMobileStepParamsPositionsOutputReference;
}
export interface SyntheticsTestMobileStepParamsVariable {
    /**
    * Example of the extracted variable. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#example SyntheticsTest#example}
    */
    readonly example?: string;
    /**
    * Name of the extracted variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#name SyntheticsTest#name}
    */
    readonly name: string;
}
export declare function syntheticsTestMobileStepParamsVariableToTerraform(struct?: SyntheticsTestMobileStepParamsVariableOutputReference | SyntheticsTestMobileStepParamsVariable): any;
export declare function syntheticsTestMobileStepParamsVariableToHclTerraform(struct?: SyntheticsTestMobileStepParamsVariableOutputReference | SyntheticsTestMobileStepParamsVariable): any;
export declare class SyntheticsTestMobileStepParamsVariableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestMobileStepParamsVariable | undefined;
    set internalValue(value: SyntheticsTestMobileStepParamsVariable | undefined);
    private _example?;
    get example(): string;
    set example(value: string);
    resetExample(): void;
    get exampleInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface SyntheticsTestMobileStepParams {
    /**
    * Check type to use for an assertion step. Valid values are `equals`, `notEquals`, `contains`, `notContains`, `startsWith`, `notStartsWith`, `greater`, `lower`, `greaterEquals`, `lowerEquals`, `matchRegex`, `between`, `isEmpty`, `notIsEmpty`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#check SyntheticsTest#check}
    */
    readonly check?: string;
    /**
    * Delay between each key stroke for a "type test" step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#delay SyntheticsTest#delay}
    */
    readonly delay?: number;
    /**
    * Valid values are `up`, `down`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#direction SyntheticsTest#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#enable SyntheticsTest#enable}
    */
    readonly enable?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#max_scrolls SyntheticsTest#max_scrolls}
    */
    readonly maxScrolls?: number;
    /**
    * ID of the Synthetics test to use as subtest.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#subtest_public_id SyntheticsTest#subtest_public_id}
    */
    readonly subtestPublicId?: string;
    /**
    * Value of the step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#value SyntheticsTest#value}
    */
    readonly value?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#with_enter SyntheticsTest#with_enter}
    */
    readonly withEnter?: boolean | cdktn.IResolvable;
    /**
    * X coordinates for a "scroll step".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#x SyntheticsTest#x}
    */
    readonly x?: number;
    /**
    * Y coordinates for a "scroll step".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#y SyntheticsTest#y}
    */
    readonly y?: number;
    /**
    * element block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#element SyntheticsTest#element}
    */
    readonly element?: SyntheticsTestMobileStepParamsElement;
    /**
    * positions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#positions SyntheticsTest#positions}
    */
    readonly positions?: SyntheticsTestMobileStepParamsPositions[] | cdktn.IResolvable;
    /**
    * variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#variable SyntheticsTest#variable}
    */
    readonly variable?: SyntheticsTestMobileStepParamsVariable;
}
export declare function syntheticsTestMobileStepParamsToTerraform(struct?: SyntheticsTestMobileStepParamsOutputReference | SyntheticsTestMobileStepParams): any;
export declare function syntheticsTestMobileStepParamsToHclTerraform(struct?: SyntheticsTestMobileStepParamsOutputReference | SyntheticsTestMobileStepParams): any;
export declare class SyntheticsTestMobileStepParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestMobileStepParams | undefined;
    set internalValue(value: SyntheticsTestMobileStepParams | undefined);
    private _check?;
    get check(): string;
    set check(value: string);
    resetCheck(): void;
    get checkInput(): string | undefined;
    private _delay?;
    get delay(): number;
    set delay(value: number);
    resetDelay(): void;
    get delayInput(): number | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _enable?;
    get enable(): boolean | cdktn.IResolvable;
    set enable(value: boolean | cdktn.IResolvable);
    resetEnable(): void;
    get enableInput(): boolean | cdktn.IResolvable | undefined;
    private _maxScrolls?;
    get maxScrolls(): number;
    set maxScrolls(value: number);
    resetMaxScrolls(): void;
    get maxScrollsInput(): number | undefined;
    private _subtestPublicId?;
    get subtestPublicId(): string;
    set subtestPublicId(value: string);
    resetSubtestPublicId(): void;
    get subtestPublicIdInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _withEnter?;
    get withEnter(): boolean | cdktn.IResolvable;
    set withEnter(value: boolean | cdktn.IResolvable);
    resetWithEnter(): void;
    get withEnterInput(): boolean | cdktn.IResolvable | undefined;
    private _x?;
    get x(): number;
    set x(value: number);
    resetX(): void;
    get xInput(): number | undefined;
    private _y?;
    get y(): number;
    set y(value: number);
    resetY(): void;
    get yInput(): number | undefined;
    private _element;
    get element(): SyntheticsTestMobileStepParamsElementOutputReference;
    putElement(value: SyntheticsTestMobileStepParamsElement): void;
    resetElement(): void;
    get elementInput(): SyntheticsTestMobileStepParamsElement | undefined;
    private _positions;
    get positions(): SyntheticsTestMobileStepParamsPositionsList;
    putPositions(value: SyntheticsTestMobileStepParamsPositions[] | cdktn.IResolvable): void;
    resetPositions(): void;
    get positionsInput(): cdktn.IResolvable | SyntheticsTestMobileStepParamsPositions[] | undefined;
    private _variable;
    get variable(): SyntheticsTestMobileStepParamsVariableOutputReference;
    putVariable(value: SyntheticsTestMobileStepParamsVariable): void;
    resetVariable(): void;
    get variableInput(): SyntheticsTestMobileStepParamsVariable | undefined;
}
export interface SyntheticsTestMobileStep {
    /**
    * A boolean set to allow this step to fail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#allow_failure SyntheticsTest#allow_failure}
    */
    readonly allowFailure?: boolean | cdktn.IResolvable;
    /**
    * A boolean set to determine if the step has a new step element.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#has_new_step_element SyntheticsTest#has_new_step_element}
    */
    readonly hasNewStepElement?: boolean | cdktn.IResolvable;
    /**
    * A boolean to use in addition to `allowFailure` to determine if the test should be marked as failed when the step fails.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#is_critical SyntheticsTest#is_critical}
    */
    readonly isCritical?: boolean | cdktn.IResolvable;
    /**
    * The name of the step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#name SyntheticsTest#name}
    */
    readonly name: string;
    /**
    * A boolean set to not take a screenshot for the step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#no_screenshot SyntheticsTest#no_screenshot}
    */
    readonly noScreenshot?: boolean | cdktn.IResolvable;
    /**
    * The public ID of the step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#public_id SyntheticsTest#public_id}
    */
    readonly publicId?: string;
    /**
    * The time before declaring a step failed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#timeout SyntheticsTest#timeout}
    */
    readonly timeout?: number;
    /**
    * The type of the step. Valid values are `assertElementContent`, `assertScreenContains`, `assertScreenLacks`, `doubleTap`, `extractVariable`, `flick`, `openDeeplink`, `playSubTest`, `pressBack`, `restartApplication`, `rotate`, `scroll`, `scrollToElement`, `tap`, `toggleWiFi`, `typeText`, `wait`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#type SyntheticsTest#type}
    */
    readonly type: string;
    /**
    * params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#params SyntheticsTest#params}
    */
    readonly params: SyntheticsTestMobileStepParams;
}
export declare function syntheticsTestMobileStepToTerraform(struct?: SyntheticsTestMobileStep | cdktn.IResolvable): any;
export declare function syntheticsTestMobileStepToHclTerraform(struct?: SyntheticsTestMobileStep | cdktn.IResolvable): any;
export declare class SyntheticsTestMobileStepOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsTestMobileStep | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsTestMobileStep | cdktn.IResolvable | undefined);
    private _allowFailure?;
    get allowFailure(): boolean | cdktn.IResolvable;
    set allowFailure(value: boolean | cdktn.IResolvable);
    resetAllowFailure(): void;
    get allowFailureInput(): boolean | cdktn.IResolvable | undefined;
    private _hasNewStepElement?;
    get hasNewStepElement(): boolean | cdktn.IResolvable;
    set hasNewStepElement(value: boolean | cdktn.IResolvable);
    resetHasNewStepElement(): void;
    get hasNewStepElementInput(): boolean | cdktn.IResolvable | undefined;
    private _isCritical?;
    get isCritical(): boolean | cdktn.IResolvable;
    set isCritical(value: boolean | cdktn.IResolvable);
    resetIsCritical(): void;
    get isCriticalInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _noScreenshot?;
    get noScreenshot(): boolean | cdktn.IResolvable;
    set noScreenshot(value: boolean | cdktn.IResolvable);
    resetNoScreenshot(): void;
    get noScreenshotInput(): boolean | cdktn.IResolvable | undefined;
    private _publicId?;
    get publicId(): string;
    set publicId(value: string);
    resetPublicId(): void;
    get publicIdInput(): string | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _params;
    get params(): SyntheticsTestMobileStepParamsOutputReference;
    putParams(value: SyntheticsTestMobileStepParams): void;
    get paramsInput(): SyntheticsTestMobileStepParams | undefined;
}
export declare class SyntheticsTestMobileStepList extends cdktn.ComplexList {
    internalValue?: SyntheticsTestMobileStep[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsTestMobileStepOutputReference;
}
export interface SyntheticsTestOptionsListCi {
    /**
    * Execution rule for a Synthetics test. Valid values are `blocking`, `non_blocking`, `skipped`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#execution_rule SyntheticsTest#execution_rule}
    */
    readonly executionRule?: string;
}
export declare function syntheticsTestOptionsListCiToTerraform(struct?: SyntheticsTestOptionsListCiOutputReference | SyntheticsTestOptionsListCi): any;
export declare function syntheticsTestOptionsListCiToHclTerraform(struct?: SyntheticsTestOptionsListCiOutputReference | SyntheticsTestOptionsListCi): any;
export declare class SyntheticsTestOptionsListCiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestOptionsListCi | undefined;
    set internalValue(value: SyntheticsTestOptionsListCi | undefined);
    private _executionRule?;
    get executionRule(): string;
    set executionRule(value: string);
    resetExecutionRule(): void;
    get executionRuleInput(): string | undefined;
}
export interface SyntheticsTestOptionsListMonitorOptions {
    /**
    * A message to include with a re-notification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#escalation_message SyntheticsTest#escalation_message}
    */
    readonly escalationMessage?: string;
    /**
    * The name of the preset for the notification for the monitor. Valid values are `show_all`, `hide_all`, `hide_query`, `hide_handles`, `hide_query_and_handles`, `show_only_snapshot`, `hide_handles_and_footer`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#notification_preset_name SyntheticsTest#notification_preset_name}
    */
    readonly notificationPresetName?: string;
    /**
    * Specify a renotification frequency in minutes. Values available by default are `0`, `10`, `20`, `30`, `40`, `50`, `60`, `90`, `120`, `180`, `240`, `300`, `360`, `720`, `1440`. Defaults to `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#renotify_interval SyntheticsTest#renotify_interval}
    */
    readonly renotifyInterval?: number;
    /**
    * The number of times a monitor renotifies. It can only be set if `renotify_interval` is set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#renotify_occurrences SyntheticsTest#renotify_occurrences}
    */
    readonly renotifyOccurrences?: number;
}
export declare function syntheticsTestOptionsListMonitorOptionsToTerraform(struct?: SyntheticsTestOptionsListMonitorOptionsOutputReference | SyntheticsTestOptionsListMonitorOptions): any;
export declare function syntheticsTestOptionsListMonitorOptionsToHclTerraform(struct?: SyntheticsTestOptionsListMonitorOptionsOutputReference | SyntheticsTestOptionsListMonitorOptions): any;
export declare class SyntheticsTestOptionsListMonitorOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestOptionsListMonitorOptions | undefined;
    set internalValue(value: SyntheticsTestOptionsListMonitorOptions | undefined);
    private _escalationMessage?;
    get escalationMessage(): string;
    set escalationMessage(value: string);
    resetEscalationMessage(): void;
    get escalationMessageInput(): string | undefined;
    private _notificationPresetName?;
    get notificationPresetName(): string;
    set notificationPresetName(value: string);
    resetNotificationPresetName(): void;
    get notificationPresetNameInput(): string | undefined;
    private _renotifyInterval?;
    get renotifyInterval(): number;
    set renotifyInterval(value: number);
    resetRenotifyInterval(): void;
    get renotifyIntervalInput(): number | undefined;
    private _renotifyOccurrences?;
    get renotifyOccurrences(): number;
    set renotifyOccurrences(value: number);
    resetRenotifyOccurrences(): void;
    get renotifyOccurrencesInput(): number | undefined;
}
export interface SyntheticsTestOptionsListRetry {
    /**
    * Number of retries needed to consider a location as failed before sending a notification alert. Maximum value: `3` for `api` tests, `2` for `browser` and `mobile` tests. Defaults to `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#count SyntheticsTest#count}
    */
    readonly count?: number;
    /**
    * Interval between a failed test and the next retry in milliseconds. Maximum value: `5000`. Defaults to `300`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#interval SyntheticsTest#interval}
    */
    readonly interval?: number;
}
export declare function syntheticsTestOptionsListRetryToTerraform(struct?: SyntheticsTestOptionsListRetryOutputReference | SyntheticsTestOptionsListRetry): any;
export declare function syntheticsTestOptionsListRetryToHclTerraform(struct?: SyntheticsTestOptionsListRetryOutputReference | SyntheticsTestOptionsListRetry): any;
export declare class SyntheticsTestOptionsListRetryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestOptionsListRetry | undefined;
    set internalValue(value: SyntheticsTestOptionsListRetry | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    resetCount(): void;
    get countInput(): number | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface SyntheticsTestOptionsListRumSettings {
    /**
    * RUM application ID used to collect RUM data for the browser test.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#application_id SyntheticsTest#application_id}
    */
    readonly applicationId?: string;
    /**
    * RUM application API key ID used to collect RUM data for the browser test.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#client_token_id SyntheticsTest#client_token_id}
    */
    readonly clientTokenId?: number;
    /**
    * Determines whether RUM data is collected during test runs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#is_enabled SyntheticsTest#is_enabled}
    */
    readonly isEnabled: boolean | cdktn.IResolvable;
}
export declare function syntheticsTestOptionsListRumSettingsToTerraform(struct?: SyntheticsTestOptionsListRumSettingsOutputReference | SyntheticsTestOptionsListRumSettings): any;
export declare function syntheticsTestOptionsListRumSettingsToHclTerraform(struct?: SyntheticsTestOptionsListRumSettingsOutputReference | SyntheticsTestOptionsListRumSettings): any;
export declare class SyntheticsTestOptionsListRumSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestOptionsListRumSettings | undefined;
    set internalValue(value: SyntheticsTestOptionsListRumSettings | undefined);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    resetApplicationId(): void;
    get applicationIdInput(): string | undefined;
    private _clientTokenId?;
    get clientTokenId(): number;
    set clientTokenId(value: number);
    resetClientTokenId(): void;
    get clientTokenIdInput(): number | undefined;
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface SyntheticsTestOptionsListSchedulingTimeframes {
    /**
    * Number representing the day of the week
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#day SyntheticsTest#day}
    */
    readonly day: number;
    /**
    * The hour of the day on which scheduling starts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#from SyntheticsTest#from}
    */
    readonly from: string;
    /**
    * The hour of the day on which scheduling ends.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#to SyntheticsTest#to}
    */
    readonly to: string;
}
export declare function syntheticsTestOptionsListSchedulingTimeframesToTerraform(struct?: SyntheticsTestOptionsListSchedulingTimeframes | cdktn.IResolvable): any;
export declare function syntheticsTestOptionsListSchedulingTimeframesToHclTerraform(struct?: SyntheticsTestOptionsListSchedulingTimeframes | cdktn.IResolvable): any;
export declare class SyntheticsTestOptionsListSchedulingTimeframesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsTestOptionsListSchedulingTimeframes | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsTestOptionsListSchedulingTimeframes | cdktn.IResolvable | undefined);
    private _day?;
    get day(): number;
    set day(value: number);
    get dayInput(): number | undefined;
    private _from?;
    get from(): string;
    set from(value: string);
    get fromInput(): string | undefined;
    private _to?;
    get to(): string;
    set to(value: string);
    get toInput(): string | undefined;
}
export declare class SyntheticsTestOptionsListSchedulingTimeframesList extends cdktn.ComplexList {
    internalValue?: SyntheticsTestOptionsListSchedulingTimeframes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsTestOptionsListSchedulingTimeframesOutputReference;
}
export interface SyntheticsTestOptionsListScheduling {
    /**
    * Timezone in which the timeframe is based.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#timezone SyntheticsTest#timezone}
    */
    readonly timezone: string;
    /**
    * timeframes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#timeframes SyntheticsTest#timeframes}
    */
    readonly timeframes: SyntheticsTestOptionsListSchedulingTimeframes[] | cdktn.IResolvable;
}
export declare function syntheticsTestOptionsListSchedulingToTerraform(struct?: SyntheticsTestOptionsListSchedulingOutputReference | SyntheticsTestOptionsListScheduling): any;
export declare function syntheticsTestOptionsListSchedulingToHclTerraform(struct?: SyntheticsTestOptionsListSchedulingOutputReference | SyntheticsTestOptionsListScheduling): any;
export declare class SyntheticsTestOptionsListSchedulingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestOptionsListScheduling | undefined;
    set internalValue(value: SyntheticsTestOptionsListScheduling | undefined);
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    get timezoneInput(): string | undefined;
    private _timeframes;
    get timeframes(): SyntheticsTestOptionsListSchedulingTimeframesList;
    putTimeframes(value: SyntheticsTestOptionsListSchedulingTimeframes[] | cdktn.IResolvable): void;
    get timeframesInput(): cdktn.IResolvable | SyntheticsTestOptionsListSchedulingTimeframes[] | undefined;
}
export interface SyntheticsTestOptionsListStruct {
    /**
    * For SSL tests, whether or not the test should allow self signed certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#accept_self_signed SyntheticsTest#accept_self_signed}
    */
    readonly acceptSelfSigned?: boolean | cdktn.IResolvable;
    /**
    * Allows loading insecure content for a request in an API test or in a multistep API test step.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#allow_insecure SyntheticsTest#allow_insecure}
    */
    readonly allowInsecure?: boolean | cdktn.IResolvable;
    /**
    * Blocked URL patterns. Requests made to URLs matching any of the patterns listed here will be blocked.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#blocked_request_patterns SyntheticsTest#blocked_request_patterns}
    */
    readonly blockedRequestPatterns?: string[];
    /**
    * For SSL tests, whether or not the test should fail on revoked certificate in stapled OCSP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#check_certificate_revocation SyntheticsTest#check_certificate_revocation}
    */
    readonly checkCertificateRevocation?: boolean | cdktn.IResolvable;
    /**
    * For SSL tests, whether or not the test should disable fetching intermediate certificates from AIA
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#disable_aia_intermediate_fetching SyntheticsTest#disable_aia_intermediate_fetching}
    */
    readonly disableAiaIntermediateFetching?: boolean | cdktn.IResolvable;
    /**
    * Disable Cross-Origin Resource Sharing for browser tests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#disable_cors SyntheticsTest#disable_cors}
    */
    readonly disableCors?: boolean | cdktn.IResolvable;
    /**
    * Disable Content Security Policy for browser tests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#disable_csp SyntheticsTest#disable_csp}
    */
    readonly disableCsp?: boolean | cdktn.IResolvable;
    /**
    * Determines whether or not the API HTTP test should follow redirects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#follow_redirects SyntheticsTest#follow_redirects}
    */
    readonly followRedirects?: boolean | cdktn.IResolvable;
    /**
    * HTTP version to use for an HTTP request in an API test or step. Valid values are `http1`, `http2`, `any`. Defaults to `"any"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#http_version SyntheticsTest#http_version}
    */
    readonly httpVersion?: string;
    /**
    * Ignore server certificate error for browser tests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#ignore_server_certificate_error SyntheticsTest#ignore_server_certificate_error}
    */
    readonly ignoreServerCertificateError?: boolean | cdktn.IResolvable;
    /**
    * Timeout before declaring the initial step as failed (in seconds) for browser tests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#initial_navigation_timeout SyntheticsTest#initial_navigation_timeout}
    */
    readonly initialNavigationTimeout?: number;
    /**
    * Minimum amount of time in failure required to trigger an alert (in seconds). Default is `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#min_failure_duration SyntheticsTest#min_failure_duration}
    */
    readonly minFailureDuration?: number;
    /**
    * Minimum number of locations in failure required to trigger an alert. Defaults to `1`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#min_location_failed SyntheticsTest#min_location_failed}
    */
    readonly minLocationFailed?: number;
    /**
    * The monitor name is used for the alert title as well as for all monitor dashboard widgets and SLOs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#monitor_name SyntheticsTest#monitor_name}
    */
    readonly monitorName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#monitor_priority SyntheticsTest#monitor_priority}
    */
    readonly monitorPriority?: number;
    /**
    * Prevents saving screenshots of the steps.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#no_screenshot SyntheticsTest#no_screenshot}
    */
    readonly noScreenshot?: boolean | cdktn.IResolvable;
    /**
    * A list of role identifiers pulled from the Roles API to restrict read and write access. **Deprecated.** This field is no longer supported by the Datadog API. Please use `datadog_restriction_policy` instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#restricted_roles SyntheticsTest#restricted_roles}
    */
    readonly restrictedRoles?: string[];
    /**
    * How often the test should run (in seconds). Valid range is `30-604800` for API tests and `60-604800` for browser tests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#tick_every SyntheticsTest#tick_every}
    */
    readonly tickEvery: number;
    /**
    * ci block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#ci SyntheticsTest#ci}
    */
    readonly ci?: SyntheticsTestOptionsListCi;
    /**
    * monitor_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#monitor_options SyntheticsTest#monitor_options}
    */
    readonly monitorOptions?: SyntheticsTestOptionsListMonitorOptions;
    /**
    * retry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#retry SyntheticsTest#retry}
    */
    readonly retry?: SyntheticsTestOptionsListRetry;
    /**
    * rum_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#rum_settings SyntheticsTest#rum_settings}
    */
    readonly rumSettings?: SyntheticsTestOptionsListRumSettings;
    /**
    * scheduling block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#scheduling SyntheticsTest#scheduling}
    */
    readonly scheduling?: SyntheticsTestOptionsListScheduling;
}
export declare function syntheticsTestOptionsListStructToTerraform(struct?: SyntheticsTestOptionsListStructOutputReference | SyntheticsTestOptionsListStruct): any;
export declare function syntheticsTestOptionsListStructToHclTerraform(struct?: SyntheticsTestOptionsListStructOutputReference | SyntheticsTestOptionsListStruct): any;
export declare class SyntheticsTestOptionsListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestOptionsListStruct | undefined;
    set internalValue(value: SyntheticsTestOptionsListStruct | undefined);
    private _acceptSelfSigned?;
    get acceptSelfSigned(): boolean | cdktn.IResolvable;
    set acceptSelfSigned(value: boolean | cdktn.IResolvable);
    resetAcceptSelfSigned(): void;
    get acceptSelfSignedInput(): boolean | cdktn.IResolvable | undefined;
    private _allowInsecure?;
    get allowInsecure(): boolean | cdktn.IResolvable;
    set allowInsecure(value: boolean | cdktn.IResolvable);
    resetAllowInsecure(): void;
    get allowInsecureInput(): boolean | cdktn.IResolvable | undefined;
    private _blockedRequestPatterns?;
    get blockedRequestPatterns(): string[];
    set blockedRequestPatterns(value: string[]);
    resetBlockedRequestPatterns(): void;
    get blockedRequestPatternsInput(): string[] | undefined;
    private _checkCertificateRevocation?;
    get checkCertificateRevocation(): boolean | cdktn.IResolvable;
    set checkCertificateRevocation(value: boolean | cdktn.IResolvable);
    resetCheckCertificateRevocation(): void;
    get checkCertificateRevocationInput(): boolean | cdktn.IResolvable | undefined;
    private _disableAiaIntermediateFetching?;
    get disableAiaIntermediateFetching(): boolean | cdktn.IResolvable;
    set disableAiaIntermediateFetching(value: boolean | cdktn.IResolvable);
    resetDisableAiaIntermediateFetching(): void;
    get disableAiaIntermediateFetchingInput(): boolean | cdktn.IResolvable | undefined;
    private _disableCors?;
    get disableCors(): boolean | cdktn.IResolvable;
    set disableCors(value: boolean | cdktn.IResolvable);
    resetDisableCors(): void;
    get disableCorsInput(): boolean | cdktn.IResolvable | undefined;
    private _disableCsp?;
    get disableCsp(): boolean | cdktn.IResolvable;
    set disableCsp(value: boolean | cdktn.IResolvable);
    resetDisableCsp(): void;
    get disableCspInput(): boolean | cdktn.IResolvable | undefined;
    private _followRedirects?;
    get followRedirects(): boolean | cdktn.IResolvable;
    set followRedirects(value: boolean | cdktn.IResolvable);
    resetFollowRedirects(): void;
    get followRedirectsInput(): boolean | cdktn.IResolvable | undefined;
    private _httpVersion?;
    get httpVersion(): string;
    set httpVersion(value: string);
    resetHttpVersion(): void;
    get httpVersionInput(): string | undefined;
    private _ignoreServerCertificateError?;
    get ignoreServerCertificateError(): boolean | cdktn.IResolvable;
    set ignoreServerCertificateError(value: boolean | cdktn.IResolvable);
    resetIgnoreServerCertificateError(): void;
    get ignoreServerCertificateErrorInput(): boolean | cdktn.IResolvable | undefined;
    private _initialNavigationTimeout?;
    get initialNavigationTimeout(): number;
    set initialNavigationTimeout(value: number);
    resetInitialNavigationTimeout(): void;
    get initialNavigationTimeoutInput(): number | undefined;
    private _minFailureDuration?;
    get minFailureDuration(): number;
    set minFailureDuration(value: number);
    resetMinFailureDuration(): void;
    get minFailureDurationInput(): number | undefined;
    private _minLocationFailed?;
    get minLocationFailed(): number;
    set minLocationFailed(value: number);
    resetMinLocationFailed(): void;
    get minLocationFailedInput(): number | undefined;
    private _monitorName?;
    get monitorName(): string;
    set monitorName(value: string);
    resetMonitorName(): void;
    get monitorNameInput(): string | undefined;
    private _monitorPriority?;
    get monitorPriority(): number;
    set monitorPriority(value: number);
    resetMonitorPriority(): void;
    get monitorPriorityInput(): number | undefined;
    private _noScreenshot?;
    get noScreenshot(): boolean | cdktn.IResolvable;
    set noScreenshot(value: boolean | cdktn.IResolvable);
    resetNoScreenshot(): void;
    get noScreenshotInput(): boolean | cdktn.IResolvable | undefined;
    private _restrictedRoles?;
    get restrictedRoles(): string[];
    set restrictedRoles(value: string[]);
    resetRestrictedRoles(): void;
    get restrictedRolesInput(): string[] | undefined;
    private _tickEvery?;
    get tickEvery(): number;
    set tickEvery(value: number);
    get tickEveryInput(): number | undefined;
    private _ci;
    get ci(): SyntheticsTestOptionsListCiOutputReference;
    putCi(value: SyntheticsTestOptionsListCi): void;
    resetCi(): void;
    get ciInput(): SyntheticsTestOptionsListCi | undefined;
    private _monitorOptions;
    get monitorOptions(): SyntheticsTestOptionsListMonitorOptionsOutputReference;
    putMonitorOptions(value: SyntheticsTestOptionsListMonitorOptions): void;
    resetMonitorOptions(): void;
    get monitorOptionsInput(): SyntheticsTestOptionsListMonitorOptions | undefined;
    private _retry;
    get retry(): SyntheticsTestOptionsListRetryOutputReference;
    putRetry(value: SyntheticsTestOptionsListRetry): void;
    resetRetry(): void;
    get retryInput(): SyntheticsTestOptionsListRetry | undefined;
    private _rumSettings;
    get rumSettings(): SyntheticsTestOptionsListRumSettingsOutputReference;
    putRumSettings(value: SyntheticsTestOptionsListRumSettings): void;
    resetRumSettings(): void;
    get rumSettingsInput(): SyntheticsTestOptionsListRumSettings | undefined;
    private _scheduling;
    get scheduling(): SyntheticsTestOptionsListSchedulingOutputReference;
    putScheduling(value: SyntheticsTestOptionsListScheduling): void;
    resetScheduling(): void;
    get schedulingInput(): SyntheticsTestOptionsListScheduling | undefined;
}
export interface SyntheticsTestRequestBasicauth {
    /**
    * Access key for `SIGV4` authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#access_key SyntheticsTest#access_key}
    */
    readonly accessKey?: string;
    /**
    * Access token url for `oauth-client` or `oauth-rop` authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#access_token_url SyntheticsTest#access_token_url}
    */
    readonly accessTokenUrl?: string;
    /**
    * Audience for `oauth-client` or `oauth-rop` authentication. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#audience SyntheticsTest#audience}
    */
    readonly audience?: string;
    /**
    * Client ID for `oauth-client` or `oauth-rop` authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#client_id SyntheticsTest#client_id}
    */
    readonly clientId?: string;
    /**
    * Client secret for `oauth-client` or `oauth-rop` authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#client_secret SyntheticsTest#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * Domain for `ntlm` authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#domain SyntheticsTest#domain}
    */
    readonly domain?: string;
    /**
    * Password for authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#password SyntheticsTest#password}
    */
    readonly password?: string;
    /**
    * Region for `SIGV4` authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#region SyntheticsTest#region}
    */
    readonly region?: string;
    /**
    * Resource for `oauth-client` or `oauth-rop` authentication. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#resource SyntheticsTest#resource}
    */
    readonly resource?: string;
    /**
    * Scope for `oauth-client` or `oauth-rop` authentication. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#scope SyntheticsTest#scope}
    */
    readonly scope?: string;
    /**
    * Secret key for `SIGV4` authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#secret_key SyntheticsTest#secret_key}
    */
    readonly secretKey?: string;
    /**
    * Service name for `SIGV4` authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#service_name SyntheticsTest#service_name}
    */
    readonly serviceName?: string;
    /**
    * Session token for `SIGV4` authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#session_token SyntheticsTest#session_token}
    */
    readonly sessionToken?: string;
    /**
    * Token API Authentication for `oauth-client` or `oauth-rop` authentication. Valid values are `header`, `body`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#token_api_authentication SyntheticsTest#token_api_authentication}
    */
    readonly tokenApiAuthentication?: string;
    /**
    * Type of basic authentication to use when performing the test. Defaults to `"web"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#type SyntheticsTest#type}
    */
    readonly type?: string;
    /**
    * Username for authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#username SyntheticsTest#username}
    */
    readonly username?: string;
    /**
    * Workstation for `ntlm` authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#workstation SyntheticsTest#workstation}
    */
    readonly workstation?: string;
}
export declare function syntheticsTestRequestBasicauthToTerraform(struct?: SyntheticsTestRequestBasicauthOutputReference | SyntheticsTestRequestBasicauth): any;
export declare function syntheticsTestRequestBasicauthToHclTerraform(struct?: SyntheticsTestRequestBasicauthOutputReference | SyntheticsTestRequestBasicauth): any;
export declare class SyntheticsTestRequestBasicauthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestRequestBasicauth | undefined;
    set internalValue(value: SyntheticsTestRequestBasicauth | undefined);
    private _accessKey?;
    get accessKey(): string;
    set accessKey(value: string);
    resetAccessKey(): void;
    get accessKeyInput(): string | undefined;
    private _accessTokenUrl?;
    get accessTokenUrl(): string;
    set accessTokenUrl(value: string);
    resetAccessTokenUrl(): void;
    get accessTokenUrlInput(): string | undefined;
    private _audience?;
    get audience(): string;
    set audience(value: string);
    resetAudience(): void;
    get audienceInput(): string | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    resetDomain(): void;
    get domainInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    resetResource(): void;
    get resourceInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
    private _secretKey?;
    get secretKey(): string;
    set secretKey(value: string);
    resetSecretKey(): void;
    get secretKeyInput(): string | undefined;
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    resetServiceName(): void;
    get serviceNameInput(): string | undefined;
    private _sessionToken?;
    get sessionToken(): string;
    set sessionToken(value: string);
    resetSessionToken(): void;
    get sessionTokenInput(): string | undefined;
    private _tokenApiAuthentication?;
    get tokenApiAuthentication(): string;
    set tokenApiAuthentication(value: string);
    resetTokenApiAuthentication(): void;
    get tokenApiAuthenticationInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _workstation?;
    get workstation(): string;
    set workstation(value: string);
    resetWorkstation(): void;
    get workstationInput(): string | undefined;
}
export interface SyntheticsTestRequestClientCertificateCert {
    /**
    * Content of the certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#content SyntheticsTest#content}
    */
    readonly content?: string;
    /**
    * File name for the certificate. Defaults to `"Provided in Terraform config"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#filename SyntheticsTest#filename}
    */
    readonly filename?: string;
}
export declare function syntheticsTestRequestClientCertificateCertToTerraform(struct?: SyntheticsTestRequestClientCertificateCertOutputReference | SyntheticsTestRequestClientCertificateCert): any;
export declare function syntheticsTestRequestClientCertificateCertToHclTerraform(struct?: SyntheticsTestRequestClientCertificateCertOutputReference | SyntheticsTestRequestClientCertificateCert): any;
export declare class SyntheticsTestRequestClientCertificateCertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestRequestClientCertificateCert | undefined;
    set internalValue(value: SyntheticsTestRequestClientCertificateCert | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    private _filename?;
    get filename(): string;
    set filename(value: string);
    resetFilename(): void;
    get filenameInput(): string | undefined;
}
export interface SyntheticsTestRequestClientCertificateKey {
    /**
    * Content of the certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#content SyntheticsTest#content}
    */
    readonly content?: string;
    /**
    * File name for the certificate. Defaults to `"Provided in Terraform config"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#filename SyntheticsTest#filename}
    */
    readonly filename?: string;
}
export declare function syntheticsTestRequestClientCertificateKeyToTerraform(struct?: SyntheticsTestRequestClientCertificateKeyOutputReference | SyntheticsTestRequestClientCertificateKey): any;
export declare function syntheticsTestRequestClientCertificateKeyToHclTerraform(struct?: SyntheticsTestRequestClientCertificateKeyOutputReference | SyntheticsTestRequestClientCertificateKey): any;
export declare class SyntheticsTestRequestClientCertificateKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestRequestClientCertificateKey | undefined;
    set internalValue(value: SyntheticsTestRequestClientCertificateKey | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    private _filename?;
    get filename(): string;
    set filename(value: string);
    resetFilename(): void;
    get filenameInput(): string | undefined;
}
export interface SyntheticsTestRequestClientCertificate {
    /**
    * cert block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#cert SyntheticsTest#cert}
    */
    readonly cert: SyntheticsTestRequestClientCertificateCert;
    /**
    * key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#key SyntheticsTest#key}
    */
    readonly key: SyntheticsTestRequestClientCertificateKey;
}
export declare function syntheticsTestRequestClientCertificateToTerraform(struct?: SyntheticsTestRequestClientCertificateOutputReference | SyntheticsTestRequestClientCertificate): any;
export declare function syntheticsTestRequestClientCertificateToHclTerraform(struct?: SyntheticsTestRequestClientCertificateOutputReference | SyntheticsTestRequestClientCertificate): any;
export declare class SyntheticsTestRequestClientCertificateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestRequestClientCertificate | undefined;
    set internalValue(value: SyntheticsTestRequestClientCertificate | undefined);
    private _cert;
    get cert(): SyntheticsTestRequestClientCertificateCertOutputReference;
    putCert(value: SyntheticsTestRequestClientCertificateCert): void;
    get certInput(): SyntheticsTestRequestClientCertificateCert | undefined;
    private _key;
    get key(): SyntheticsTestRequestClientCertificateKeyOutputReference;
    putKey(value: SyntheticsTestRequestClientCertificateKey): void;
    get keyInput(): SyntheticsTestRequestClientCertificateKey | undefined;
}
export interface SyntheticsTestRequestDefinition {
    /**
    * The request body.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#body SyntheticsTest#body}
    */
    readonly body?: string;
    /**
    * Type of the request body. Valid values are `text/plain`, `application/json`, `text/xml`, `text/html`, `application/x-www-form-urlencoded`, `graphql`, `application/octet-stream`, `multipart/form-data`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#body_type SyntheticsTest#body_type}
    */
    readonly bodyType?: string;
    /**
    * The type of gRPC call to perform. Valid values are `healthcheck`, `unary`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#call_type SyntheticsTest#call_type}
    */
    readonly callType?: string;
    /**
    * By default, the client certificate is applied on the domain of the starting URL for browser tests. If you want your client certificate to be applied on other domains instead, add them in `certificate_domains`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#certificate_domains SyntheticsTest#certificate_domains}
    */
    readonly certificateDomains?: string[];
    /**
    * For Network Path tests, an optional label displayed for the destination host in the Network Path visualization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#destination_service SyntheticsTest#destination_service}
    */
    readonly destinationService?: string;
    /**
    * DNS server to use for DNS tests (`subtype = "dns"`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#dns_server SyntheticsTest#dns_server}
    */
    readonly dnsServer?: string;
    /**
    * DNS server port to use for DNS tests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#dns_server_port SyntheticsTest#dns_server_port}
    */
    readonly dnsServerPort?: string;
    /**
    * For Network Path tests, the number of packets sent to probe the destination to measure packet loss, latency, and jitter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#e2e_queries SyntheticsTest#e2e_queries}
    */
    readonly e2EQueries?: number;
    /**
    * Form data to be sent when `body_type` is `multipart/form-data`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#form SyntheticsTest#form}
    */
    readonly form?: {
        [key: string]: string;
    };
    /**
    * Host name to perform the test with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#host SyntheticsTest#host}
    */
    readonly host?: string;
    /**
    * HTTP version to use for an HTTP request in an API test or step. **Deprecated.** Use `http_version` in the `options_list` field instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#http_version SyntheticsTest#http_version}
    */
    readonly httpVersion?: string;
    /**
    * For Websocket tests, whether the message is treated as a base64-encoded string in the server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#is_message_base64_encoded SyntheticsTest#is_message_base64_encoded}
    */
    readonly isMessageBase64Encoded?: boolean | cdktn.IResolvable;
    /**
    * For Network Path tests, the maximum time-to-live (max number of hops) used in outgoing probe packets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#max_ttl SyntheticsTest#max_ttl}
    */
    readonly maxTtl?: number;
    /**
    * For gRPC, UDP, and Websocket tests, message to send with the request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#message SyntheticsTest#message}
    */
    readonly message?: string;
    /**
    * Either the HTTP method/verb to use or a gRPC method available on the service set in the `service` field. Required if `subtype` is `HTTP` or if `subtype` is `grpc` and `callType` is `unary`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#method SyntheticsTest#method}
    */
    readonly method?: string;
    /**
    * Determines whether or not to save the response body.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#no_saving_response_body SyntheticsTest#no_saving_response_body}
    */
    readonly noSavingResponseBody?: boolean | cdktn.IResolvable;
    /**
    * Number of pings to use per test for ICMP tests (`subtype = "icmp"`) between 0 and 10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#number_of_packets SyntheticsTest#number_of_packets}
    */
    readonly numberOfPackets?: number;
    /**
    * Persist cookies across redirects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#persist_cookies SyntheticsTest#persist_cookies}
    */
    readonly persistCookies?: boolean | cdktn.IResolvable;
    /**
    * The content of a proto file as a string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#plain_proto_file SyntheticsTest#plain_proto_file}
    */
    readonly plainProtoFile?: string;
    /**
    * Port to use when performing the test.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#port SyntheticsTest#port}
    */
    readonly port?: string;
    /**
    * A protobuf JSON descriptor. **Deprecated.** Use `plain_proto_file` instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#proto_json_descriptor SyntheticsTest#proto_json_descriptor}
    */
    readonly protoJsonDescriptor?: string;
    /**
    * For SSL tests, it specifies on which server you want to initiate the TLS handshake, allowing the server to present one of multiple possible certificates on the same IP address and TCP port number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#servername SyntheticsTest#servername}
    */
    readonly servername?: string;
    /**
    * The gRPC service on which you want to perform the gRPC call.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#service SyntheticsTest#service}
    */
    readonly service?: string;
    /**
    * This will turn on a traceroute probe to discover all gateways along the path to the host destination. For ICMP tests (`subtype = "icmp"`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#should_track_hops SyntheticsTest#should_track_hops}
    */
    readonly shouldTrackHops?: boolean | cdktn.IResolvable;
    /**
    * For Network Path tests, an optional label displayed for the source host in the Network Path visualization
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#source_service SyntheticsTest#source_service}
    */
    readonly sourceService?: string;
    /**
    * For TCP Network Path tests, the TCP traceroute strategy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#tcp_method SyntheticsTest#tcp_method}
    */
    readonly tcpMethod?: string;
    /**
    * Timeout in seconds for the test.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#timeout SyntheticsTest#timeout}
    */
    readonly timeout?: number;
    /**
    * For Network Path tests, the number of traceroute path tracings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#traceroute_queries SyntheticsTest#traceroute_queries}
    */
    readonly tracerouteQueries?: number;
    /**
    * The URL to send the request to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#url SyntheticsTest#url}
    */
    readonly url?: string;
}
export declare function syntheticsTestRequestDefinitionToTerraform(struct?: SyntheticsTestRequestDefinitionOutputReference | SyntheticsTestRequestDefinition): any;
export declare function syntheticsTestRequestDefinitionToHclTerraform(struct?: SyntheticsTestRequestDefinitionOutputReference | SyntheticsTestRequestDefinition): any;
export declare class SyntheticsTestRequestDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestRequestDefinition | undefined;
    set internalValue(value: SyntheticsTestRequestDefinition | undefined);
    private _body?;
    get body(): string;
    set body(value: string);
    resetBody(): void;
    get bodyInput(): string | undefined;
    private _bodyType?;
    get bodyType(): string;
    set bodyType(value: string);
    resetBodyType(): void;
    get bodyTypeInput(): string | undefined;
    private _callType?;
    get callType(): string;
    set callType(value: string);
    resetCallType(): void;
    get callTypeInput(): string | undefined;
    private _certificateDomains?;
    get certificateDomains(): string[];
    set certificateDomains(value: string[]);
    resetCertificateDomains(): void;
    get certificateDomainsInput(): string[] | undefined;
    private _destinationService?;
    get destinationService(): string;
    set destinationService(value: string);
    resetDestinationService(): void;
    get destinationServiceInput(): string | undefined;
    private _dnsServer?;
    get dnsServer(): string;
    set dnsServer(value: string);
    resetDnsServer(): void;
    get dnsServerInput(): string | undefined;
    private _dnsServerPort?;
    get dnsServerPort(): string;
    set dnsServerPort(value: string);
    resetDnsServerPort(): void;
    get dnsServerPortInput(): string | undefined;
    private _e2EQueries?;
    get e2EQueries(): number;
    set e2EQueries(value: number);
    resetE2EQueries(): void;
    get e2EQueriesInput(): number | undefined;
    private _form?;
    get form(): {
        [key: string]: string;
    };
    set form(value: {
        [key: string]: string;
    });
    resetForm(): void;
    get formInput(): {
        [key: string]: string;
    } | undefined;
    private _host?;
    get host(): string;
    set host(value: string);
    resetHost(): void;
    get hostInput(): string | undefined;
    private _httpVersion?;
    get httpVersion(): string;
    set httpVersion(value: string);
    resetHttpVersion(): void;
    get httpVersionInput(): string | undefined;
    private _isMessageBase64Encoded?;
    get isMessageBase64Encoded(): boolean | cdktn.IResolvable;
    set isMessageBase64Encoded(value: boolean | cdktn.IResolvable);
    resetIsMessageBase64Encoded(): void;
    get isMessageBase64EncodedInput(): boolean | cdktn.IResolvable | undefined;
    private _maxTtl?;
    get maxTtl(): number;
    set maxTtl(value: number);
    resetMaxTtl(): void;
    get maxTtlInput(): number | undefined;
    private _message?;
    get message(): string;
    set message(value: string);
    resetMessage(): void;
    get messageInput(): string | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _noSavingResponseBody?;
    get noSavingResponseBody(): boolean | cdktn.IResolvable;
    set noSavingResponseBody(value: boolean | cdktn.IResolvable);
    resetNoSavingResponseBody(): void;
    get noSavingResponseBodyInput(): boolean | cdktn.IResolvable | undefined;
    private _numberOfPackets?;
    get numberOfPackets(): number;
    set numberOfPackets(value: number);
    resetNumberOfPackets(): void;
    get numberOfPacketsInput(): number | undefined;
    private _persistCookies?;
    get persistCookies(): boolean | cdktn.IResolvable;
    set persistCookies(value: boolean | cdktn.IResolvable);
    resetPersistCookies(): void;
    get persistCookiesInput(): boolean | cdktn.IResolvable | undefined;
    private _plainProtoFile?;
    get plainProtoFile(): string;
    set plainProtoFile(value: string);
    resetPlainProtoFile(): void;
    get plainProtoFileInput(): string | undefined;
    private _port?;
    get port(): string;
    set port(value: string);
    resetPort(): void;
    get portInput(): string | undefined;
    private _protoJsonDescriptor?;
    get protoJsonDescriptor(): string;
    set protoJsonDescriptor(value: string);
    resetProtoJsonDescriptor(): void;
    get protoJsonDescriptorInput(): string | undefined;
    private _servername?;
    get servername(): string;
    set servername(value: string);
    resetServername(): void;
    get servernameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
    private _shouldTrackHops?;
    get shouldTrackHops(): boolean | cdktn.IResolvable;
    set shouldTrackHops(value: boolean | cdktn.IResolvable);
    resetShouldTrackHops(): void;
    get shouldTrackHopsInput(): boolean | cdktn.IResolvable | undefined;
    private _sourceService?;
    get sourceService(): string;
    set sourceService(value: string);
    resetSourceService(): void;
    get sourceServiceInput(): string | undefined;
    private _tcpMethod?;
    get tcpMethod(): string;
    set tcpMethod(value: string);
    resetTcpMethod(): void;
    get tcpMethodInput(): string | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _tracerouteQueries?;
    get tracerouteQueries(): number;
    set tracerouteQueries(value: number);
    resetTracerouteQueries(): void;
    get tracerouteQueriesInput(): number | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
}
export interface SyntheticsTestRequestFile {
    /**
    * Content of the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#content SyntheticsTest#content}
    */
    readonly content?: string;
    /**
    * Name of the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#name SyntheticsTest#name}
    */
    readonly name: string;
    /**
    * Original name of the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#original_file_name SyntheticsTest#original_file_name}
    */
    readonly originalFileName?: string;
    /**
    * Size of the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#size SyntheticsTest#size}
    */
    readonly size: number;
    /**
    * Type of the file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#type SyntheticsTest#type}
    */
    readonly type: string;
}
export declare function syntheticsTestRequestFileToTerraform(struct?: SyntheticsTestRequestFile | cdktn.IResolvable): any;
export declare function syntheticsTestRequestFileToHclTerraform(struct?: SyntheticsTestRequestFile | cdktn.IResolvable): any;
export declare class SyntheticsTestRequestFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsTestRequestFile | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsTestRequestFile | cdktn.IResolvable | undefined);
    get bucketKey(): string;
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _originalFileName?;
    get originalFileName(): string;
    set originalFileName(value: string);
    resetOriginalFileName(): void;
    get originalFileNameInput(): string | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    get sizeInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class SyntheticsTestRequestFileList extends cdktn.ComplexList {
    internalValue?: SyntheticsTestRequestFile[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsTestRequestFileOutputReference;
}
export interface SyntheticsTestRequestProxy {
    /**
    * Header name and value map.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#headers SyntheticsTest#headers}
    */
    readonly headers?: {
        [key: string]: string;
    };
    /**
    * URL of the proxy to perform the test.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#url SyntheticsTest#url}
    */
    readonly url: string;
}
export declare function syntheticsTestRequestProxyToTerraform(struct?: SyntheticsTestRequestProxyOutputReference | SyntheticsTestRequestProxy): any;
export declare function syntheticsTestRequestProxyToHclTerraform(struct?: SyntheticsTestRequestProxyOutputReference | SyntheticsTestRequestProxy): any;
export declare class SyntheticsTestRequestProxyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SyntheticsTestRequestProxy | undefined;
    set internalValue(value: SyntheticsTestRequestProxy | undefined);
    private _headers?;
    get headers(): {
        [key: string]: string;
    };
    set headers(value: {
        [key: string]: string;
    });
    resetHeaders(): void;
    get headersInput(): {
        [key: string]: string;
    } | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test datadog_synthetics_test}
*/
export declare class SyntheticsTest extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_synthetics_test";
    /**
    * Generates CDKTN code for importing a SyntheticsTest resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SyntheticsTest to import
    * @param importFromId The id of the existing SyntheticsTest that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SyntheticsTest to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_test datadog_synthetics_test} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SyntheticsTestConfig
    */
    constructor(scope: Construct, id: string, config: SyntheticsTestConfig);
    private _configInitialApplicationArguments?;
    get configInitialApplicationArguments(): {
        [key: string]: string;
    };
    set configInitialApplicationArguments(value: {
        [key: string]: string;
    });
    resetConfigInitialApplicationArguments(): void;
    get configInitialApplicationArgumentsInput(): {
        [key: string]: string;
    } | undefined;
    private _deviceIds?;
    get deviceIds(): string[];
    set deviceIds(value: string[]);
    resetDeviceIds(): void;
    get deviceIdsInput(): string[] | undefined;
    private _forceDeleteDependencies?;
    get forceDeleteDependencies(): boolean | cdktn.IResolvable;
    set forceDeleteDependencies(value: boolean | cdktn.IResolvable);
    resetForceDeleteDependencies(): void;
    get forceDeleteDependenciesInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _locations?;
    get locations(): string[];
    set locations(value: string[]);
    get locationsInput(): string[] | undefined;
    private _message?;
    get message(): string;
    set message(value: string);
    resetMessage(): void;
    get messageInput(): string | undefined;
    get monitorId(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _requestHeaders?;
    get requestHeaders(): {
        [key: string]: string;
    };
    set requestHeaders(value: {
        [key: string]: string;
    });
    resetRequestHeaders(): void;
    get requestHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _requestMetadata?;
    get requestMetadata(): {
        [key: string]: string;
    };
    set requestMetadata(value: {
        [key: string]: string;
    });
    resetRequestMetadata(): void;
    get requestMetadataInput(): {
        [key: string]: string;
    } | undefined;
    private _requestQuery?;
    get requestQuery(): {
        [key: string]: string;
    };
    set requestQuery(value: {
        [key: string]: string;
    });
    resetRequestQuery(): void;
    get requestQueryInput(): {
        [key: string]: string;
    } | undefined;
    private _setCookie?;
    get setCookie(): string;
    set setCookie(value: string);
    resetSetCookie(): void;
    get setCookieInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
    private _subtype?;
    get subtype(): string;
    set subtype(value: string);
    resetSubtype(): void;
    get subtypeInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _variablesFromScript?;
    get variablesFromScript(): string;
    set variablesFromScript(value: string);
    resetVariablesFromScript(): void;
    get variablesFromScriptInput(): string | undefined;
    private _apiStep;
    get apiStep(): SyntheticsTestApiStepList;
    putApiStep(value: SyntheticsTestApiStep[] | cdktn.IResolvable): void;
    resetApiStep(): void;
    get apiStepInput(): cdktn.IResolvable | SyntheticsTestApiStep[] | undefined;
    private _assertion;
    get assertion(): SyntheticsTestAssertionList;
    putAssertion(value: SyntheticsTestAssertion[] | cdktn.IResolvable): void;
    resetAssertion(): void;
    get assertionInput(): cdktn.IResolvable | SyntheticsTestAssertion[] | undefined;
    private _browserStep;
    get browserStep(): SyntheticsTestBrowserStepList;
    putBrowserStep(value: SyntheticsTestBrowserStep[] | cdktn.IResolvable): void;
    resetBrowserStep(): void;
    get browserStepInput(): cdktn.IResolvable | SyntheticsTestBrowserStep[] | undefined;
    private _browserVariable;
    get browserVariable(): SyntheticsTestBrowserVariableList;
    putBrowserVariable(value: SyntheticsTestBrowserVariable[] | cdktn.IResolvable): void;
    resetBrowserVariable(): void;
    get browserVariableInput(): cdktn.IResolvable | SyntheticsTestBrowserVariable[] | undefined;
    private _configVariable;
    get configVariable(): SyntheticsTestConfigVariableList;
    putConfigVariable(value: SyntheticsTestConfigVariable[] | cdktn.IResolvable): void;
    resetConfigVariable(): void;
    get configVariableInput(): cdktn.IResolvable | SyntheticsTestConfigVariable[] | undefined;
    private _mobileOptionsList;
    get mobileOptionsList(): SyntheticsTestMobileOptionsListStructOutputReference;
    putMobileOptionsList(value: SyntheticsTestMobileOptionsListStruct): void;
    resetMobileOptionsList(): void;
    get mobileOptionsListInput(): SyntheticsTestMobileOptionsListStruct | undefined;
    private _mobileStep;
    get mobileStep(): SyntheticsTestMobileStepList;
    putMobileStep(value: SyntheticsTestMobileStep[] | cdktn.IResolvable): void;
    resetMobileStep(): void;
    get mobileStepInput(): cdktn.IResolvable | SyntheticsTestMobileStep[] | undefined;
    private _optionsList;
    get optionsList(): SyntheticsTestOptionsListStructOutputReference;
    putOptionsList(value: SyntheticsTestOptionsListStruct): void;
    resetOptionsList(): void;
    get optionsListInput(): SyntheticsTestOptionsListStruct | undefined;
    private _requestBasicauth;
    get requestBasicauth(): SyntheticsTestRequestBasicauthOutputReference;
    putRequestBasicauth(value: SyntheticsTestRequestBasicauth): void;
    resetRequestBasicauth(): void;
    get requestBasicauthInput(): SyntheticsTestRequestBasicauth | undefined;
    private _requestClientCertificate;
    get requestClientCertificate(): SyntheticsTestRequestClientCertificateOutputReference;
    putRequestClientCertificate(value: SyntheticsTestRequestClientCertificate): void;
    resetRequestClientCertificate(): void;
    get requestClientCertificateInput(): SyntheticsTestRequestClientCertificate | undefined;
    private _requestDefinition;
    get requestDefinition(): SyntheticsTestRequestDefinitionOutputReference;
    putRequestDefinition(value: SyntheticsTestRequestDefinition): void;
    resetRequestDefinition(): void;
    get requestDefinitionInput(): SyntheticsTestRequestDefinition | undefined;
    private _requestFile;
    get requestFile(): SyntheticsTestRequestFileList;
    putRequestFile(value: SyntheticsTestRequestFile[] | cdktn.IResolvable): void;
    resetRequestFile(): void;
    get requestFileInput(): cdktn.IResolvable | SyntheticsTestRequestFile[] | undefined;
    private _requestProxy;
    get requestProxy(): SyntheticsTestRequestProxyOutputReference;
    putRequestProxy(value: SyntheticsTestRequestProxy): void;
    resetRequestProxy(): void;
    get requestProxyInput(): SyntheticsTestRequestProxy | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
