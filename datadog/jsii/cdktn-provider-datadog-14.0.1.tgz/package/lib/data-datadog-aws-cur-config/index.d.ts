/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogAwsCurConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Datadog cloud account ID for the AWS CUR configuration you want to retrieve information about.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/aws_cur_config#cloud_account_id DataDatadogAwsCurConfig#cloud_account_id}
    */
    readonly cloudAccountId: number;
}
export interface DataDatadogAwsCurConfigAccountFilters {
}
export declare function dataDatadogAwsCurConfigAccountFiltersToTerraform(struct?: DataDatadogAwsCurConfigAccountFilters | cdktn.IResolvable): any;
export declare function dataDatadogAwsCurConfigAccountFiltersToHclTerraform(struct?: DataDatadogAwsCurConfigAccountFilters | cdktn.IResolvable): any;
export declare class DataDatadogAwsCurConfigAccountFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogAwsCurConfigAccountFilters | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogAwsCurConfigAccountFilters | cdktn.IResolvable | undefined);
    get excludedAccounts(): string[];
    get includeNewAccounts(): cdktn.IResolvable;
    get includedAccounts(): string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/aws_cur_config datadog_aws_cur_config}
*/
export declare class DataDatadogAwsCurConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_aws_cur_config";
    /**
    * Generates CDKTN code for importing a DataDatadogAwsCurConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogAwsCurConfig to import
    * @param importFromId The id of the existing DataDatadogAwsCurConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/aws_cur_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogAwsCurConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/aws_cur_config datadog_aws_cur_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogAwsCurConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogAwsCurConfigConfig);
    get accountId(): string;
    get bucketName(): string;
    get bucketRegion(): string;
    private _cloudAccountId?;
    get cloudAccountId(): number;
    set cloudAccountId(value: number);
    get cloudAccountIdInput(): number | undefined;
    get createdAt(): string;
    get errorMessages(): string[];
    get id(): string;
    get reportName(): string;
    get reportPrefix(): string;
    get status(): string;
    get statusUpdatedAt(): string;
    get updatedAt(): string;
    private _accountFilters;
    get accountFilters(): DataDatadogAwsCurConfigAccountFiltersOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
