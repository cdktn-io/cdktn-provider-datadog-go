/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogMonitorsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/monitors#id DataDatadogMonitors#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A list of monitor tags to limit the search. This filters on the tags set on the monitor itself.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/monitors#monitor_tags_filter DataDatadogMonitors#monitor_tags_filter}
    */
    readonly monitorTagsFilter?: string[];
    /**
    * A monitor name to limit the search.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/monitors#name_filter DataDatadogMonitors#name_filter}
    */
    readonly nameFilter?: string;
    /**
    * A list of tags to limit the search. This filters on the monitor scope.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/monitors#tags_filter DataDatadogMonitors#tags_filter}
    */
    readonly tagsFilter?: string[];
}
export interface DataDatadogMonitorsMonitors {
}
export declare function dataDatadogMonitorsMonitorsToTerraform(struct?: DataDatadogMonitorsMonitors): any;
export declare function dataDatadogMonitorsMonitorsToHclTerraform(struct?: DataDatadogMonitorsMonitors): any;
export declare class DataDatadogMonitorsMonitorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogMonitorsMonitors | undefined;
    set internalValue(value: DataDatadogMonitorsMonitors | undefined);
    get id(): number;
    get name(): string;
    get type(): string;
}
export declare class DataDatadogMonitorsMonitorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogMonitorsMonitorsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/monitors datadog_monitors}
*/
export declare class DataDatadogMonitors extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_monitors";
    /**
    * Generates CDKTN code for importing a DataDatadogMonitors resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogMonitors to import
    * @param importFromId The id of the existing DataDatadogMonitors that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/monitors#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogMonitors to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/monitors datadog_monitors} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogMonitorsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogMonitorsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _monitorTagsFilter?;
    get monitorTagsFilter(): string[];
    set monitorTagsFilter(value: string[]);
    resetMonitorTagsFilter(): void;
    get monitorTagsFilterInput(): string[] | undefined;
    private _monitors;
    get monitors(): DataDatadogMonitorsMonitorsList;
    private _nameFilter?;
    get nameFilter(): string;
    set nameFilter(value: string);
    resetNameFilter(): void;
    get nameFilterInput(): string | undefined;
    private _tagsFilter?;
    get tagsFilter(): string[];
    set tagsFilter(value: string[]);
    resetTagsFilter(): void;
    get tagsFilterInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
