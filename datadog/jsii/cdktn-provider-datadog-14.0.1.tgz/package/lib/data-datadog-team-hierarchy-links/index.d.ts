/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogTeamHierarchyLinksConfig extends cdktn.TerraformMetaArguments {
    /**
    * Filter by parent team ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team_hierarchy_links#filter_parent_team DataDatadogTeamHierarchyLinks#filter_parent_team}
    */
    readonly filterParentTeam?: string;
    /**
    * Filter by sub team ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team_hierarchy_links#filter_sub_team DataDatadogTeamHierarchyLinks#filter_sub_team}
    */
    readonly filterSubTeam?: string;
    /**
    * The team hierarchy link’s identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team_hierarchy_links#link_id DataDatadogTeamHierarchyLinks#link_id}
    */
    readonly linkId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team_hierarchy_links datadog_team_hierarchy_links}
*/
export declare class DataDatadogTeamHierarchyLinks extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_team_hierarchy_links";
    /**
    * Generates CDKTN code for importing a DataDatadogTeamHierarchyLinks resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogTeamHierarchyLinks to import
    * @param importFromId The id of the existing DataDatadogTeamHierarchyLinks that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team_hierarchy_links#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogTeamHierarchyLinks to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team_hierarchy_links datadog_team_hierarchy_links} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogTeamHierarchyLinksConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogTeamHierarchyLinksConfig);
    get createdAt(): string;
    private _filterParentTeam?;
    get filterParentTeam(): string;
    set filterParentTeam(value: string);
    resetFilterParentTeam(): void;
    get filterParentTeamInput(): string | undefined;
    private _filterSubTeam?;
    get filterSubTeam(): string;
    set filterSubTeam(value: string);
    resetFilterSubTeam(): void;
    get filterSubTeamInput(): string | undefined;
    get id(): string;
    private _linkId?;
    get linkId(): string;
    set linkId(value: string);
    resetLinkId(): void;
    get linkIdInput(): string | undefined;
    get provisionedBy(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
