/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OnCallUserNotificationChannelConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the user to associate the notification channel with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_user_notification_channel#user_id OnCallUserNotificationChannel#user_id}
    */
    readonly userId: string;
    /**
    * email block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_user_notification_channel#email OnCallUserNotificationChannel#email}
    */
    readonly email?: OnCallUserNotificationChannelEmail;
    /**
    * phone block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_user_notification_channel#phone OnCallUserNotificationChannel#phone}
    */
    readonly phone?: OnCallUserNotificationChannelPhone;
}
export interface OnCallUserNotificationChannelEmail {
    /**
    * The e-mail address to be notified
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_user_notification_channel#address OnCallUserNotificationChannel#address}
    */
    readonly address?: string;
    /**
    * Preferred content formats for notifications
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_user_notification_channel#formats OnCallUserNotificationChannel#formats}
    */
    readonly formats?: string[];
}
export declare function onCallUserNotificationChannelEmailToTerraform(struct?: OnCallUserNotificationChannelEmail | cdktn.IResolvable): any;
export declare function onCallUserNotificationChannelEmailToHclTerraform(struct?: OnCallUserNotificationChannelEmail | cdktn.IResolvable): any;
export declare class OnCallUserNotificationChannelEmailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OnCallUserNotificationChannelEmail | cdktn.IResolvable | undefined;
    set internalValue(value: OnCallUserNotificationChannelEmail | cdktn.IResolvable | undefined);
    private _address?;
    get address(): string;
    set address(value: string);
    resetAddress(): void;
    get addressInput(): string | undefined;
    private _formats?;
    get formats(): string[];
    set formats(value: string[]);
    resetFormats(): void;
    get formatsInput(): string[] | undefined;
}
export interface OnCallUserNotificationChannelPhone {
    /**
    * The E-164 formatted phone number (for example, +3371234567)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_user_notification_channel#number OnCallUserNotificationChannel#number}
    */
    readonly number?: string;
}
export declare function onCallUserNotificationChannelPhoneToTerraform(struct?: OnCallUserNotificationChannelPhone | cdktn.IResolvable): any;
export declare function onCallUserNotificationChannelPhoneToHclTerraform(struct?: OnCallUserNotificationChannelPhone | cdktn.IResolvable): any;
export declare class OnCallUserNotificationChannelPhoneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OnCallUserNotificationChannelPhone | cdktn.IResolvable | undefined;
    set internalValue(value: OnCallUserNotificationChannelPhone | cdktn.IResolvable | undefined);
    private _number?;
    get number(): string;
    set number(value: string);
    resetNumber(): void;
    get numberInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_user_notification_channel datadog_on_call_user_notification_channel}
*/
export declare class OnCallUserNotificationChannel extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_on_call_user_notification_channel";
    /**
    * Generates CDKTN code for importing a OnCallUserNotificationChannel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OnCallUserNotificationChannel to import
    * @param importFromId The id of the existing OnCallUserNotificationChannel that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_user_notification_channel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OnCallUserNotificationChannel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_user_notification_channel datadog_on_call_user_notification_channel} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OnCallUserNotificationChannelConfig
    */
    constructor(scope: Construct, id: string, config: OnCallUserNotificationChannelConfig);
    get id(): string;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    get userIdInput(): string | undefined;
    private _email;
    get email(): OnCallUserNotificationChannelEmailOutputReference;
    putEmail(value: OnCallUserNotificationChannelEmail): void;
    resetEmail(): void;
    get emailInput(): cdktn.IResolvable | OnCallUserNotificationChannelEmail | undefined;
    private _phone;
    get phone(): OnCallUserNotificationChannelPhoneOutputReference;
    putPhone(value: OnCallUserNotificationChannelPhone): void;
    resetPhone(): void;
    get phoneInput(): cdktn.IResolvable | OnCallUserNotificationChannelPhone | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
