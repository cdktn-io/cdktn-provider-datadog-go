/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SyntheticsGlobalVariableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Description of the global variable. Defaults to `""`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#description SyntheticsGlobalVariable#description}
    */
    readonly description?: string;
    /**
    * If set to true, the global variable is a FIDO variable. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#is_fido SyntheticsGlobalVariable#is_fido}
    */
    readonly isFido?: boolean | cdktn.IResolvable;
    /**
    * If set to true, the global variable is a TOTP variable. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#is_totp SyntheticsGlobalVariable#is_totp}
    */
    readonly isTotp?: boolean | cdktn.IResolvable;
    /**
    * Synthetics global variable name. Must be all uppercase with underscores.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#name SyntheticsGlobalVariable#name}
    */
    readonly name: string;
    /**
    * Id of the Synthetics test to use for a variable from test.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#parse_test_id SyntheticsGlobalVariable#parse_test_id}
    */
    readonly parseTestId?: string;
    /**
    * A list of role identifiers to associate with the Synthetics global variable. **Deprecated.** This field is no longer supported by the Datadog API. Please use `datadog_restriction_policy` instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#restricted_roles SyntheticsGlobalVariable#restricted_roles}
    */
    readonly restrictedRoles?: string[];
    /**
    * If set to true, the value of the global variable is hidden. This setting is automatically set to `true` if `is_totp` or `is_fido` is set to `true`. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#secure SyntheticsGlobalVariable#secure}
    */
    readonly secure?: boolean | cdktn.IResolvable;
    /**
    * A list of tags to associate with your synthetics global variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#tags SyntheticsGlobalVariable#tags}
    */
    readonly tags?: string[];
    /**
    * The value of the global variable. Required unless `is_fido` is set to `true` or `value_wo` is used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#value SyntheticsGlobalVariable#value}
    */
    readonly value?: string;
    /**
    * Write-only value of the global variable. Must be used with `value_wo_version`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#value_wo SyntheticsGlobalVariable#value_wo}
    */
    readonly valueWo?: string;
    /**
    * Version associated with the write-only value. Changing this triggers an update. Can be any string (e.g., '1', 'v2.1', '2024-Q1'). String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#value_wo_version SyntheticsGlobalVariable#value_wo_version}
    */
    readonly valueWoVersion?: string;
    /**
    * options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#options SyntheticsGlobalVariable#options}
    */
    readonly options?: SyntheticsGlobalVariableOptions[] | cdktn.IResolvable;
    /**
    * parse_test_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#parse_test_options SyntheticsGlobalVariable#parse_test_options}
    */
    readonly parseTestOptions?: SyntheticsGlobalVariableParseTestOptions[] | cdktn.IResolvable;
}
export interface SyntheticsGlobalVariableOptionsTotpParameters {
    /**
    * Number of digits for the OTP. Value must be between 4 and 10.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#digits SyntheticsGlobalVariable#digits}
    */
    readonly digits: number;
    /**
    * Interval for which to refresh the token (in seconds). Value must be between 0 and 999.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#refresh_interval SyntheticsGlobalVariable#refresh_interval}
    */
    readonly refreshInterval: number;
}
export declare function syntheticsGlobalVariableOptionsTotpParametersToTerraform(struct?: SyntheticsGlobalVariableOptionsTotpParameters | cdktn.IResolvable): any;
export declare function syntheticsGlobalVariableOptionsTotpParametersToHclTerraform(struct?: SyntheticsGlobalVariableOptionsTotpParameters | cdktn.IResolvable): any;
export declare class SyntheticsGlobalVariableOptionsTotpParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsGlobalVariableOptionsTotpParameters | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsGlobalVariableOptionsTotpParameters | cdktn.IResolvable | undefined);
    private _digits?;
    get digits(): number;
    set digits(value: number);
    get digitsInput(): number | undefined;
    private _refreshInterval?;
    get refreshInterval(): number;
    set refreshInterval(value: number);
    get refreshIntervalInput(): number | undefined;
}
export declare class SyntheticsGlobalVariableOptionsTotpParametersList extends cdktn.ComplexList {
    internalValue?: SyntheticsGlobalVariableOptionsTotpParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsGlobalVariableOptionsTotpParametersOutputReference;
}
export interface SyntheticsGlobalVariableOptions {
    /**
    * totp_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#totp_parameters SyntheticsGlobalVariable#totp_parameters}
    */
    readonly totpParameters?: SyntheticsGlobalVariableOptionsTotpParameters[] | cdktn.IResolvable;
}
export declare function syntheticsGlobalVariableOptionsToTerraform(struct?: SyntheticsGlobalVariableOptions | cdktn.IResolvable): any;
export declare function syntheticsGlobalVariableOptionsToHclTerraform(struct?: SyntheticsGlobalVariableOptions | cdktn.IResolvable): any;
export declare class SyntheticsGlobalVariableOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsGlobalVariableOptions | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsGlobalVariableOptions | cdktn.IResolvable | undefined);
    private _totpParameters;
    get totpParameters(): SyntheticsGlobalVariableOptionsTotpParametersList;
    putTotpParameters(value: SyntheticsGlobalVariableOptionsTotpParameters[] | cdktn.IResolvable): void;
    resetTotpParameters(): void;
    get totpParametersInput(): cdktn.IResolvable | SyntheticsGlobalVariableOptionsTotpParameters[] | undefined;
}
export declare class SyntheticsGlobalVariableOptionsList extends cdktn.ComplexList {
    internalValue?: SyntheticsGlobalVariableOptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsGlobalVariableOptionsOutputReference;
}
export interface SyntheticsGlobalVariableParseTestOptionsParser {
    /**
    * Type of parser to extract the value. Valid values are `raw`, `json_path`, `regex`, `x_path`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#type SyntheticsGlobalVariable#type}
    */
    readonly type: string;
    /**
    * Value for the parser to use, required for type `json_path` or `regex`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#value SyntheticsGlobalVariable#value}
    */
    readonly value?: string;
}
export declare function syntheticsGlobalVariableParseTestOptionsParserToTerraform(struct?: SyntheticsGlobalVariableParseTestOptionsParser | cdktn.IResolvable): any;
export declare function syntheticsGlobalVariableParseTestOptionsParserToHclTerraform(struct?: SyntheticsGlobalVariableParseTestOptionsParser | cdktn.IResolvable): any;
export declare class SyntheticsGlobalVariableParseTestOptionsParserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsGlobalVariableParseTestOptionsParser | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsGlobalVariableParseTestOptionsParser | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class SyntheticsGlobalVariableParseTestOptionsParserList extends cdktn.ComplexList {
    internalValue?: SyntheticsGlobalVariableParseTestOptionsParser[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsGlobalVariableParseTestOptionsParserOutputReference;
}
export interface SyntheticsGlobalVariableParseTestOptions {
    /**
    * Required when type = `http_header`. Defines the header to use to extract the value
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#field SyntheticsGlobalVariable#field}
    */
    readonly field?: string;
    /**
    * When type is `local_variable`, name of the local variable to use to extract the value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#local_variable_name SyntheticsGlobalVariable#local_variable_name}
    */
    readonly localVariableName?: string;
    /**
    * Defines the source to use to extract the value. Valid values are `http_body`, `http_header`, `http_status_code`, `local_variable`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#type SyntheticsGlobalVariable#type}
    */
    readonly type: string;
    /**
    * parser block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#parser SyntheticsGlobalVariable#parser}
    */
    readonly parser?: SyntheticsGlobalVariableParseTestOptionsParser[] | cdktn.IResolvable;
}
export declare function syntheticsGlobalVariableParseTestOptionsToTerraform(struct?: SyntheticsGlobalVariableParseTestOptions | cdktn.IResolvable): any;
export declare function syntheticsGlobalVariableParseTestOptionsToHclTerraform(struct?: SyntheticsGlobalVariableParseTestOptions | cdktn.IResolvable): any;
export declare class SyntheticsGlobalVariableParseTestOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsGlobalVariableParseTestOptions | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsGlobalVariableParseTestOptions | cdktn.IResolvable | undefined);
    private _field?;
    get field(): string;
    set field(value: string);
    resetField(): void;
    get fieldInput(): string | undefined;
    private _localVariableName?;
    get localVariableName(): string;
    set localVariableName(value: string);
    resetLocalVariableName(): void;
    get localVariableNameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _parser;
    get parser(): SyntheticsGlobalVariableParseTestOptionsParserList;
    putParser(value: SyntheticsGlobalVariableParseTestOptionsParser[] | cdktn.IResolvable): void;
    resetParser(): void;
    get parserInput(): cdktn.IResolvable | SyntheticsGlobalVariableParseTestOptionsParser[] | undefined;
}
export declare class SyntheticsGlobalVariableParseTestOptionsList extends cdktn.ComplexList {
    internalValue?: SyntheticsGlobalVariableParseTestOptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsGlobalVariableParseTestOptionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable datadog_synthetics_global_variable}
*/
export declare class SyntheticsGlobalVariable extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_synthetics_global_variable";
    /**
    * Generates CDKTN code for importing a SyntheticsGlobalVariable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SyntheticsGlobalVariable to import
    * @param importFromId The id of the existing SyntheticsGlobalVariable that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SyntheticsGlobalVariable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_global_variable datadog_synthetics_global_variable} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SyntheticsGlobalVariableConfig
    */
    constructor(scope: Construct, id: string, config: SyntheticsGlobalVariableConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _isFido?;
    get isFido(): boolean | cdktn.IResolvable;
    set isFido(value: boolean | cdktn.IResolvable);
    resetIsFido(): void;
    get isFidoInput(): boolean | cdktn.IResolvable | undefined;
    private _isTotp?;
    get isTotp(): boolean | cdktn.IResolvable;
    set isTotp(value: boolean | cdktn.IResolvable);
    resetIsTotp(): void;
    get isTotpInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parseTestId?;
    get parseTestId(): string;
    set parseTestId(value: string);
    resetParseTestId(): void;
    get parseTestIdInput(): string | undefined;
    private _restrictedRoles?;
    get restrictedRoles(): string[];
    set restrictedRoles(value: string[]);
    resetRestrictedRoles(): void;
    get restrictedRolesInput(): string[] | undefined;
    private _secure?;
    get secure(): boolean | cdktn.IResolvable;
    set secure(value: boolean | cdktn.IResolvable);
    resetSecure(): void;
    get secureInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _valueWo?;
    get valueWo(): string;
    set valueWo(value: string);
    resetValueWo(): void;
    get valueWoInput(): string | undefined;
    private _valueWoVersion?;
    get valueWoVersion(): string;
    set valueWoVersion(value: string);
    resetValueWoVersion(): void;
    get valueWoVersionInput(): string | undefined;
    private _options;
    get options(): SyntheticsGlobalVariableOptionsList;
    putOptions(value: SyntheticsGlobalVariableOptions[] | cdktn.IResolvable): void;
    resetOptions(): void;
    get optionsInput(): cdktn.IResolvable | SyntheticsGlobalVariableOptions[] | undefined;
    private _parseTestOptions;
    get parseTestOptions(): SyntheticsGlobalVariableParseTestOptionsList;
    putParseTestOptions(value: SyntheticsGlobalVariableParseTestOptions[] | cdktn.IResolvable): void;
    resetParseTestOptions(): void;
    get parseTestOptionsInput(): cdktn.IResolvable | SyntheticsGlobalVariableParseTestOptions[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
