/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogMetricTagsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The metric for which to fetch tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/metric_tags#metric DataDatadogMetricTags#metric}
    */
    readonly metric: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/metric_tags datadog_metric_tags}
*/
export declare class DataDatadogMetricTags extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_metric_tags";
    /**
    * Generates CDKTN code for importing a DataDatadogMetricTags resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogMetricTags to import
    * @param importFromId The id of the existing DataDatadogMetricTags that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/metric_tags#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogMetricTags to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/metric_tags datadog_metric_tags} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogMetricTagsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogMetricTagsConfig);
    get id(): string;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    get tags(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
