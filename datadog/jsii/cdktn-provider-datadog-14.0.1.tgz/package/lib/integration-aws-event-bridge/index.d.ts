/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IntegrationAwsEventBridgeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Your AWS Account ID without dashes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_event_bridge#account_id IntegrationAwsEventBridge#account_id}
    */
    readonly accountId: string;
    /**
    * True if Datadog should create the event bus in addition to the event source. Requires the `events:CreateEventBus` permission. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_event_bridge#create_event_bus IntegrationAwsEventBridge#create_event_bus}
    */
    readonly createEventBus?: boolean | cdktn.IResolvable;
    /**
    * The given part of the event source name, which is then combined with an assigned suffix to form the full name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_event_bridge#event_generator_name IntegrationAwsEventBridge#event_generator_name}
    */
    readonly eventGeneratorName: string;
    /**
    * The event source's [AWS region](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_event_bridge#region IntegrationAwsEventBridge#region}
    */
    readonly region: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_event_bridge datadog_integration_aws_event_bridge}
*/
export declare class IntegrationAwsEventBridge extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_integration_aws_event_bridge";
    /**
    * Generates CDKTN code for importing a IntegrationAwsEventBridge resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IntegrationAwsEventBridge to import
    * @param importFromId The id of the existing IntegrationAwsEventBridge that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_event_bridge#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IntegrationAwsEventBridge to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_event_bridge datadog_integration_aws_event_bridge} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IntegrationAwsEventBridgeConfig
    */
    constructor(scope: Construct, id: string, config: IntegrationAwsEventBridgeConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _createEventBus?;
    get createEventBus(): boolean | cdktn.IResolvable;
    set createEventBus(value: boolean | cdktn.IResolvable);
    resetCreateEventBus(): void;
    get createEventBusInput(): boolean | cdktn.IResolvable | undefined;
    private _eventGeneratorName?;
    get eventGeneratorName(): string;
    set eventGeneratorName(value: string);
    get eventGeneratorNameInput(): string | undefined;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
