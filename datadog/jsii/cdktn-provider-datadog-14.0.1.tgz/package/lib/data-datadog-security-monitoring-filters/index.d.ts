/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogSecurityMonitoringFiltersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/security_monitoring_filters#id DataDatadogSecurityMonitoringFilters#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataDatadogSecurityMonitoringFiltersFiltersExclusionFilter {
}
export declare function dataDatadogSecurityMonitoringFiltersFiltersExclusionFilterToTerraform(struct?: DataDatadogSecurityMonitoringFiltersFiltersExclusionFilter): any;
export declare function dataDatadogSecurityMonitoringFiltersFiltersExclusionFilterToHclTerraform(struct?: DataDatadogSecurityMonitoringFiltersFiltersExclusionFilter): any;
export declare class DataDatadogSecurityMonitoringFiltersFiltersExclusionFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringFiltersFiltersExclusionFilter | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringFiltersFiltersExclusionFilter | undefined);
    get name(): string;
    get query(): string;
}
export declare class DataDatadogSecurityMonitoringFiltersFiltersExclusionFilterList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringFiltersFiltersExclusionFilterOutputReference;
}
export interface DataDatadogSecurityMonitoringFiltersFilters {
}
export declare function dataDatadogSecurityMonitoringFiltersFiltersToTerraform(struct?: DataDatadogSecurityMonitoringFiltersFilters): any;
export declare function dataDatadogSecurityMonitoringFiltersFiltersToHclTerraform(struct?: DataDatadogSecurityMonitoringFiltersFilters): any;
export declare class DataDatadogSecurityMonitoringFiltersFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringFiltersFilters | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringFiltersFilters | undefined);
    private _exclusionFilter;
    get exclusionFilter(): DataDatadogSecurityMonitoringFiltersFiltersExclusionFilterList;
    get filteredDataType(): string;
    get isEnabled(): cdktn.IResolvable;
    get name(): string;
    get query(): string;
    get version(): number;
}
export declare class DataDatadogSecurityMonitoringFiltersFiltersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringFiltersFiltersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/security_monitoring_filters datadog_security_monitoring_filters}
*/
export declare class DataDatadogSecurityMonitoringFilters extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_security_monitoring_filters";
    /**
    * Generates CDKTN code for importing a DataDatadogSecurityMonitoringFilters resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogSecurityMonitoringFilters to import
    * @param importFromId The id of the existing DataDatadogSecurityMonitoringFilters that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/security_monitoring_filters#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogSecurityMonitoringFilters to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/security_monitoring_filters datadog_security_monitoring_filters} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogSecurityMonitoringFiltersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogSecurityMonitoringFiltersConfig);
    private _filters;
    get filters(): DataDatadogSecurityMonitoringFiltersFiltersList;
    get filtersIds(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
