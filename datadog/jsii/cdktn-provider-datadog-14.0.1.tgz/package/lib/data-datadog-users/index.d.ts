/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogUsersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Filter all users by the given string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/users#filter DataDatadogUsers#filter}
    */
    readonly filter?: string;
    /**
    * Filter on status attribute. Comma-separated list with possible values of Active, Pending, and Disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/users#filter_status DataDatadogUsers#filter_status}
    */
    readonly filterStatus?: string;
}
export interface DataDatadogUsersUsers {
}
export declare function dataDatadogUsersUsersToTerraform(struct?: DataDatadogUsersUsers): any;
export declare function dataDatadogUsersUsersToHclTerraform(struct?: DataDatadogUsersUsers): any;
export declare class DataDatadogUsersUsersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogUsersUsers | undefined;
    set internalValue(value: DataDatadogUsersUsers | undefined);
    get createdAt(): string;
    get disabled(): cdktn.IResolvable;
    get email(): string;
    get handle(): string;
    get icon(): string;
    get id(): string;
    get mfaEnabled(): cdktn.IResolvable;
    get modifiedAt(): string;
    get name(): string;
    get serviceAccount(): cdktn.IResolvable;
    get status(): string;
    get title(): string;
    get verified(): cdktn.IResolvable;
}
export declare class DataDatadogUsersUsersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogUsersUsersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/users datadog_users}
*/
export declare class DataDatadogUsers extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_users";
    /**
    * Generates CDKTN code for importing a DataDatadogUsers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogUsers to import
    * @param importFromId The id of the existing DataDatadogUsers that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/users#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogUsers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/users datadog_users} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogUsersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogUsersConfig);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _filterStatus?;
    get filterStatus(): string;
    set filterStatus(value: string);
    resetFilterStatus(): void;
    get filterStatusInput(): string | undefined;
    get id(): string;
    private _users;
    get users(): DataDatadogUsersUsersList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
