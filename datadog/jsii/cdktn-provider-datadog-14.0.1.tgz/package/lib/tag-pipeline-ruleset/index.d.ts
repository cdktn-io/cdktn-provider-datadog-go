/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TagPipelineRulesetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether the ruleset is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#enabled TagPipelineRuleset#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The name of the ruleset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#name TagPipelineRuleset#name}
    */
    readonly name: string;
    /**
    * rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#rules TagPipelineRuleset#rules}
    */
    readonly rules?: TagPipelineRulesetRules[] | cdktn.IResolvable;
}
export interface TagPipelineRulesetRulesMapping {
    /**
    * The destination key for the mapping.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#destination_key TagPipelineRuleset#destination_key}
    */
    readonly destinationKey?: string;
    /**
    * Whether to apply the mapping only if the destination key doesn't exist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#if_not_exists TagPipelineRuleset#if_not_exists}
    */
    readonly ifNotExists?: boolean | cdktn.IResolvable;
    /**
    * Behavior when the tag already exists. Valid values: `append` (append to the existing tag value), `replace` (replace existing tag value), `do_not_apply` (never apply if tag already exists). Valid values are `append`, `replace`, `do_not_apply`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#if_tag_exists TagPipelineRuleset#if_tag_exists}
    */
    readonly ifTagExists?: string;
    /**
    * The source keys for the mapping.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#source_keys TagPipelineRuleset#source_keys}
    */
    readonly sourceKeys?: string[];
}
export declare function tagPipelineRulesetRulesMappingToTerraform(struct?: TagPipelineRulesetRulesMapping | cdktn.IResolvable): any;
export declare function tagPipelineRulesetRulesMappingToHclTerraform(struct?: TagPipelineRulesetRulesMapping | cdktn.IResolvable): any;
export declare class TagPipelineRulesetRulesMappingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TagPipelineRulesetRulesMapping | cdktn.IResolvable | undefined;
    set internalValue(value: TagPipelineRulesetRulesMapping | cdktn.IResolvable | undefined);
    private _destinationKey?;
    get destinationKey(): string;
    set destinationKey(value: string);
    resetDestinationKey(): void;
    get destinationKeyInput(): string | undefined;
    private _ifNotExists?;
    get ifNotExists(): boolean | cdktn.IResolvable;
    set ifNotExists(value: boolean | cdktn.IResolvable);
    resetIfNotExists(): void;
    get ifNotExistsInput(): boolean | cdktn.IResolvable | undefined;
    private _ifTagExists?;
    get ifTagExists(): string;
    set ifTagExists(value: string);
    resetIfTagExists(): void;
    get ifTagExistsInput(): string | undefined;
    private _sourceKeys?;
    get sourceKeys(): string[];
    set sourceKeys(value: string[]);
    resetSourceKeys(): void;
    get sourceKeysInput(): string[] | undefined;
}
export interface TagPipelineRulesetRulesQueryAddition {
    /**
    * The key to add.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#key TagPipelineRuleset#key}
    */
    readonly key?: string;
    /**
    * The value to add.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#value TagPipelineRuleset#value}
    */
    readonly value?: string;
}
export declare function tagPipelineRulesetRulesQueryAdditionToTerraform(struct?: TagPipelineRulesetRulesQueryAddition | cdktn.IResolvable): any;
export declare function tagPipelineRulesetRulesQueryAdditionToHclTerraform(struct?: TagPipelineRulesetRulesQueryAddition | cdktn.IResolvable): any;
export declare class TagPipelineRulesetRulesQueryAdditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TagPipelineRulesetRulesQueryAddition | cdktn.IResolvable | undefined;
    set internalValue(value: TagPipelineRulesetRulesQueryAddition | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface TagPipelineRulesetRulesQuery {
    /**
    * Whether the query matching is case insensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#case_insensitivity TagPipelineRuleset#case_insensitivity}
    */
    readonly caseInsensitivity?: boolean | cdktn.IResolvable;
    /**
    * Whether to apply the query only if the key doesn't exist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#if_not_exists TagPipelineRuleset#if_not_exists}
    */
    readonly ifNotExists?: boolean | cdktn.IResolvable;
    /**
    * Behavior when the tag already exists. Valid values: `append` (append to the existing tag value), `replace` (replace existing tag value), `do_not_apply` (never apply if tag already exists). Valid values are `append`, `replace`, `do_not_apply`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#if_tag_exists TagPipelineRuleset#if_tag_exists}
    */
    readonly ifTagExists?: string;
    /**
    * The query string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#query TagPipelineRuleset#query}
    */
    readonly query?: string;
    /**
    * addition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#addition TagPipelineRuleset#addition}
    */
    readonly addition?: TagPipelineRulesetRulesQueryAddition;
}
export declare function tagPipelineRulesetRulesQueryToTerraform(struct?: TagPipelineRulesetRulesQuery | cdktn.IResolvable): any;
export declare function tagPipelineRulesetRulesQueryToHclTerraform(struct?: TagPipelineRulesetRulesQuery | cdktn.IResolvable): any;
export declare class TagPipelineRulesetRulesQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TagPipelineRulesetRulesQuery | cdktn.IResolvable | undefined;
    set internalValue(value: TagPipelineRulesetRulesQuery | cdktn.IResolvable | undefined);
    private _caseInsensitivity?;
    get caseInsensitivity(): boolean | cdktn.IResolvable;
    set caseInsensitivity(value: boolean | cdktn.IResolvable);
    resetCaseInsensitivity(): void;
    get caseInsensitivityInput(): boolean | cdktn.IResolvable | undefined;
    private _ifNotExists?;
    get ifNotExists(): boolean | cdktn.IResolvable;
    set ifNotExists(value: boolean | cdktn.IResolvable);
    resetIfNotExists(): void;
    get ifNotExistsInput(): boolean | cdktn.IResolvable | undefined;
    private _ifTagExists?;
    get ifTagExists(): string;
    set ifTagExists(value: string);
    resetIfTagExists(): void;
    get ifTagExistsInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
    private _addition;
    get addition(): TagPipelineRulesetRulesQueryAdditionOutputReference;
    putAddition(value: TagPipelineRulesetRulesQueryAddition): void;
    resetAddition(): void;
    get additionInput(): cdktn.IResolvable | TagPipelineRulesetRulesQueryAddition | undefined;
}
export interface TagPipelineRulesetRulesReferenceTableFieldPairs {
    /**
    * The input column name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#input_column TagPipelineRuleset#input_column}
    */
    readonly inputColumn?: string;
    /**
    * The output key name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#output_key TagPipelineRuleset#output_key}
    */
    readonly outputKey?: string;
}
export declare function tagPipelineRulesetRulesReferenceTableFieldPairsToTerraform(struct?: TagPipelineRulesetRulesReferenceTableFieldPairs | cdktn.IResolvable): any;
export declare function tagPipelineRulesetRulesReferenceTableFieldPairsToHclTerraform(struct?: TagPipelineRulesetRulesReferenceTableFieldPairs | cdktn.IResolvable): any;
export declare class TagPipelineRulesetRulesReferenceTableFieldPairsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TagPipelineRulesetRulesReferenceTableFieldPairs | cdktn.IResolvable | undefined;
    set internalValue(value: TagPipelineRulesetRulesReferenceTableFieldPairs | cdktn.IResolvable | undefined);
    private _inputColumn?;
    get inputColumn(): string;
    set inputColumn(value: string);
    resetInputColumn(): void;
    get inputColumnInput(): string | undefined;
    private _outputKey?;
    get outputKey(): string;
    set outputKey(value: string);
    resetOutputKey(): void;
    get outputKeyInput(): string | undefined;
}
export declare class TagPipelineRulesetRulesReferenceTableFieldPairsList extends cdktn.ComplexList {
    internalValue?: TagPipelineRulesetRulesReferenceTableFieldPairs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TagPipelineRulesetRulesReferenceTableFieldPairsOutputReference;
}
export interface TagPipelineRulesetRulesReferenceTable {
    /**
    * Whether the reference table lookup is case insensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#case_insensitivity TagPipelineRuleset#case_insensitivity}
    */
    readonly caseInsensitivity?: boolean | cdktn.IResolvable;
    /**
    * Whether to apply the reference table only if the key doesn't exist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#if_not_exists TagPipelineRuleset#if_not_exists}
    */
    readonly ifNotExists?: boolean | cdktn.IResolvable;
    /**
    * Behavior when the tag already exists. Valid values: `append` (append to the existing tag value), `replace` (replace existing tag value), `do_not_apply` (never apply if tag already exists). Valid values are `append`, `replace`, `do_not_apply`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#if_tag_exists TagPipelineRuleset#if_tag_exists}
    */
    readonly ifTagExists?: string;
    /**
    * The source keys for the reference table lookup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#source_keys TagPipelineRuleset#source_keys}
    */
    readonly sourceKeys?: string[];
    /**
    * The name of the reference table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#table_name TagPipelineRuleset#table_name}
    */
    readonly tableName?: string;
    /**
    * field_pairs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#field_pairs TagPipelineRuleset#field_pairs}
    */
    readonly fieldPairs?: TagPipelineRulesetRulesReferenceTableFieldPairs[] | cdktn.IResolvable;
}
export declare function tagPipelineRulesetRulesReferenceTableToTerraform(struct?: TagPipelineRulesetRulesReferenceTable | cdktn.IResolvable): any;
export declare function tagPipelineRulesetRulesReferenceTableToHclTerraform(struct?: TagPipelineRulesetRulesReferenceTable | cdktn.IResolvable): any;
export declare class TagPipelineRulesetRulesReferenceTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TagPipelineRulesetRulesReferenceTable | cdktn.IResolvable | undefined;
    set internalValue(value: TagPipelineRulesetRulesReferenceTable | cdktn.IResolvable | undefined);
    private _caseInsensitivity?;
    get caseInsensitivity(): boolean | cdktn.IResolvable;
    set caseInsensitivity(value: boolean | cdktn.IResolvable);
    resetCaseInsensitivity(): void;
    get caseInsensitivityInput(): boolean | cdktn.IResolvable | undefined;
    private _ifNotExists?;
    get ifNotExists(): boolean | cdktn.IResolvable;
    set ifNotExists(value: boolean | cdktn.IResolvable);
    resetIfNotExists(): void;
    get ifNotExistsInput(): boolean | cdktn.IResolvable | undefined;
    private _ifTagExists?;
    get ifTagExists(): string;
    set ifTagExists(value: string);
    resetIfTagExists(): void;
    get ifTagExistsInput(): string | undefined;
    private _sourceKeys?;
    get sourceKeys(): string[];
    set sourceKeys(value: string[]);
    resetSourceKeys(): void;
    get sourceKeysInput(): string[] | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    resetTableName(): void;
    get tableNameInput(): string | undefined;
    private _fieldPairs;
    get fieldPairs(): TagPipelineRulesetRulesReferenceTableFieldPairsList;
    putFieldPairs(value: TagPipelineRulesetRulesReferenceTableFieldPairs[] | cdktn.IResolvable): void;
    resetFieldPairs(): void;
    get fieldPairsInput(): cdktn.IResolvable | TagPipelineRulesetRulesReferenceTableFieldPairs[] | undefined;
}
export interface TagPipelineRulesetRules {
    /**
    * Whether the rule is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#enabled TagPipelineRuleset#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * The name of the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#name TagPipelineRuleset#name}
    */
    readonly name: string;
    /**
    * mapping block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#mapping TagPipelineRuleset#mapping}
    */
    readonly mapping?: TagPipelineRulesetRulesMapping;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#query TagPipelineRuleset#query}
    */
    readonly query?: TagPipelineRulesetRulesQuery;
    /**
    * reference_table block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#reference_table TagPipelineRuleset#reference_table}
    */
    readonly referenceTable?: TagPipelineRulesetRulesReferenceTable;
}
export declare function tagPipelineRulesetRulesToTerraform(struct?: TagPipelineRulesetRules | cdktn.IResolvable): any;
export declare function tagPipelineRulesetRulesToHclTerraform(struct?: TagPipelineRulesetRules | cdktn.IResolvable): any;
export declare class TagPipelineRulesetRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TagPipelineRulesetRules | cdktn.IResolvable | undefined;
    set internalValue(value: TagPipelineRulesetRules | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _metadata;
    get metadata(): cdktn.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _mapping;
    get mapping(): TagPipelineRulesetRulesMappingOutputReference;
    putMapping(value: TagPipelineRulesetRulesMapping): void;
    resetMapping(): void;
    get mappingInput(): cdktn.IResolvable | TagPipelineRulesetRulesMapping | undefined;
    private _query;
    get query(): TagPipelineRulesetRulesQueryOutputReference;
    putQuery(value: TagPipelineRulesetRulesQuery): void;
    resetQuery(): void;
    get queryInput(): cdktn.IResolvable | TagPipelineRulesetRulesQuery | undefined;
    private _referenceTable;
    get referenceTable(): TagPipelineRulesetRulesReferenceTableOutputReference;
    putReferenceTable(value: TagPipelineRulesetRulesReferenceTable): void;
    resetReferenceTable(): void;
    get referenceTableInput(): cdktn.IResolvable | TagPipelineRulesetRulesReferenceTable | undefined;
}
export declare class TagPipelineRulesetRulesList extends cdktn.ComplexList {
    internalValue?: TagPipelineRulesetRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TagPipelineRulesetRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset datadog_tag_pipeline_ruleset}
*/
export declare class TagPipelineRuleset extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_tag_pipeline_ruleset";
    /**
    * Generates CDKTN code for importing a TagPipelineRuleset resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TagPipelineRuleset to import
    * @param importFromId The id of the existing TagPipelineRuleset that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TagPipelineRuleset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/tag_pipeline_ruleset datadog_tag_pipeline_ruleset} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TagPipelineRulesetConfig
    */
    constructor(scope: Construct, id: string, config: TagPipelineRulesetConfig);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get position(): number;
    get version(): number;
    private _rules;
    get rules(): TagPipelineRulesetRulesList;
    putRules(value: TagPipelineRulesetRules[] | cdktn.IResolvable): void;
    resetRules(): void;
    get rulesInput(): cdktn.IResolvable | TagPipelineRulesetRules[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
