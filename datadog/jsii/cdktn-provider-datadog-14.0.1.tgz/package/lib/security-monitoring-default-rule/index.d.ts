/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SecurityMonitoringDefaultRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Custom Message (will override default message) for generated signals.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#custom_message SecurityMonitoringDefaultRule#custom_message}
    */
    readonly customMessage?: string;
    /**
    * The name (will override default name) of the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#custom_name SecurityMonitoringDefaultRule#custom_name}
    */
    readonly customName?: string;
    /**
    * Custom tags for generated signals.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#custom_tags SecurityMonitoringDefaultRule#custom_tags}
    */
    readonly customTags?: string[];
    /**
    * Enable the rule. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#enabled SecurityMonitoringDefaultRule#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#id SecurityMonitoringDefaultRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * case block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#case SecurityMonitoringDefaultRule#case}
    */
    readonly case?: SecurityMonitoringDefaultRuleCase[] | cdktn.IResolvable;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#filter SecurityMonitoringDefaultRule#filter}
    */
    readonly filter?: SecurityMonitoringDefaultRuleFilter[] | cdktn.IResolvable;
    /**
    * options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#options SecurityMonitoringDefaultRule#options}
    */
    readonly options?: SecurityMonitoringDefaultRuleOptions;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#query SecurityMonitoringDefaultRule#query}
    */
    readonly query?: SecurityMonitoringDefaultRuleQuery[] | cdktn.IResolvable;
}
export interface SecurityMonitoringDefaultRuleCase {
    /**
    * Status of the rule case to override. Valid values are `info`, `low`, `medium`, `high`, `critical`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#custom_status SecurityMonitoringDefaultRule#custom_status}
    */
    readonly customStatus?: string;
    /**
    * Notification targets for each rule case.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#notifications SecurityMonitoringDefaultRule#notifications}
    */
    readonly notifications?: string[];
    /**
    * Status of the rule case to match. Valid values are `info`, `low`, `medium`, `high`, `critical`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#status SecurityMonitoringDefaultRule#status}
    */
    readonly status: string;
}
export declare function securityMonitoringDefaultRuleCaseToTerraform(struct?: SecurityMonitoringDefaultRuleCase | cdktn.IResolvable): any;
export declare function securityMonitoringDefaultRuleCaseToHclTerraform(struct?: SecurityMonitoringDefaultRuleCase | cdktn.IResolvable): any;
export declare class SecurityMonitoringDefaultRuleCaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SecurityMonitoringDefaultRuleCase | cdktn.IResolvable | undefined;
    set internalValue(value: SecurityMonitoringDefaultRuleCase | cdktn.IResolvable | undefined);
    private _customStatus?;
    get customStatus(): string;
    set customStatus(value: string);
    resetCustomStatus(): void;
    get customStatusInput(): string | undefined;
    private _notifications?;
    get notifications(): string[];
    set notifications(value: string[]);
    resetNotifications(): void;
    get notificationsInput(): string[] | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
}
export declare class SecurityMonitoringDefaultRuleCaseList extends cdktn.ComplexList {
    internalValue?: SecurityMonitoringDefaultRuleCase[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SecurityMonitoringDefaultRuleCaseOutputReference;
}
export interface SecurityMonitoringDefaultRuleFilter {
    /**
    * The type of filtering action. Allowed enum values: require, suppress Valid values are `require`, `suppress`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#action SecurityMonitoringDefaultRule#action}
    */
    readonly action: string;
    /**
    * Query for selecting logs to apply the filtering action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#query SecurityMonitoringDefaultRule#query}
    */
    readonly query: string;
}
export declare function securityMonitoringDefaultRuleFilterToTerraform(struct?: SecurityMonitoringDefaultRuleFilter | cdktn.IResolvable): any;
export declare function securityMonitoringDefaultRuleFilterToHclTerraform(struct?: SecurityMonitoringDefaultRuleFilter | cdktn.IResolvable): any;
export declare class SecurityMonitoringDefaultRuleFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SecurityMonitoringDefaultRuleFilter | cdktn.IResolvable | undefined;
    set internalValue(value: SecurityMonitoringDefaultRuleFilter | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class SecurityMonitoringDefaultRuleFilterList extends cdktn.ComplexList {
    internalValue?: SecurityMonitoringDefaultRuleFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SecurityMonitoringDefaultRuleFilterOutputReference;
}
export interface SecurityMonitoringDefaultRuleOptions {
    /**
    * If true, signals in non-production environments have a lower severity than what is defined by the rule case, which can reduce noise. The decrement is applied when the environment tag of the signal starts with `staging`, `test`, or `dev`. Only available when the rule type is `log_detection`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#decrease_criticality_based_on_env SecurityMonitoringDefaultRule#decrease_criticality_based_on_env}
    */
    readonly decreaseCriticalityBasedOnEnv?: boolean | cdktn.IResolvable;
}
export declare function securityMonitoringDefaultRuleOptionsToTerraform(struct?: SecurityMonitoringDefaultRuleOptionsOutputReference | SecurityMonitoringDefaultRuleOptions): any;
export declare function securityMonitoringDefaultRuleOptionsToHclTerraform(struct?: SecurityMonitoringDefaultRuleOptionsOutputReference | SecurityMonitoringDefaultRuleOptions): any;
export declare class SecurityMonitoringDefaultRuleOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SecurityMonitoringDefaultRuleOptions | undefined;
    set internalValue(value: SecurityMonitoringDefaultRuleOptions | undefined);
    private _decreaseCriticalityBasedOnEnv?;
    get decreaseCriticalityBasedOnEnv(): boolean | cdktn.IResolvable;
    set decreaseCriticalityBasedOnEnv(value: boolean | cdktn.IResolvable);
    resetDecreaseCriticalityBasedOnEnv(): void;
    get decreaseCriticalityBasedOnEnvInput(): boolean | cdktn.IResolvable | undefined;
}
export interface SecurityMonitoringDefaultRuleQueryAgentRule {
    /**
    * **Deprecated**. It won't be applied anymore.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#agent_rule_id SecurityMonitoringDefaultRule#agent_rule_id}
    */
    readonly agentRuleId: string;
    /**
    * **Deprecated**. It won't be applied anymore.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#expression SecurityMonitoringDefaultRule#expression}
    */
    readonly expression: string;
}
export declare function securityMonitoringDefaultRuleQueryAgentRuleToTerraform(struct?: SecurityMonitoringDefaultRuleQueryAgentRule | cdktn.IResolvable): any;
export declare function securityMonitoringDefaultRuleQueryAgentRuleToHclTerraform(struct?: SecurityMonitoringDefaultRuleQueryAgentRule | cdktn.IResolvable): any;
export declare class SecurityMonitoringDefaultRuleQueryAgentRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SecurityMonitoringDefaultRuleQueryAgentRule | cdktn.IResolvable | undefined;
    set internalValue(value: SecurityMonitoringDefaultRuleQueryAgentRule | cdktn.IResolvable | undefined);
    private _agentRuleId?;
    get agentRuleId(): string;
    set agentRuleId(value: string);
    get agentRuleIdInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
}
export declare class SecurityMonitoringDefaultRuleQueryAgentRuleList extends cdktn.ComplexList {
    internalValue?: SecurityMonitoringDefaultRuleQueryAgentRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SecurityMonitoringDefaultRuleQueryAgentRuleOutputReference;
}
export interface SecurityMonitoringDefaultRuleQuery {
    /**
    * The aggregation type. For Signal Correlation rules, it must be event_count. Valid values are `count`, `cardinality`, `sum`, `max`, `new_value`, `geo_data`, `event_count`, `none`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#aggregation SecurityMonitoringDefaultRule#aggregation}
    */
    readonly aggregation?: string;
    /**
    * Query extension to append to the logs query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#custom_query_extension SecurityMonitoringDefaultRule#custom_query_extension}
    */
    readonly customQueryExtension?: string;
    /**
    * Source of events. Valid values are `logs`, `audit`, `app_sec_spans`, `spans`, `security_runtime`, `network`, `events`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#data_source SecurityMonitoringDefaultRule#data_source}
    */
    readonly dataSource?: string;
    /**
    * Field for which the cardinality is measured. Sent as an array.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#distinct_fields SecurityMonitoringDefaultRule#distinct_fields}
    */
    readonly distinctFields?: string[];
    /**
    * Fields to group by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#group_by_fields SecurityMonitoringDefaultRule#group_by_fields}
    */
    readonly groupByFields?: string[];
    /**
    * When false, events without a group-by value are ignored by the rule. When true, events with missing group-by fields are processed with `N/A`, replacing the missing values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#has_optional_group_by_fields SecurityMonitoringDefaultRule#has_optional_group_by_fields}
    */
    readonly hasOptionalGroupByFields?: boolean | cdktn.IResolvable;
    /**
    * The target field to aggregate over when using the `sum`, `max`, or `geo_data` aggregations. **Deprecated.** Configure `metrics` instead. This attribute will be removed in the next major version of the provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#metric SecurityMonitoringDefaultRule#metric}
    */
    readonly metric?: string;
    /**
    * Group of target fields to aggregate over when using the `sum`, `max`, `geo_data`, or `new_value` aggregations. The `sum`, `max`, and `geo_data` aggregations only accept one value in this list, whereas the `new_value` aggregation accepts up to five values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#metrics SecurityMonitoringDefaultRule#metrics}
    */
    readonly metrics?: string[];
    /**
    * Name of the query. Not compatible with `new_value` aggregations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#name SecurityMonitoringDefaultRule#name}
    */
    readonly name?: string;
    /**
    * Query to run on logs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#query SecurityMonitoringDefaultRule#query}
    */
    readonly query?: string;
    /**
    * agent_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#agent_rule SecurityMonitoringDefaultRule#agent_rule}
    */
    readonly agentRule?: SecurityMonitoringDefaultRuleQueryAgentRule[] | cdktn.IResolvable;
}
export declare function securityMonitoringDefaultRuleQueryToTerraform(struct?: SecurityMonitoringDefaultRuleQuery | cdktn.IResolvable): any;
export declare function securityMonitoringDefaultRuleQueryToHclTerraform(struct?: SecurityMonitoringDefaultRuleQuery | cdktn.IResolvable): any;
export declare class SecurityMonitoringDefaultRuleQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SecurityMonitoringDefaultRuleQuery | cdktn.IResolvable | undefined;
    set internalValue(value: SecurityMonitoringDefaultRuleQuery | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    resetAggregation(): void;
    get aggregationInput(): string | undefined;
    private _customQueryExtension?;
    get customQueryExtension(): string;
    set customQueryExtension(value: string);
    resetCustomQueryExtension(): void;
    get customQueryExtensionInput(): string | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    resetDataSource(): void;
    get dataSourceInput(): string | undefined;
    private _distinctFields?;
    get distinctFields(): string[];
    set distinctFields(value: string[]);
    resetDistinctFields(): void;
    get distinctFieldsInput(): string[] | undefined;
    private _groupByFields?;
    get groupByFields(): string[];
    set groupByFields(value: string[]);
    resetGroupByFields(): void;
    get groupByFieldsInput(): string[] | undefined;
    private _hasOptionalGroupByFields?;
    get hasOptionalGroupByFields(): boolean | cdktn.IResolvable;
    set hasOptionalGroupByFields(value: boolean | cdktn.IResolvable);
    resetHasOptionalGroupByFields(): void;
    get hasOptionalGroupByFieldsInput(): boolean | cdktn.IResolvable | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _metrics?;
    get metrics(): string[];
    set metrics(value: string[]);
    resetMetrics(): void;
    get metricsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
    private _agentRule;
    get agentRule(): SecurityMonitoringDefaultRuleQueryAgentRuleList;
    putAgentRule(value: SecurityMonitoringDefaultRuleQueryAgentRule[] | cdktn.IResolvable): void;
    resetAgentRule(): void;
    get agentRuleInput(): cdktn.IResolvable | SecurityMonitoringDefaultRuleQueryAgentRule[] | undefined;
}
export declare class SecurityMonitoringDefaultRuleQueryList extends cdktn.ComplexList {
    internalValue?: SecurityMonitoringDefaultRuleQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SecurityMonitoringDefaultRuleQueryOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule datadog_security_monitoring_default_rule}
*/
export declare class SecurityMonitoringDefaultRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_security_monitoring_default_rule";
    /**
    * Generates CDKTN code for importing a SecurityMonitoringDefaultRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecurityMonitoringDefaultRule to import
    * @param importFromId The id of the existing SecurityMonitoringDefaultRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecurityMonitoringDefaultRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_default_rule datadog_security_monitoring_default_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecurityMonitoringDefaultRuleConfig = {}
    */
    constructor(scope: Construct, id: string, config?: SecurityMonitoringDefaultRuleConfig);
    private _customMessage?;
    get customMessage(): string;
    set customMessage(value: string);
    resetCustomMessage(): void;
    get customMessageInput(): string | undefined;
    private _customName?;
    get customName(): string;
    set customName(value: string);
    resetCustomName(): void;
    get customNameInput(): string | undefined;
    private _customTags?;
    get customTags(): string[];
    set customTags(value: string[]);
    resetCustomTags(): void;
    get customTagsInput(): string[] | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get type(): string;
    private _case;
    get case(): SecurityMonitoringDefaultRuleCaseList;
    putCase(value: SecurityMonitoringDefaultRuleCase[] | cdktn.IResolvable): void;
    resetCase(): void;
    get caseInput(): cdktn.IResolvable | SecurityMonitoringDefaultRuleCase[] | undefined;
    private _filter;
    get filter(): SecurityMonitoringDefaultRuleFilterList;
    putFilter(value: SecurityMonitoringDefaultRuleFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | SecurityMonitoringDefaultRuleFilter[] | undefined;
    private _options;
    get options(): SecurityMonitoringDefaultRuleOptionsOutputReference;
    putOptions(value: SecurityMonitoringDefaultRuleOptions): void;
    resetOptions(): void;
    get optionsInput(): SecurityMonitoringDefaultRuleOptions | undefined;
    private _query;
    get query(): SecurityMonitoringDefaultRuleQueryList;
    putQuery(value: SecurityMonitoringDefaultRuleQuery[] | cdktn.IResolvable): void;
    resetQuery(): void;
    get queryInput(): cdktn.IResolvable | SecurityMonitoringDefaultRuleQuery[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
