/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComplianceCustomFrameworkConfig extends cdktn.TerraformMetaArguments {
    /**
    * The framework handle. String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/compliance_custom_framework#handle ComplianceCustomFramework#handle}
    */
    readonly handle: string;
    /**
    * The URL of the icon representing the framework
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/compliance_custom_framework#icon_url ComplianceCustomFramework#icon_url}
    */
    readonly iconUrl?: string;
    /**
    * The framework name. String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/compliance_custom_framework#name ComplianceCustomFramework#name}
    */
    readonly name: string;
    /**
    * The framework version. String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/compliance_custom_framework#version ComplianceCustomFramework#version}
    */
    readonly version: string;
    /**
    * requirements block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/compliance_custom_framework#requirements ComplianceCustomFramework#requirements}
    */
    readonly requirements?: ComplianceCustomFrameworkRequirements[] | cdktn.IResolvable;
}
export interface ComplianceCustomFrameworkRequirementsControls {
    /**
    * The name of the control. String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/compliance_custom_framework#name ComplianceCustomFramework#name}
    */
    readonly name: string;
    /**
    * The set of rules IDs for the control.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/compliance_custom_framework#rules_id ComplianceCustomFramework#rules_id}
    */
    readonly rulesId: string[];
}
export declare function complianceCustomFrameworkRequirementsControlsToTerraform(struct?: ComplianceCustomFrameworkRequirementsControls | cdktn.IResolvable): any;
export declare function complianceCustomFrameworkRequirementsControlsToHclTerraform(struct?: ComplianceCustomFrameworkRequirementsControls | cdktn.IResolvable): any;
export declare class ComplianceCustomFrameworkRequirementsControlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComplianceCustomFrameworkRequirementsControls | cdktn.IResolvable | undefined;
    set internalValue(value: ComplianceCustomFrameworkRequirementsControls | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _rulesId?;
    get rulesId(): string[];
    set rulesId(value: string[]);
    get rulesIdInput(): string[] | undefined;
}
export declare class ComplianceCustomFrameworkRequirementsControlsList extends cdktn.ComplexList {
    internalValue?: ComplianceCustomFrameworkRequirementsControls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComplianceCustomFrameworkRequirementsControlsOutputReference;
}
export interface ComplianceCustomFrameworkRequirements {
    /**
    * The name of the requirement. String length must be at least 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/compliance_custom_framework#name ComplianceCustomFramework#name}
    */
    readonly name: string;
    /**
    * controls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/compliance_custom_framework#controls ComplianceCustomFramework#controls}
    */
    readonly controls?: ComplianceCustomFrameworkRequirementsControls[] | cdktn.IResolvable;
}
export declare function complianceCustomFrameworkRequirementsToTerraform(struct?: ComplianceCustomFrameworkRequirements | cdktn.IResolvable): any;
export declare function complianceCustomFrameworkRequirementsToHclTerraform(struct?: ComplianceCustomFrameworkRequirements | cdktn.IResolvable): any;
export declare class ComplianceCustomFrameworkRequirementsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ComplianceCustomFrameworkRequirements | cdktn.IResolvable | undefined;
    set internalValue(value: ComplianceCustomFrameworkRequirements | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _controls;
    get controls(): ComplianceCustomFrameworkRequirementsControlsList;
    putControls(value: ComplianceCustomFrameworkRequirementsControls[] | cdktn.IResolvable): void;
    resetControls(): void;
    get controlsInput(): cdktn.IResolvable | ComplianceCustomFrameworkRequirementsControls[] | undefined;
}
export declare class ComplianceCustomFrameworkRequirementsList extends cdktn.ComplexList {
    internalValue?: ComplianceCustomFrameworkRequirements[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ComplianceCustomFrameworkRequirementsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/compliance_custom_framework datadog_compliance_custom_framework}
*/
export declare class ComplianceCustomFramework extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_compliance_custom_framework";
    /**
    * Generates CDKTN code for importing a ComplianceCustomFramework resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComplianceCustomFramework to import
    * @param importFromId The id of the existing ComplianceCustomFramework that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/compliance_custom_framework#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComplianceCustomFramework to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/compliance_custom_framework datadog_compliance_custom_framework} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComplianceCustomFrameworkConfig
    */
    constructor(scope: Construct, id: string, config: ComplianceCustomFrameworkConfig);
    private _handle?;
    get handle(): string;
    set handle(value: string);
    get handleInput(): string | undefined;
    private _iconUrl?;
    get iconUrl(): string;
    set iconUrl(value: string);
    resetIconUrl(): void;
    get iconUrlInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    private _requirements;
    get requirements(): ComplianceCustomFrameworkRequirementsList;
    putRequirements(value: ComplianceCustomFrameworkRequirements[] | cdktn.IResolvable): void;
    resetRequirements(): void;
    get requirementsInput(): cdktn.IResolvable | ComplianceCustomFrameworkRequirements[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
