/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogWorkflowAutomationConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the workflow.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/workflow_automation#id DataDatadogWorkflowAutomation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/workflow_automation datadog_workflow_automation}
*/
export declare class DataDatadogWorkflowAutomation extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_workflow_automation";
    /**
    * Generates CDKTN code for importing a DataDatadogWorkflowAutomation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogWorkflowAutomation to import
    * @param importFromId The id of the existing DataDatadogWorkflowAutomation that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/workflow_automation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogWorkflowAutomation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/workflow_automation datadog_workflow_automation} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogWorkflowAutomationConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogWorkflowAutomationConfig);
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get name(): string;
    get published(): cdktn.IResolvable;
    get specJson(): string;
    get tags(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
