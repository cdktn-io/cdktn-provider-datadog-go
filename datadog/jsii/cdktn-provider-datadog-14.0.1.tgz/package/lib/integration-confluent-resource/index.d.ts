/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IntegrationConfluentResourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Confluent Account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_confluent_resource#account_id IntegrationConfluentResource#account_id}
    */
    readonly accountId: string;
    /**
    * Enable the `custom.consumer_lag_offset` metric, which contains extra metric tags. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_confluent_resource#enable_custom_metrics IntegrationConfluentResource#enable_custom_metrics}
    */
    readonly enableCustomMetrics?: boolean | cdktn.IResolvable;
    /**
    * The ID associated with a Confluent resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_confluent_resource#resource_id IntegrationConfluentResource#resource_id}
    */
    readonly resourceId: string;
    /**
    * The resource type of the Resource. Can be `kafka`, `connector`, `ksql`, or `schema_registry`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_confluent_resource#resource_type IntegrationConfluentResource#resource_type}
    */
    readonly resourceType?: string;
    /**
    * A list of strings representing tags. Can be a single key, or key-value pairs separated by a colon.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_confluent_resource#tags IntegrationConfluentResource#tags}
    */
    readonly tags?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_confluent_resource datadog_integration_confluent_resource}
*/
export declare class IntegrationConfluentResource extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_integration_confluent_resource";
    /**
    * Generates CDKTN code for importing a IntegrationConfluentResource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IntegrationConfluentResource to import
    * @param importFromId The id of the existing IntegrationConfluentResource that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_confluent_resource#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IntegrationConfluentResource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_confluent_resource datadog_integration_confluent_resource} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IntegrationConfluentResourceConfig
    */
    constructor(scope: Construct, id: string, config: IntegrationConfluentResourceConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _enableCustomMetrics?;
    get enableCustomMetrics(): boolean | cdktn.IResolvable;
    set enableCustomMetrics(value: boolean | cdktn.IResolvable);
    resetEnableCustomMetrics(): void;
    get enableCustomMetricsInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    resetResourceType(): void;
    get resourceTypeInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
