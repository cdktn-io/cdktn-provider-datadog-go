/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CustomAllocationRulesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether to override UI-defined rules. When set to true, any rules created via the UI that are not defined in Terraform will be deleted and Terraform will be used as the source of truth for rules and their ordering. When set to false, any rules created via the UI that are at the end of order will be kept but will be warned, otherwise an error will be thrown in terraform plan phase. Default is false
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rules#override_ui_defined_resources CustomAllocationRules#override_ui_defined_resources}
    */
    readonly overrideUiDefinedResources?: boolean | cdktn.IResolvable;
    /**
    * The list of Custom Allocation Rule IDs, in order. Rules are executed in the order specified in this list. Comes from the `id` field on a `datadog_custom_allocation_rule` resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rules#rule_ids CustomAllocationRules#rule_ids}
    */
    readonly ruleIds: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rules datadog_custom_allocation_rules}
*/
export declare class CustomAllocationRules extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_custom_allocation_rules";
    /**
    * Generates CDKTN code for importing a CustomAllocationRules resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CustomAllocationRules to import
    * @param importFromId The id of the existing CustomAllocationRules that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CustomAllocationRules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/custom_allocation_rules datadog_custom_allocation_rules} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CustomAllocationRulesConfig
    */
    constructor(scope: Construct, id: string, config: CustomAllocationRulesConfig);
    get id(): string;
    private _overrideUiDefinedResources?;
    get overrideUiDefinedResources(): boolean | cdktn.IResolvable;
    set overrideUiDefinedResources(value: boolean | cdktn.IResolvable);
    resetOverrideUiDefinedResources(): void;
    get overrideUiDefinedResourcesInput(): boolean | cdktn.IResolvable | undefined;
    private _ruleIds?;
    get ruleIds(): string[];
    set ruleIds(value: string[]);
    get ruleIdsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
