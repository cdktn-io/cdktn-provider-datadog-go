/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SecurityMonitoringCriticalAssetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether the critical asset is enabled. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_critical_asset#enabled SecurityMonitoringCriticalAsset#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The query used to match a critical asset and the associated signals. Uses the same syntax as the search bar in the Security Signals Explorer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_critical_asset#query SecurityMonitoringCriticalAsset#query}
    */
    readonly query: string;
    /**
    * The rule query to filter which detection rules this critical asset applies to. Uses the same syntax as the search bar for detection rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_critical_asset#rule_query SecurityMonitoringCriticalAsset#rule_query}
    */
    readonly ruleQuery: string;
    /**
    * The severity change applied to signals matching this critical asset. Valid values are `critical`, `high`, `medium`, `low`, `info`, `increase`, `decrease`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_critical_asset#severity SecurityMonitoringCriticalAsset#severity}
    */
    readonly severity: string;
    /**
    * A list of tags associated with the critical asset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_critical_asset#tags SecurityMonitoringCriticalAsset#tags}
    */
    readonly tags?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_critical_asset datadog_security_monitoring_critical_asset}
*/
export declare class SecurityMonitoringCriticalAsset extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_security_monitoring_critical_asset";
    /**
    * Generates CDKTN code for importing a SecurityMonitoringCriticalAsset resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecurityMonitoringCriticalAsset to import
    * @param importFromId The id of the existing SecurityMonitoringCriticalAsset that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_critical_asset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecurityMonitoringCriticalAsset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/security_monitoring_critical_asset datadog_security_monitoring_critical_asset} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecurityMonitoringCriticalAssetConfig
    */
    constructor(scope: Construct, id: string, config: SecurityMonitoringCriticalAssetConfig);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _ruleQuery?;
    get ruleQuery(): string;
    set ruleQuery(value: string);
    get ruleQueryInput(): string | undefined;
    private _severity?;
    get severity(): string;
    set severity(value: string);
    get severityInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
