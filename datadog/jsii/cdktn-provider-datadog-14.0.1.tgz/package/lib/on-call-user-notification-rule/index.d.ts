/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OnCallUserNotificationRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Notification category to associate the rule with. Valid values are `high_urgency`, `low_urgency`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_user_notification_rule#category OnCallUserNotificationRule#category}
    */
    readonly category: string;
    /**
    * ID of the notification channel to associate the notification rule with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_user_notification_rule#channel_id OnCallUserNotificationRule#channel_id}
    */
    readonly channelId: string;
    /**
    * Number of minutes to elapse before this rule is evaluated.  `0` indicates immediate evaluation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_user_notification_rule#delay_minutes OnCallUserNotificationRule#delay_minutes}
    */
    readonly delayMinutes: number;
    /**
    * ID of the user to associate the notification rule with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_user_notification_rule#user_id OnCallUserNotificationRule#user_id}
    */
    readonly userId: string;
    /**
    * phone block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_user_notification_rule#phone OnCallUserNotificationRule#phone}
    */
    readonly phone?: OnCallUserNotificationRulePhone;
}
export interface OnCallUserNotificationRulePhone {
    /**
    * Specifies the method in which a phone is used in a notification rule. Valid values are `sms`, `voice`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_user_notification_rule#method OnCallUserNotificationRule#method}
    */
    readonly method?: string;
}
export declare function onCallUserNotificationRulePhoneToTerraform(struct?: OnCallUserNotificationRulePhone | cdktn.IResolvable): any;
export declare function onCallUserNotificationRulePhoneToHclTerraform(struct?: OnCallUserNotificationRulePhone | cdktn.IResolvable): any;
export declare class OnCallUserNotificationRulePhoneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OnCallUserNotificationRulePhone | cdktn.IResolvable | undefined;
    set internalValue(value: OnCallUserNotificationRulePhone | cdktn.IResolvable | undefined);
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_user_notification_rule datadog_on_call_user_notification_rule}
*/
export declare class OnCallUserNotificationRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_on_call_user_notification_rule";
    /**
    * Generates CDKTN code for importing a OnCallUserNotificationRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OnCallUserNotificationRule to import
    * @param importFromId The id of the existing OnCallUserNotificationRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_user_notification_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OnCallUserNotificationRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_user_notification_rule datadog_on_call_user_notification_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OnCallUserNotificationRuleConfig
    */
    constructor(scope: Construct, id: string, config: OnCallUserNotificationRuleConfig);
    private _category?;
    get category(): string;
    set category(value: string);
    get categoryInput(): string | undefined;
    private _channelId?;
    get channelId(): string;
    set channelId(value: string);
    get channelIdInput(): string | undefined;
    private _delayMinutes?;
    get delayMinutes(): number;
    set delayMinutes(value: number);
    get delayMinutesInput(): number | undefined;
    get id(): string;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    get userIdInput(): string | undefined;
    private _phone;
    get phone(): OnCallUserNotificationRulePhoneOutputReference;
    putPhone(value: OnCallUserNotificationRulePhone): void;
    resetPhone(): void;
    get phoneInput(): cdktn.IResolvable | OnCallUserNotificationRulePhone | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
