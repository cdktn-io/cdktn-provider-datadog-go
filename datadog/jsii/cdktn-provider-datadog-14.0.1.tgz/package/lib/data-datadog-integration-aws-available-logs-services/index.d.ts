/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogIntegrationAwsAvailableLogsServicesConfig extends cdktn.TerraformMetaArguments {
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/integration_aws_available_logs_services datadog_integration_aws_available_logs_services}
*/
export declare class DataDatadogIntegrationAwsAvailableLogsServices extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_integration_aws_available_logs_services";
    /**
    * Generates CDKTN code for importing a DataDatadogIntegrationAwsAvailableLogsServices resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogIntegrationAwsAvailableLogsServices to import
    * @param importFromId The id of the existing DataDatadogIntegrationAwsAvailableLogsServices that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/integration_aws_available_logs_services#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogIntegrationAwsAvailableLogsServices to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/integration_aws_available_logs_services datadog_integration_aws_available_logs_services} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogIntegrationAwsAvailableLogsServicesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogIntegrationAwsAvailableLogsServicesConfig);
    get awsLogsServices(): string[];
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
