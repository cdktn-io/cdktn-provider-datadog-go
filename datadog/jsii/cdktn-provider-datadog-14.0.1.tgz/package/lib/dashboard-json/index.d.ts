/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DashboardJsonConfig extends cdktn.TerraformMetaArguments {
    /**
    * The JSON formatted definition of the Dashboard.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard_json#dashboard DashboardJson#dashboard}
    */
    readonly dashboard: string;
    /**
    * A list of dashboard lists this dashboard belongs to. This attribute should not be set if managing the corresponding dashboard lists using Terraform as it causes inconsistent behavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard_json#dashboard_lists DashboardJson#dashboard_lists}
    */
    readonly dashboardLists?: number[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard_json#id DashboardJson#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The URL of the dashboard.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard_json#url DashboardJson#url}
    */
    readonly url?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard_json datadog_dashboard_json}
*/
export declare class DashboardJson extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_dashboard_json";
    /**
    * Generates CDKTN code for importing a DashboardJson resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DashboardJson to import
    * @param importFromId The id of the existing DashboardJson that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard_json#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DashboardJson to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard_json datadog_dashboard_json} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DashboardJsonConfig
    */
    constructor(scope: Construct, id: string, config: DashboardJsonConfig);
    private _dashboard?;
    get dashboard(): string;
    set dashboard(value: string);
    get dashboardInput(): string | undefined;
    private _dashboardLists?;
    get dashboardLists(): number[];
    set dashboardLists(value: number[]);
    resetDashboardLists(): void;
    get dashboardListsInput(): number[] | undefined;
    get dashboardListsRemoved(): number[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
