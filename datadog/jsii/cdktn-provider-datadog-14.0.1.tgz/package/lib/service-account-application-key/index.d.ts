/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ServiceAccountApplicationKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Name of the application key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_account_application_key#name ServiceAccountApplicationKey#name}
    */
    readonly name: string;
    /**
    * Authorization scopes for the Application Key. Application Keys configured with no scopes have full access.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_account_application_key#scopes ServiceAccountApplicationKey#scopes}
    */
    readonly scopes?: string[];
    /**
    * ID of the service account that owns this key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_account_application_key#service_account_id ServiceAccountApplicationKey#service_account_id}
    */
    readonly serviceAccountId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_account_application_key datadog_service_account_application_key}
*/
export declare class ServiceAccountApplicationKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_service_account_application_key";
    /**
    * Generates CDKTN code for importing a ServiceAccountApplicationKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServiceAccountApplicationKey to import
    * @param importFromId The id of the existing ServiceAccountApplicationKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_account_application_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServiceAccountApplicationKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/service_account_application_key datadog_service_account_application_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServiceAccountApplicationKeyConfig
    */
    constructor(scope: Construct, id: string, config: ServiceAccountApplicationKeyConfig);
    get createdAt(): string;
    get id(): string;
    get key(): string;
    get last4(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
    private _serviceAccountId?;
    get serviceAccountId(): string;
    set serviceAccountId(value: string);
    get serviceAccountIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
