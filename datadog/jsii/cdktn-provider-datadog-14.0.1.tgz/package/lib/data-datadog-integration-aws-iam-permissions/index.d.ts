/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogIntegrationAwsIamPermissionsConfig extends cdktn.TerraformMetaArguments {
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/integration_aws_iam_permissions datadog_integration_aws_iam_permissions}
*/
export declare class DataDatadogIntegrationAwsIamPermissions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_integration_aws_iam_permissions";
    /**
    * Generates CDKTN code for importing a DataDatadogIntegrationAwsIamPermissions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogIntegrationAwsIamPermissions to import
    * @param importFromId The id of the existing DataDatadogIntegrationAwsIamPermissions that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/integration_aws_iam_permissions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogIntegrationAwsIamPermissions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/integration_aws_iam_permissions datadog_integration_aws_iam_permissions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogIntegrationAwsIamPermissionsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogIntegrationAwsIamPermissionsConfig);
    get iamPermissions(): string[];
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
