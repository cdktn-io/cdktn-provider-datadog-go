/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TeamPermissionSettingConfig extends cdktn.TerraformMetaArguments {
    /**
    * The identifier for the action. Valid values are `manage_membership`, `edit`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_permission_setting#action TeamPermissionSetting#action}
    */
    readonly action: string;
    /**
    * ID of the team the team permission setting is associated with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_permission_setting#team_id TeamPermissionSetting#team_id}
    */
    readonly teamId: string;
    /**
    * The action value. Valid values are dependent on the action. `manage_membership` action allows `admins`, `members`, `organization`, `user_access_manage` values. `edit` action allows `admins`, `members`, `teams_manage` values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_permission_setting#value TeamPermissionSetting#value}
    */
    readonly value: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_permission_setting datadog_team_permission_setting}
*/
export declare class TeamPermissionSetting extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_team_permission_setting";
    /**
    * Generates CDKTN code for importing a TeamPermissionSetting resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TeamPermissionSetting to import
    * @param importFromId The id of the existing TeamPermissionSetting that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_permission_setting#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TeamPermissionSetting to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_permission_setting datadog_team_permission_setting} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TeamPermissionSettingConfig
    */
    constructor(scope: Construct, id: string, config: TeamPermissionSettingConfig);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    get id(): string;
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    get teamIdInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
