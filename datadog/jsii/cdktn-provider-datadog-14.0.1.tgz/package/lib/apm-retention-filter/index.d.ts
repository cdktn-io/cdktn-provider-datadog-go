/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApmRetentionFilterConfig extends cdktn.TerraformMetaArguments {
    /**
    * the status of the retention filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/apm_retention_filter#enabled ApmRetentionFilter#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * The type of the retention filter, currently only spans-processing-sampling is available. Valid values are `spans-sampling-processor`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/apm_retention_filter#filter_type ApmRetentionFilter#filter_type}
    */
    readonly filterType: string;
    /**
    * The name of the retention filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/apm_retention_filter#name ApmRetentionFilter#name}
    */
    readonly name: string;
    /**
    * Sample rate to apply to spans going through this retention filter as a string; a value of 1.0 keeps all spans matching the query. Value must be between 0.00 and 1.00.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/apm_retention_filter#rate ApmRetentionFilter#rate}
    */
    readonly rate: string;
    /**
    * Sample rate to apply to traces with spans going through this retention filter as a string; a value of 1.0 keeps all traces matching the query. Value must be between 0.00 and 1.00.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/apm_retention_filter#trace_rate ApmRetentionFilter#trace_rate}
    */
    readonly traceRate?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/apm_retention_filter#filter ApmRetentionFilter#filter}
    */
    readonly filter?: ApmRetentionFilterFilter;
}
export interface ApmRetentionFilterFilter {
    /**
    * The search query - follow the span search syntax, use `AND` between tags and `\` to escape special characters, use nanosecond for duration. Defaults to `"*"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/apm_retention_filter#query ApmRetentionFilter#query}
    */
    readonly query?: string;
}
export declare function apmRetentionFilterFilterToTerraform(struct?: ApmRetentionFilterFilter | cdktn.IResolvable): any;
export declare function apmRetentionFilterFilterToHclTerraform(struct?: ApmRetentionFilterFilter | cdktn.IResolvable): any;
export declare class ApmRetentionFilterFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApmRetentionFilterFilter | cdktn.IResolvable | undefined;
    set internalValue(value: ApmRetentionFilterFilter | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/apm_retention_filter datadog_apm_retention_filter}
*/
export declare class ApmRetentionFilter extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_apm_retention_filter";
    /**
    * Generates CDKTN code for importing a ApmRetentionFilter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApmRetentionFilter to import
    * @param importFromId The id of the existing ApmRetentionFilter that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/apm_retention_filter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApmRetentionFilter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/apm_retention_filter datadog_apm_retention_filter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApmRetentionFilterConfig
    */
    constructor(scope: Construct, id: string, config: ApmRetentionFilterConfig);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _filterType?;
    get filterType(): string;
    set filterType(value: string);
    get filterTypeInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _rate?;
    get rate(): string;
    set rate(value: string);
    get rateInput(): string | undefined;
    private _traceRate?;
    get traceRate(): string;
    set traceRate(value: string);
    resetTraceRate(): void;
    get traceRateInput(): string | undefined;
    private _filter;
    get filter(): ApmRetentionFilterFilterOutputReference;
    putFilter(value: ApmRetentionFilterFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | ApmRetentionFilterFilter | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
