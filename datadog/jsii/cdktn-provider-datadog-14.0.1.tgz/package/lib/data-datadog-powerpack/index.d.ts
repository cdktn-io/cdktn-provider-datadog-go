/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogPowerpackConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the Powerpack to search for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/powerpack#name DataDatadogPowerpack#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/powerpack datadog_powerpack}
*/
export declare class DataDatadogPowerpack extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_powerpack";
    /**
    * Generates CDKTN code for importing a DataDatadogPowerpack resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogPowerpack to import
    * @param importFromId The id of the existing DataDatadogPowerpack that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/powerpack#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogPowerpack to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/powerpack datadog_powerpack} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogPowerpackConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogPowerpackConfig);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
