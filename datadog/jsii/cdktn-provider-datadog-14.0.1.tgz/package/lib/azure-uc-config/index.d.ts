/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AzureUcConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * The tenant ID of the Azure account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/azure_uc_config#account_id AzureUcConfig#account_id}
    */
    readonly accountId: string;
    /**
    * The client ID of the Azure account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/azure_uc_config#client_id AzureUcConfig#client_id}
    */
    readonly clientId: string;
    /**
    * The scope of your observed subscription.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/azure_uc_config#scope AzureUcConfig#scope}
    */
    readonly scope: string;
    /**
    * actual_bill_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/azure_uc_config#actual_bill_config AzureUcConfig#actual_bill_config}
    */
    readonly actualBillConfig: AzureUcConfigActualBillConfig;
    /**
    * amortized_bill_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/azure_uc_config#amortized_bill_config AzureUcConfig#amortized_bill_config}
    */
    readonly amortizedBillConfig: AzureUcConfigAmortizedBillConfig;
}
export interface AzureUcConfigActualBillConfig {
    /**
    * The name of the configured Azure Export.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/azure_uc_config#export_name AzureUcConfig#export_name}
    */
    readonly exportName: string;
    /**
    * The path where the Azure Export is saved.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/azure_uc_config#export_path AzureUcConfig#export_path}
    */
    readonly exportPath: string;
    /**
    * The name of the storage account where the Azure Export is saved.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/azure_uc_config#storage_account AzureUcConfig#storage_account}
    */
    readonly storageAccount: string;
    /**
    * The name of the storage container where the Azure Export is saved.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/azure_uc_config#storage_container AzureUcConfig#storage_container}
    */
    readonly storageContainer: string;
}
export declare function azureUcConfigActualBillConfigToTerraform(struct?: AzureUcConfigActualBillConfig | cdktn.IResolvable): any;
export declare function azureUcConfigActualBillConfigToHclTerraform(struct?: AzureUcConfigActualBillConfig | cdktn.IResolvable): any;
export declare class AzureUcConfigActualBillConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AzureUcConfigActualBillConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AzureUcConfigActualBillConfig | cdktn.IResolvable | undefined);
    private _exportName?;
    get exportName(): string;
    set exportName(value: string);
    get exportNameInput(): string | undefined;
    private _exportPath?;
    get exportPath(): string;
    set exportPath(value: string);
    get exportPathInput(): string | undefined;
    private _storageAccount?;
    get storageAccount(): string;
    set storageAccount(value: string);
    get storageAccountInput(): string | undefined;
    private _storageContainer?;
    get storageContainer(): string;
    set storageContainer(value: string);
    get storageContainerInput(): string | undefined;
}
export interface AzureUcConfigAmortizedBillConfig {
    /**
    * The name of the configured Azure Export.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/azure_uc_config#export_name AzureUcConfig#export_name}
    */
    readonly exportName: string;
    /**
    * The path where the Azure Export is saved.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/azure_uc_config#export_path AzureUcConfig#export_path}
    */
    readonly exportPath: string;
    /**
    * The name of the storage account where the Azure Export is saved.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/azure_uc_config#storage_account AzureUcConfig#storage_account}
    */
    readonly storageAccount: string;
    /**
    * The name of the storage container where the Azure Export is saved.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/azure_uc_config#storage_container AzureUcConfig#storage_container}
    */
    readonly storageContainer: string;
}
export declare function azureUcConfigAmortizedBillConfigToTerraform(struct?: AzureUcConfigAmortizedBillConfig | cdktn.IResolvable): any;
export declare function azureUcConfigAmortizedBillConfigToHclTerraform(struct?: AzureUcConfigAmortizedBillConfig | cdktn.IResolvable): any;
export declare class AzureUcConfigAmortizedBillConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AzureUcConfigAmortizedBillConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AzureUcConfigAmortizedBillConfig | cdktn.IResolvable | undefined);
    private _exportName?;
    get exportName(): string;
    set exportName(value: string);
    get exportNameInput(): string | undefined;
    private _exportPath?;
    get exportPath(): string;
    set exportPath(value: string);
    get exportPathInput(): string | undefined;
    private _storageAccount?;
    get storageAccount(): string;
    set storageAccount(value: string);
    get storageAccountInput(): string | undefined;
    private _storageContainer?;
    get storageContainer(): string;
    set storageContainer(value: string);
    get storageContainerInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/azure_uc_config datadog_azure_uc_config}
*/
export declare class AzureUcConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_azure_uc_config";
    /**
    * Generates CDKTN code for importing a AzureUcConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AzureUcConfig to import
    * @param importFromId The id of the existing AzureUcConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/azure_uc_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AzureUcConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/azure_uc_config datadog_azure_uc_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AzureUcConfigConfig
    */
    constructor(scope: Construct, id: string, config: AzureUcConfigConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    get createdAt(): string;
    get errorMessages(): string[];
    get id(): string;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
    get status(): string;
    get statusUpdatedAt(): string;
    get updatedAt(): string;
    private _actualBillConfig;
    get actualBillConfig(): AzureUcConfigActualBillConfigOutputReference;
    putActualBillConfig(value: AzureUcConfigActualBillConfig): void;
    get actualBillConfigInput(): cdktn.IResolvable | AzureUcConfigActualBillConfig | undefined;
    private _amortizedBillConfig;
    get amortizedBillConfig(): AzureUcConfigAmortizedBillConfigOutputReference;
    putAmortizedBillConfig(value: AzureUcConfigAmortizedBillConfig): void;
    get amortizedBillConfigInput(): cdktn.IResolvable | AzureUcConfigAmortizedBillConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
