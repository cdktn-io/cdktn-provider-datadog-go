/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogReferenceTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * The UUID of the reference table. Either id or table_name must be specified, but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/reference_table#id DataDatadogReferenceTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the reference table. Either id or table_name must be specified, but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/reference_table#table_name DataDatadogReferenceTable#table_name}
    */
    readonly tableName?: string;
    /**
    * schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/reference_table#schema DataDatadogReferenceTable#schema}
    */
    readonly schema?: DataDatadogReferenceTableSchema;
}
export interface DataDatadogReferenceTableFileMetadataAccessDetailsAwsDetail {
}
export declare function dataDatadogReferenceTableFileMetadataAccessDetailsAwsDetailToTerraform(struct?: DataDatadogReferenceTableFileMetadataAccessDetailsAwsDetail | cdktn.IResolvable): any;
export declare function dataDatadogReferenceTableFileMetadataAccessDetailsAwsDetailToHclTerraform(struct?: DataDatadogReferenceTableFileMetadataAccessDetailsAwsDetail | cdktn.IResolvable): any;
export declare class DataDatadogReferenceTableFileMetadataAccessDetailsAwsDetailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogReferenceTableFileMetadataAccessDetailsAwsDetail | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogReferenceTableFileMetadataAccessDetailsAwsDetail | cdktn.IResolvable | undefined);
    get awsAccountId(): string;
    get awsBucketName(): string;
    get filePath(): string;
}
export interface DataDatadogReferenceTableFileMetadataAccessDetailsAzureDetail {
}
export declare function dataDatadogReferenceTableFileMetadataAccessDetailsAzureDetailToTerraform(struct?: DataDatadogReferenceTableFileMetadataAccessDetailsAzureDetail | cdktn.IResolvable): any;
export declare function dataDatadogReferenceTableFileMetadataAccessDetailsAzureDetailToHclTerraform(struct?: DataDatadogReferenceTableFileMetadataAccessDetailsAzureDetail | cdktn.IResolvable): any;
export declare class DataDatadogReferenceTableFileMetadataAccessDetailsAzureDetailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogReferenceTableFileMetadataAccessDetailsAzureDetail | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogReferenceTableFileMetadataAccessDetailsAzureDetail | cdktn.IResolvable | undefined);
    get azureClientId(): string;
    get azureContainerName(): string;
    get azureStorageAccountName(): string;
    get azureTenantId(): string;
    get filePath(): string;
}
export interface DataDatadogReferenceTableFileMetadataAccessDetailsGcpDetail {
}
export declare function dataDatadogReferenceTableFileMetadataAccessDetailsGcpDetailToTerraform(struct?: DataDatadogReferenceTableFileMetadataAccessDetailsGcpDetail | cdktn.IResolvable): any;
export declare function dataDatadogReferenceTableFileMetadataAccessDetailsGcpDetailToHclTerraform(struct?: DataDatadogReferenceTableFileMetadataAccessDetailsGcpDetail | cdktn.IResolvable): any;
export declare class DataDatadogReferenceTableFileMetadataAccessDetailsGcpDetailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogReferenceTableFileMetadataAccessDetailsGcpDetail | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogReferenceTableFileMetadataAccessDetailsGcpDetail | cdktn.IResolvable | undefined);
    get filePath(): string;
    get gcpBucketName(): string;
    get gcpProjectId(): string;
    get gcpServiceAccountEmail(): string;
}
export interface DataDatadogReferenceTableFileMetadataAccessDetails {
}
export declare function dataDatadogReferenceTableFileMetadataAccessDetailsToTerraform(struct?: DataDatadogReferenceTableFileMetadataAccessDetails | cdktn.IResolvable): any;
export declare function dataDatadogReferenceTableFileMetadataAccessDetailsToHclTerraform(struct?: DataDatadogReferenceTableFileMetadataAccessDetails | cdktn.IResolvable): any;
export declare class DataDatadogReferenceTableFileMetadataAccessDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogReferenceTableFileMetadataAccessDetails | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogReferenceTableFileMetadataAccessDetails | cdktn.IResolvable | undefined);
    private _awsDetail;
    get awsDetail(): DataDatadogReferenceTableFileMetadataAccessDetailsAwsDetailOutputReference;
    private _azureDetail;
    get azureDetail(): DataDatadogReferenceTableFileMetadataAccessDetailsAzureDetailOutputReference;
    private _gcpDetail;
    get gcpDetail(): DataDatadogReferenceTableFileMetadataAccessDetailsGcpDetailOutputReference;
}
export interface DataDatadogReferenceTableFileMetadata {
}
export declare function dataDatadogReferenceTableFileMetadataToTerraform(struct?: DataDatadogReferenceTableFileMetadata | cdktn.IResolvable): any;
export declare function dataDatadogReferenceTableFileMetadataToHclTerraform(struct?: DataDatadogReferenceTableFileMetadata | cdktn.IResolvable): any;
export declare class DataDatadogReferenceTableFileMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogReferenceTableFileMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogReferenceTableFileMetadata | cdktn.IResolvable | undefined);
    get errorMessage(): string;
    get errorRowCount(): number;
    get errorType(): string;
    get syncEnabled(): cdktn.IResolvable;
    private _accessDetails;
    get accessDetails(): DataDatadogReferenceTableFileMetadataAccessDetailsOutputReference;
}
export interface DataDatadogReferenceTableSchemaFields {
}
export declare function dataDatadogReferenceTableSchemaFieldsToTerraform(struct?: DataDatadogReferenceTableSchemaFields | cdktn.IResolvable): any;
export declare function dataDatadogReferenceTableSchemaFieldsToHclTerraform(struct?: DataDatadogReferenceTableSchemaFields | cdktn.IResolvable): any;
export declare class DataDatadogReferenceTableSchemaFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogReferenceTableSchemaFields | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogReferenceTableSchemaFields | cdktn.IResolvable | undefined);
    get name(): string;
    get type(): string;
}
export declare class DataDatadogReferenceTableSchemaFieldsList extends cdktn.ComplexList {
    internalValue?: DataDatadogReferenceTableSchemaFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogReferenceTableSchemaFieldsOutputReference;
}
export interface DataDatadogReferenceTableSchema {
    /**
    * fields block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/reference_table#fields DataDatadogReferenceTable#fields}
    */
    readonly fields?: DataDatadogReferenceTableSchemaFields[] | cdktn.IResolvable;
}
export declare function dataDatadogReferenceTableSchemaToTerraform(struct?: DataDatadogReferenceTableSchema | cdktn.IResolvable): any;
export declare function dataDatadogReferenceTableSchemaToHclTerraform(struct?: DataDatadogReferenceTableSchema | cdktn.IResolvable): any;
export declare class DataDatadogReferenceTableSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogReferenceTableSchema | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogReferenceTableSchema | cdktn.IResolvable | undefined);
    get primaryKeys(): string[];
    private _fields;
    get fields(): DataDatadogReferenceTableSchemaFieldsList;
    putFields(value: DataDatadogReferenceTableSchemaFields[] | cdktn.IResolvable): void;
    resetFields(): void;
    get fieldsInput(): cdktn.IResolvable | DataDatadogReferenceTableSchemaFields[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/reference_table datadog_reference_table}
*/
export declare class DataDatadogReferenceTable extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_reference_table";
    /**
    * Generates CDKTN code for importing a DataDatadogReferenceTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogReferenceTable to import
    * @param importFromId The id of the existing DataDatadogReferenceTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/reference_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogReferenceTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/reference_table datadog_reference_table} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogReferenceTableConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogReferenceTableConfig);
    get createdBy(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedBy(): string;
    get rowCount(): number;
    get source(): string;
    get status(): string;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    resetTableName(): void;
    get tableNameInput(): string | undefined;
    get tags(): string[];
    get updatedAt(): string;
    private _fileMetadata;
    get fileMetadata(): DataDatadogReferenceTableFileMetadataOutputReference;
    private _schema;
    get schema(): DataDatadogReferenceTableSchemaOutputReference;
    putSchema(value: DataDatadogReferenceTableSchema): void;
    resetSchema(): void;
    get schemaInput(): cdktn.IResolvable | DataDatadogReferenceTableSchema | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
