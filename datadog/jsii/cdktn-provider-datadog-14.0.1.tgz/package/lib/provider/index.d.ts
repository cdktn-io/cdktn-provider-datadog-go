/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatadogProviderConfig {
    /**
    * (Required unless validate is false) Datadog API key. This can also be set via the DD_API_KEY environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs#api_key DatadogProvider#api_key}
    */
    readonly apiKey?: string;
    /**
    * The API URL. This can also be set via the DD_HOST environment variable, and defaults to `https://api.datadoghq.com`. Note that this URL must not end with the `/api/` path. For example, `https://api.datadoghq.com/` is a correct value, while `https://api.datadoghq.com/api/` is not. And if you're working with "EU" version of Datadog, use `https://api.datadoghq.eu/`. Other Datadog region examples: `https://api.us5.datadoghq.com/`, `https://api.us3.datadoghq.com/` and `https://api.ddog-gov.com/`. See https://docs.datadoghq.com/getting_started/site/ for all available regions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs#api_url DatadogProvider#api_url}
    */
    readonly apiUrl?: string;
    /**
    * (Required unless validate is false) Datadog APP key. This can also be set via the DD_APP_KEY environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs#app_key DatadogProvider#app_key}
    */
    readonly appKey?: string;
    /**
    * The AWS access key ID; used for cloud-provider-based authentication. This can also be set using the `AWS_ACCESS_KEY_ID` environment variable. Required when using `cloud_provider_type` set to `aws`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs#aws_access_key_id DatadogProvider#aws_access_key_id}
    */
    readonly awsAccessKeyId?: string;
    /**
    * The AWS secret access key; used for cloud-provider-based authentication. This can also be set using the `AWS_SECRET_ACCESS_KEY` environment variable. Required when using `cloud_provider_type` set to `aws`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs#aws_secret_access_key DatadogProvider#aws_secret_access_key}
    */
    readonly awsSecretAccessKey?: string;
    /**
    * The AWS session token; used for cloud-provider-based authentication. This can also be set using the `AWS_SESSION_TOKEN` environment variable. Required when using `cloud_provider_type` set to `aws` and using temporary credentials.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs#aws_session_token DatadogProvider#aws_session_token}
    */
    readonly awsSessionToken?: string;
    /**
    * The cloud provider region specifier; used for cloud-provider-based authentication. For example, `us-east-1` for AWS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs#cloud_provider_region DatadogProvider#cloud_provider_region}
    */
    readonly cloudProviderRegion?: string;
    /**
    * Specifies the cloud provider used for cloud-provider-based authentication, enabling keyless access without API or app keys. Only [`aws`] is supported. This feature is in Preview. If you'd like to enable it for your organization, contact [support](https://docs.datadoghq.com/help/).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs#cloud_provider_type DatadogProvider#cloud_provider_type}
    */
    readonly cloudProviderType?: string;
    /**
    * The HTTP request retry back off base. Defaults to 2.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs#http_client_retry_backoff_base DatadogProvider#http_client_retry_backoff_base}
    */
    readonly httpClientRetryBackoffBase?: number;
    /**
    * The HTTP request retry back off multiplier. Defaults to 2.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs#http_client_retry_backoff_multiplier DatadogProvider#http_client_retry_backoff_multiplier}
    */
    readonly httpClientRetryBackoffMultiplier?: number;
    /**
    * Enables request retries on HTTP status codes 429 and 5xx. Valid values are [`true`, `false`]. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs#http_client_retry_enabled DatadogProvider#http_client_retry_enabled}
    */
    readonly httpClientRetryEnabled?: string;
    /**
    * The HTTP request maximum retry number. Defaults to 3.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs#http_client_retry_max_retries DatadogProvider#http_client_retry_max_retries}
    */
    readonly httpClientRetryMaxRetries?: number;
    /**
    * The HTTP request retry timeout period. Defaults to 60 seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs#http_client_retry_timeout DatadogProvider#http_client_retry_timeout}
    */
    readonly httpClientRetryTimeout?: number;
    /**
    * The organization UUID; used for cloud-provider-based authentication. See the [Datadog API documentation](https://docs.datadoghq.com/api/v1/organizations/) for more information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs#org_uuid DatadogProvider#org_uuid}
    */
    readonly orgUuid?: string;
    /**
    * Enables validation of the provided API key during provider initialization. Valid values are [`true`, `false`]. Default is true. When false, api_key won't be checked.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs#validate DatadogProvider#validate}
    */
    readonly validate?: string;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs#alias DatadogProvider#alias}
    */
    readonly alias?: string;
    /**
    * default_tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs#default_tags DatadogProvider#default_tags}
    */
    readonly defaultTags?: DatadogProviderDefaultTags;
}
export interface DatadogProviderDefaultTags {
    /**
    * [Experimental - Logs Indexes, Logs Pipelines, Monitors Security Monitoring Rules, and Service Level Objectives only] Resource tags to be applied by default across all resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs#tags DatadogProvider#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
export declare function datadogProviderDefaultTagsToTerraform(struct?: DatadogProviderDefaultTags): any;
export declare function datadogProviderDefaultTagsToHclTerraform(struct?: DatadogProviderDefaultTags): any;
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs datadog}
*/
export declare class DatadogProvider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "datadog";
    /**
    * Generates CDKTN code for importing a DatadogProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatadogProvider to import
    * @param importFromId The id of the existing DatadogProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatadogProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs datadog} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatadogProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DatadogProviderConfig);
    private _apiKey?;
    get apiKey(): string | undefined;
    set apiKey(value: string | undefined);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
    private _apiUrl?;
    get apiUrl(): string | undefined;
    set apiUrl(value: string | undefined);
    resetApiUrl(): void;
    get apiUrlInput(): string | undefined;
    private _appKey?;
    get appKey(): string | undefined;
    set appKey(value: string | undefined);
    resetAppKey(): void;
    get appKeyInput(): string | undefined;
    private _awsAccessKeyId?;
    get awsAccessKeyId(): string | undefined;
    set awsAccessKeyId(value: string | undefined);
    resetAwsAccessKeyId(): void;
    get awsAccessKeyIdInput(): string | undefined;
    private _awsSecretAccessKey?;
    get awsSecretAccessKey(): string | undefined;
    set awsSecretAccessKey(value: string | undefined);
    resetAwsSecretAccessKey(): void;
    get awsSecretAccessKeyInput(): string | undefined;
    private _awsSessionToken?;
    get awsSessionToken(): string | undefined;
    set awsSessionToken(value: string | undefined);
    resetAwsSessionToken(): void;
    get awsSessionTokenInput(): string | undefined;
    private _cloudProviderRegion?;
    get cloudProviderRegion(): string | undefined;
    set cloudProviderRegion(value: string | undefined);
    resetCloudProviderRegion(): void;
    get cloudProviderRegionInput(): string | undefined;
    private _cloudProviderType?;
    get cloudProviderType(): string | undefined;
    set cloudProviderType(value: string | undefined);
    resetCloudProviderType(): void;
    get cloudProviderTypeInput(): string | undefined;
    private _httpClientRetryBackoffBase?;
    get httpClientRetryBackoffBase(): number | undefined;
    set httpClientRetryBackoffBase(value: number | undefined);
    resetHttpClientRetryBackoffBase(): void;
    get httpClientRetryBackoffBaseInput(): number | undefined;
    private _httpClientRetryBackoffMultiplier?;
    get httpClientRetryBackoffMultiplier(): number | undefined;
    set httpClientRetryBackoffMultiplier(value: number | undefined);
    resetHttpClientRetryBackoffMultiplier(): void;
    get httpClientRetryBackoffMultiplierInput(): number | undefined;
    private _httpClientRetryEnabled?;
    get httpClientRetryEnabled(): string | undefined;
    set httpClientRetryEnabled(value: string | undefined);
    resetHttpClientRetryEnabled(): void;
    get httpClientRetryEnabledInput(): string | undefined;
    private _httpClientRetryMaxRetries?;
    get httpClientRetryMaxRetries(): number | undefined;
    set httpClientRetryMaxRetries(value: number | undefined);
    resetHttpClientRetryMaxRetries(): void;
    get httpClientRetryMaxRetriesInput(): number | undefined;
    private _httpClientRetryTimeout?;
    get httpClientRetryTimeout(): number | undefined;
    set httpClientRetryTimeout(value: number | undefined);
    resetHttpClientRetryTimeout(): void;
    get httpClientRetryTimeoutInput(): number | undefined;
    private _orgUuid?;
    get orgUuid(): string | undefined;
    set orgUuid(value: string | undefined);
    resetOrgUuid(): void;
    get orgUuidInput(): string | undefined;
    private _validate?;
    get validate(): string | undefined;
    set validate(value: string | undefined);
    resetValidate(): void;
    get validateInput(): string | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _defaultTags?;
    get defaultTags(): DatadogProviderDefaultTags | undefined;
    set defaultTags(value: DatadogProviderDefaultTags | undefined);
    resetDefaultTags(): void;
    get defaultTagsInput(): DatadogProviderDefaultTags | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
