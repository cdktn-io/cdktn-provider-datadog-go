/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IntegrationPagerdutyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Your PagerDuty API token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_pagerduty#api_token IntegrationPagerduty#api_token}
    */
    readonly apiToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_pagerduty#id IntegrationPagerduty#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Array of your schedule URLs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_pagerduty#schedules IntegrationPagerduty#schedules}
    */
    readonly schedules?: string[];
    /**
    * Your PagerDuty account’s personalized subdomain name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_pagerduty#subdomain IntegrationPagerduty#subdomain}
    */
    readonly subdomain: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_pagerduty datadog_integration_pagerduty}
*/
export declare class IntegrationPagerduty extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_integration_pagerduty";
    /**
    * Generates CDKTN code for importing a IntegrationPagerduty resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IntegrationPagerduty to import
    * @param importFromId The id of the existing IntegrationPagerduty that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_pagerduty#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IntegrationPagerduty to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_pagerduty datadog_integration_pagerduty} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IntegrationPagerdutyConfig
    */
    constructor(scope: Construct, id: string, config: IntegrationPagerdutyConfig);
    private _apiToken?;
    get apiToken(): string;
    set apiToken(value: string);
    resetApiToken(): void;
    get apiTokenInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _schedules?;
    get schedules(): string[];
    set schedules(value: string[]);
    resetSchedules(): void;
    get schedulesInput(): string[] | undefined;
    private _subdomain?;
    get subdomain(): string;
    set subdomain(value: string);
    get subdomainInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
