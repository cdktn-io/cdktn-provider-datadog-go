/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OpenapiApiConfig extends cdktn.TerraformMetaArguments {
    /**
    * The textual content of the OpenAPI specification. Use [`file()`](https://developer.hashicorp.com/terraform/language/functions/file) in order to reference another file in the repository (see exmaple).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/openapi_api#spec OpenapiApi#spec}
    */
    readonly spec: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/openapi_api datadog_openapi_api}
*/
export declare class OpenapiApi extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_openapi_api";
    /**
    * Generates CDKTN code for importing a OpenapiApi resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OpenapiApi to import
    * @param importFromId The id of the existing OpenapiApi that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/openapi_api#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OpenapiApi to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/openapi_api datadog_openapi_api} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OpenapiApiConfig
    */
    constructor(scope: Construct, id: string, config: OpenapiApiConfig);
    get id(): string;
    private _spec?;
    get spec(): string;
    set spec(value: string);
    get specInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
