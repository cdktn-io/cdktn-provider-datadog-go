/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApiKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Name for API Key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/api_key#name ApiKey#name}
    */
    readonly name: string;
    /**
    * Whether the API key is used for remote config. Set to true only if remote config is enabled in `/organization-settings/remote-config`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/api_key#remote_config_read_enabled ApiKey#remote_config_read_enabled}
    */
    readonly remoteConfigReadEnabled?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/api_key datadog_api_key}
*/
export declare class ApiKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_api_key";
    /**
    * Generates CDKTN code for importing a ApiKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApiKey to import
    * @param importFromId The id of the existing ApiKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/api_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApiKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/api_key datadog_api_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApiKeyConfig
    */
    constructor(scope: Construct, id: string, config: ApiKeyConfig);
    get id(): string;
    get key(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _remoteConfigReadEnabled?;
    get remoteConfigReadEnabled(): boolean | cdktn.IResolvable;
    set remoteConfigReadEnabled(value: boolean | cdktn.IResolvable);
    resetRemoteConfigReadEnabled(): void;
    get remoteConfigReadEnabledInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
