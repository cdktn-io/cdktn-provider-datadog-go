/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WebhookCustomVariableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether the custom variable is secret or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/webhook_custom_variable#is_secret WebhookCustomVariable#is_secret}
    */
    readonly isSecret: boolean | cdktn.IResolvable;
    /**
    * The name of the variable. It corresponds with `<CUSTOM_VARIABLE_NAME>`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/webhook_custom_variable#name WebhookCustomVariable#name}
    */
    readonly name: string;
    /**
    * The value of the custom variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/webhook_custom_variable#value WebhookCustomVariable#value}
    */
    readonly value: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/webhook_custom_variable datadog_webhook_custom_variable}
*/
export declare class WebhookCustomVariable extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_webhook_custom_variable";
    /**
    * Generates CDKTN code for importing a WebhookCustomVariable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WebhookCustomVariable to import
    * @param importFromId The id of the existing WebhookCustomVariable that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/webhook_custom_variable#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WebhookCustomVariable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/webhook_custom_variable datadog_webhook_custom_variable} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WebhookCustomVariableConfig
    */
    constructor(scope: Construct, id: string, config: WebhookCustomVariableConfig);
    get id(): string;
    private _isSecret?;
    get isSecret(): boolean | cdktn.IResolvable;
    set isSecret(value: boolean | cdktn.IResolvable);
    get isSecretInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
