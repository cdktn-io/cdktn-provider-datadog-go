/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogServiceLevelObjectiveConfig extends cdktn.TerraformMetaArguments {
    /**
    * A SLO ID to limit the search.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_level_objective#id DataDatadogServiceLevelObjective#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filter results based on SLO numerator and denominator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_level_objective#metrics_query DataDatadogServiceLevelObjective#metrics_query}
    */
    readonly metricsQuery?: string;
    /**
    * Filter results based on SLO names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_level_objective#name_query DataDatadogServiceLevelObjective#name_query}
    */
    readonly nameQuery?: string;
    /**
    * Filter results based on a single SLO tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_level_objective#tags_query DataDatadogServiceLevelObjective#tags_query}
    */
    readonly tagsQuery?: string;
}
export interface DataDatadogServiceLevelObjectiveQuery {
}
export declare function dataDatadogServiceLevelObjectiveQueryToTerraform(struct?: DataDatadogServiceLevelObjectiveQuery): any;
export declare function dataDatadogServiceLevelObjectiveQueryToHclTerraform(struct?: DataDatadogServiceLevelObjectiveQuery): any;
export declare class DataDatadogServiceLevelObjectiveQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogServiceLevelObjectiveQuery | undefined;
    set internalValue(value: DataDatadogServiceLevelObjectiveQuery | undefined);
    get denominator(): string;
    get numerator(): string;
}
export declare class DataDatadogServiceLevelObjectiveQueryList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogServiceLevelObjectiveQueryOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_level_objective datadog_service_level_objective}
*/
export declare class DataDatadogServiceLevelObjective extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_service_level_objective";
    /**
    * Generates CDKTN code for importing a DataDatadogServiceLevelObjective resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogServiceLevelObjective to import
    * @param importFromId The id of the existing DataDatadogServiceLevelObjective that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_level_objective#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogServiceLevelObjective to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/service_level_objective datadog_service_level_objective} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogServiceLevelObjectiveConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogServiceLevelObjectiveConfig);
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metricsQuery?;
    get metricsQuery(): string;
    set metricsQuery(value: string);
    resetMetricsQuery(): void;
    get metricsQueryInput(): string | undefined;
    get name(): string;
    private _nameQuery?;
    get nameQuery(): string;
    set nameQuery(value: string);
    resetNameQuery(): void;
    get nameQueryInput(): string | undefined;
    private _query;
    get query(): DataDatadogServiceLevelObjectiveQueryList;
    get tags(): string[];
    private _tagsQuery?;
    get tagsQuery(): string;
    set tagsQuery(value: string);
    resetTagsQuery(): void;
    get tagsQueryInput(): string | undefined;
    get targetThreshold(): number;
    get timeframe(): string;
    get type(): string;
    get warningThreshold(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
