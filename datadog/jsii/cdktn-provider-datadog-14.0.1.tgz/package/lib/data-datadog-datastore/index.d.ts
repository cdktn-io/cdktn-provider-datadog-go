/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogDatastoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique identifier of the datastore to retrieve. If not specified, returns a single datastore from the list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/datastore#datastore_id DataDatadogDatastore#datastore_id}
    */
    readonly datastoreId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/datastore datadog_datastore}
*/
export declare class DataDatadogDatastore extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_datastore";
    /**
    * Generates CDKTN code for importing a DataDatadogDatastore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogDatastore to import
    * @param importFromId The id of the existing DataDatadogDatastore that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/datastore#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogDatastore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/datastore datadog_datastore} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogDatastoreConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogDatastoreConfig);
    get createdAt(): string;
    get creatorUserId(): number;
    get creatorUserUuid(): string;
    private _datastoreId?;
    get datastoreId(): string;
    set datastoreId(value: string);
    resetDatastoreId(): void;
    get datastoreIdInput(): string | undefined;
    get description(): string;
    get id(): string;
    get modifiedAt(): string;
    get name(): string;
    get orgId(): number;
    get primaryColumnName(): string;
    get primaryKeyGenerationStrategy(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
