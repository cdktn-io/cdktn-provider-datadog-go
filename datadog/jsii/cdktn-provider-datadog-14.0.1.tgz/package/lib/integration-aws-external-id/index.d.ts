/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IntegrationAwsExternalIdConfig extends cdktn.TerraformMetaArguments {
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_external_id datadog_integration_aws_external_id}
*/
export declare class IntegrationAwsExternalId extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_integration_aws_external_id";
    /**
    * Generates CDKTN code for importing a IntegrationAwsExternalId resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IntegrationAwsExternalId to import
    * @param importFromId The id of the existing IntegrationAwsExternalId that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_external_id#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IntegrationAwsExternalId to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_aws_external_id datadog_integration_aws_external_id} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IntegrationAwsExternalIdConfig = {}
    */
    constructor(scope: Construct, id: string, config?: IntegrationAwsExternalIdConfig);
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
