/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogSyntheticsGlobalVariableConfig extends cdktn.TerraformMetaArguments {
    /**
    * The synthetics global variable name to search for. Must only match one global variable. Must be all uppercase with underscores.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/synthetics_global_variable#name DataDatadogSyntheticsGlobalVariable#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/synthetics_global_variable datadog_synthetics_global_variable}
*/
export declare class DataDatadogSyntheticsGlobalVariable extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_synthetics_global_variable";
    /**
    * Generates CDKTN code for importing a DataDatadogSyntheticsGlobalVariable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogSyntheticsGlobalVariable to import
    * @param importFromId The id of the existing DataDatadogSyntheticsGlobalVariable that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/synthetics_global_variable#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogSyntheticsGlobalVariable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/synthetics_global_variable datadog_synthetics_global_variable} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogSyntheticsGlobalVariableConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogSyntheticsGlobalVariableConfig);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get tags(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
