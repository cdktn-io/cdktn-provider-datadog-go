/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogUserConfig extends cdktn.TerraformMetaArguments {
    /**
    * When true, `filter` string is exact matched against the user's `email`, followed by `name` attribute. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/user#exact_match DataDatadogUser#exact_match}
    */
    readonly exactMatch?: boolean | cdktn.IResolvable;
    /**
    * When true, service accounts are excluded from the result. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/user#exclude_service_accounts DataDatadogUser#exclude_service_accounts}
    */
    readonly excludeServiceAccounts?: boolean | cdktn.IResolvable;
    /**
    * Filter all users by the given string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/user#filter DataDatadogUser#filter}
    */
    readonly filter: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/user#id DataDatadogUser#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/user datadog_user}
*/
export declare class DataDatadogUser extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_user";
    /**
    * Generates CDKTN code for importing a DataDatadogUser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogUser to import
    * @param importFromId The id of the existing DataDatadogUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/user datadog_user} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogUserConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogUserConfig);
    get createdAt(): string;
    get disabled(): cdktn.IResolvable;
    get email(): string;
    private _exactMatch?;
    get exactMatch(): boolean | cdktn.IResolvable;
    set exactMatch(value: boolean | cdktn.IResolvable);
    resetExactMatch(): void;
    get exactMatchInput(): boolean | cdktn.IResolvable | undefined;
    private _excludeServiceAccounts?;
    get excludeServiceAccounts(): boolean | cdktn.IResolvable;
    set excludeServiceAccounts(value: boolean | cdktn.IResolvable);
    resetExcludeServiceAccounts(): void;
    get excludeServiceAccountsInput(): boolean | cdktn.IResolvable | undefined;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    get filterInput(): string | undefined;
    get handle(): string;
    get icon(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get mfaEnabled(): cdktn.IResolvable;
    get modifiedAt(): string;
    get name(): string;
    get serviceAccount(): cdktn.IResolvable;
    get status(): string;
    get title(): string;
    get verified(): cdktn.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
