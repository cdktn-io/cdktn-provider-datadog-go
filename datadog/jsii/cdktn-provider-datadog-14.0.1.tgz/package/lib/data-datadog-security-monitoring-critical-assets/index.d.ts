/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogSecurityMonitoringCriticalAssetsConfig extends cdktn.TerraformMetaArguments {
}
export interface DataDatadogSecurityMonitoringCriticalAssetsCriticalAssets {
}
export declare function dataDatadogSecurityMonitoringCriticalAssetsCriticalAssetsToTerraform(struct?: DataDatadogSecurityMonitoringCriticalAssetsCriticalAssets): any;
export declare function dataDatadogSecurityMonitoringCriticalAssetsCriticalAssetsToHclTerraform(struct?: DataDatadogSecurityMonitoringCriticalAssetsCriticalAssets): any;
export declare class DataDatadogSecurityMonitoringCriticalAssetsCriticalAssetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringCriticalAssetsCriticalAssets | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringCriticalAssetsCriticalAssets | undefined);
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get query(): string;
    get ruleQuery(): string;
    get severity(): string;
    get tags(): string[];
}
export declare class DataDatadogSecurityMonitoringCriticalAssetsCriticalAssetsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringCriticalAssetsCriticalAssetsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/security_monitoring_critical_assets datadog_security_monitoring_critical_assets}
*/
export declare class DataDatadogSecurityMonitoringCriticalAssets extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_security_monitoring_critical_assets";
    /**
    * Generates CDKTN code for importing a DataDatadogSecurityMonitoringCriticalAssets resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogSecurityMonitoringCriticalAssets to import
    * @param importFromId The id of the existing DataDatadogSecurityMonitoringCriticalAssets that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/security_monitoring_critical_assets#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogSecurityMonitoringCriticalAssets to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/security_monitoring_critical_assets datadog_security_monitoring_critical_assets} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogSecurityMonitoringCriticalAssetsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogSecurityMonitoringCriticalAssetsConfig);
    private _criticalAssets;
    get criticalAssets(): DataDatadogSecurityMonitoringCriticalAssetsCriticalAssetsList;
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
