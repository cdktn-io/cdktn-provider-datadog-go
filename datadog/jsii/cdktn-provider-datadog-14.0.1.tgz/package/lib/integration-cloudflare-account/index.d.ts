/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IntegrationCloudflareAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * The API key (or token) for the Cloudflare account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_cloudflare_account#api_key IntegrationCloudflareAccount#api_key}
    */
    readonly apiKey: string;
    /**
    * The email associated with the Cloudflare account. If an API key is provided (and not a token), this field is also required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_cloudflare_account#email IntegrationCloudflareAccount#email}
    */
    readonly email?: string;
    /**
    * The name of the Cloudflare account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_cloudflare_account#name IntegrationCloudflareAccount#name}
    */
    readonly name: string;
    /**
    * An allowlist of resources to pull metrics for. Includes `web`, `dns`, `lb` (load balancer), and `worker`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_cloudflare_account#resources IntegrationCloudflareAccount#resources}
    */
    readonly resources?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_cloudflare_account datadog_integration_cloudflare_account}
*/
export declare class IntegrationCloudflareAccount extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_integration_cloudflare_account";
    /**
    * Generates CDKTN code for importing a IntegrationCloudflareAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IntegrationCloudflareAccount to import
    * @param importFromId The id of the existing IntegrationCloudflareAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_cloudflare_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IntegrationCloudflareAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_cloudflare_account datadog_integration_cloudflare_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IntegrationCloudflareAccountConfig
    */
    constructor(scope: Construct, id: string, config: IntegrationCloudflareAccountConfig);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    get apiKeyInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _resources?;
    get resources(): string[];
    set resources(value: string[]);
    resetResources(): void;
    get resourcesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
