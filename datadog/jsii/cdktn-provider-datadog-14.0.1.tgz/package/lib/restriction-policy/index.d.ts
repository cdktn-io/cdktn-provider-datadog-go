/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RestrictionPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier for the resource, formatted as resource_type:resource_id.
    *
    * Resources to define `resource_type` :
    * * [List of supported resources](https://docs.datadoghq.com/account_management/rbac/granular_access)
    * * [Resource type definition](https://docs.datadoghq.com/api/latest/restriction-policies/#supported-resources)
    *
    * Restrictions :
    * * Dashboards : support is in private beta. Reach out to your Datadog contact or support to enable this.
    * * Monitors : Management of restriction policy through terraform is now available in Preview. Please request access via https://docs.datadoghq.com/help
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/restriction_policy#resource_id RestrictionPolicy#resource_id}
    */
    readonly resourceId: string;
    /**
    * bindings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/restriction_policy#bindings RestrictionPolicy#bindings}
    */
    readonly bindings?: RestrictionPolicyBindings[] | cdktn.IResolvable;
}
export interface RestrictionPolicyBindings {
    /**
    * An array of principals. A principal is a subject or group of subjects. Each principal is formatted as `type:id`. Supported types: `role`, `team`, `user`, and `org`. Org ID can be obtained using a `GET /api/v2/current_user` API request. Find it in the `data.relationships.org.data.id` field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/restriction_policy#principals RestrictionPolicy#principals}
    */
    readonly principals: string[];
    /**
    * The role/level of access. See this page for more details https://docs.datadoghq.com/api/latest/restriction-policies/#supported-relations-for-resources
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/restriction_policy#relation RestrictionPolicy#relation}
    */
    readonly relation: string;
}
export declare function restrictionPolicyBindingsToTerraform(struct?: RestrictionPolicyBindings | cdktn.IResolvable): any;
export declare function restrictionPolicyBindingsToHclTerraform(struct?: RestrictionPolicyBindings | cdktn.IResolvable): any;
export declare class RestrictionPolicyBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RestrictionPolicyBindings | cdktn.IResolvable | undefined;
    set internalValue(value: RestrictionPolicyBindings | cdktn.IResolvable | undefined);
    private _principals?;
    get principals(): string[];
    set principals(value: string[]);
    get principalsInput(): string[] | undefined;
    private _relation?;
    get relation(): string;
    set relation(value: string);
    get relationInput(): string | undefined;
}
export declare class RestrictionPolicyBindingsList extends cdktn.ComplexList {
    internalValue?: RestrictionPolicyBindings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RestrictionPolicyBindingsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/restriction_policy datadog_restriction_policy}
*/
export declare class RestrictionPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_restriction_policy";
    /**
    * Generates CDKTN code for importing a RestrictionPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RestrictionPolicy to import
    * @param importFromId The id of the existing RestrictionPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/restriction_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RestrictionPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/restriction_policy datadog_restriction_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RestrictionPolicyConfig
    */
    constructor(scope: Construct, id: string, config: RestrictionPolicyConfig);
    get id(): string;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
    private _bindings;
    get bindings(): RestrictionPolicyBindingsList;
    putBindings(value: RestrictionPolicyBindings[] | cdktn.IResolvable): void;
    resetBindings(): void;
    get bindingsInput(): cdktn.IResolvable | RestrictionPolicyBindings[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
