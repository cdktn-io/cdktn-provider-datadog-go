/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IntegrationGcpStsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Tags to be associated with GCP metrics and service checks from your account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp_sts#account_tags IntegrationGcpSts#account_tags}
    */
    readonly accountTags?: string[];
    /**
    * Silence monitors for expected GCE instance shutdowns.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp_sts#automute IntegrationGcpSts#automute}
    */
    readonly automute?: boolean | cdktn.IResolvable;
    /**
    * Your service account email address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp_sts#client_email IntegrationGcpSts#client_email}
    */
    readonly clientEmail: string;
    /**
    * List of filters to limit the Cloud Run revisions that are pulled into Datadog by using tags. Only Cloud Run revision resources that apply to specified filters are imported into Datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp_sts#cloud_run_revision_filters IntegrationGcpSts#cloud_run_revision_filters}
    */
    readonly cloudRunRevisionFilters?: string[];
    /**
    * List of filters to limit the VM instances that are pulled into Datadog by using tags. Only VM instance resources that apply to specified filters are imported into Datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp_sts#host_filters IntegrationGcpSts#host_filters}
    */
    readonly hostFilters?: string[];
    /**
    * Whether Datadog collects cloud security posture management resources from your GCP project. If enabled, requires `resource_collection_enabled` to also be enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp_sts#is_cspm_enabled IntegrationGcpSts#is_cspm_enabled}
    */
    readonly isCspmEnabled?: boolean | cdktn.IResolvable;
    /**
    * When enabled, Datadog collects metrics where location is explicitly stated as 'global' or where location information cannot be deduced from GCP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp_sts#is_global_location_enabled IntegrationGcpSts#is_global_location_enabled}
    */
    readonly isGlobalLocationEnabled?: boolean | cdktn.IResolvable;
    /**
    * When enabled, Datadog includes the `X-Goog-User-Project` header to attribute Google Cloud billing and quota usage to the monitored project instead of the default service account project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp_sts#is_per_project_quota_enabled IntegrationGcpSts#is_per_project_quota_enabled}
    */
    readonly isPerProjectQuotaEnabled?: boolean | cdktn.IResolvable;
    /**
    * When enabled, Datadog scans for all resource change data in your Google Cloud environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp_sts#is_resource_change_collection_enabled IntegrationGcpSts#is_resource_change_collection_enabled}
    */
    readonly isResourceChangeCollectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * When enabled, Datadog will attempt to collect Security Command Center Findings. Note: This requires additional permissions on the service account. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp_sts#is_security_command_center_enabled IntegrationGcpSts#is_security_command_center_enabled}
    */
    readonly isSecurityCommandCenterEnabled?: boolean | cdktn.IResolvable;
    /**
    * Configurations for GCP metric namespaces.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp_sts#metric_namespace_configs IntegrationGcpSts#metric_namespace_configs}
    */
    readonly metricNamespaceConfigs?: IntegrationGcpStsMetricNamespaceConfigs[] | cdktn.IResolvable;
    /**
    * Configurations for GCP monitored resources. Only monitored resources that apply to specified filters are imported into Datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp_sts#monitored_resource_configs IntegrationGcpSts#monitored_resource_configs}
    */
    readonly monitoredResourceConfigs?: IntegrationGcpStsMonitoredResourceConfigs[] | cdktn.IResolvable;
    /**
    * Configurations for GCP location filtering, such as region, multi-region, or zone. Only monitored resources that match the specified regions are imported into Datadog. By default, Datadog collects from all locations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp_sts#region_filter_configs IntegrationGcpSts#region_filter_configs}
    */
    readonly regionFilterConfigs?: string[];
    /**
    * When enabled, Datadog scans for all resources in your GCP environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp_sts#resource_collection_enabled IntegrationGcpSts#resource_collection_enabled}
    */
    readonly resourceCollectionEnabled?: boolean | cdktn.IResolvable;
}
export interface IntegrationGcpStsMetricNamespaceConfigs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp_sts#disabled IntegrationGcpSts#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp_sts#filters IntegrationGcpSts#filters}
    */
    readonly filters?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp_sts#id IntegrationGcpSts#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export declare function integrationGcpStsMetricNamespaceConfigsToTerraform(struct?: IntegrationGcpStsMetricNamespaceConfigs | cdktn.IResolvable): any;
export declare function integrationGcpStsMetricNamespaceConfigsToHclTerraform(struct?: IntegrationGcpStsMetricNamespaceConfigs | cdktn.IResolvable): any;
export declare class IntegrationGcpStsMetricNamespaceConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IntegrationGcpStsMetricNamespaceConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: IntegrationGcpStsMetricNamespaceConfigs | cdktn.IResolvable | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _filters?;
    get filters(): string[];
    set filters(value: string[]);
    resetFilters(): void;
    get filtersInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
}
export declare class IntegrationGcpStsMetricNamespaceConfigsList extends cdktn.ComplexList {
    internalValue?: IntegrationGcpStsMetricNamespaceConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IntegrationGcpStsMetricNamespaceConfigsOutputReference;
}
export interface IntegrationGcpStsMonitoredResourceConfigs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp_sts#filters IntegrationGcpSts#filters}
    */
    readonly filters?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp_sts#type IntegrationGcpSts#type}
    */
    readonly type?: string;
}
export declare function integrationGcpStsMonitoredResourceConfigsToTerraform(struct?: IntegrationGcpStsMonitoredResourceConfigs | cdktn.IResolvable): any;
export declare function integrationGcpStsMonitoredResourceConfigsToHclTerraform(struct?: IntegrationGcpStsMonitoredResourceConfigs | cdktn.IResolvable): any;
export declare class IntegrationGcpStsMonitoredResourceConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IntegrationGcpStsMonitoredResourceConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: IntegrationGcpStsMonitoredResourceConfigs | cdktn.IResolvable | undefined);
    private _filters?;
    get filters(): string[];
    set filters(value: string[]);
    resetFilters(): void;
    get filtersInput(): string[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class IntegrationGcpStsMonitoredResourceConfigsList extends cdktn.ComplexList {
    internalValue?: IntegrationGcpStsMonitoredResourceConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IntegrationGcpStsMonitoredResourceConfigsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp_sts datadog_integration_gcp_sts}
*/
export declare class IntegrationGcpSts extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_integration_gcp_sts";
    /**
    * Generates CDKTN code for importing a IntegrationGcpSts resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IntegrationGcpSts to import
    * @param importFromId The id of the existing IntegrationGcpSts that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp_sts#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IntegrationGcpSts to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp_sts datadog_integration_gcp_sts} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IntegrationGcpStsConfig
    */
    constructor(scope: Construct, id: string, config: IntegrationGcpStsConfig);
    private _accountTags?;
    get accountTags(): string[];
    set accountTags(value: string[]);
    resetAccountTags(): void;
    get accountTagsInput(): string[] | undefined;
    private _automute?;
    get automute(): boolean | cdktn.IResolvable;
    set automute(value: boolean | cdktn.IResolvable);
    resetAutomute(): void;
    get automuteInput(): boolean | cdktn.IResolvable | undefined;
    private _clientEmail?;
    get clientEmail(): string;
    set clientEmail(value: string);
    get clientEmailInput(): string | undefined;
    private _cloudRunRevisionFilters?;
    get cloudRunRevisionFilters(): string[];
    set cloudRunRevisionFilters(value: string[]);
    resetCloudRunRevisionFilters(): void;
    get cloudRunRevisionFiltersInput(): string[] | undefined;
    get delegateAccountEmail(): string;
    private _hostFilters?;
    get hostFilters(): string[];
    set hostFilters(value: string[]);
    resetHostFilters(): void;
    get hostFiltersInput(): string[] | undefined;
    get id(): string;
    private _isCspmEnabled?;
    get isCspmEnabled(): boolean | cdktn.IResolvable;
    set isCspmEnabled(value: boolean | cdktn.IResolvable);
    resetIsCspmEnabled(): void;
    get isCspmEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _isGlobalLocationEnabled?;
    get isGlobalLocationEnabled(): boolean | cdktn.IResolvable;
    set isGlobalLocationEnabled(value: boolean | cdktn.IResolvable);
    resetIsGlobalLocationEnabled(): void;
    get isGlobalLocationEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _isPerProjectQuotaEnabled?;
    get isPerProjectQuotaEnabled(): boolean | cdktn.IResolvable;
    set isPerProjectQuotaEnabled(value: boolean | cdktn.IResolvable);
    resetIsPerProjectQuotaEnabled(): void;
    get isPerProjectQuotaEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _isResourceChangeCollectionEnabled?;
    get isResourceChangeCollectionEnabled(): boolean | cdktn.IResolvable;
    set isResourceChangeCollectionEnabled(value: boolean | cdktn.IResolvable);
    resetIsResourceChangeCollectionEnabled(): void;
    get isResourceChangeCollectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _isSecurityCommandCenterEnabled?;
    get isSecurityCommandCenterEnabled(): boolean | cdktn.IResolvable;
    set isSecurityCommandCenterEnabled(value: boolean | cdktn.IResolvable);
    resetIsSecurityCommandCenterEnabled(): void;
    get isSecurityCommandCenterEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _metricNamespaceConfigs;
    get metricNamespaceConfigs(): IntegrationGcpStsMetricNamespaceConfigsList;
    putMetricNamespaceConfigs(value: IntegrationGcpStsMetricNamespaceConfigs[] | cdktn.IResolvable): void;
    resetMetricNamespaceConfigs(): void;
    get metricNamespaceConfigsInput(): cdktn.IResolvable | IntegrationGcpStsMetricNamespaceConfigs[] | undefined;
    private _monitoredResourceConfigs;
    get monitoredResourceConfigs(): IntegrationGcpStsMonitoredResourceConfigsList;
    putMonitoredResourceConfigs(value: IntegrationGcpStsMonitoredResourceConfigs[] | cdktn.IResolvable): void;
    resetMonitoredResourceConfigs(): void;
    get monitoredResourceConfigsInput(): cdktn.IResolvable | IntegrationGcpStsMonitoredResourceConfigs[] | undefined;
    private _regionFilterConfigs?;
    get regionFilterConfigs(): string[];
    set regionFilterConfigs(value: string[]);
    resetRegionFilterConfigs(): void;
    get regionFilterConfigsInput(): string[] | undefined;
    private _resourceCollectionEnabled?;
    get resourceCollectionEnabled(): boolean | cdktn.IResolvable;
    set resourceCollectionEnabled(value: boolean | cdktn.IResolvable);
    resetResourceCollectionEnabled(): void;
    get resourceCollectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
