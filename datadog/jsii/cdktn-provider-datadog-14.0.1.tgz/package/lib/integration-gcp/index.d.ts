/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IntegrationGcpConfig extends cdktn.TerraformMetaArguments {
    /**
    * Silence monitors for expected GCE instance shutdowns. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp#automute IntegrationGcp#automute}
    */
    readonly automute?: boolean | cdktn.IResolvable;
    /**
    * Your email found in your JSON service account key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp#client_email IntegrationGcp#client_email}
    */
    readonly clientEmail: string;
    /**
    * Your ID found in your JSON service account key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp#client_id IntegrationGcp#client_id}
    */
    readonly clientId: string;
    /**
    * List of filters to limit the Cloud Run revisions that are pulled into Datadog by using tags. Only Cloud Run revision resources that apply to specified filters are imported into Datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp#cloud_run_revision_filters IntegrationGcp#cloud_run_revision_filters}
    */
    readonly cloudRunRevisionFilters?: string[];
    /**
    * Whether Datadog collects cloud security posture management resources from your GCP project. If enabled, requires `resource_collection_enabled` to also be enabled. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp#cspm_resource_collection_enabled IntegrationGcp#cspm_resource_collection_enabled}
    */
    readonly cspmResourceCollectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * List of filters to limit the VM instances that are pulled into Datadog by using tags. Only VM instance resources that apply to specified filters are imported into Datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp#host_filters IntegrationGcp#host_filters}
    */
    readonly hostFilters?: string;
    /**
    * When enabled, Datadog scans for all resource change data in your Google Cloud environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp#is_resource_change_collection_enabled IntegrationGcp#is_resource_change_collection_enabled}
    */
    readonly isResourceChangeCollectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * When enabled, Datadog will attempt to collect Security Command Center Findings. Note: This requires additional permissions on the service account. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp#is_security_command_center_enabled IntegrationGcp#is_security_command_center_enabled}
    */
    readonly isSecurityCommandCenterEnabled?: boolean | cdktn.IResolvable;
    /**
    * Configurations for GCP monitored resources. Only monitored resources that apply to specified filters are imported into Datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp#monitored_resource_configs IntegrationGcp#monitored_resource_configs}
    */
    readonly monitoredResourceConfigs?: IntegrationGcpMonitoredResourceConfigs[] | cdktn.IResolvable;
    /**
    * Your private key name found in your JSON service account key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp#private_key IntegrationGcp#private_key}
    */
    readonly privateKey: string;
    /**
    * Your private key ID found in your JSON service account key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp#private_key_id IntegrationGcp#private_key_id}
    */
    readonly privateKeyId: string;
    /**
    * Your Google Cloud project ID found in your JSON service account key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp#project_id IntegrationGcp#project_id}
    */
    readonly projectId: string;
    /**
    * When enabled, Datadog scans for all resources in your GCP environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp#resource_collection_enabled IntegrationGcp#resource_collection_enabled}
    */
    readonly resourceCollectionEnabled?: boolean | cdktn.IResolvable;
}
export interface IntegrationGcpMonitoredResourceConfigs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp#filters IntegrationGcp#filters}
    */
    readonly filters?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp#type IntegrationGcp#type}
    */
    readonly type?: string;
}
export declare function integrationGcpMonitoredResourceConfigsToTerraform(struct?: IntegrationGcpMonitoredResourceConfigs | cdktn.IResolvable): any;
export declare function integrationGcpMonitoredResourceConfigsToHclTerraform(struct?: IntegrationGcpMonitoredResourceConfigs | cdktn.IResolvable): any;
export declare class IntegrationGcpMonitoredResourceConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): IntegrationGcpMonitoredResourceConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: IntegrationGcpMonitoredResourceConfigs | cdktn.IResolvable | undefined);
    private _filters?;
    get filters(): string[];
    set filters(value: string[]);
    resetFilters(): void;
    get filtersInput(): string[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class IntegrationGcpMonitoredResourceConfigsList extends cdktn.ComplexList {
    internalValue?: IntegrationGcpMonitoredResourceConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): IntegrationGcpMonitoredResourceConfigsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp datadog_integration_gcp}
*/
export declare class IntegrationGcp extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_integration_gcp";
    /**
    * Generates CDKTN code for importing a IntegrationGcp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IntegrationGcp to import
    * @param importFromId The id of the existing IntegrationGcp that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IntegrationGcp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_gcp datadog_integration_gcp} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IntegrationGcpConfig
    */
    constructor(scope: Construct, id: string, config: IntegrationGcpConfig);
    private _automute?;
    get automute(): boolean | cdktn.IResolvable;
    set automute(value: boolean | cdktn.IResolvable);
    resetAutomute(): void;
    get automuteInput(): boolean | cdktn.IResolvable | undefined;
    private _clientEmail?;
    get clientEmail(): string;
    set clientEmail(value: string);
    get clientEmailInput(): string | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    private _cloudRunRevisionFilters?;
    get cloudRunRevisionFilters(): string[];
    set cloudRunRevisionFilters(value: string[]);
    resetCloudRunRevisionFilters(): void;
    get cloudRunRevisionFiltersInput(): string[] | undefined;
    private _cspmResourceCollectionEnabled?;
    get cspmResourceCollectionEnabled(): boolean | cdktn.IResolvable;
    set cspmResourceCollectionEnabled(value: boolean | cdktn.IResolvable);
    resetCspmResourceCollectionEnabled(): void;
    get cspmResourceCollectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _hostFilters?;
    get hostFilters(): string;
    set hostFilters(value: string);
    resetHostFilters(): void;
    get hostFiltersInput(): string | undefined;
    get id(): string;
    private _isResourceChangeCollectionEnabled?;
    get isResourceChangeCollectionEnabled(): boolean | cdktn.IResolvable;
    set isResourceChangeCollectionEnabled(value: boolean | cdktn.IResolvable);
    resetIsResourceChangeCollectionEnabled(): void;
    get isResourceChangeCollectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _isSecurityCommandCenterEnabled?;
    get isSecurityCommandCenterEnabled(): boolean | cdktn.IResolvable;
    set isSecurityCommandCenterEnabled(value: boolean | cdktn.IResolvable);
    resetIsSecurityCommandCenterEnabled(): void;
    get isSecurityCommandCenterEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _monitoredResourceConfigs;
    get monitoredResourceConfigs(): IntegrationGcpMonitoredResourceConfigsList;
    putMonitoredResourceConfigs(value: IntegrationGcpMonitoredResourceConfigs[] | cdktn.IResolvable): void;
    resetMonitoredResourceConfigs(): void;
    get monitoredResourceConfigsInput(): cdktn.IResolvable | IntegrationGcpMonitoredResourceConfigs[] | undefined;
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    get privateKeyInput(): string | undefined;
    private _privateKeyId?;
    get privateKeyId(): string;
    set privateKeyId(value: string);
    get privateKeyIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _resourceCollectionEnabled?;
    get resourceCollectionEnabled(): boolean | cdktn.IResolvable;
    set resourceCollectionEnabled(value: boolean | cdktn.IResolvable);
    resetResourceCollectionEnabled(): void;
    get resourceCollectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
