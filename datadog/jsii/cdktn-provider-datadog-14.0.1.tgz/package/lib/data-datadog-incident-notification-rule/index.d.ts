/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogIncidentNotificationRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the incident notification rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/incident_notification_rule#id DataDatadogIncidentNotificationRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/incident_notification_rule#conditions DataDatadogIncidentNotificationRule#conditions}
    */
    readonly conditions?: DataDatadogIncidentNotificationRuleConditions[] | cdktn.IResolvable;
}
export interface DataDatadogIncidentNotificationRuleConditions {
}
export declare function dataDatadogIncidentNotificationRuleConditionsToTerraform(struct?: DataDatadogIncidentNotificationRuleConditions | cdktn.IResolvable): any;
export declare function dataDatadogIncidentNotificationRuleConditionsToHclTerraform(struct?: DataDatadogIncidentNotificationRuleConditions | cdktn.IResolvable): any;
export declare class DataDatadogIncidentNotificationRuleConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogIncidentNotificationRuleConditions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogIncidentNotificationRuleConditions | cdktn.IResolvable | undefined);
    get field(): string;
    get values(): string[];
}
export declare class DataDatadogIncidentNotificationRuleConditionsList extends cdktn.ComplexList {
    internalValue?: DataDatadogIncidentNotificationRuleConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogIncidentNotificationRuleConditionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/incident_notification_rule datadog_incident_notification_rule}
*/
export declare class DataDatadogIncidentNotificationRule extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_incident_notification_rule";
    /**
    * Generates CDKTN code for importing a DataDatadogIncidentNotificationRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogIncidentNotificationRule to import
    * @param importFromId The id of the existing DataDatadogIncidentNotificationRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/incident_notification_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogIncidentNotificationRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/incident_notification_rule datadog_incident_notification_rule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogIncidentNotificationRuleConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogIncidentNotificationRuleConfig);
    get created(): string;
    get enabled(): cdktn.IResolvable;
    get handles(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get incidentType(): string;
    get modified(): string;
    get notificationTemplate(): string;
    get renotifyOn(): string[];
    get trigger(): string;
    get visibility(): string;
    private _conditions;
    get conditions(): DataDatadogIncidentNotificationRuleConditionsList;
    putConditions(value: DataDatadogIncidentNotificationRuleConditions[] | cdktn.IResolvable): void;
    resetConditions(): void;
    get conditionsInput(): cdktn.IResolvable | DataDatadogIncidentNotificationRuleConditions[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
