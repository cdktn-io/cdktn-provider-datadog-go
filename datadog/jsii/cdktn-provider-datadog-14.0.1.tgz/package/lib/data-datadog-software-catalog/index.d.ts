/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogSoftwareCatalogConfig extends cdktn.TerraformMetaArguments {
    /**
    * Filter entities by excluding snapshotted entities.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/software_catalog#filter_exclude_snapshot DataDatadogSoftwareCatalog#filter_exclude_snapshot}
    */
    readonly filterExcludeSnapshot?: string;
    /**
    * Filter entities by UUID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/software_catalog#filter_id DataDatadogSoftwareCatalog#filter_id}
    */
    readonly filterId?: string;
    /**
    * Filter entities by kind.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/software_catalog#filter_kind DataDatadogSoftwareCatalog#filter_kind}
    */
    readonly filterKind?: string;
    /**
    * Filter entities by name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/software_catalog#filter_name DataDatadogSoftwareCatalog#filter_name}
    */
    readonly filterName?: string;
    /**
    * Filter entities by owner.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/software_catalog#filter_owner DataDatadogSoftwareCatalog#filter_owner}
    */
    readonly filterOwner?: string;
    /**
    * Filter entities by reference.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/software_catalog#filter_ref DataDatadogSoftwareCatalog#filter_ref}
    */
    readonly filterRef?: string;
    /**
    * Filter entities by relation type. Valid values are `RelationTypeOwns`, `RelationTypeOwnedBy`, `RelationTypeDependsOn`, `RelationTypeDependencyOf`, `RelationTypePartsOf`, `RelationTypeHasPart`, `RelationTypeOtherOwns`, `RelationTypeOtherOwnedBy`, `RelationTypeImplementedBy`, `RelationTypeImplements`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/software_catalog#filter_relation_type DataDatadogSoftwareCatalog#filter_relation_type}
    */
    readonly filterRelationType?: string;
}
export interface DataDatadogSoftwareCatalogEntities {
}
export declare function dataDatadogSoftwareCatalogEntitiesToTerraform(struct?: DataDatadogSoftwareCatalogEntities): any;
export declare function dataDatadogSoftwareCatalogEntitiesToHclTerraform(struct?: DataDatadogSoftwareCatalogEntities): any;
export declare class DataDatadogSoftwareCatalogEntitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSoftwareCatalogEntities | undefined;
    set internalValue(value: DataDatadogSoftwareCatalogEntities | undefined);
    get displayName(): string;
    get id(): string;
    get kind(): string;
    get name(): string;
    get namespace(): string;
    get owner(): string;
    get tags(): string[];
}
export declare class DataDatadogSoftwareCatalogEntitiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSoftwareCatalogEntitiesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/software_catalog datadog_software_catalog}
*/
export declare class DataDatadogSoftwareCatalog extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_software_catalog";
    /**
    * Generates CDKTN code for importing a DataDatadogSoftwareCatalog resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogSoftwareCatalog to import
    * @param importFromId The id of the existing DataDatadogSoftwareCatalog that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/software_catalog#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogSoftwareCatalog to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/software_catalog datadog_software_catalog} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogSoftwareCatalogConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogSoftwareCatalogConfig);
    private _entities;
    get entities(): DataDatadogSoftwareCatalogEntitiesList;
    private _filterExcludeSnapshot?;
    get filterExcludeSnapshot(): string;
    set filterExcludeSnapshot(value: string);
    resetFilterExcludeSnapshot(): void;
    get filterExcludeSnapshotInput(): string | undefined;
    private _filterId?;
    get filterId(): string;
    set filterId(value: string);
    resetFilterId(): void;
    get filterIdInput(): string | undefined;
    private _filterKind?;
    get filterKind(): string;
    set filterKind(value: string);
    resetFilterKind(): void;
    get filterKindInput(): string | undefined;
    private _filterName?;
    get filterName(): string;
    set filterName(value: string);
    resetFilterName(): void;
    get filterNameInput(): string | undefined;
    private _filterOwner?;
    get filterOwner(): string;
    set filterOwner(value: string);
    resetFilterOwner(): void;
    get filterOwnerInput(): string | undefined;
    private _filterRef?;
    get filterRef(): string;
    set filterRef(value: string);
    resetFilterRef(): void;
    get filterRefInput(): string | undefined;
    private _filterRelationType?;
    get filterRelationType(): string;
    set filterRelationType(value: string);
    resetFilterRelationType(): void;
    get filterRelationTypeInput(): string | undefined;
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
