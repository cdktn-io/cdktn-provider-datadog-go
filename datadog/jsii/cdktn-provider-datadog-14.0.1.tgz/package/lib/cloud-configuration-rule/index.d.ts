/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudConfigurationRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether the cloud configuration rule is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_configuration_rule#enabled CloudConfigurationRule#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Defaults to empty list. This function will be deprecated soon. Use the notification rules function instead. Fields to group by when generating signals, e.g. @resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_configuration_rule#group_by CloudConfigurationRule#group_by}
    */
    readonly groupBy?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_configuration_rule#id CloudConfigurationRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The message associated to the rule that will be shown in findings and signals.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_configuration_rule#message CloudConfigurationRule#message}
    */
    readonly message: string;
    /**
    * The name of the cloud configuration rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_configuration_rule#name CloudConfigurationRule#name}
    */
    readonly name: string;
    /**
    * This function will be deprecated soon. Use the notification rules function instead. Notification targets for signals. Defaults to empty list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_configuration_rule#notifications CloudConfigurationRule#notifications}
    */
    readonly notifications?: string[];
    /**
    * Policy written in Rego format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_configuration_rule#policy CloudConfigurationRule#policy}
    */
    readonly policy: string;
    /**
    * Related resource types to be checked by the rule. Defaults to empty list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_configuration_rule#related_resource_types CloudConfigurationRule#related_resource_types}
    */
    readonly relatedResourceTypes?: string[];
    /**
    * Main resource type to be checked by the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_configuration_rule#resource_type CloudConfigurationRule#resource_type}
    */
    readonly resourceType: string;
    /**
    * Severity of the rule and associated signals. Valid values are `info`, `low`, `medium`, `high`, `critical`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_configuration_rule#severity CloudConfigurationRule#severity}
    */
    readonly severity: string;
    /**
    * Tags of the rule, propagated to findings and signals. Defaults to empty list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_configuration_rule#tags CloudConfigurationRule#tags}
    */
    readonly tags?: string[];
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_configuration_rule#filter CloudConfigurationRule#filter}
    */
    readonly filter?: CloudConfigurationRuleFilter[] | cdktn.IResolvable;
}
export interface CloudConfigurationRuleFilter {
    /**
    * The type of filtering action. Valid values are `require`, `suppress`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_configuration_rule#action CloudConfigurationRule#action}
    */
    readonly action: string;
    /**
    * Query for selecting logs to apply the filtering action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_configuration_rule#query CloudConfigurationRule#query}
    */
    readonly query: string;
}
export declare function cloudConfigurationRuleFilterToTerraform(struct?: CloudConfigurationRuleFilter | cdktn.IResolvable): any;
export declare function cloudConfigurationRuleFilterToHclTerraform(struct?: CloudConfigurationRuleFilter | cdktn.IResolvable): any;
export declare class CloudConfigurationRuleFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudConfigurationRuleFilter | cdktn.IResolvable | undefined;
    set internalValue(value: CloudConfigurationRuleFilter | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class CloudConfigurationRuleFilterList extends cdktn.ComplexList {
    internalValue?: CloudConfigurationRuleFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudConfigurationRuleFilterOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_configuration_rule datadog_cloud_configuration_rule}
*/
export declare class CloudConfigurationRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_cloud_configuration_rule";
    /**
    * Generates CDKTN code for importing a CloudConfigurationRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudConfigurationRule to import
    * @param importFromId The id of the existing CloudConfigurationRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_configuration_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudConfigurationRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/cloud_configuration_rule datadog_cloud_configuration_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudConfigurationRuleConfig
    */
    constructor(scope: Construct, id: string, config: CloudConfigurationRuleConfig);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _groupBy?;
    get groupBy(): string[];
    set groupBy(value: string[]);
    resetGroupBy(): void;
    get groupByInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _message?;
    get message(): string;
    set message(value: string);
    get messageInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _notifications?;
    get notifications(): string[];
    set notifications(value: string[]);
    resetNotifications(): void;
    get notificationsInput(): string[] | undefined;
    private _policy?;
    get policy(): string;
    set policy(value: string);
    get policyInput(): string | undefined;
    private _relatedResourceTypes?;
    get relatedResourceTypes(): string[];
    set relatedResourceTypes(value: string[]);
    resetRelatedResourceTypes(): void;
    get relatedResourceTypesInput(): string[] | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    get resourceTypeInput(): string | undefined;
    private _severity?;
    get severity(): string;
    set severity(value: string);
    get severityInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _filter;
    get filter(): CloudConfigurationRuleFilterList;
    putFilter(value: CloudConfigurationRuleFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | CloudConfigurationRuleFilter[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
