/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LogsCustomPipelineConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#description LogsCustomPipeline#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#id LogsCustomPipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#tags LogsCustomPipeline#tags}
    */
    readonly tags?: string[];
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#filter LogsCustomPipeline#filter}
    */
    readonly filter: LogsCustomPipelineFilter[] | cdktn.IResolvable;
    /**
    * processor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#processor LogsCustomPipeline#processor}
    */
    readonly processor?: LogsCustomPipelineProcessor[] | cdktn.IResolvable;
}
export interface LogsCustomPipelineFilter {
    /**
    * Filter criteria of the category.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#query LogsCustomPipeline#query}
    */
    readonly query: string;
}
export declare function logsCustomPipelineFilterToTerraform(struct?: LogsCustomPipelineFilter | cdktn.IResolvable): any;
export declare function logsCustomPipelineFilterToHclTerraform(struct?: LogsCustomPipelineFilter | cdktn.IResolvable): any;
export declare class LogsCustomPipelineFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsCustomPipelineFilter | cdktn.IResolvable | undefined;
    set internalValue(value: LogsCustomPipelineFilter | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class LogsCustomPipelineFilterList extends cdktn.ComplexList {
    internalValue?: LogsCustomPipelineFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsCustomPipelineFilterOutputReference;
}
export interface LogsCustomPipelineProcessorArithmeticProcessor {
    /**
    * Arithmetic operation between one or more log attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#expression LogsCustomPipeline#expression}
    */
    readonly expression: string;
    /**
    * Boolean value to enable your pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * If true, it replaces all missing attributes of expression by 0, false skips the operation if an attribute is missing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_replace_missing LogsCustomPipeline#is_replace_missing}
    */
    readonly isReplaceMissing?: boolean | cdktn.IResolvable;
    /**
    * Your pipeline name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * Name of the attribute that contains the result of the arithmetic operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
}
export declare function logsCustomPipelineProcessorArithmeticProcessorToTerraform(struct?: LogsCustomPipelineProcessorArithmeticProcessorOutputReference | LogsCustomPipelineProcessorArithmeticProcessor): any;
export declare function logsCustomPipelineProcessorArithmeticProcessorToHclTerraform(struct?: LogsCustomPipelineProcessorArithmeticProcessorOutputReference | LogsCustomPipelineProcessorArithmeticProcessor): any;
export declare class LogsCustomPipelineProcessorArithmeticProcessorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorArithmeticProcessor | undefined;
    set internalValue(value: LogsCustomPipelineProcessorArithmeticProcessor | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _isReplaceMissing?;
    get isReplaceMissing(): boolean | cdktn.IResolvable;
    set isReplaceMissing(value: boolean | cdktn.IResolvable);
    resetIsReplaceMissing(): void;
    get isReplaceMissingInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorArrayProcessorOperationAppend {
    /**
    * Remove or preserve the remapped source element. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#preserve_source LogsCustomPipeline#preserve_source}
    */
    readonly preserveSource?: boolean | cdktn.IResolvable;
    /**
    * Attribute path containing the value to append.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#source LogsCustomPipeline#source}
    */
    readonly source: string;
    /**
    * Attribute path of the array to append to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
}
export declare function logsCustomPipelineProcessorArrayProcessorOperationAppendToTerraform(struct?: LogsCustomPipelineProcessorArrayProcessorOperationAppendOutputReference | LogsCustomPipelineProcessorArrayProcessorOperationAppend): any;
export declare function logsCustomPipelineProcessorArrayProcessorOperationAppendToHclTerraform(struct?: LogsCustomPipelineProcessorArrayProcessorOperationAppendOutputReference | LogsCustomPipelineProcessorArrayProcessorOperationAppend): any;
export declare class LogsCustomPipelineProcessorArrayProcessorOperationAppendOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorArrayProcessorOperationAppend | undefined;
    set internalValue(value: LogsCustomPipelineProcessorArrayProcessorOperationAppend | undefined);
    private _preserveSource?;
    get preserveSource(): boolean | cdktn.IResolvable;
    set preserveSource(value: boolean | cdktn.IResolvable);
    resetPreserveSource(): void;
    get preserveSourceInput(): boolean | cdktn.IResolvable | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorArrayProcessorOperationLength {
    /**
    * Attribute path of the array to compute the length of.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#source LogsCustomPipeline#source}
    */
    readonly source: string;
    /**
    * Attribute that receives the computed length.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
}
export declare function logsCustomPipelineProcessorArrayProcessorOperationLengthToTerraform(struct?: LogsCustomPipelineProcessorArrayProcessorOperationLengthOutputReference | LogsCustomPipelineProcessorArrayProcessorOperationLength): any;
export declare function logsCustomPipelineProcessorArrayProcessorOperationLengthToHclTerraform(struct?: LogsCustomPipelineProcessorArrayProcessorOperationLengthOutputReference | LogsCustomPipelineProcessorArrayProcessorOperationLength): any;
export declare class LogsCustomPipelineProcessorArrayProcessorOperationLengthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorArrayProcessorOperationLength | undefined;
    set internalValue(value: LogsCustomPipelineProcessorArrayProcessorOperationLength | undefined);
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorArrayProcessorOperationSelect {
    /**
    * Filter expression (e.g. key1:value1 OR key2:value2) used to find the matching element.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#filter LogsCustomPipeline#filter}
    */
    readonly filter: string;
    /**
    * Attribute path of the array to search into.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#source LogsCustomPipeline#source}
    */
    readonly source: string;
    /**
    * Attribute that receives the extracted value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
    /**
    * Attribute key from the matching object that should be extracted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#value_to_extract LogsCustomPipeline#value_to_extract}
    */
    readonly valueToExtract: string;
}
export declare function logsCustomPipelineProcessorArrayProcessorOperationSelectToTerraform(struct?: LogsCustomPipelineProcessorArrayProcessorOperationSelectOutputReference | LogsCustomPipelineProcessorArrayProcessorOperationSelect): any;
export declare function logsCustomPipelineProcessorArrayProcessorOperationSelectToHclTerraform(struct?: LogsCustomPipelineProcessorArrayProcessorOperationSelectOutputReference | LogsCustomPipelineProcessorArrayProcessorOperationSelect): any;
export declare class LogsCustomPipelineProcessorArrayProcessorOperationSelectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorArrayProcessorOperationSelect | undefined;
    set internalValue(value: LogsCustomPipelineProcessorArrayProcessorOperationSelect | undefined);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    get filterInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _valueToExtract?;
    get valueToExtract(): string;
    set valueToExtract(value: string);
    get valueToExtractInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorArrayProcessorOperation {
    /**
    * append block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#append LogsCustomPipeline#append}
    */
    readonly append?: LogsCustomPipelineProcessorArrayProcessorOperationAppend;
    /**
    * length block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#length LogsCustomPipeline#length}
    */
    readonly length?: LogsCustomPipelineProcessorArrayProcessorOperationLength;
    /**
    * select block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#select LogsCustomPipeline#select}
    */
    readonly select?: LogsCustomPipelineProcessorArrayProcessorOperationSelect;
}
export declare function logsCustomPipelineProcessorArrayProcessorOperationToTerraform(struct?: LogsCustomPipelineProcessorArrayProcessorOperationOutputReference | LogsCustomPipelineProcessorArrayProcessorOperation): any;
export declare function logsCustomPipelineProcessorArrayProcessorOperationToHclTerraform(struct?: LogsCustomPipelineProcessorArrayProcessorOperationOutputReference | LogsCustomPipelineProcessorArrayProcessorOperation): any;
export declare class LogsCustomPipelineProcessorArrayProcessorOperationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorArrayProcessorOperation | undefined;
    set internalValue(value: LogsCustomPipelineProcessorArrayProcessorOperation | undefined);
    private _append;
    get append(): LogsCustomPipelineProcessorArrayProcessorOperationAppendOutputReference;
    putAppend(value: LogsCustomPipelineProcessorArrayProcessorOperationAppend): void;
    resetAppend(): void;
    get appendInput(): LogsCustomPipelineProcessorArrayProcessorOperationAppend | undefined;
    private _length;
    get length(): LogsCustomPipelineProcessorArrayProcessorOperationLengthOutputReference;
    putLength(value: LogsCustomPipelineProcessorArrayProcessorOperationLength): void;
    resetLength(): void;
    get lengthInput(): LogsCustomPipelineProcessorArrayProcessorOperationLength | undefined;
    private _select;
    get select(): LogsCustomPipelineProcessorArrayProcessorOperationSelectOutputReference;
    putSelect(value: LogsCustomPipelineProcessorArrayProcessorOperationSelect): void;
    resetSelect(): void;
    get selectInput(): LogsCustomPipelineProcessorArrayProcessorOperationSelect | undefined;
}
export interface LogsCustomPipelineProcessorArrayProcessor {
    /**
    * Boolean value to enable your processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Your processor name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * operation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#operation LogsCustomPipeline#operation}
    */
    readonly operation: LogsCustomPipelineProcessorArrayProcessorOperation;
}
export declare function logsCustomPipelineProcessorArrayProcessorToTerraform(struct?: LogsCustomPipelineProcessorArrayProcessorOutputReference | LogsCustomPipelineProcessorArrayProcessor): any;
export declare function logsCustomPipelineProcessorArrayProcessorToHclTerraform(struct?: LogsCustomPipelineProcessorArrayProcessorOutputReference | LogsCustomPipelineProcessorArrayProcessor): any;
export declare class LogsCustomPipelineProcessorArrayProcessorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorArrayProcessor | undefined;
    set internalValue(value: LogsCustomPipelineProcessorArrayProcessor | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _operation;
    get operation(): LogsCustomPipelineProcessorArrayProcessorOperationOutputReference;
    putOperation(value: LogsCustomPipelineProcessorArrayProcessorOperation): void;
    get operationInput(): LogsCustomPipelineProcessorArrayProcessorOperation | undefined;
}
export interface LogsCustomPipelineProcessorAttributeRemapper {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * Override the target element if already set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#override_on_conflict LogsCustomPipeline#override_on_conflict}
    */
    readonly overrideOnConflict?: boolean | cdktn.IResolvable;
    /**
    * Remove or preserve the remapped source element.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#preserve_source LogsCustomPipeline#preserve_source}
    */
    readonly preserveSource?: boolean | cdktn.IResolvable;
    /**
    * Defines where the sources are from (log `attribute` or `tag`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#source_type LogsCustomPipeline#source_type}
    */
    readonly sourceType: string;
    /**
    * List of source attributes or tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources: string[];
    /**
    * Final attribute or tag name to remap the sources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
    /**
    * If the `target_type` of the remapper is `attribute`, try to cast the value to a new specific type. If the cast is not possible, the original type is kept. `string`, `integer`, or `double` are the possible types. If the `target_type` is `tag`, this parameter may not be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target_format LogsCustomPipeline#target_format}
    */
    readonly targetFormat?: string;
    /**
    * Defines if the target is a log `attribute` or `tag`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target_type LogsCustomPipeline#target_type}
    */
    readonly targetType: string;
}
export declare function logsCustomPipelineProcessorAttributeRemapperToTerraform(struct?: LogsCustomPipelineProcessorAttributeRemapperOutputReference | LogsCustomPipelineProcessorAttributeRemapper): any;
export declare function logsCustomPipelineProcessorAttributeRemapperToHclTerraform(struct?: LogsCustomPipelineProcessorAttributeRemapperOutputReference | LogsCustomPipelineProcessorAttributeRemapper): any;
export declare class LogsCustomPipelineProcessorAttributeRemapperOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorAttributeRemapper | undefined;
    set internalValue(value: LogsCustomPipelineProcessorAttributeRemapper | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _overrideOnConflict?;
    get overrideOnConflict(): boolean | cdktn.IResolvable;
    set overrideOnConflict(value: boolean | cdktn.IResolvable);
    resetOverrideOnConflict(): void;
    get overrideOnConflictInput(): boolean | cdktn.IResolvable | undefined;
    private _preserveSource?;
    get preserveSource(): boolean | cdktn.IResolvable;
    set preserveSource(value: boolean | cdktn.IResolvable);
    resetPreserveSource(): void;
    get preserveSourceInput(): boolean | cdktn.IResolvable | undefined;
    private _sourceType?;
    get sourceType(): string;
    set sourceType(value: string);
    get sourceTypeInput(): string | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    get sourcesInput(): string[] | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _targetFormat?;
    get targetFormat(): string;
    set targetFormat(value: string);
    resetTargetFormat(): void;
    get targetFormatInput(): string | undefined;
    private _targetType?;
    get targetType(): string;
    set targetType(value: string);
    get targetTypeInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorCategoryProcessorCategoryFilter {
    /**
    * Filter criteria of the category.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#query LogsCustomPipeline#query}
    */
    readonly query: string;
}
export declare function logsCustomPipelineProcessorCategoryProcessorCategoryFilterToTerraform(struct?: LogsCustomPipelineProcessorCategoryProcessorCategoryFilterOutputReference | LogsCustomPipelineProcessorCategoryProcessorCategoryFilter): any;
export declare function logsCustomPipelineProcessorCategoryProcessorCategoryFilterToHclTerraform(struct?: LogsCustomPipelineProcessorCategoryProcessorCategoryFilterOutputReference | LogsCustomPipelineProcessorCategoryProcessorCategoryFilter): any;
export declare class LogsCustomPipelineProcessorCategoryProcessorCategoryFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorCategoryProcessorCategoryFilter | undefined;
    set internalValue(value: LogsCustomPipelineProcessorCategoryProcessorCategoryFilter | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorCategoryProcessorCategory {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#filter LogsCustomPipeline#filter}
    */
    readonly filter: LogsCustomPipelineProcessorCategoryProcessorCategoryFilter;
}
export declare function logsCustomPipelineProcessorCategoryProcessorCategoryToTerraform(struct?: LogsCustomPipelineProcessorCategoryProcessorCategory | cdktn.IResolvable): any;
export declare function logsCustomPipelineProcessorCategoryProcessorCategoryToHclTerraform(struct?: LogsCustomPipelineProcessorCategoryProcessorCategory | cdktn.IResolvable): any;
export declare class LogsCustomPipelineProcessorCategoryProcessorCategoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsCustomPipelineProcessorCategoryProcessorCategory | cdktn.IResolvable | undefined;
    set internalValue(value: LogsCustomPipelineProcessorCategoryProcessorCategory | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _filter;
    get filter(): LogsCustomPipelineProcessorCategoryProcessorCategoryFilterOutputReference;
    putFilter(value: LogsCustomPipelineProcessorCategoryProcessorCategoryFilter): void;
    get filterInput(): LogsCustomPipelineProcessorCategoryProcessorCategoryFilter | undefined;
}
export declare class LogsCustomPipelineProcessorCategoryProcessorCategoryList extends cdktn.ComplexList {
    internalValue?: LogsCustomPipelineProcessorCategoryProcessorCategory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsCustomPipelineProcessorCategoryProcessorCategoryOutputReference;
}
export interface LogsCustomPipelineProcessorCategoryProcessor {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the category
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * Name of the target attribute whose value is defined by the matching category.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
    /**
    * category block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#category LogsCustomPipeline#category}
    */
    readonly category: LogsCustomPipelineProcessorCategoryProcessorCategory[] | cdktn.IResolvable;
}
export declare function logsCustomPipelineProcessorCategoryProcessorToTerraform(struct?: LogsCustomPipelineProcessorCategoryProcessorOutputReference | LogsCustomPipelineProcessorCategoryProcessor): any;
export declare function logsCustomPipelineProcessorCategoryProcessorToHclTerraform(struct?: LogsCustomPipelineProcessorCategoryProcessorOutputReference | LogsCustomPipelineProcessorCategoryProcessor): any;
export declare class LogsCustomPipelineProcessorCategoryProcessorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorCategoryProcessor | undefined;
    set internalValue(value: LogsCustomPipelineProcessorCategoryProcessor | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _category;
    get category(): LogsCustomPipelineProcessorCategoryProcessorCategoryList;
    putCategory(value: LogsCustomPipelineProcessorCategoryProcessorCategory[] | cdktn.IResolvable): void;
    get categoryInput(): cdktn.IResolvable | LogsCustomPipelineProcessorCategoryProcessorCategory[] | undefined;
}
export interface LogsCustomPipelineProcessorDateRemapper {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * List of source attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources: string[];
}
export declare function logsCustomPipelineProcessorDateRemapperToTerraform(struct?: LogsCustomPipelineProcessorDateRemapperOutputReference | LogsCustomPipelineProcessorDateRemapper): any;
export declare function logsCustomPipelineProcessorDateRemapperToHclTerraform(struct?: LogsCustomPipelineProcessorDateRemapperOutputReference | LogsCustomPipelineProcessorDateRemapper): any;
export declare class LogsCustomPipelineProcessorDateRemapperOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorDateRemapper | undefined;
    set internalValue(value: LogsCustomPipelineProcessorDateRemapper | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    get sourcesInput(): string[] | undefined;
}
export interface LogsCustomPipelineProcessorDecoderProcessor {
    /**
    * Encoding type: base64 or base16
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#binary_to_text_encoding LogsCustomPipeline#binary_to_text_encoding}
    */
    readonly binaryToTextEncoding: string;
    /**
    * Input representation: utf-8 or integer
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#input_representation LogsCustomPipeline#input_representation}
    */
    readonly inputRepresentation: string;
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * Encoded message
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#source LogsCustomPipeline#source}
    */
    readonly source: string;
    /**
    * Decoded message
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
}
export declare function logsCustomPipelineProcessorDecoderProcessorToTerraform(struct?: LogsCustomPipelineProcessorDecoderProcessorOutputReference | LogsCustomPipelineProcessorDecoderProcessor): any;
export declare function logsCustomPipelineProcessorDecoderProcessorToHclTerraform(struct?: LogsCustomPipelineProcessorDecoderProcessorOutputReference | LogsCustomPipelineProcessorDecoderProcessor): any;
export declare class LogsCustomPipelineProcessorDecoderProcessorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorDecoderProcessor | undefined;
    set internalValue(value: LogsCustomPipelineProcessorDecoderProcessor | undefined);
    private _binaryToTextEncoding?;
    get binaryToTextEncoding(): string;
    set binaryToTextEncoding(value: string);
    get binaryToTextEncodingInput(): string | undefined;
    private _inputRepresentation?;
    get inputRepresentation(): string;
    set inputRepresentation(value: string);
    get inputRepresentationInput(): string | undefined;
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorGeoIpParser {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * List of source attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources: string[];
    /**
    * Name of the parent attribute that contains all the extracted details from the sources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
}
export declare function logsCustomPipelineProcessorGeoIpParserToTerraform(struct?: LogsCustomPipelineProcessorGeoIpParserOutputReference | LogsCustomPipelineProcessorGeoIpParser): any;
export declare function logsCustomPipelineProcessorGeoIpParserToHclTerraform(struct?: LogsCustomPipelineProcessorGeoIpParserOutputReference | LogsCustomPipelineProcessorGeoIpParser): any;
export declare class LogsCustomPipelineProcessorGeoIpParserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorGeoIpParser | undefined;
    set internalValue(value: LogsCustomPipelineProcessorGeoIpParser | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    get sourcesInput(): string[] | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorGrokParserGrok {
    /**
    * Match rules for your grok parser.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#match_rules LogsCustomPipeline#match_rules}
    */
    readonly matchRules: string;
    /**
    * Support rules for your grok parser.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#support_rules LogsCustomPipeline#support_rules}
    */
    readonly supportRules: string;
}
export declare function logsCustomPipelineProcessorGrokParserGrokToTerraform(struct?: LogsCustomPipelineProcessorGrokParserGrokOutputReference | LogsCustomPipelineProcessorGrokParserGrok): any;
export declare function logsCustomPipelineProcessorGrokParserGrokToHclTerraform(struct?: LogsCustomPipelineProcessorGrokParserGrokOutputReference | LogsCustomPipelineProcessorGrokParserGrok): any;
export declare class LogsCustomPipelineProcessorGrokParserGrokOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorGrokParserGrok | undefined;
    set internalValue(value: LogsCustomPipelineProcessorGrokParserGrok | undefined);
    private _matchRules?;
    get matchRules(): string;
    set matchRules(value: string);
    get matchRulesInput(): string | undefined;
    private _supportRules?;
    get supportRules(): string;
    set supportRules(value: string);
    get supportRulesInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorGrokParser {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * List of sample logs for this parser. It can save up to 5 samples. Each sample takes up to 5000 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#samples LogsCustomPipeline#samples}
    */
    readonly samples?: string[];
    /**
    * Name of the log attribute to parse.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#source LogsCustomPipeline#source}
    */
    readonly source: string;
    /**
    * grok block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#grok LogsCustomPipeline#grok}
    */
    readonly grok: LogsCustomPipelineProcessorGrokParserGrok;
}
export declare function logsCustomPipelineProcessorGrokParserToTerraform(struct?: LogsCustomPipelineProcessorGrokParserOutputReference | LogsCustomPipelineProcessorGrokParser): any;
export declare function logsCustomPipelineProcessorGrokParserToHclTerraform(struct?: LogsCustomPipelineProcessorGrokParserOutputReference | LogsCustomPipelineProcessorGrokParser): any;
export declare class LogsCustomPipelineProcessorGrokParserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorGrokParser | undefined;
    set internalValue(value: LogsCustomPipelineProcessorGrokParser | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _samples?;
    get samples(): string[];
    set samples(value: string[]);
    resetSamples(): void;
    get samplesInput(): string[] | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _grok;
    get grok(): LogsCustomPipelineProcessorGrokParserGrokOutputReference;
    putGrok(value: LogsCustomPipelineProcessorGrokParserGrok): void;
    get grokInput(): LogsCustomPipelineProcessorGrokParserGrok | undefined;
}
export interface LogsCustomPipelineProcessorLookupProcessor {
    /**
    * Default lookup value to use if there is no entry in the lookup table for the value of the source attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#default_lookup LogsCustomPipeline#default_lookup}
    */
    readonly defaultLookup?: string;
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * List of entries of the lookup table using `key,value` format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#lookup_table LogsCustomPipeline#lookup_table}
    */
    readonly lookupTable: string[];
    /**
    * Name of the processor
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * Name of the source attribute used to do the lookup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#source LogsCustomPipeline#source}
    */
    readonly source: string;
    /**
    * Name of the attribute that contains the result of the lookup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
}
export declare function logsCustomPipelineProcessorLookupProcessorToTerraform(struct?: LogsCustomPipelineProcessorLookupProcessorOutputReference | LogsCustomPipelineProcessorLookupProcessor): any;
export declare function logsCustomPipelineProcessorLookupProcessorToHclTerraform(struct?: LogsCustomPipelineProcessorLookupProcessorOutputReference | LogsCustomPipelineProcessorLookupProcessor): any;
export declare class LogsCustomPipelineProcessorLookupProcessorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorLookupProcessor | undefined;
    set internalValue(value: LogsCustomPipelineProcessorLookupProcessor | undefined);
    private _defaultLookup?;
    get defaultLookup(): string;
    set defaultLookup(value: string);
    resetDefaultLookup(): void;
    get defaultLookupInput(): string | undefined;
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _lookupTable?;
    get lookupTable(): string[];
    set lookupTable(value: string[]);
    get lookupTableInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorMessageRemapper {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * List of source attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources: string[];
}
export declare function logsCustomPipelineProcessorMessageRemapperToTerraform(struct?: LogsCustomPipelineProcessorMessageRemapperOutputReference | LogsCustomPipelineProcessorMessageRemapper): any;
export declare function logsCustomPipelineProcessorMessageRemapperToHclTerraform(struct?: LogsCustomPipelineProcessorMessageRemapperOutputReference | LogsCustomPipelineProcessorMessageRemapper): any;
export declare class LogsCustomPipelineProcessorMessageRemapperOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorMessageRemapper | undefined;
    set internalValue(value: LogsCustomPipelineProcessorMessageRemapper | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    get sourcesInput(): string[] | undefined;
}
export interface LogsCustomPipelineProcessorPipelineFilter {
    /**
    * Filter criteria of the category.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#query LogsCustomPipeline#query}
    */
    readonly query: string;
}
export declare function logsCustomPipelineProcessorPipelineFilterToTerraform(struct?: LogsCustomPipelineProcessorPipelineFilter | cdktn.IResolvable): any;
export declare function logsCustomPipelineProcessorPipelineFilterToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineFilter | cdktn.IResolvable): any;
export declare class LogsCustomPipelineProcessorPipelineFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsCustomPipelineProcessorPipelineFilter | cdktn.IResolvable | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineFilter | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export declare class LogsCustomPipelineProcessorPipelineFilterList extends cdktn.ComplexList {
    internalValue?: LogsCustomPipelineProcessorPipelineFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsCustomPipelineProcessorPipelineFilterOutputReference;
}
export interface LogsCustomPipelineProcessorPipelineProcessorArithmeticProcessor {
    /**
    * Arithmetic operation between one or more log attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#expression LogsCustomPipeline#expression}
    */
    readonly expression: string;
    /**
    * Boolean value to enable your pipeline.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * If true, it replaces all missing attributes of expression by 0, false skips the operation if an attribute is missing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_replace_missing LogsCustomPipeline#is_replace_missing}
    */
    readonly isReplaceMissing?: boolean | cdktn.IResolvable;
    /**
    * Your pipeline name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * Name of the attribute that contains the result of the arithmetic operation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
}
export declare function logsCustomPipelineProcessorPipelineProcessorArithmeticProcessorToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorArithmeticProcessorOutputReference | LogsCustomPipelineProcessorPipelineProcessorArithmeticProcessor): any;
export declare function logsCustomPipelineProcessorPipelineProcessorArithmeticProcessorToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorArithmeticProcessorOutputReference | LogsCustomPipelineProcessorPipelineProcessorArithmeticProcessor): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorArithmeticProcessorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorArithmeticProcessor | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorArithmeticProcessor | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _isReplaceMissing?;
    get isReplaceMissing(): boolean | cdktn.IResolvable;
    set isReplaceMissing(value: boolean | cdktn.IResolvable);
    resetIsReplaceMissing(): void;
    get isReplaceMissingInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationAppend {
    /**
    * Remove or preserve the remapped source element. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#preserve_source LogsCustomPipeline#preserve_source}
    */
    readonly preserveSource?: boolean | cdktn.IResolvable;
    /**
    * Attribute path containing the value to append.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#source LogsCustomPipeline#source}
    */
    readonly source: string;
    /**
    * Attribute path of the array to append to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
}
export declare function logsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationAppendToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationAppendOutputReference | LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationAppend): any;
export declare function logsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationAppendToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationAppendOutputReference | LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationAppend): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationAppendOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationAppend | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationAppend | undefined);
    private _preserveSource?;
    get preserveSource(): boolean | cdktn.IResolvable;
    set preserveSource(value: boolean | cdktn.IResolvable);
    resetPreserveSource(): void;
    get preserveSourceInput(): boolean | cdktn.IResolvable | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationLength {
    /**
    * Attribute path of the array to compute the length of.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#source LogsCustomPipeline#source}
    */
    readonly source: string;
    /**
    * Attribute that receives the computed length.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
}
export declare function logsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationLengthToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationLengthOutputReference | LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationLength): any;
export declare function logsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationLengthToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationLengthOutputReference | LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationLength): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationLengthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationLength | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationLength | undefined);
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationSelect {
    /**
    * Filter expression (e.g. key1:value1 OR key2:value2) used to find the matching element.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#filter LogsCustomPipeline#filter}
    */
    readonly filter: string;
    /**
    * Attribute path of the array to search into.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#source LogsCustomPipeline#source}
    */
    readonly source: string;
    /**
    * Attribute that receives the extracted value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
    /**
    * Attribute key from the matching object that should be extracted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#value_to_extract LogsCustomPipeline#value_to_extract}
    */
    readonly valueToExtract: string;
}
export declare function logsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationSelectToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationSelectOutputReference | LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationSelect): any;
export declare function logsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationSelectToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationSelectOutputReference | LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationSelect): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationSelectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationSelect | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationSelect | undefined);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    get filterInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _valueToExtract?;
    get valueToExtract(): string;
    set valueToExtract(value: string);
    get valueToExtractInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperation {
    /**
    * append block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#append LogsCustomPipeline#append}
    */
    readonly append?: LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationAppend;
    /**
    * length block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#length LogsCustomPipeline#length}
    */
    readonly length?: LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationLength;
    /**
    * select block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#select LogsCustomPipeline#select}
    */
    readonly select?: LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationSelect;
}
export declare function logsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationOutputReference | LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperation): any;
export declare function logsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationOutputReference | LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperation): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperation | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperation | undefined);
    private _append;
    get append(): LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationAppendOutputReference;
    putAppend(value: LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationAppend): void;
    resetAppend(): void;
    get appendInput(): LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationAppend | undefined;
    private _length;
    get length(): LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationLengthOutputReference;
    putLength(value: LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationLength): void;
    resetLength(): void;
    get lengthInput(): LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationLength | undefined;
    private _select;
    get select(): LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationSelectOutputReference;
    putSelect(value: LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationSelect): void;
    resetSelect(): void;
    get selectInput(): LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationSelect | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorArrayProcessor {
    /**
    * Boolean value to enable your processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Your processor name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * operation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#operation LogsCustomPipeline#operation}
    */
    readonly operation: LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperation;
}
export declare function logsCustomPipelineProcessorPipelineProcessorArrayProcessorToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOutputReference | LogsCustomPipelineProcessorPipelineProcessorArrayProcessor): any;
export declare function logsCustomPipelineProcessorPipelineProcessorArrayProcessorToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOutputReference | LogsCustomPipelineProcessorPipelineProcessorArrayProcessor): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorArrayProcessor | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorArrayProcessor | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _operation;
    get operation(): LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperationOutputReference;
    putOperation(value: LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperation): void;
    get operationInput(): LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOperation | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorAttributeRemapper {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * Override the target element if already set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#override_on_conflict LogsCustomPipeline#override_on_conflict}
    */
    readonly overrideOnConflict?: boolean | cdktn.IResolvable;
    /**
    * Remove or preserve the remapped source element.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#preserve_source LogsCustomPipeline#preserve_source}
    */
    readonly preserveSource?: boolean | cdktn.IResolvable;
    /**
    * Defines where the sources are from (log `attribute` or `tag`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#source_type LogsCustomPipeline#source_type}
    */
    readonly sourceType: string;
    /**
    * List of source attributes or tags.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources: string[];
    /**
    * Final attribute or tag name to remap the sources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
    /**
    * If the `target_type` of the remapper is `attribute`, try to cast the value to a new specific type. If the cast is not possible, the original type is kept. `string`, `integer`, or `double` are the possible types. If the `target_type` is `tag`, this parameter may not be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target_format LogsCustomPipeline#target_format}
    */
    readonly targetFormat?: string;
    /**
    * Defines if the target is a log `attribute` or `tag`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target_type LogsCustomPipeline#target_type}
    */
    readonly targetType: string;
}
export declare function logsCustomPipelineProcessorPipelineProcessorAttributeRemapperToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorAttributeRemapperOutputReference | LogsCustomPipelineProcessorPipelineProcessorAttributeRemapper): any;
export declare function logsCustomPipelineProcessorPipelineProcessorAttributeRemapperToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorAttributeRemapperOutputReference | LogsCustomPipelineProcessorPipelineProcessorAttributeRemapper): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorAttributeRemapperOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorAttributeRemapper | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorAttributeRemapper | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _overrideOnConflict?;
    get overrideOnConflict(): boolean | cdktn.IResolvable;
    set overrideOnConflict(value: boolean | cdktn.IResolvable);
    resetOverrideOnConflict(): void;
    get overrideOnConflictInput(): boolean | cdktn.IResolvable | undefined;
    private _preserveSource?;
    get preserveSource(): boolean | cdktn.IResolvable;
    set preserveSource(value: boolean | cdktn.IResolvable);
    resetPreserveSource(): void;
    get preserveSourceInput(): boolean | cdktn.IResolvable | undefined;
    private _sourceType?;
    get sourceType(): string;
    set sourceType(value: string);
    get sourceTypeInput(): string | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    get sourcesInput(): string[] | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _targetFormat?;
    get targetFormat(): string;
    set targetFormat(value: string);
    resetTargetFormat(): void;
    get targetFormatInput(): string | undefined;
    private _targetType?;
    get targetType(): string;
    set targetType(value: string);
    get targetTypeInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategoryFilter {
    /**
    * Filter criteria of the category.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#query LogsCustomPipeline#query}
    */
    readonly query: string;
}
export declare function logsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategoryFilterToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategoryFilterOutputReference | LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategoryFilter): any;
export declare function logsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategoryFilterToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategoryFilterOutputReference | LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategoryFilter): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategoryFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategoryFilter | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategoryFilter | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategory {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#filter LogsCustomPipeline#filter}
    */
    readonly filter: LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategoryFilter;
}
export declare function logsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategoryToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategory | cdktn.IResolvable): any;
export declare function logsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategoryToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategory | cdktn.IResolvable): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategory | cdktn.IResolvable | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategory | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _filter;
    get filter(): LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategoryFilterOutputReference;
    putFilter(value: LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategoryFilter): void;
    get filterInput(): LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategoryFilter | undefined;
}
export declare class LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategoryList extends cdktn.ComplexList {
    internalValue?: LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategoryOutputReference;
}
export interface LogsCustomPipelineProcessorPipelineProcessorCategoryProcessor {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the category
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * Name of the target attribute whose value is defined by the matching category.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
    /**
    * category block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#category LogsCustomPipeline#category}
    */
    readonly category: LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategory[] | cdktn.IResolvable;
}
export declare function logsCustomPipelineProcessorPipelineProcessorCategoryProcessorToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorOutputReference | LogsCustomPipelineProcessorPipelineProcessorCategoryProcessor): any;
export declare function logsCustomPipelineProcessorPipelineProcessorCategoryProcessorToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorOutputReference | LogsCustomPipelineProcessorPipelineProcessorCategoryProcessor): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorCategoryProcessor | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorCategoryProcessor | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _category;
    get category(): LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategoryList;
    putCategory(value: LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategory[] | cdktn.IResolvable): void;
    get categoryInput(): cdktn.IResolvable | LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorCategory[] | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorDateRemapper {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * List of source attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources: string[];
}
export declare function logsCustomPipelineProcessorPipelineProcessorDateRemapperToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorDateRemapperOutputReference | LogsCustomPipelineProcessorPipelineProcessorDateRemapper): any;
export declare function logsCustomPipelineProcessorPipelineProcessorDateRemapperToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorDateRemapperOutputReference | LogsCustomPipelineProcessorPipelineProcessorDateRemapper): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorDateRemapperOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorDateRemapper | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorDateRemapper | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    get sourcesInput(): string[] | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorDecoderProcessor {
    /**
    * Encoding type: base64 or base16
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#binary_to_text_encoding LogsCustomPipeline#binary_to_text_encoding}
    */
    readonly binaryToTextEncoding: string;
    /**
    * Input representation: utf-8 or integer
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#input_representation LogsCustomPipeline#input_representation}
    */
    readonly inputRepresentation: string;
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * Encoded message
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#source LogsCustomPipeline#source}
    */
    readonly source: string;
    /**
    * Decoded message
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
}
export declare function logsCustomPipelineProcessorPipelineProcessorDecoderProcessorToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorDecoderProcessorOutputReference | LogsCustomPipelineProcessorPipelineProcessorDecoderProcessor): any;
export declare function logsCustomPipelineProcessorPipelineProcessorDecoderProcessorToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorDecoderProcessorOutputReference | LogsCustomPipelineProcessorPipelineProcessorDecoderProcessor): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorDecoderProcessorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorDecoderProcessor | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorDecoderProcessor | undefined);
    private _binaryToTextEncoding?;
    get binaryToTextEncoding(): string;
    set binaryToTextEncoding(value: string);
    get binaryToTextEncodingInput(): string | undefined;
    private _inputRepresentation?;
    get inputRepresentation(): string;
    set inputRepresentation(value: string);
    get inputRepresentationInput(): string | undefined;
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorGeoIpParser {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * List of source attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources: string[];
    /**
    * Name of the parent attribute that contains all the extracted details from the sources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
}
export declare function logsCustomPipelineProcessorPipelineProcessorGeoIpParserToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorGeoIpParserOutputReference | LogsCustomPipelineProcessorPipelineProcessorGeoIpParser): any;
export declare function logsCustomPipelineProcessorPipelineProcessorGeoIpParserToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorGeoIpParserOutputReference | LogsCustomPipelineProcessorPipelineProcessorGeoIpParser): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorGeoIpParserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorGeoIpParser | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorGeoIpParser | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    get sourcesInput(): string[] | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorGrokParserGrok {
    /**
    * Match rules for your grok parser.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#match_rules LogsCustomPipeline#match_rules}
    */
    readonly matchRules: string;
    /**
    * Support rules for your grok parser.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#support_rules LogsCustomPipeline#support_rules}
    */
    readonly supportRules: string;
}
export declare function logsCustomPipelineProcessorPipelineProcessorGrokParserGrokToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorGrokParserGrokOutputReference | LogsCustomPipelineProcessorPipelineProcessorGrokParserGrok): any;
export declare function logsCustomPipelineProcessorPipelineProcessorGrokParserGrokToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorGrokParserGrokOutputReference | LogsCustomPipelineProcessorPipelineProcessorGrokParserGrok): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorGrokParserGrokOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorGrokParserGrok | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorGrokParserGrok | undefined);
    private _matchRules?;
    get matchRules(): string;
    set matchRules(value: string);
    get matchRulesInput(): string | undefined;
    private _supportRules?;
    get supportRules(): string;
    set supportRules(value: string);
    get supportRulesInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorGrokParser {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * List of sample logs for this parser. It can save up to 5 samples. Each sample takes up to 5000 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#samples LogsCustomPipeline#samples}
    */
    readonly samples?: string[];
    /**
    * Name of the log attribute to parse.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#source LogsCustomPipeline#source}
    */
    readonly source: string;
    /**
    * grok block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#grok LogsCustomPipeline#grok}
    */
    readonly grok: LogsCustomPipelineProcessorPipelineProcessorGrokParserGrok;
}
export declare function logsCustomPipelineProcessorPipelineProcessorGrokParserToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorGrokParserOutputReference | LogsCustomPipelineProcessorPipelineProcessorGrokParser): any;
export declare function logsCustomPipelineProcessorPipelineProcessorGrokParserToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorGrokParserOutputReference | LogsCustomPipelineProcessorPipelineProcessorGrokParser): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorGrokParserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorGrokParser | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorGrokParser | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _samples?;
    get samples(): string[];
    set samples(value: string[]);
    resetSamples(): void;
    get samplesInput(): string[] | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _grok;
    get grok(): LogsCustomPipelineProcessorPipelineProcessorGrokParserGrokOutputReference;
    putGrok(value: LogsCustomPipelineProcessorPipelineProcessorGrokParserGrok): void;
    get grokInput(): LogsCustomPipelineProcessorPipelineProcessorGrokParserGrok | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorLookupProcessor {
    /**
    * Default lookup value to use if there is no entry in the lookup table for the value of the source attribute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#default_lookup LogsCustomPipeline#default_lookup}
    */
    readonly defaultLookup?: string;
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * List of entries of the lookup table using `key,value` format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#lookup_table LogsCustomPipeline#lookup_table}
    */
    readonly lookupTable: string[];
    /**
    * Name of the processor
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * Name of the source attribute used to do the lookup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#source LogsCustomPipeline#source}
    */
    readonly source: string;
    /**
    * Name of the attribute that contains the result of the lookup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
}
export declare function logsCustomPipelineProcessorPipelineProcessorLookupProcessorToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorLookupProcessorOutputReference | LogsCustomPipelineProcessorPipelineProcessorLookupProcessor): any;
export declare function logsCustomPipelineProcessorPipelineProcessorLookupProcessorToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorLookupProcessorOutputReference | LogsCustomPipelineProcessorPipelineProcessorLookupProcessor): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorLookupProcessorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorLookupProcessor | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorLookupProcessor | undefined);
    private _defaultLookup?;
    get defaultLookup(): string;
    set defaultLookup(value: string);
    resetDefaultLookup(): void;
    get defaultLookupInput(): string | undefined;
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _lookupTable?;
    get lookupTable(): string[];
    set lookupTable(value: string[]);
    get lookupTableInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorMessageRemapper {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * List of source attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources: string[];
}
export declare function logsCustomPipelineProcessorPipelineProcessorMessageRemapperToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorMessageRemapperOutputReference | LogsCustomPipelineProcessorPipelineProcessorMessageRemapper): any;
export declare function logsCustomPipelineProcessorPipelineProcessorMessageRemapperToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorMessageRemapperOutputReference | LogsCustomPipelineProcessorPipelineProcessorMessageRemapper): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorMessageRemapperOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorMessageRemapper | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorMessageRemapper | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    get sourcesInput(): string[] | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorReferenceTableLookupProcessor {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the Reference Table for the source attribute and their associated target attribute values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#lookup_enrichment_table LogsCustomPipeline#lookup_enrichment_table}
    */
    readonly lookupEnrichmentTable: string;
    /**
    * Name of the processor
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * Name of the source attribute used to do the lookup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#source LogsCustomPipeline#source}
    */
    readonly source: string;
    /**
    * Name of the attribute that contains the result of the lookup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
}
export declare function logsCustomPipelineProcessorPipelineProcessorReferenceTableLookupProcessorToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorReferenceTableLookupProcessorOutputReference | LogsCustomPipelineProcessorPipelineProcessorReferenceTableLookupProcessor): any;
export declare function logsCustomPipelineProcessorPipelineProcessorReferenceTableLookupProcessorToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorReferenceTableLookupProcessorOutputReference | LogsCustomPipelineProcessorPipelineProcessorReferenceTableLookupProcessor): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorReferenceTableLookupProcessorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorReferenceTableLookupProcessor | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorReferenceTableLookupProcessor | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _lookupEnrichmentTable?;
    get lookupEnrichmentTable(): string;
    set lookupEnrichmentTable(value: string);
    get lookupEnrichmentTableInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilter {
    /**
    * Filter criteria of the category.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#query LogsCustomPipeline#query}
    */
    readonly query: string;
}
export declare function logsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilterToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilterOutputReference | LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilter): any;
export declare function logsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilterToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilterOutputReference | LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilter): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilter | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilter | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategories {
    /**
    * ID to inject into the category.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#id LogsCustomPipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: number;
    /**
    * Value to assign to target schema field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#filter LogsCustomPipeline#filter}
    */
    readonly filter: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilter;
}
export declare function logsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategories | cdktn.IResolvable): any;
export declare function logsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategories | cdktn.IResolvable): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategories | cdktn.IResolvable | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategories | cdktn.IResolvable | undefined);
    private _id?;
    get id(): number;
    set id(value: number);
    get idInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _filter;
    get filter(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilterOutputReference;
    putFilter(value: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilter): void;
    get filterInput(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilter | undefined;
}
export declare class LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesList extends cdktn.ComplexList {
    internalValue?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategories[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesOutputReference;
}
export interface LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallback {
    /**
    * Fallback sources used to populate value of field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources?: {
        [key: string]: string;
    };
    /**
    * Values that define when the fallback is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#values LogsCustomPipeline#values}
    */
    readonly values?: {
        [key: string]: string;
    };
}
export declare function logsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallbackToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallbackOutputReference | LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallback): any;
export declare function logsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallbackToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallbackOutputReference | LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallback): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallbackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallback | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallback | undefined);
    private _sources?;
    get sources(): {
        [key: string]: string;
    };
    set sources(value: {
        [key: string]: string;
    });
    resetSources(): void;
    get sourcesInput(): {
        [key: string]: string;
    } | undefined;
    private _values?;
    get values(): {
        [key: string]: string;
    };
    set values(value: {
        [key: string]: string;
    });
    resetValues(): void;
    get valuesInput(): {
        [key: string]: string;
    } | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargets {
    /**
    * ID of the field to map log attributes to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#id LogsCustomPipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the field to map log attributes to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
}
export declare function logsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargetsToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargetsOutputReference | LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargets): any;
export declare function logsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargetsToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargetsOutputReference | LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargets): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargets | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargets | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapper {
    /**
    * Name of the logs schema category mapper.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name: string;
    /**
    * categories block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#categories LogsCustomPipeline#categories}
    */
    readonly categories: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategories[] | cdktn.IResolvable;
    /**
    * fallback block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#fallback LogsCustomPipeline#fallback}
    */
    readonly fallback?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallback;
    /**
    * targets block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#targets LogsCustomPipeline#targets}
    */
    readonly targets: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargets;
}
export declare function logsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapper | cdktn.IResolvable): any;
export declare function logsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapper | cdktn.IResolvable): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapper | cdktn.IResolvable | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapper | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _categories;
    get categories(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesList;
    putCategories(value: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategories[] | cdktn.IResolvable): void;
    get categoriesInput(): cdktn.IResolvable | LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategories[] | undefined;
    private _fallback;
    get fallback(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallbackOutputReference;
    putFallback(value: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallback): void;
    resetFallback(): void;
    get fallbackInput(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallback | undefined;
    private _targets;
    get targets(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargetsOutputReference;
    putTargets(value: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargets): void;
    get targetsInput(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargets | undefined;
}
export declare class LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperList extends cdktn.ComplexList {
    internalValue?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapper[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperOutputReference;
}
export interface LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaRemapper {
    /**
    * Name of the logs schema remapper.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name: string;
    /**
    * Override or not the target element if already set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#override_on_conflict LogsCustomPipeline#override_on_conflict}
    */
    readonly overrideOnConflict?: boolean | cdktn.IResolvable;
    /**
    * Remove or preserve the remapped source element.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#preserve_source LogsCustomPipeline#preserve_source}
    */
    readonly preserveSource?: boolean | cdktn.IResolvable;
    /**
    * Array of source attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources: string[];
    /**
    * Target field to map log source field to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
    /**
    * If the `target_type` of the remapper is `attribute`, try to cast the value to a new specific type. If the cast is not possible, the original type is kept. `string`, `integer`, or `double` are the possible types. If the `target_type` is `tag`, this parameter may not be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target_format LogsCustomPipeline#target_format}
    */
    readonly targetFormat?: string;
}
export declare function logsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaRemapperToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaRemapper | cdktn.IResolvable): any;
export declare function logsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaRemapperToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaRemapper | cdktn.IResolvable): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaRemapperOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaRemapper | cdktn.IResolvable | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaRemapper | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _overrideOnConflict?;
    get overrideOnConflict(): boolean | cdktn.IResolvable;
    set overrideOnConflict(value: boolean | cdktn.IResolvable);
    resetOverrideOnConflict(): void;
    get overrideOnConflictInput(): boolean | cdktn.IResolvable | undefined;
    private _preserveSource?;
    get preserveSource(): boolean | cdktn.IResolvable;
    set preserveSource(value: boolean | cdktn.IResolvable);
    resetPreserveSource(): void;
    get preserveSourceInput(): boolean | cdktn.IResolvable | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    get sourcesInput(): string[] | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _targetFormat?;
    get targetFormat(): string;
    set targetFormat(value: string);
    resetTargetFormat(): void;
    get targetFormatInput(): string | undefined;
}
export declare class LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaRemapperList extends cdktn.ComplexList {
    internalValue?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaRemapper[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaRemapperOutputReference;
}
export interface LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappers {
    /**
    * schema_category_mapper block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#schema_category_mapper LogsCustomPipeline#schema_category_mapper}
    */
    readonly schemaCategoryMapper?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapper[] | cdktn.IResolvable;
    /**
    * schema_remapper block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#schema_remapper LogsCustomPipeline#schema_remapper}
    */
    readonly schemaRemapper?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaRemapper[] | cdktn.IResolvable;
}
export declare function logsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappers | cdktn.IResolvable): any;
export declare function logsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappers | cdktn.IResolvable): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappers | cdktn.IResolvable | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappers | cdktn.IResolvable | undefined);
    private _schemaCategoryMapper;
    get schemaCategoryMapper(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperList;
    putSchemaCategoryMapper(value: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapper[] | cdktn.IResolvable): void;
    resetSchemaCategoryMapper(): void;
    get schemaCategoryMapperInput(): cdktn.IResolvable | LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaCategoryMapper[] | undefined;
    private _schemaRemapper;
    get schemaRemapper(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaRemapperList;
    putSchemaRemapper(value: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaRemapper[] | cdktn.IResolvable): void;
    resetSchemaRemapper(): void;
    get schemaRemapperInput(): cdktn.IResolvable | LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersSchemaRemapper[] | undefined;
}
export declare class LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersList extends cdktn.ComplexList {
    internalValue?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersOutputReference;
}
export interface LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorSchema {
    /**
    * Class name of the schema to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#class_name LogsCustomPipeline#class_name}
    */
    readonly className: string;
    /**
    * Class UID of the schema to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#class_uid LogsCustomPipeline#class_uid}
    */
    readonly classUid: number;
    /**
    * Optional list of extensions to modify the schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#extensions LogsCustomPipeline#extensions}
    */
    readonly extensions?: string[];
    /**
    * Optional list of profiles to modify the schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#profiles LogsCustomPipeline#profiles}
    */
    readonly profiles?: string[];
    /**
    * Type of schema to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#schema_type LogsCustomPipeline#schema_type}
    */
    readonly schemaType: string;
    /**
    * Version of the schema to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#version LogsCustomPipeline#version}
    */
    readonly version: string;
}
export declare function logsCustomPipelineProcessorPipelineProcessorSchemaProcessorSchemaToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorSchemaOutputReference | LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorSchema): any;
export declare function logsCustomPipelineProcessorPipelineProcessorSchemaProcessorSchemaToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorSchemaOutputReference | LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorSchema): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorSchema | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorSchema | undefined);
    private _className?;
    get className(): string;
    set className(value: string);
    get classNameInput(): string | undefined;
    private _classUid?;
    get classUid(): number;
    set classUid(value: number);
    get classUidInput(): number | undefined;
    private _extensions?;
    get extensions(): string[];
    set extensions(value: string[]);
    resetExtensions(): void;
    get extensionsInput(): string[] | undefined;
    private _profiles?;
    get profiles(): string[];
    set profiles(value: string[]);
    resetProfiles(): void;
    get profilesInput(): string[] | undefined;
    private _schemaType?;
    get schemaType(): string;
    set schemaType(value: string);
    get schemaTypeInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorSchemaProcessor {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * The name of the processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * mappers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#mappers LogsCustomPipeline#mappers}
    */
    readonly mappers: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappers[] | cdktn.IResolvable;
    /**
    * schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#schema LogsCustomPipeline#schema}
    */
    readonly schema: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorSchema;
}
export declare function logsCustomPipelineProcessorPipelineProcessorSchemaProcessorToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorOutputReference | LogsCustomPipelineProcessorPipelineProcessorSchemaProcessor): any;
export declare function logsCustomPipelineProcessorPipelineProcessorSchemaProcessorToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorOutputReference | LogsCustomPipelineProcessorPipelineProcessorSchemaProcessor): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessor | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessor | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _mappers;
    get mappers(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappersList;
    putMappers(value: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappers[] | cdktn.IResolvable): void;
    get mappersInput(): cdktn.IResolvable | LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorMappers[] | undefined;
    private _schema;
    get schema(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorSchemaOutputReference;
    putSchema(value: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorSchema): void;
    get schemaInput(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorSchema | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorServiceRemapper {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * List of source attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources: string[];
}
export declare function logsCustomPipelineProcessorPipelineProcessorServiceRemapperToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorServiceRemapperOutputReference | LogsCustomPipelineProcessorPipelineProcessorServiceRemapper): any;
export declare function logsCustomPipelineProcessorPipelineProcessorServiceRemapperToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorServiceRemapperOutputReference | LogsCustomPipelineProcessorPipelineProcessorServiceRemapper): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorServiceRemapperOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorServiceRemapper | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorServiceRemapper | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    get sourcesInput(): string[] | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorSpanIdRemapper {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * List of source attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources: string[];
}
export declare function logsCustomPipelineProcessorPipelineProcessorSpanIdRemapperToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorSpanIdRemapperOutputReference | LogsCustomPipelineProcessorPipelineProcessorSpanIdRemapper): any;
export declare function logsCustomPipelineProcessorPipelineProcessorSpanIdRemapperToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorSpanIdRemapperOutputReference | LogsCustomPipelineProcessorPipelineProcessorSpanIdRemapper): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorSpanIdRemapperOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorSpanIdRemapper | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorSpanIdRemapper | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    get sourcesInput(): string[] | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorStatusRemapper {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * List of source attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources: string[];
}
export declare function logsCustomPipelineProcessorPipelineProcessorStatusRemapperToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorStatusRemapperOutputReference | LogsCustomPipelineProcessorPipelineProcessorStatusRemapper): any;
export declare function logsCustomPipelineProcessorPipelineProcessorStatusRemapperToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorStatusRemapperOutputReference | LogsCustomPipelineProcessorPipelineProcessorStatusRemapper): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorStatusRemapperOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorStatusRemapper | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorStatusRemapper | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    get sourcesInput(): string[] | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorStringBuilderProcessor {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * If it replaces all missing attributes of template by an empty string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_replace_missing LogsCustomPipeline#is_replace_missing}
    */
    readonly isReplaceMissing?: boolean | cdktn.IResolvable;
    /**
    * The name of the processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * The name of the attribute that contains the result of the template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
    /**
    * The formula with one or more attributes and raw text.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#template LogsCustomPipeline#template}
    */
    readonly template: string;
}
export declare function logsCustomPipelineProcessorPipelineProcessorStringBuilderProcessorToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorStringBuilderProcessorOutputReference | LogsCustomPipelineProcessorPipelineProcessorStringBuilderProcessor): any;
export declare function logsCustomPipelineProcessorPipelineProcessorStringBuilderProcessorToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorStringBuilderProcessorOutputReference | LogsCustomPipelineProcessorPipelineProcessorStringBuilderProcessor): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorStringBuilderProcessorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorStringBuilderProcessor | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorStringBuilderProcessor | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _isReplaceMissing?;
    get isReplaceMissing(): boolean | cdktn.IResolvable;
    set isReplaceMissing(value: boolean | cdktn.IResolvable);
    resetIsReplaceMissing(): void;
    get isReplaceMissingInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _template?;
    get template(): string;
    set template(value: string);
    get templateInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorTraceIdRemapper {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * List of source attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources: string[];
}
export declare function logsCustomPipelineProcessorPipelineProcessorTraceIdRemapperToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorTraceIdRemapperOutputReference | LogsCustomPipelineProcessorPipelineProcessorTraceIdRemapper): any;
export declare function logsCustomPipelineProcessorPipelineProcessorTraceIdRemapperToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorTraceIdRemapperOutputReference | LogsCustomPipelineProcessorPipelineProcessorTraceIdRemapper): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorTraceIdRemapperOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorTraceIdRemapper | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorTraceIdRemapper | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    get sourcesInput(): string[] | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorUrlParser {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * Normalize the ending slashes or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#normalize_ending_slashes LogsCustomPipeline#normalize_ending_slashes}
    */
    readonly normalizeEndingSlashes?: boolean | cdktn.IResolvable;
    /**
    * List of source attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources: string[];
    /**
    * Name of the parent attribute that contains all the extracted details from the sources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
}
export declare function logsCustomPipelineProcessorPipelineProcessorUrlParserToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorUrlParserOutputReference | LogsCustomPipelineProcessorPipelineProcessorUrlParser): any;
export declare function logsCustomPipelineProcessorPipelineProcessorUrlParserToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorUrlParserOutputReference | LogsCustomPipelineProcessorPipelineProcessorUrlParser): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorUrlParserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorUrlParser | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorUrlParser | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _normalizeEndingSlashes?;
    get normalizeEndingSlashes(): boolean | cdktn.IResolvable;
    set normalizeEndingSlashes(value: boolean | cdktn.IResolvable);
    resetNormalizeEndingSlashes(): void;
    get normalizeEndingSlashesInput(): boolean | cdktn.IResolvable | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    get sourcesInput(): string[] | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessorUserAgentParser {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * If the source attribute is URL encoded or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_encoded LogsCustomPipeline#is_encoded}
    */
    readonly isEncoded?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * List of source attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources: string[];
    /**
    * Name of the parent attribute that contains all the extracted details from the sources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
}
export declare function logsCustomPipelineProcessorPipelineProcessorUserAgentParserToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorUserAgentParserOutputReference | LogsCustomPipelineProcessorPipelineProcessorUserAgentParser): any;
export declare function logsCustomPipelineProcessorPipelineProcessorUserAgentParserToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessorUserAgentParserOutputReference | LogsCustomPipelineProcessorPipelineProcessorUserAgentParser): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorUserAgentParserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessorUserAgentParser | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessorUserAgentParser | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _isEncoded?;
    get isEncoded(): boolean | cdktn.IResolvable;
    set isEncoded(value: boolean | cdktn.IResolvable);
    resetIsEncoded(): void;
    get isEncodedInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    get sourcesInput(): string[] | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorPipelineProcessor {
    /**
    * arithmetic_processor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#arithmetic_processor LogsCustomPipeline#arithmetic_processor}
    */
    readonly arithmeticProcessor?: LogsCustomPipelineProcessorPipelineProcessorArithmeticProcessor;
    /**
    * array_processor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#array_processor LogsCustomPipeline#array_processor}
    */
    readonly arrayProcessor?: LogsCustomPipelineProcessorPipelineProcessorArrayProcessor;
    /**
    * attribute_remapper block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#attribute_remapper LogsCustomPipeline#attribute_remapper}
    */
    readonly attributeRemapper?: LogsCustomPipelineProcessorPipelineProcessorAttributeRemapper;
    /**
    * category_processor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#category_processor LogsCustomPipeline#category_processor}
    */
    readonly categoryProcessor?: LogsCustomPipelineProcessorPipelineProcessorCategoryProcessor;
    /**
    * date_remapper block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#date_remapper LogsCustomPipeline#date_remapper}
    */
    readonly dateRemapper?: LogsCustomPipelineProcessorPipelineProcessorDateRemapper;
    /**
    * decoder_processor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#decoder_processor LogsCustomPipeline#decoder_processor}
    */
    readonly decoderProcessor?: LogsCustomPipelineProcessorPipelineProcessorDecoderProcessor;
    /**
    * geo_ip_parser block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#geo_ip_parser LogsCustomPipeline#geo_ip_parser}
    */
    readonly geoIpParser?: LogsCustomPipelineProcessorPipelineProcessorGeoIpParser;
    /**
    * grok_parser block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#grok_parser LogsCustomPipeline#grok_parser}
    */
    readonly grokParser?: LogsCustomPipelineProcessorPipelineProcessorGrokParser;
    /**
    * lookup_processor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#lookup_processor LogsCustomPipeline#lookup_processor}
    */
    readonly lookupProcessor?: LogsCustomPipelineProcessorPipelineProcessorLookupProcessor;
    /**
    * message_remapper block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#message_remapper LogsCustomPipeline#message_remapper}
    */
    readonly messageRemapper?: LogsCustomPipelineProcessorPipelineProcessorMessageRemapper;
    /**
    * reference_table_lookup_processor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#reference_table_lookup_processor LogsCustomPipeline#reference_table_lookup_processor}
    */
    readonly referenceTableLookupProcessor?: LogsCustomPipelineProcessorPipelineProcessorReferenceTableLookupProcessor;
    /**
    * schema_processor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#schema_processor LogsCustomPipeline#schema_processor}
    */
    readonly schemaProcessor?: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessor;
    /**
    * service_remapper block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#service_remapper LogsCustomPipeline#service_remapper}
    */
    readonly serviceRemapper?: LogsCustomPipelineProcessorPipelineProcessorServiceRemapper;
    /**
    * span_id_remapper block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#span_id_remapper LogsCustomPipeline#span_id_remapper}
    */
    readonly spanIdRemapper?: LogsCustomPipelineProcessorPipelineProcessorSpanIdRemapper;
    /**
    * status_remapper block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#status_remapper LogsCustomPipeline#status_remapper}
    */
    readonly statusRemapper?: LogsCustomPipelineProcessorPipelineProcessorStatusRemapper;
    /**
    * string_builder_processor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#string_builder_processor LogsCustomPipeline#string_builder_processor}
    */
    readonly stringBuilderProcessor?: LogsCustomPipelineProcessorPipelineProcessorStringBuilderProcessor;
    /**
    * trace_id_remapper block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#trace_id_remapper LogsCustomPipeline#trace_id_remapper}
    */
    readonly traceIdRemapper?: LogsCustomPipelineProcessorPipelineProcessorTraceIdRemapper;
    /**
    * url_parser block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#url_parser LogsCustomPipeline#url_parser}
    */
    readonly urlParser?: LogsCustomPipelineProcessorPipelineProcessorUrlParser;
    /**
    * user_agent_parser block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#user_agent_parser LogsCustomPipeline#user_agent_parser}
    */
    readonly userAgentParser?: LogsCustomPipelineProcessorPipelineProcessorUserAgentParser;
}
export declare function logsCustomPipelineProcessorPipelineProcessorToTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessor | cdktn.IResolvable): any;
export declare function logsCustomPipelineProcessorPipelineProcessorToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineProcessor | cdktn.IResolvable): any;
export declare class LogsCustomPipelineProcessorPipelineProcessorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsCustomPipelineProcessorPipelineProcessor | cdktn.IResolvable | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipelineProcessor | cdktn.IResolvable | undefined);
    private _arithmeticProcessor;
    get arithmeticProcessor(): LogsCustomPipelineProcessorPipelineProcessorArithmeticProcessorOutputReference;
    putArithmeticProcessor(value: LogsCustomPipelineProcessorPipelineProcessorArithmeticProcessor): void;
    resetArithmeticProcessor(): void;
    get arithmeticProcessorInput(): LogsCustomPipelineProcessorPipelineProcessorArithmeticProcessor | undefined;
    private _arrayProcessor;
    get arrayProcessor(): LogsCustomPipelineProcessorPipelineProcessorArrayProcessorOutputReference;
    putArrayProcessor(value: LogsCustomPipelineProcessorPipelineProcessorArrayProcessor): void;
    resetArrayProcessor(): void;
    get arrayProcessorInput(): LogsCustomPipelineProcessorPipelineProcessorArrayProcessor | undefined;
    private _attributeRemapper;
    get attributeRemapper(): LogsCustomPipelineProcessorPipelineProcessorAttributeRemapperOutputReference;
    putAttributeRemapper(value: LogsCustomPipelineProcessorPipelineProcessorAttributeRemapper): void;
    resetAttributeRemapper(): void;
    get attributeRemapperInput(): LogsCustomPipelineProcessorPipelineProcessorAttributeRemapper | undefined;
    private _categoryProcessor;
    get categoryProcessor(): LogsCustomPipelineProcessorPipelineProcessorCategoryProcessorOutputReference;
    putCategoryProcessor(value: LogsCustomPipelineProcessorPipelineProcessorCategoryProcessor): void;
    resetCategoryProcessor(): void;
    get categoryProcessorInput(): LogsCustomPipelineProcessorPipelineProcessorCategoryProcessor | undefined;
    private _dateRemapper;
    get dateRemapper(): LogsCustomPipelineProcessorPipelineProcessorDateRemapperOutputReference;
    putDateRemapper(value: LogsCustomPipelineProcessorPipelineProcessorDateRemapper): void;
    resetDateRemapper(): void;
    get dateRemapperInput(): LogsCustomPipelineProcessorPipelineProcessorDateRemapper | undefined;
    private _decoderProcessor;
    get decoderProcessor(): LogsCustomPipelineProcessorPipelineProcessorDecoderProcessorOutputReference;
    putDecoderProcessor(value: LogsCustomPipelineProcessorPipelineProcessorDecoderProcessor): void;
    resetDecoderProcessor(): void;
    get decoderProcessorInput(): LogsCustomPipelineProcessorPipelineProcessorDecoderProcessor | undefined;
    private _geoIpParser;
    get geoIpParser(): LogsCustomPipelineProcessorPipelineProcessorGeoIpParserOutputReference;
    putGeoIpParser(value: LogsCustomPipelineProcessorPipelineProcessorGeoIpParser): void;
    resetGeoIpParser(): void;
    get geoIpParserInput(): LogsCustomPipelineProcessorPipelineProcessorGeoIpParser | undefined;
    private _grokParser;
    get grokParser(): LogsCustomPipelineProcessorPipelineProcessorGrokParserOutputReference;
    putGrokParser(value: LogsCustomPipelineProcessorPipelineProcessorGrokParser): void;
    resetGrokParser(): void;
    get grokParserInput(): LogsCustomPipelineProcessorPipelineProcessorGrokParser | undefined;
    private _lookupProcessor;
    get lookupProcessor(): LogsCustomPipelineProcessorPipelineProcessorLookupProcessorOutputReference;
    putLookupProcessor(value: LogsCustomPipelineProcessorPipelineProcessorLookupProcessor): void;
    resetLookupProcessor(): void;
    get lookupProcessorInput(): LogsCustomPipelineProcessorPipelineProcessorLookupProcessor | undefined;
    private _messageRemapper;
    get messageRemapper(): LogsCustomPipelineProcessorPipelineProcessorMessageRemapperOutputReference;
    putMessageRemapper(value: LogsCustomPipelineProcessorPipelineProcessorMessageRemapper): void;
    resetMessageRemapper(): void;
    get messageRemapperInput(): LogsCustomPipelineProcessorPipelineProcessorMessageRemapper | undefined;
    private _referenceTableLookupProcessor;
    get referenceTableLookupProcessor(): LogsCustomPipelineProcessorPipelineProcessorReferenceTableLookupProcessorOutputReference;
    putReferenceTableLookupProcessor(value: LogsCustomPipelineProcessorPipelineProcessorReferenceTableLookupProcessor): void;
    resetReferenceTableLookupProcessor(): void;
    get referenceTableLookupProcessorInput(): LogsCustomPipelineProcessorPipelineProcessorReferenceTableLookupProcessor | undefined;
    private _schemaProcessor;
    get schemaProcessor(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessorOutputReference;
    putSchemaProcessor(value: LogsCustomPipelineProcessorPipelineProcessorSchemaProcessor): void;
    resetSchemaProcessor(): void;
    get schemaProcessorInput(): LogsCustomPipelineProcessorPipelineProcessorSchemaProcessor | undefined;
    private _serviceRemapper;
    get serviceRemapper(): LogsCustomPipelineProcessorPipelineProcessorServiceRemapperOutputReference;
    putServiceRemapper(value: LogsCustomPipelineProcessorPipelineProcessorServiceRemapper): void;
    resetServiceRemapper(): void;
    get serviceRemapperInput(): LogsCustomPipelineProcessorPipelineProcessorServiceRemapper | undefined;
    private _spanIdRemapper;
    get spanIdRemapper(): LogsCustomPipelineProcessorPipelineProcessorSpanIdRemapperOutputReference;
    putSpanIdRemapper(value: LogsCustomPipelineProcessorPipelineProcessorSpanIdRemapper): void;
    resetSpanIdRemapper(): void;
    get spanIdRemapperInput(): LogsCustomPipelineProcessorPipelineProcessorSpanIdRemapper | undefined;
    private _statusRemapper;
    get statusRemapper(): LogsCustomPipelineProcessorPipelineProcessorStatusRemapperOutputReference;
    putStatusRemapper(value: LogsCustomPipelineProcessorPipelineProcessorStatusRemapper): void;
    resetStatusRemapper(): void;
    get statusRemapperInput(): LogsCustomPipelineProcessorPipelineProcessorStatusRemapper | undefined;
    private _stringBuilderProcessor;
    get stringBuilderProcessor(): LogsCustomPipelineProcessorPipelineProcessorStringBuilderProcessorOutputReference;
    putStringBuilderProcessor(value: LogsCustomPipelineProcessorPipelineProcessorStringBuilderProcessor): void;
    resetStringBuilderProcessor(): void;
    get stringBuilderProcessorInput(): LogsCustomPipelineProcessorPipelineProcessorStringBuilderProcessor | undefined;
    private _traceIdRemapper;
    get traceIdRemapper(): LogsCustomPipelineProcessorPipelineProcessorTraceIdRemapperOutputReference;
    putTraceIdRemapper(value: LogsCustomPipelineProcessorPipelineProcessorTraceIdRemapper): void;
    resetTraceIdRemapper(): void;
    get traceIdRemapperInput(): LogsCustomPipelineProcessorPipelineProcessorTraceIdRemapper | undefined;
    private _urlParser;
    get urlParser(): LogsCustomPipelineProcessorPipelineProcessorUrlParserOutputReference;
    putUrlParser(value: LogsCustomPipelineProcessorPipelineProcessorUrlParser): void;
    resetUrlParser(): void;
    get urlParserInput(): LogsCustomPipelineProcessorPipelineProcessorUrlParser | undefined;
    private _userAgentParser;
    get userAgentParser(): LogsCustomPipelineProcessorPipelineProcessorUserAgentParserOutputReference;
    putUserAgentParser(value: LogsCustomPipelineProcessorPipelineProcessorUserAgentParser): void;
    resetUserAgentParser(): void;
    get userAgentParserInput(): LogsCustomPipelineProcessorPipelineProcessorUserAgentParser | undefined;
}
export declare class LogsCustomPipelineProcessorPipelineProcessorList extends cdktn.ComplexList {
    internalValue?: LogsCustomPipelineProcessorPipelineProcessor[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsCustomPipelineProcessorPipelineProcessorOutputReference;
}
export interface LogsCustomPipelineProcessorPipeline {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#description LogsCustomPipeline#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#tags LogsCustomPipeline#tags}
    */
    readonly tags?: string[];
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#filter LogsCustomPipeline#filter}
    */
    readonly filter: LogsCustomPipelineProcessorPipelineFilter[] | cdktn.IResolvable;
    /**
    * processor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#processor LogsCustomPipeline#processor}
    */
    readonly processor?: LogsCustomPipelineProcessorPipelineProcessor[] | cdktn.IResolvable;
}
export declare function logsCustomPipelineProcessorPipelineToTerraform(struct?: LogsCustomPipelineProcessorPipelineOutputReference | LogsCustomPipelineProcessorPipeline): any;
export declare function logsCustomPipelineProcessorPipelineToHclTerraform(struct?: LogsCustomPipelineProcessorPipelineOutputReference | LogsCustomPipelineProcessorPipeline): any;
export declare class LogsCustomPipelineProcessorPipelineOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorPipeline | undefined;
    set internalValue(value: LogsCustomPipelineProcessorPipeline | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _filter;
    get filter(): LogsCustomPipelineProcessorPipelineFilterList;
    putFilter(value: LogsCustomPipelineProcessorPipelineFilter[] | cdktn.IResolvable): void;
    get filterInput(): cdktn.IResolvable | LogsCustomPipelineProcessorPipelineFilter[] | undefined;
    private _processor;
    get processor(): LogsCustomPipelineProcessorPipelineProcessorList;
    putProcessor(value: LogsCustomPipelineProcessorPipelineProcessor[] | cdktn.IResolvable): void;
    resetProcessor(): void;
    get processorInput(): cdktn.IResolvable | LogsCustomPipelineProcessorPipelineProcessor[] | undefined;
}
export interface LogsCustomPipelineProcessorReferenceTableLookupProcessor {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the Reference Table for the source attribute and their associated target attribute values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#lookup_enrichment_table LogsCustomPipeline#lookup_enrichment_table}
    */
    readonly lookupEnrichmentTable: string;
    /**
    * Name of the processor
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * Name of the source attribute used to do the lookup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#source LogsCustomPipeline#source}
    */
    readonly source: string;
    /**
    * Name of the attribute that contains the result of the lookup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
}
export declare function logsCustomPipelineProcessorReferenceTableLookupProcessorToTerraform(struct?: LogsCustomPipelineProcessorReferenceTableLookupProcessorOutputReference | LogsCustomPipelineProcessorReferenceTableLookupProcessor): any;
export declare function logsCustomPipelineProcessorReferenceTableLookupProcessorToHclTerraform(struct?: LogsCustomPipelineProcessorReferenceTableLookupProcessorOutputReference | LogsCustomPipelineProcessorReferenceTableLookupProcessor): any;
export declare class LogsCustomPipelineProcessorReferenceTableLookupProcessorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorReferenceTableLookupProcessor | undefined;
    set internalValue(value: LogsCustomPipelineProcessorReferenceTableLookupProcessor | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _lookupEnrichmentTable?;
    get lookupEnrichmentTable(): string;
    set lookupEnrichmentTable(value: string);
    get lookupEnrichmentTableInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilter {
    /**
    * Filter criteria of the category.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#query LogsCustomPipeline#query}
    */
    readonly query: string;
}
export declare function logsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilterToTerraform(struct?: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilterOutputReference | LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilter): any;
export declare function logsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilterToHclTerraform(struct?: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilterOutputReference | LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilter): any;
export declare class LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilter | undefined;
    set internalValue(value: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilter | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategories {
    /**
    * ID to inject into the category.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#id LogsCustomPipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: number;
    /**
    * Value to assign to target schema field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#filter LogsCustomPipeline#filter}
    */
    readonly filter: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilter;
}
export declare function logsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesToTerraform(struct?: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategories | cdktn.IResolvable): any;
export declare function logsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesToHclTerraform(struct?: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategories | cdktn.IResolvable): any;
export declare class LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategories | cdktn.IResolvable | undefined;
    set internalValue(value: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategories | cdktn.IResolvable | undefined);
    private _id?;
    get id(): number;
    set id(value: number);
    get idInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _filter;
    get filter(): LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilterOutputReference;
    putFilter(value: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilter): void;
    get filterInput(): LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesFilter | undefined;
}
export declare class LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesList extends cdktn.ComplexList {
    internalValue?: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategories[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesOutputReference;
}
export interface LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallback {
    /**
    * Fallback sources used to populate value of field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources?: {
        [key: string]: string;
    };
    /**
    * Values that define when the fallback is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#values LogsCustomPipeline#values}
    */
    readonly values?: {
        [key: string]: string;
    };
}
export declare function logsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallbackToTerraform(struct?: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallbackOutputReference | LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallback): any;
export declare function logsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallbackToHclTerraform(struct?: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallbackOutputReference | LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallback): any;
export declare class LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallbackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallback | undefined;
    set internalValue(value: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallback | undefined);
    private _sources?;
    get sources(): {
        [key: string]: string;
    };
    set sources(value: {
        [key: string]: string;
    });
    resetSources(): void;
    get sourcesInput(): {
        [key: string]: string;
    } | undefined;
    private _values?;
    get values(): {
        [key: string]: string;
    };
    set values(value: {
        [key: string]: string;
    });
    resetValues(): void;
    get valuesInput(): {
        [key: string]: string;
    } | undefined;
}
export interface LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargets {
    /**
    * ID of the field to map log attributes to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#id LogsCustomPipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the field to map log attributes to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
}
export declare function logsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargetsToTerraform(struct?: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargetsOutputReference | LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargets): any;
export declare function logsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargetsToHclTerraform(struct?: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargetsOutputReference | LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargets): any;
export declare class LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargets | undefined;
    set internalValue(value: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargets | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapper {
    /**
    * Name of the logs schema category mapper.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name: string;
    /**
    * categories block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#categories LogsCustomPipeline#categories}
    */
    readonly categories: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategories[] | cdktn.IResolvable;
    /**
    * fallback block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#fallback LogsCustomPipeline#fallback}
    */
    readonly fallback?: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallback;
    /**
    * targets block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#targets LogsCustomPipeline#targets}
    */
    readonly targets: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargets;
}
export declare function logsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperToTerraform(struct?: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapper | cdktn.IResolvable): any;
export declare function logsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperToHclTerraform(struct?: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapper | cdktn.IResolvable): any;
export declare class LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapper | cdktn.IResolvable | undefined;
    set internalValue(value: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapper | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _categories;
    get categories(): LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategoriesList;
    putCategories(value: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategories[] | cdktn.IResolvable): void;
    get categoriesInput(): cdktn.IResolvable | LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperCategories[] | undefined;
    private _fallback;
    get fallback(): LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallbackOutputReference;
    putFallback(value: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallback): void;
    resetFallback(): void;
    get fallbackInput(): LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperFallback | undefined;
    private _targets;
    get targets(): LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargetsOutputReference;
    putTargets(value: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargets): void;
    get targetsInput(): LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperTargets | undefined;
}
export declare class LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperList extends cdktn.ComplexList {
    internalValue?: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapper[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperOutputReference;
}
export interface LogsCustomPipelineProcessorSchemaProcessorMappersSchemaRemapper {
    /**
    * Name of the logs schema remapper.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name: string;
    /**
    * Override or not the target element if already set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#override_on_conflict LogsCustomPipeline#override_on_conflict}
    */
    readonly overrideOnConflict?: boolean | cdktn.IResolvable;
    /**
    * Remove or preserve the remapped source element.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#preserve_source LogsCustomPipeline#preserve_source}
    */
    readonly preserveSource?: boolean | cdktn.IResolvable;
    /**
    * Array of source attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources: string[];
    /**
    * Target field to map log source field to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
    /**
    * If the `target_type` of the remapper is `attribute`, try to cast the value to a new specific type. If the cast is not possible, the original type is kept. `string`, `integer`, or `double` are the possible types. If the `target_type` is `tag`, this parameter may not be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target_format LogsCustomPipeline#target_format}
    */
    readonly targetFormat?: string;
}
export declare function logsCustomPipelineProcessorSchemaProcessorMappersSchemaRemapperToTerraform(struct?: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaRemapper | cdktn.IResolvable): any;
export declare function logsCustomPipelineProcessorSchemaProcessorMappersSchemaRemapperToHclTerraform(struct?: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaRemapper | cdktn.IResolvable): any;
export declare class LogsCustomPipelineProcessorSchemaProcessorMappersSchemaRemapperOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsCustomPipelineProcessorSchemaProcessorMappersSchemaRemapper | cdktn.IResolvable | undefined;
    set internalValue(value: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaRemapper | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _overrideOnConflict?;
    get overrideOnConflict(): boolean | cdktn.IResolvable;
    set overrideOnConflict(value: boolean | cdktn.IResolvable);
    resetOverrideOnConflict(): void;
    get overrideOnConflictInput(): boolean | cdktn.IResolvable | undefined;
    private _preserveSource?;
    get preserveSource(): boolean | cdktn.IResolvable;
    set preserveSource(value: boolean | cdktn.IResolvable);
    resetPreserveSource(): void;
    get preserveSourceInput(): boolean | cdktn.IResolvable | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    get sourcesInput(): string[] | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _targetFormat?;
    get targetFormat(): string;
    set targetFormat(value: string);
    resetTargetFormat(): void;
    get targetFormatInput(): string | undefined;
}
export declare class LogsCustomPipelineProcessorSchemaProcessorMappersSchemaRemapperList extends cdktn.ComplexList {
    internalValue?: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaRemapper[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsCustomPipelineProcessorSchemaProcessorMappersSchemaRemapperOutputReference;
}
export interface LogsCustomPipelineProcessorSchemaProcessorMappers {
    /**
    * schema_category_mapper block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#schema_category_mapper LogsCustomPipeline#schema_category_mapper}
    */
    readonly schemaCategoryMapper?: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapper[] | cdktn.IResolvable;
    /**
    * schema_remapper block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#schema_remapper LogsCustomPipeline#schema_remapper}
    */
    readonly schemaRemapper?: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaRemapper[] | cdktn.IResolvable;
}
export declare function logsCustomPipelineProcessorSchemaProcessorMappersToTerraform(struct?: LogsCustomPipelineProcessorSchemaProcessorMappers | cdktn.IResolvable): any;
export declare function logsCustomPipelineProcessorSchemaProcessorMappersToHclTerraform(struct?: LogsCustomPipelineProcessorSchemaProcessorMappers | cdktn.IResolvable): any;
export declare class LogsCustomPipelineProcessorSchemaProcessorMappersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsCustomPipelineProcessorSchemaProcessorMappers | cdktn.IResolvable | undefined;
    set internalValue(value: LogsCustomPipelineProcessorSchemaProcessorMappers | cdktn.IResolvable | undefined);
    private _schemaCategoryMapper;
    get schemaCategoryMapper(): LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapperList;
    putSchemaCategoryMapper(value: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapper[] | cdktn.IResolvable): void;
    resetSchemaCategoryMapper(): void;
    get schemaCategoryMapperInput(): cdktn.IResolvable | LogsCustomPipelineProcessorSchemaProcessorMappersSchemaCategoryMapper[] | undefined;
    private _schemaRemapper;
    get schemaRemapper(): LogsCustomPipelineProcessorSchemaProcessorMappersSchemaRemapperList;
    putSchemaRemapper(value: LogsCustomPipelineProcessorSchemaProcessorMappersSchemaRemapper[] | cdktn.IResolvable): void;
    resetSchemaRemapper(): void;
    get schemaRemapperInput(): cdktn.IResolvable | LogsCustomPipelineProcessorSchemaProcessorMappersSchemaRemapper[] | undefined;
}
export declare class LogsCustomPipelineProcessorSchemaProcessorMappersList extends cdktn.ComplexList {
    internalValue?: LogsCustomPipelineProcessorSchemaProcessorMappers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsCustomPipelineProcessorSchemaProcessorMappersOutputReference;
}
export interface LogsCustomPipelineProcessorSchemaProcessorSchema {
    /**
    * Class name of the schema to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#class_name LogsCustomPipeline#class_name}
    */
    readonly className: string;
    /**
    * Class UID of the schema to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#class_uid LogsCustomPipeline#class_uid}
    */
    readonly classUid: number;
    /**
    * Optional list of extensions to modify the schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#extensions LogsCustomPipeline#extensions}
    */
    readonly extensions?: string[];
    /**
    * Optional list of profiles to modify the schema.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#profiles LogsCustomPipeline#profiles}
    */
    readonly profiles?: string[];
    /**
    * Type of schema to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#schema_type LogsCustomPipeline#schema_type}
    */
    readonly schemaType: string;
    /**
    * Version of the schema to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#version LogsCustomPipeline#version}
    */
    readonly version: string;
}
export declare function logsCustomPipelineProcessorSchemaProcessorSchemaToTerraform(struct?: LogsCustomPipelineProcessorSchemaProcessorSchemaOutputReference | LogsCustomPipelineProcessorSchemaProcessorSchema): any;
export declare function logsCustomPipelineProcessorSchemaProcessorSchemaToHclTerraform(struct?: LogsCustomPipelineProcessorSchemaProcessorSchemaOutputReference | LogsCustomPipelineProcessorSchemaProcessorSchema): any;
export declare class LogsCustomPipelineProcessorSchemaProcessorSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorSchemaProcessorSchema | undefined;
    set internalValue(value: LogsCustomPipelineProcessorSchemaProcessorSchema | undefined);
    private _className?;
    get className(): string;
    set className(value: string);
    get classNameInput(): string | undefined;
    private _classUid?;
    get classUid(): number;
    set classUid(value: number);
    get classUidInput(): number | undefined;
    private _extensions?;
    get extensions(): string[];
    set extensions(value: string[]);
    resetExtensions(): void;
    get extensionsInput(): string[] | undefined;
    private _profiles?;
    get profiles(): string[];
    set profiles(value: string[]);
    resetProfiles(): void;
    get profilesInput(): string[] | undefined;
    private _schemaType?;
    get schemaType(): string;
    set schemaType(value: string);
    get schemaTypeInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorSchemaProcessor {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * The name of the processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * mappers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#mappers LogsCustomPipeline#mappers}
    */
    readonly mappers: LogsCustomPipelineProcessorSchemaProcessorMappers[] | cdktn.IResolvable;
    /**
    * schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#schema LogsCustomPipeline#schema}
    */
    readonly schema: LogsCustomPipelineProcessorSchemaProcessorSchema;
}
export declare function logsCustomPipelineProcessorSchemaProcessorToTerraform(struct?: LogsCustomPipelineProcessorSchemaProcessorOutputReference | LogsCustomPipelineProcessorSchemaProcessor): any;
export declare function logsCustomPipelineProcessorSchemaProcessorToHclTerraform(struct?: LogsCustomPipelineProcessorSchemaProcessorOutputReference | LogsCustomPipelineProcessorSchemaProcessor): any;
export declare class LogsCustomPipelineProcessorSchemaProcessorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorSchemaProcessor | undefined;
    set internalValue(value: LogsCustomPipelineProcessorSchemaProcessor | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _mappers;
    get mappers(): LogsCustomPipelineProcessorSchemaProcessorMappersList;
    putMappers(value: LogsCustomPipelineProcessorSchemaProcessorMappers[] | cdktn.IResolvable): void;
    get mappersInput(): cdktn.IResolvable | LogsCustomPipelineProcessorSchemaProcessorMappers[] | undefined;
    private _schema;
    get schema(): LogsCustomPipelineProcessorSchemaProcessorSchemaOutputReference;
    putSchema(value: LogsCustomPipelineProcessorSchemaProcessorSchema): void;
    get schemaInput(): LogsCustomPipelineProcessorSchemaProcessorSchema | undefined;
}
export interface LogsCustomPipelineProcessorServiceRemapper {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * List of source attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources: string[];
}
export declare function logsCustomPipelineProcessorServiceRemapperToTerraform(struct?: LogsCustomPipelineProcessorServiceRemapperOutputReference | LogsCustomPipelineProcessorServiceRemapper): any;
export declare function logsCustomPipelineProcessorServiceRemapperToHclTerraform(struct?: LogsCustomPipelineProcessorServiceRemapperOutputReference | LogsCustomPipelineProcessorServiceRemapper): any;
export declare class LogsCustomPipelineProcessorServiceRemapperOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorServiceRemapper | undefined;
    set internalValue(value: LogsCustomPipelineProcessorServiceRemapper | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    get sourcesInput(): string[] | undefined;
}
export interface LogsCustomPipelineProcessorSpanIdRemapper {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * List of source attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources: string[];
}
export declare function logsCustomPipelineProcessorSpanIdRemapperToTerraform(struct?: LogsCustomPipelineProcessorSpanIdRemapperOutputReference | LogsCustomPipelineProcessorSpanIdRemapper): any;
export declare function logsCustomPipelineProcessorSpanIdRemapperToHclTerraform(struct?: LogsCustomPipelineProcessorSpanIdRemapperOutputReference | LogsCustomPipelineProcessorSpanIdRemapper): any;
export declare class LogsCustomPipelineProcessorSpanIdRemapperOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorSpanIdRemapper | undefined;
    set internalValue(value: LogsCustomPipelineProcessorSpanIdRemapper | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    get sourcesInput(): string[] | undefined;
}
export interface LogsCustomPipelineProcessorStatusRemapper {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * List of source attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources: string[];
}
export declare function logsCustomPipelineProcessorStatusRemapperToTerraform(struct?: LogsCustomPipelineProcessorStatusRemapperOutputReference | LogsCustomPipelineProcessorStatusRemapper): any;
export declare function logsCustomPipelineProcessorStatusRemapperToHclTerraform(struct?: LogsCustomPipelineProcessorStatusRemapperOutputReference | LogsCustomPipelineProcessorStatusRemapper): any;
export declare class LogsCustomPipelineProcessorStatusRemapperOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorStatusRemapper | undefined;
    set internalValue(value: LogsCustomPipelineProcessorStatusRemapper | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    get sourcesInput(): string[] | undefined;
}
export interface LogsCustomPipelineProcessorStringBuilderProcessor {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * If it replaces all missing attributes of template by an empty string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_replace_missing LogsCustomPipeline#is_replace_missing}
    */
    readonly isReplaceMissing?: boolean | cdktn.IResolvable;
    /**
    * The name of the processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * The name of the attribute that contains the result of the template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
    /**
    * The formula with one or more attributes and raw text.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#template LogsCustomPipeline#template}
    */
    readonly template: string;
}
export declare function logsCustomPipelineProcessorStringBuilderProcessorToTerraform(struct?: LogsCustomPipelineProcessorStringBuilderProcessorOutputReference | LogsCustomPipelineProcessorStringBuilderProcessor): any;
export declare function logsCustomPipelineProcessorStringBuilderProcessorToHclTerraform(struct?: LogsCustomPipelineProcessorStringBuilderProcessorOutputReference | LogsCustomPipelineProcessorStringBuilderProcessor): any;
export declare class LogsCustomPipelineProcessorStringBuilderProcessorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorStringBuilderProcessor | undefined;
    set internalValue(value: LogsCustomPipelineProcessorStringBuilderProcessor | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _isReplaceMissing?;
    get isReplaceMissing(): boolean | cdktn.IResolvable;
    set isReplaceMissing(value: boolean | cdktn.IResolvable);
    resetIsReplaceMissing(): void;
    get isReplaceMissingInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _template?;
    get template(): string;
    set template(value: string);
    get templateInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorTraceIdRemapper {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * List of source attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources: string[];
}
export declare function logsCustomPipelineProcessorTraceIdRemapperToTerraform(struct?: LogsCustomPipelineProcessorTraceIdRemapperOutputReference | LogsCustomPipelineProcessorTraceIdRemapper): any;
export declare function logsCustomPipelineProcessorTraceIdRemapperToHclTerraform(struct?: LogsCustomPipelineProcessorTraceIdRemapperOutputReference | LogsCustomPipelineProcessorTraceIdRemapper): any;
export declare class LogsCustomPipelineProcessorTraceIdRemapperOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorTraceIdRemapper | undefined;
    set internalValue(value: LogsCustomPipelineProcessorTraceIdRemapper | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    get sourcesInput(): string[] | undefined;
}
export interface LogsCustomPipelineProcessorUrlParser {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * Normalize the ending slashes or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#normalize_ending_slashes LogsCustomPipeline#normalize_ending_slashes}
    */
    readonly normalizeEndingSlashes?: boolean | cdktn.IResolvable;
    /**
    * List of source attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources: string[];
    /**
    * Name of the parent attribute that contains all the extracted details from the sources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
}
export declare function logsCustomPipelineProcessorUrlParserToTerraform(struct?: LogsCustomPipelineProcessorUrlParserOutputReference | LogsCustomPipelineProcessorUrlParser): any;
export declare function logsCustomPipelineProcessorUrlParserToHclTerraform(struct?: LogsCustomPipelineProcessorUrlParserOutputReference | LogsCustomPipelineProcessorUrlParser): any;
export declare class LogsCustomPipelineProcessorUrlParserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorUrlParser | undefined;
    set internalValue(value: LogsCustomPipelineProcessorUrlParser | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _normalizeEndingSlashes?;
    get normalizeEndingSlashes(): boolean | cdktn.IResolvable;
    set normalizeEndingSlashes(value: boolean | cdktn.IResolvable);
    resetNormalizeEndingSlashes(): void;
    get normalizeEndingSlashesInput(): boolean | cdktn.IResolvable | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    get sourcesInput(): string[] | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
}
export interface LogsCustomPipelineProcessorUserAgentParser {
    /**
    * If the processor is enabled or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_enabled LogsCustomPipeline#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * If the source attribute is URL encoded or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#is_encoded LogsCustomPipeline#is_encoded}
    */
    readonly isEncoded?: boolean | cdktn.IResolvable;
    /**
    * Name of the processor
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#name LogsCustomPipeline#name}
    */
    readonly name?: string;
    /**
    * List of source attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#sources LogsCustomPipeline#sources}
    */
    readonly sources: string[];
    /**
    * Name of the parent attribute that contains all the extracted details from the sources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#target LogsCustomPipeline#target}
    */
    readonly target: string;
}
export declare function logsCustomPipelineProcessorUserAgentParserToTerraform(struct?: LogsCustomPipelineProcessorUserAgentParserOutputReference | LogsCustomPipelineProcessorUserAgentParser): any;
export declare function logsCustomPipelineProcessorUserAgentParserToHclTerraform(struct?: LogsCustomPipelineProcessorUserAgentParserOutputReference | LogsCustomPipelineProcessorUserAgentParser): any;
export declare class LogsCustomPipelineProcessorUserAgentParserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsCustomPipelineProcessorUserAgentParser | undefined;
    set internalValue(value: LogsCustomPipelineProcessorUserAgentParser | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _isEncoded?;
    get isEncoded(): boolean | cdktn.IResolvable;
    set isEncoded(value: boolean | cdktn.IResolvable);
    resetIsEncoded(): void;
    get isEncodedInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    get sourcesInput(): string[] | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
}
export interface LogsCustomPipelineProcessor {
    /**
    * arithmetic_processor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#arithmetic_processor LogsCustomPipeline#arithmetic_processor}
    */
    readonly arithmeticProcessor?: LogsCustomPipelineProcessorArithmeticProcessor;
    /**
    * array_processor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#array_processor LogsCustomPipeline#array_processor}
    */
    readonly arrayProcessor?: LogsCustomPipelineProcessorArrayProcessor;
    /**
    * attribute_remapper block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#attribute_remapper LogsCustomPipeline#attribute_remapper}
    */
    readonly attributeRemapper?: LogsCustomPipelineProcessorAttributeRemapper;
    /**
    * category_processor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#category_processor LogsCustomPipeline#category_processor}
    */
    readonly categoryProcessor?: LogsCustomPipelineProcessorCategoryProcessor;
    /**
    * date_remapper block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#date_remapper LogsCustomPipeline#date_remapper}
    */
    readonly dateRemapper?: LogsCustomPipelineProcessorDateRemapper;
    /**
    * decoder_processor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#decoder_processor LogsCustomPipeline#decoder_processor}
    */
    readonly decoderProcessor?: LogsCustomPipelineProcessorDecoderProcessor;
    /**
    * geo_ip_parser block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#geo_ip_parser LogsCustomPipeline#geo_ip_parser}
    */
    readonly geoIpParser?: LogsCustomPipelineProcessorGeoIpParser;
    /**
    * grok_parser block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#grok_parser LogsCustomPipeline#grok_parser}
    */
    readonly grokParser?: LogsCustomPipelineProcessorGrokParser;
    /**
    * lookup_processor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#lookup_processor LogsCustomPipeline#lookup_processor}
    */
    readonly lookupProcessor?: LogsCustomPipelineProcessorLookupProcessor;
    /**
    * message_remapper block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#message_remapper LogsCustomPipeline#message_remapper}
    */
    readonly messageRemapper?: LogsCustomPipelineProcessorMessageRemapper;
    /**
    * pipeline block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#pipeline LogsCustomPipeline#pipeline}
    */
    readonly pipeline?: LogsCustomPipelineProcessorPipeline;
    /**
    * reference_table_lookup_processor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#reference_table_lookup_processor LogsCustomPipeline#reference_table_lookup_processor}
    */
    readonly referenceTableLookupProcessor?: LogsCustomPipelineProcessorReferenceTableLookupProcessor;
    /**
    * schema_processor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#schema_processor LogsCustomPipeline#schema_processor}
    */
    readonly schemaProcessor?: LogsCustomPipelineProcessorSchemaProcessor;
    /**
    * service_remapper block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#service_remapper LogsCustomPipeline#service_remapper}
    */
    readonly serviceRemapper?: LogsCustomPipelineProcessorServiceRemapper;
    /**
    * span_id_remapper block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#span_id_remapper LogsCustomPipeline#span_id_remapper}
    */
    readonly spanIdRemapper?: LogsCustomPipelineProcessorSpanIdRemapper;
    /**
    * status_remapper block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#status_remapper LogsCustomPipeline#status_remapper}
    */
    readonly statusRemapper?: LogsCustomPipelineProcessorStatusRemapper;
    /**
    * string_builder_processor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#string_builder_processor LogsCustomPipeline#string_builder_processor}
    */
    readonly stringBuilderProcessor?: LogsCustomPipelineProcessorStringBuilderProcessor;
    /**
    * trace_id_remapper block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#trace_id_remapper LogsCustomPipeline#trace_id_remapper}
    */
    readonly traceIdRemapper?: LogsCustomPipelineProcessorTraceIdRemapper;
    /**
    * url_parser block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#url_parser LogsCustomPipeline#url_parser}
    */
    readonly urlParser?: LogsCustomPipelineProcessorUrlParser;
    /**
    * user_agent_parser block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#user_agent_parser LogsCustomPipeline#user_agent_parser}
    */
    readonly userAgentParser?: LogsCustomPipelineProcessorUserAgentParser;
}
export declare function logsCustomPipelineProcessorToTerraform(struct?: LogsCustomPipelineProcessor | cdktn.IResolvable): any;
export declare function logsCustomPipelineProcessorToHclTerraform(struct?: LogsCustomPipelineProcessor | cdktn.IResolvable): any;
export declare class LogsCustomPipelineProcessorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsCustomPipelineProcessor | cdktn.IResolvable | undefined;
    set internalValue(value: LogsCustomPipelineProcessor | cdktn.IResolvable | undefined);
    private _arithmeticProcessor;
    get arithmeticProcessor(): LogsCustomPipelineProcessorArithmeticProcessorOutputReference;
    putArithmeticProcessor(value: LogsCustomPipelineProcessorArithmeticProcessor): void;
    resetArithmeticProcessor(): void;
    get arithmeticProcessorInput(): LogsCustomPipelineProcessorArithmeticProcessor | undefined;
    private _arrayProcessor;
    get arrayProcessor(): LogsCustomPipelineProcessorArrayProcessorOutputReference;
    putArrayProcessor(value: LogsCustomPipelineProcessorArrayProcessor): void;
    resetArrayProcessor(): void;
    get arrayProcessorInput(): LogsCustomPipelineProcessorArrayProcessor | undefined;
    private _attributeRemapper;
    get attributeRemapper(): LogsCustomPipelineProcessorAttributeRemapperOutputReference;
    putAttributeRemapper(value: LogsCustomPipelineProcessorAttributeRemapper): void;
    resetAttributeRemapper(): void;
    get attributeRemapperInput(): LogsCustomPipelineProcessorAttributeRemapper | undefined;
    private _categoryProcessor;
    get categoryProcessor(): LogsCustomPipelineProcessorCategoryProcessorOutputReference;
    putCategoryProcessor(value: LogsCustomPipelineProcessorCategoryProcessor): void;
    resetCategoryProcessor(): void;
    get categoryProcessorInput(): LogsCustomPipelineProcessorCategoryProcessor | undefined;
    private _dateRemapper;
    get dateRemapper(): LogsCustomPipelineProcessorDateRemapperOutputReference;
    putDateRemapper(value: LogsCustomPipelineProcessorDateRemapper): void;
    resetDateRemapper(): void;
    get dateRemapperInput(): LogsCustomPipelineProcessorDateRemapper | undefined;
    private _decoderProcessor;
    get decoderProcessor(): LogsCustomPipelineProcessorDecoderProcessorOutputReference;
    putDecoderProcessor(value: LogsCustomPipelineProcessorDecoderProcessor): void;
    resetDecoderProcessor(): void;
    get decoderProcessorInput(): LogsCustomPipelineProcessorDecoderProcessor | undefined;
    private _geoIpParser;
    get geoIpParser(): LogsCustomPipelineProcessorGeoIpParserOutputReference;
    putGeoIpParser(value: LogsCustomPipelineProcessorGeoIpParser): void;
    resetGeoIpParser(): void;
    get geoIpParserInput(): LogsCustomPipelineProcessorGeoIpParser | undefined;
    private _grokParser;
    get grokParser(): LogsCustomPipelineProcessorGrokParserOutputReference;
    putGrokParser(value: LogsCustomPipelineProcessorGrokParser): void;
    resetGrokParser(): void;
    get grokParserInput(): LogsCustomPipelineProcessorGrokParser | undefined;
    private _lookupProcessor;
    get lookupProcessor(): LogsCustomPipelineProcessorLookupProcessorOutputReference;
    putLookupProcessor(value: LogsCustomPipelineProcessorLookupProcessor): void;
    resetLookupProcessor(): void;
    get lookupProcessorInput(): LogsCustomPipelineProcessorLookupProcessor | undefined;
    private _messageRemapper;
    get messageRemapper(): LogsCustomPipelineProcessorMessageRemapperOutputReference;
    putMessageRemapper(value: LogsCustomPipelineProcessorMessageRemapper): void;
    resetMessageRemapper(): void;
    get messageRemapperInput(): LogsCustomPipelineProcessorMessageRemapper | undefined;
    private _pipeline;
    get pipeline(): LogsCustomPipelineProcessorPipelineOutputReference;
    putPipeline(value: LogsCustomPipelineProcessorPipeline): void;
    resetPipeline(): void;
    get pipelineInput(): LogsCustomPipelineProcessorPipeline | undefined;
    private _referenceTableLookupProcessor;
    get referenceTableLookupProcessor(): LogsCustomPipelineProcessorReferenceTableLookupProcessorOutputReference;
    putReferenceTableLookupProcessor(value: LogsCustomPipelineProcessorReferenceTableLookupProcessor): void;
    resetReferenceTableLookupProcessor(): void;
    get referenceTableLookupProcessorInput(): LogsCustomPipelineProcessorReferenceTableLookupProcessor | undefined;
    private _schemaProcessor;
    get schemaProcessor(): LogsCustomPipelineProcessorSchemaProcessorOutputReference;
    putSchemaProcessor(value: LogsCustomPipelineProcessorSchemaProcessor): void;
    resetSchemaProcessor(): void;
    get schemaProcessorInput(): LogsCustomPipelineProcessorSchemaProcessor | undefined;
    private _serviceRemapper;
    get serviceRemapper(): LogsCustomPipelineProcessorServiceRemapperOutputReference;
    putServiceRemapper(value: LogsCustomPipelineProcessorServiceRemapper): void;
    resetServiceRemapper(): void;
    get serviceRemapperInput(): LogsCustomPipelineProcessorServiceRemapper | undefined;
    private _spanIdRemapper;
    get spanIdRemapper(): LogsCustomPipelineProcessorSpanIdRemapperOutputReference;
    putSpanIdRemapper(value: LogsCustomPipelineProcessorSpanIdRemapper): void;
    resetSpanIdRemapper(): void;
    get spanIdRemapperInput(): LogsCustomPipelineProcessorSpanIdRemapper | undefined;
    private _statusRemapper;
    get statusRemapper(): LogsCustomPipelineProcessorStatusRemapperOutputReference;
    putStatusRemapper(value: LogsCustomPipelineProcessorStatusRemapper): void;
    resetStatusRemapper(): void;
    get statusRemapperInput(): LogsCustomPipelineProcessorStatusRemapper | undefined;
    private _stringBuilderProcessor;
    get stringBuilderProcessor(): LogsCustomPipelineProcessorStringBuilderProcessorOutputReference;
    putStringBuilderProcessor(value: LogsCustomPipelineProcessorStringBuilderProcessor): void;
    resetStringBuilderProcessor(): void;
    get stringBuilderProcessorInput(): LogsCustomPipelineProcessorStringBuilderProcessor | undefined;
    private _traceIdRemapper;
    get traceIdRemapper(): LogsCustomPipelineProcessorTraceIdRemapperOutputReference;
    putTraceIdRemapper(value: LogsCustomPipelineProcessorTraceIdRemapper): void;
    resetTraceIdRemapper(): void;
    get traceIdRemapperInput(): LogsCustomPipelineProcessorTraceIdRemapper | undefined;
    private _urlParser;
    get urlParser(): LogsCustomPipelineProcessorUrlParserOutputReference;
    putUrlParser(value: LogsCustomPipelineProcessorUrlParser): void;
    resetUrlParser(): void;
    get urlParserInput(): LogsCustomPipelineProcessorUrlParser | undefined;
    private _userAgentParser;
    get userAgentParser(): LogsCustomPipelineProcessorUserAgentParserOutputReference;
    putUserAgentParser(value: LogsCustomPipelineProcessorUserAgentParser): void;
    resetUserAgentParser(): void;
    get userAgentParserInput(): LogsCustomPipelineProcessorUserAgentParser | undefined;
}
export declare class LogsCustomPipelineProcessorList extends cdktn.ComplexList {
    internalValue?: LogsCustomPipelineProcessor[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsCustomPipelineProcessorOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline datadog_logs_custom_pipeline}
*/
export declare class LogsCustomPipeline extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_logs_custom_pipeline";
    /**
    * Generates CDKTN code for importing a LogsCustomPipeline resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LogsCustomPipeline to import
    * @param importFromId The id of the existing LogsCustomPipeline that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LogsCustomPipeline to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_custom_pipeline datadog_logs_custom_pipeline} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LogsCustomPipelineConfig
    */
    constructor(scope: Construct, id: string, config: LogsCustomPipelineConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _filter;
    get filter(): LogsCustomPipelineFilterList;
    putFilter(value: LogsCustomPipelineFilter[] | cdktn.IResolvable): void;
    get filterInput(): cdktn.IResolvable | LogsCustomPipelineFilter[] | undefined;
    private _processor;
    get processor(): LogsCustomPipelineProcessorList;
    putProcessor(value: LogsCustomPipelineProcessor[] | cdktn.IResolvable): void;
    resetProcessor(): void;
    get processorInput(): cdktn.IResolvable | LogsCustomPipelineProcessor[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
