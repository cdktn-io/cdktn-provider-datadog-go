/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LogsIndexConfig extends cdktn.TerraformMetaArguments {
    /**
    * The number of log events you can send in this index per day before you are rate-limited.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_index#daily_limit LogsIndex#daily_limit}
    */
    readonly dailyLimit?: number;
    /**
    * A percentage threshold of the daily quota at which a Datadog warning event is generated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_index#daily_limit_warning_threshold_percentage LogsIndex#daily_limit_warning_threshold_percentage}
    */
    readonly dailyLimitWarningThresholdPercentage?: number;
    /**
    * If true, sets the daily_limit value to null and the index is not limited on a daily basis (any specified daily_limit value in the request is ignored). If false or omitted, the index's current daily_limit is maintained.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_index#disable_daily_limit LogsIndex#disable_daily_limit}
    */
    readonly disableDailyLimit?: boolean | cdktn.IResolvable;
    /**
    * The total number of days logs are stored in Standard and Flex Tier before being deleted from the index.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_index#flex_retention_days LogsIndex#flex_retention_days}
    */
    readonly flexRetentionDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_index#id LogsIndex#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the index. Index names cannot be modified after creation. If this value is changed, a new index will be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_index#name LogsIndex#name}
    */
    readonly name: string;
    /**
    * The number of days logs are stored in Standard Tier before aging into the Flex Tier or being deleted from the index.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_index#retention_days LogsIndex#retention_days}
    */
    readonly retentionDays?: number;
    /**
    * A list of tags for this index. Tags must be in `key:value` format. If default tags are present at the provider level, they will be added to this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_index#tags LogsIndex#tags}
    */
    readonly tags?: string[];
    /**
    * daily_limit_reset block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_index#daily_limit_reset LogsIndex#daily_limit_reset}
    */
    readonly dailyLimitReset?: LogsIndexDailyLimitReset;
    /**
    * exclusion_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_index#exclusion_filter LogsIndex#exclusion_filter}
    */
    readonly exclusionFilter?: LogsIndexExclusionFilter[] | cdktn.IResolvable;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_index#filter LogsIndex#filter}
    */
    readonly filter: LogsIndexFilter;
}
export interface LogsIndexDailyLimitReset {
    /**
    * String in `HH:00` format representing the time of day the daily limit should be reset. The hours must be between 00 and 23 (inclusive).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_index#reset_time LogsIndex#reset_time}
    */
    readonly resetTime: string;
    /**
    * String in `(-|+)HH:00` format representing the UTC offset to apply to the given reset time. The hours must be between -12 and +14 (inclusive).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_index#reset_utc_offset LogsIndex#reset_utc_offset}
    */
    readonly resetUtcOffset: string;
}
export declare function logsIndexDailyLimitResetToTerraform(struct?: LogsIndexDailyLimitResetOutputReference | LogsIndexDailyLimitReset): any;
export declare function logsIndexDailyLimitResetToHclTerraform(struct?: LogsIndexDailyLimitResetOutputReference | LogsIndexDailyLimitReset): any;
export declare class LogsIndexDailyLimitResetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsIndexDailyLimitReset | undefined;
    set internalValue(value: LogsIndexDailyLimitReset | undefined);
    private _resetTime?;
    get resetTime(): string;
    set resetTime(value: string);
    get resetTimeInput(): string | undefined;
    private _resetUtcOffset?;
    get resetUtcOffset(): string;
    set resetUtcOffset(value: string);
    get resetUtcOffsetInput(): string | undefined;
}
export interface LogsIndexExclusionFilterFilter {
    /**
    * Only logs matching the filter criteria and the query of the parent index will be considered for this exclusion filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_index#query LogsIndex#query}
    */
    readonly query?: string;
    /**
    * The fraction of logs excluded by the exclusion filter, when active.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_index#sample_rate LogsIndex#sample_rate}
    */
    readonly sampleRate?: number;
}
export declare function logsIndexExclusionFilterFilterToTerraform(struct?: LogsIndexExclusionFilterFilter | cdktn.IResolvable): any;
export declare function logsIndexExclusionFilterFilterToHclTerraform(struct?: LogsIndexExclusionFilterFilter | cdktn.IResolvable): any;
export declare class LogsIndexExclusionFilterFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsIndexExclusionFilterFilter | cdktn.IResolvable | undefined;
    set internalValue(value: LogsIndexExclusionFilterFilter | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
    private _sampleRate?;
    get sampleRate(): number;
    set sampleRate(value: number);
    resetSampleRate(): void;
    get sampleRateInput(): number | undefined;
}
export declare class LogsIndexExclusionFilterFilterList extends cdktn.ComplexList {
    internalValue?: LogsIndexExclusionFilterFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsIndexExclusionFilterFilterOutputReference;
}
export interface LogsIndexExclusionFilter {
    /**
    * A boolean stating if the exclusion is active or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_index#is_enabled LogsIndex#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * The name of the exclusion filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_index#name LogsIndex#name}
    */
    readonly name?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_index#filter LogsIndex#filter}
    */
    readonly filter?: LogsIndexExclusionFilterFilter[] | cdktn.IResolvable;
}
export declare function logsIndexExclusionFilterToTerraform(struct?: LogsIndexExclusionFilter | cdktn.IResolvable): any;
export declare function logsIndexExclusionFilterToHclTerraform(struct?: LogsIndexExclusionFilter | cdktn.IResolvable): any;
export declare class LogsIndexExclusionFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LogsIndexExclusionFilter | cdktn.IResolvable | undefined;
    set internalValue(value: LogsIndexExclusionFilter | cdktn.IResolvable | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _filter;
    get filter(): LogsIndexExclusionFilterFilterList;
    putFilter(value: LogsIndexExclusionFilterFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | LogsIndexExclusionFilterFilter[] | undefined;
}
export declare class LogsIndexExclusionFilterList extends cdktn.ComplexList {
    internalValue?: LogsIndexExclusionFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LogsIndexExclusionFilterOutputReference;
}
export interface LogsIndexFilter {
    /**
    * Logs filter criteria. Only logs matching this filter criteria are considered for this index.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_index#query LogsIndex#query}
    */
    readonly query: string;
}
export declare function logsIndexFilterToTerraform(struct?: LogsIndexFilterOutputReference | LogsIndexFilter): any;
export declare function logsIndexFilterToHclTerraform(struct?: LogsIndexFilterOutputReference | LogsIndexFilter): any;
export declare class LogsIndexFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogsIndexFilter | undefined;
    set internalValue(value: LogsIndexFilter | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_index datadog_logs_index}
*/
export declare class LogsIndex extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_logs_index";
    /**
    * Generates CDKTN code for importing a LogsIndex resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LogsIndex to import
    * @param importFromId The id of the existing LogsIndex that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_index#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LogsIndex to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_index datadog_logs_index} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LogsIndexConfig
    */
    constructor(scope: Construct, id: string, config: LogsIndexConfig);
    private _dailyLimit?;
    get dailyLimit(): number;
    set dailyLimit(value: number);
    resetDailyLimit(): void;
    get dailyLimitInput(): number | undefined;
    private _dailyLimitWarningThresholdPercentage?;
    get dailyLimitWarningThresholdPercentage(): number;
    set dailyLimitWarningThresholdPercentage(value: number);
    resetDailyLimitWarningThresholdPercentage(): void;
    get dailyLimitWarningThresholdPercentageInput(): number | undefined;
    private _disableDailyLimit?;
    get disableDailyLimit(): boolean | cdktn.IResolvable;
    set disableDailyLimit(value: boolean | cdktn.IResolvable);
    resetDisableDailyLimit(): void;
    get disableDailyLimitInput(): boolean | cdktn.IResolvable | undefined;
    private _flexRetentionDays?;
    get flexRetentionDays(): number;
    set flexRetentionDays(value: number);
    resetFlexRetentionDays(): void;
    get flexRetentionDaysInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _retentionDays?;
    get retentionDays(): number;
    set retentionDays(value: number);
    resetRetentionDays(): void;
    get retentionDaysInput(): number | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _dailyLimitReset;
    get dailyLimitReset(): LogsIndexDailyLimitResetOutputReference;
    putDailyLimitReset(value: LogsIndexDailyLimitReset): void;
    resetDailyLimitReset(): void;
    get dailyLimitResetInput(): LogsIndexDailyLimitReset | undefined;
    private _exclusionFilter;
    get exclusionFilter(): LogsIndexExclusionFilterList;
    putExclusionFilter(value: LogsIndexExclusionFilter[] | cdktn.IResolvable): void;
    resetExclusionFilter(): void;
    get exclusionFilterInput(): cdktn.IResolvable | LogsIndexExclusionFilter[] | undefined;
    private _filter;
    get filter(): LogsIndexFilterOutputReference;
    putFilter(value: LogsIndexFilter): void;
    get filterInput(): LogsIndexFilter | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
