/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogIntegrationAwsIamPermissionsStandardConfig extends cdktn.TerraformMetaArguments {
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/integration_aws_iam_permissions_standard datadog_integration_aws_iam_permissions_standard}
*/
export declare class DataDatadogIntegrationAwsIamPermissionsStandard extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_integration_aws_iam_permissions_standard";
    /**
    * Generates CDKTN code for importing a DataDatadogIntegrationAwsIamPermissionsStandard resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogIntegrationAwsIamPermissionsStandard to import
    * @param importFromId The id of the existing DataDatadogIntegrationAwsIamPermissionsStandard that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/integration_aws_iam_permissions_standard#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogIntegrationAwsIamPermissionsStandard to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/integration_aws_iam_permissions_standard datadog_integration_aws_iam_permissions_standard} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogIntegrationAwsIamPermissionsStandardConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogIntegrationAwsIamPermissionsStandardConfig);
    get iamPermissions(): string[];
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
