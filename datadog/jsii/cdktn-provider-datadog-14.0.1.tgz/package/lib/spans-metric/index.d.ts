/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SpansMetricConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the span-based metric. This field can't be updated after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/spans_metric#name SpansMetric#name}
    */
    readonly name: string;
    /**
    * compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/spans_metric#compute SpansMetric#compute}
    */
    readonly compute?: SpansMetricCompute;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/spans_metric#filter SpansMetric#filter}
    */
    readonly filter?: SpansMetricFilter;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/spans_metric#group_by SpansMetric#group_by}
    */
    readonly groupBy?: SpansMetricGroupBy[] | cdktn.IResolvable;
}
export interface SpansMetricCompute {
    /**
    * The type of aggregation to use. This field can't be updated after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/spans_metric#aggregation_type SpansMetric#aggregation_type}
    */
    readonly aggregationType: string;
    /**
    * Toggle to include or exclude percentile aggregations for distribution metrics. Only present when the `aggregation_type` is `distribution`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/spans_metric#include_percentiles SpansMetric#include_percentiles}
    */
    readonly includePercentiles?: boolean | cdktn.IResolvable;
    /**
    * The path to the value the span-based metric will aggregate on (only used if the aggregation type is a "distribution"). This field can't be updated after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/spans_metric#path SpansMetric#path}
    */
    readonly path?: string;
}
export declare function spansMetricComputeToTerraform(struct?: SpansMetricCompute | cdktn.IResolvable): any;
export declare function spansMetricComputeToHclTerraform(struct?: SpansMetricCompute | cdktn.IResolvable): any;
export declare class SpansMetricComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SpansMetricCompute | cdktn.IResolvable | undefined;
    set internalValue(value: SpansMetricCompute | cdktn.IResolvable | undefined);
    private _aggregationType?;
    get aggregationType(): string;
    set aggregationType(value: string);
    get aggregationTypeInput(): string | undefined;
    private _includePercentiles?;
    get includePercentiles(): boolean | cdktn.IResolvable;
    set includePercentiles(value: boolean | cdktn.IResolvable);
    resetIncludePercentiles(): void;
    get includePercentilesInput(): boolean | cdktn.IResolvable | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export interface SpansMetricFilter {
    /**
    * The search query - following the span search syntax. Defaults to `"*"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/spans_metric#query SpansMetric#query}
    */
    readonly query?: string;
}
export declare function spansMetricFilterToTerraform(struct?: SpansMetricFilter | cdktn.IResolvable): any;
export declare function spansMetricFilterToHclTerraform(struct?: SpansMetricFilter | cdktn.IResolvable): any;
export declare class SpansMetricFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SpansMetricFilter | cdktn.IResolvable | undefined;
    set internalValue(value: SpansMetricFilter | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
}
export interface SpansMetricGroupBy {
    /**
    * The path to the value the span-based metric will be aggregated over.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/spans_metric#path SpansMetric#path}
    */
    readonly path: string;
    /**
    * Eventual name of the tag that gets created. By default, the path attribute is used as the tag name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/spans_metric#tag_name SpansMetric#tag_name}
    */
    readonly tagName?: string;
}
export declare function spansMetricGroupByToTerraform(struct?: SpansMetricGroupBy | cdktn.IResolvable): any;
export declare function spansMetricGroupByToHclTerraform(struct?: SpansMetricGroupBy | cdktn.IResolvable): any;
export declare class SpansMetricGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SpansMetricGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: SpansMetricGroupBy | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _tagName?;
    get tagName(): string;
    set tagName(value: string);
    resetTagName(): void;
    get tagNameInput(): string | undefined;
}
export declare class SpansMetricGroupByList extends cdktn.ComplexList {
    internalValue?: SpansMetricGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SpansMetricGroupByOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/spans_metric datadog_spans_metric}
*/
export declare class SpansMetric extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_spans_metric";
    /**
    * Generates CDKTN code for importing a SpansMetric resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SpansMetric to import
    * @param importFromId The id of the existing SpansMetric that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/spans_metric#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SpansMetric to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/spans_metric datadog_spans_metric} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SpansMetricConfig
    */
    constructor(scope: Construct, id: string, config: SpansMetricConfig);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _compute;
    get compute(): SpansMetricComputeOutputReference;
    putCompute(value: SpansMetricCompute): void;
    resetCompute(): void;
    get computeInput(): cdktn.IResolvable | SpansMetricCompute | undefined;
    private _filter;
    get filter(): SpansMetricFilterOutputReference;
    putFilter(value: SpansMetricFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | SpansMetricFilter | undefined;
    private _groupBy;
    get groupBy(): SpansMetricGroupByList;
    putGroupBy(value: SpansMetricGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | SpansMetricGroupBy[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
