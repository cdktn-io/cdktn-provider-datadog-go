/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IntegrationFastlyServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Fastly Account id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_fastly_service#account_id IntegrationFastlyService#account_id}
    */
    readonly accountId?: string;
    /**
    * The ID of the Fastly service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_fastly_service#service_id IntegrationFastlyService#service_id}
    */
    readonly serviceId: string;
    /**
    * A list of tags for the Fastly service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_fastly_service#tags IntegrationFastlyService#tags}
    */
    readonly tags?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_fastly_service datadog_integration_fastly_service}
*/
export declare class IntegrationFastlyService extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_integration_fastly_service";
    /**
    * Generates CDKTN code for importing a IntegrationFastlyService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IntegrationFastlyService to import
    * @param importFromId The id of the existing IntegrationFastlyService that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_fastly_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IntegrationFastlyService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_fastly_service datadog_integration_fastly_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IntegrationFastlyServiceConfig
    */
    constructor(scope: Construct, id: string, config: IntegrationFastlyServiceConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get id(): string;
    private _serviceId?;
    get serviceId(): string;
    set serviceId(value: string);
    get serviceIdInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
