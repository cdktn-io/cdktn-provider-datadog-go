/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogSyntheticsLocationsConfig extends cdktn.TerraformMetaArguments {
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/synthetics_locations datadog_synthetics_locations}
*/
export declare class DataDatadogSyntheticsLocations extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_synthetics_locations";
    /**
    * Generates CDKTN code for importing a DataDatadogSyntheticsLocations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogSyntheticsLocations to import
    * @param importFromId The id of the existing DataDatadogSyntheticsLocations that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/synthetics_locations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogSyntheticsLocations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/synthetics_locations datadog_synthetics_locations} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogSyntheticsLocationsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogSyntheticsLocationsConfig);
    get id(): string;
    private _locations;
    get locations(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
