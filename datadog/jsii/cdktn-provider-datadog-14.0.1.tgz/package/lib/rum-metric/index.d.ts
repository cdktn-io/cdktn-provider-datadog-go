/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RumMetricConfig extends cdktn.TerraformMetaArguments {
    /**
    * The type of RUM events to filter on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_metric#event_type RumMetric#event_type}
    */
    readonly eventType: string;
    /**
    * The name of the RUM-based metric. This field can't be updated after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_metric#name RumMetric#name}
    */
    readonly name: string;
    /**
    * compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_metric#compute RumMetric#compute}
    */
    readonly compute?: RumMetricCompute;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_metric#filter RumMetric#filter}
    */
    readonly filter?: RumMetricFilter;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_metric#group_by RumMetric#group_by}
    */
    readonly groupBy?: RumMetricGroupBy[] | cdktn.IResolvable;
    /**
    * uniqueness block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_metric#uniqueness RumMetric#uniqueness}
    */
    readonly uniqueness?: RumMetricUniqueness;
}
export interface RumMetricCompute {
    /**
    * The type of aggregation to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_metric#aggregation_type RumMetric#aggregation_type}
    */
    readonly aggregationType: string;
    /**
    * Toggle to include or exclude percentile aggregations for distribution metrics. Only present when `aggregation_type` is `distribution`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_metric#include_percentiles RumMetric#include_percentiles}
    */
    readonly includePercentiles?: boolean | cdktn.IResolvable;
    /**
    * The path to the value the RUM-based metric will aggregate on. Only present when `aggregation_type` is `distribution`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_metric#path RumMetric#path}
    */
    readonly path?: string;
}
export declare function rumMetricComputeToTerraform(struct?: RumMetricCompute | cdktn.IResolvable): any;
export declare function rumMetricComputeToHclTerraform(struct?: RumMetricCompute | cdktn.IResolvable): any;
export declare class RumMetricComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RumMetricCompute | cdktn.IResolvable | undefined;
    set internalValue(value: RumMetricCompute | cdktn.IResolvable | undefined);
    private _aggregationType?;
    get aggregationType(): string;
    set aggregationType(value: string);
    get aggregationTypeInput(): string | undefined;
    private _includePercentiles?;
    get includePercentiles(): boolean | cdktn.IResolvable;
    set includePercentiles(value: boolean | cdktn.IResolvable);
    resetIncludePercentiles(): void;
    get includePercentilesInput(): boolean | cdktn.IResolvable | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export interface RumMetricFilter {
    /**
    * The search query. Follows RUM search syntax.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_metric#query RumMetric#query}
    */
    readonly query?: string;
}
export declare function rumMetricFilterToTerraform(struct?: RumMetricFilter | cdktn.IResolvable): any;
export declare function rumMetricFilterToHclTerraform(struct?: RumMetricFilter | cdktn.IResolvable): any;
export declare class RumMetricFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RumMetricFilter | cdktn.IResolvable | undefined;
    set internalValue(value: RumMetricFilter | cdktn.IResolvable | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
}
export interface RumMetricGroupBy {
    /**
    * The path to the value the RUM-based metric will be aggregated over.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_metric#path RumMetric#path}
    */
    readonly path?: string;
    /**
    * Name of the tag that gets created. By default, `path` is used as the tag name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_metric#tag_name RumMetric#tag_name}
    */
    readonly tagName?: string;
}
export declare function rumMetricGroupByToTerraform(struct?: RumMetricGroupBy | cdktn.IResolvable): any;
export declare function rumMetricGroupByToHclTerraform(struct?: RumMetricGroupBy | cdktn.IResolvable): any;
export declare class RumMetricGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RumMetricGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: RumMetricGroupBy | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _tagName?;
    get tagName(): string;
    set tagName(value: string);
    resetTagName(): void;
    get tagNameInput(): string | undefined;
}
export declare class RumMetricGroupByList extends cdktn.ComplexList {
    internalValue?: RumMetricGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RumMetricGroupByOutputReference;
}
export interface RumMetricUniqueness {
    /**
    * When to count updatable events. `match` when the event is first seen, or `end` when the event is complete.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_metric#when RumMetric#when}
    */
    readonly when?: string;
}
export declare function rumMetricUniquenessToTerraform(struct?: RumMetricUniqueness | cdktn.IResolvable): any;
export declare function rumMetricUniquenessToHclTerraform(struct?: RumMetricUniqueness | cdktn.IResolvable): any;
export declare class RumMetricUniquenessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RumMetricUniqueness | cdktn.IResolvable | undefined;
    set internalValue(value: RumMetricUniqueness | cdktn.IResolvable | undefined);
    private _when?;
    get when(): string;
    set when(value: string);
    resetWhen(): void;
    get whenInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_metric datadog_rum_metric}
*/
export declare class RumMetric extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_rum_metric";
    /**
    * Generates CDKTN code for importing a RumMetric resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RumMetric to import
    * @param importFromId The id of the existing RumMetric that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_metric#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RumMetric to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_metric datadog_rum_metric} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RumMetricConfig
    */
    constructor(scope: Construct, id: string, config: RumMetricConfig);
    private _eventType?;
    get eventType(): string;
    set eventType(value: string);
    get eventTypeInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _compute;
    get compute(): RumMetricComputeOutputReference;
    putCompute(value: RumMetricCompute): void;
    resetCompute(): void;
    get computeInput(): cdktn.IResolvable | RumMetricCompute | undefined;
    private _filter;
    get filter(): RumMetricFilterOutputReference;
    putFilter(value: RumMetricFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | RumMetricFilter | undefined;
    private _groupBy;
    get groupBy(): RumMetricGroupByList;
    putGroupBy(value: RumMetricGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | RumMetricGroupBy[] | undefined;
    private _uniqueness;
    get uniqueness(): RumMetricUniquenessOutputReference;
    putUniqueness(value: RumMetricUniqueness): void;
    resetUniqueness(): void;
    get uniquenessInput(): cdktn.IResolvable | RumMetricUniqueness | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
