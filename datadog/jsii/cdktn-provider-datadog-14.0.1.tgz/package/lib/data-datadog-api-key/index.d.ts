/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogApiKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether to use exact match when searching by name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/api_key#exact_match DataDatadogApiKey#exact_match}
    */
    readonly exactMatch?: boolean | cdktn.IResolvable;
    /**
    * The ID of this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/api_key#id DataDatadogApiKey#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name for API Key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/api_key#name DataDatadogApiKey#name}
    */
    readonly name?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/api_key datadog_api_key}
*/
export declare class DataDatadogApiKey extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_api_key";
    /**
    * Generates CDKTN code for importing a DataDatadogApiKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogApiKey to import
    * @param importFromId The id of the existing DataDatadogApiKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/api_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogApiKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/api_key datadog_api_key} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogApiKeyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogApiKeyConfig);
    private _exactMatch?;
    get exactMatch(): boolean | cdktn.IResolvable;
    set exactMatch(value: boolean | cdktn.IResolvable);
    resetExactMatch(): void;
    get exactMatchInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get key(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get remoteConfigReadEnabled(): cdktn.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
