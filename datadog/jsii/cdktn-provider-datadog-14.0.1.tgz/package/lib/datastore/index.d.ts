/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatastoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * A human-readable description about the datastore.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/datastore#description Datastore#description}
    */
    readonly description?: string;
    /**
    * The display name for the new datastore.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/datastore#name Datastore#name}
    */
    readonly name: string;
    /**
    * The organization access level for the datastore. For example, 'contributor'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/datastore#org_access Datastore#org_access}
    */
    readonly orgAccess?: string;
    /**
    * The name of the primary key column for this datastore. Primary column names:   - Must abide by both [PostgreSQL naming conventions](https://www.postgresql.org/docs/7.0/syntax525.htm)   - Cannot exceed 63 characters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/datastore#primary_column_name Datastore#primary_column_name}
    */
    readonly primaryColumnName: string;
    /**
    * Can be set to `uuid` to automatically generate primary keys when new items are added. Default value is `none`, which requires you to supply a primary key for each new item.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/datastore#primary_key_generation_strategy Datastore#primary_key_generation_strategy}
    */
    readonly primaryKeyGenerationStrategy?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/datastore datadog_datastore}
*/
export declare class Datastore extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_datastore";
    /**
    * Generates CDKTN code for importing a Datastore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Datastore to import
    * @param importFromId The id of the existing Datastore that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/datastore#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Datastore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/datastore datadog_datastore} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatastoreConfig
    */
    constructor(scope: Construct, id: string, config: DatastoreConfig);
    get createdAt(): string;
    get creatorUserId(): number;
    get creatorUserUuid(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get modifiedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _orgAccess?;
    get orgAccess(): string;
    set orgAccess(value: string);
    resetOrgAccess(): void;
    get orgAccessInput(): string | undefined;
    get orgId(): number;
    private _primaryColumnName?;
    get primaryColumnName(): string;
    set primaryColumnName(value: string);
    get primaryColumnNameInput(): string | undefined;
    private _primaryKeyGenerationStrategy?;
    get primaryKeyGenerationStrategy(): string;
    set primaryKeyGenerationStrategy(value: string);
    resetPrimaryKeyGenerationStrategy(): void;
    get primaryKeyGenerationStrategyInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
