/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RumApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Name of the RUM application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_application#name RumApplication#name}
    */
    readonly name: string;
    /**
    * Controls the retention policy for Product Analytics data derived from RUM events. Valid values are `MAX`, `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_application#product_analytics_retention_state RumApplication#product_analytics_retention_state}
    */
    readonly productAnalyticsRetentionState?: string;
    /**
    * Configures which RUM events are processed and stored for the application. Valid values are `ALL`, `ERROR_FOCUSED_MODE`, `NONE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_application#rum_event_processing_state RumApplication#rum_event_processing_state}
    */
    readonly rumEventProcessingState?: string;
    /**
    * Type of the RUM application. Supported values are `browser`, `ios`, `android`, `react-native`, `flutter`. Defaults to `"browser"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_application#type RumApplication#type}
    */
    readonly type?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_application datadog_rum_application}
*/
export declare class RumApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_rum_application";
    /**
    * Generates CDKTN code for importing a RumApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RumApplication to import
    * @param importFromId The id of the existing RumApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RumApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/rum_application datadog_rum_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RumApplicationConfig
    */
    constructor(scope: Construct, id: string, config: RumApplicationConfig);
    get apiKeyId(): number;
    get clientToken(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _productAnalyticsRetentionState?;
    get productAnalyticsRetentionState(): string;
    set productAnalyticsRetentionState(value: string);
    resetProductAnalyticsRetentionState(): void;
    get productAnalyticsRetentionStateInput(): string | undefined;
    private _rumEventProcessingState?;
    get rumEventProcessingState(): string;
    set rumEventProcessingState(value: string);
    resetRumEventProcessingState(): void;
    get rumEventProcessingStateInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
