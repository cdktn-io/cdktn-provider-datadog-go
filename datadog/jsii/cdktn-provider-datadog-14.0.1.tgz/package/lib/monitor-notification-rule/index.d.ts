/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MonitorNotificationRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the monitor notification rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor_notification_rule#name MonitorNotificationRule#name}
    */
    readonly name: string;
    /**
    * List of recipients to notify. Cannot be used with `conditional_recipients`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor_notification_rule#recipients MonitorNotificationRule#recipients}
    */
    readonly recipients?: string[];
    /**
    * conditional_recipients block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor_notification_rule#conditional_recipients MonitorNotificationRule#conditional_recipients}
    */
    readonly conditionalRecipients?: MonitorNotificationRuleConditionalRecipients;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor_notification_rule#filter MonitorNotificationRule#filter}
    */
    readonly filter?: MonitorNotificationRuleFilter;
}
export interface MonitorNotificationRuleConditionalRecipientsConditions {
    /**
    * A list of recipients to notify. Uses the same format as the monitor message field. Must not start with an '@'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor_notification_rule#recipients MonitorNotificationRule#recipients}
    */
    readonly recipients: string[];
    /**
    * Defines the condition under which the recipients are notified. Supported formats: Monitor status condition using `transition_type:<status>` (for example `transition_type:is_alert`) or a single tag `key:value pair` (for example `env:prod`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor_notification_rule#scope MonitorNotificationRule#scope}
    */
    readonly scope: string;
}
export declare function monitorNotificationRuleConditionalRecipientsConditionsToTerraform(struct?: MonitorNotificationRuleConditionalRecipientsConditions | cdktn.IResolvable): any;
export declare function monitorNotificationRuleConditionalRecipientsConditionsToHclTerraform(struct?: MonitorNotificationRuleConditionalRecipientsConditions | cdktn.IResolvable): any;
export declare class MonitorNotificationRuleConditionalRecipientsConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MonitorNotificationRuleConditionalRecipientsConditions | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorNotificationRuleConditionalRecipientsConditions | cdktn.IResolvable | undefined);
    private _recipients?;
    get recipients(): string[];
    set recipients(value: string[]);
    get recipientsInput(): string[] | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
}
export declare class MonitorNotificationRuleConditionalRecipientsConditionsList extends cdktn.ComplexList {
    internalValue?: MonitorNotificationRuleConditionalRecipientsConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MonitorNotificationRuleConditionalRecipientsConditionsOutputReference;
}
export interface MonitorNotificationRuleConditionalRecipients {
    /**
    * If none of the `conditions` applied, `fallback_recipients` will get notified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor_notification_rule#fallback_recipients MonitorNotificationRule#fallback_recipients}
    */
    readonly fallbackRecipients?: string[];
    /**
    * conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor_notification_rule#conditions MonitorNotificationRule#conditions}
    */
    readonly conditions?: MonitorNotificationRuleConditionalRecipientsConditions[] | cdktn.IResolvable;
}
export declare function monitorNotificationRuleConditionalRecipientsToTerraform(struct?: MonitorNotificationRuleConditionalRecipients | cdktn.IResolvable): any;
export declare function monitorNotificationRuleConditionalRecipientsToHclTerraform(struct?: MonitorNotificationRuleConditionalRecipients | cdktn.IResolvable): any;
export declare class MonitorNotificationRuleConditionalRecipientsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorNotificationRuleConditionalRecipients | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorNotificationRuleConditionalRecipients | cdktn.IResolvable | undefined);
    private _fallbackRecipients?;
    get fallbackRecipients(): string[];
    set fallbackRecipients(value: string[]);
    resetFallbackRecipients(): void;
    get fallbackRecipientsInput(): string[] | undefined;
    private _conditions;
    get conditions(): MonitorNotificationRuleConditionalRecipientsConditionsList;
    putConditions(value: MonitorNotificationRuleConditionalRecipientsConditions[] | cdktn.IResolvable): void;
    resetConditions(): void;
    get conditionsInput(): cdktn.IResolvable | MonitorNotificationRuleConditionalRecipientsConditions[] | undefined;
}
export interface MonitorNotificationRuleFilter {
    /**
    * A scope expression composed of `key:value` pairs (such as `env:prod`) with boolean operators (AND, OR, NOT) and parentheses for grouping.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor_notification_rule#scope MonitorNotificationRule#scope}
    */
    readonly scope?: string;
    /**
    * A list of tag key:value pairs (e.g. team:product). All tags must match (AND semantics).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor_notification_rule#tags MonitorNotificationRule#tags}
    */
    readonly tags?: string[];
}
export declare function monitorNotificationRuleFilterToTerraform(struct?: MonitorNotificationRuleFilter | cdktn.IResolvable): any;
export declare function monitorNotificationRuleFilterToHclTerraform(struct?: MonitorNotificationRuleFilter | cdktn.IResolvable): any;
export declare class MonitorNotificationRuleFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MonitorNotificationRuleFilter | cdktn.IResolvable | undefined;
    set internalValue(value: MonitorNotificationRuleFilter | cdktn.IResolvable | undefined);
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor_notification_rule datadog_monitor_notification_rule}
*/
export declare class MonitorNotificationRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_monitor_notification_rule";
    /**
    * Generates CDKTN code for importing a MonitorNotificationRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MonitorNotificationRule to import
    * @param importFromId The id of the existing MonitorNotificationRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor_notification_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MonitorNotificationRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/monitor_notification_rule datadog_monitor_notification_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MonitorNotificationRuleConfig
    */
    constructor(scope: Construct, id: string, config: MonitorNotificationRuleConfig);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _recipients?;
    get recipients(): string[];
    set recipients(value: string[]);
    resetRecipients(): void;
    get recipientsInput(): string[] | undefined;
    private _conditionalRecipients;
    get conditionalRecipients(): MonitorNotificationRuleConditionalRecipientsOutputReference;
    putConditionalRecipients(value: MonitorNotificationRuleConditionalRecipients): void;
    resetConditionalRecipients(): void;
    get conditionalRecipientsInput(): cdktn.IResolvable | MonitorNotificationRuleConditionalRecipients | undefined;
    private _filter;
    get filter(): MonitorNotificationRuleFilterOutputReference;
    putFilter(value: MonitorNotificationRuleFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | MonitorNotificationRuleFilter | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
