/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogCustomAllocationRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the custom allocation rule to retrieve.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/custom_allocation_rule#rule_id DataDatadogCustomAllocationRule#rule_id}
    */
    readonly ruleId?: number;
    /**
    * costs_to_allocate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/custom_allocation_rule#costs_to_allocate DataDatadogCustomAllocationRule#costs_to_allocate}
    */
    readonly costsToAllocate?: DataDatadogCustomAllocationRuleCostsToAllocate[] | cdktn.IResolvable;
    /**
    * strategy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/custom_allocation_rule#strategy DataDatadogCustomAllocationRule#strategy}
    */
    readonly strategy?: DataDatadogCustomAllocationRuleStrategy;
}
export interface DataDatadogCustomAllocationRuleCostsToAllocate {
}
export declare function dataDatadogCustomAllocationRuleCostsToAllocateToTerraform(struct?: DataDatadogCustomAllocationRuleCostsToAllocate | cdktn.IResolvable): any;
export declare function dataDatadogCustomAllocationRuleCostsToAllocateToHclTerraform(struct?: DataDatadogCustomAllocationRuleCostsToAllocate | cdktn.IResolvable): any;
export declare class DataDatadogCustomAllocationRuleCostsToAllocateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogCustomAllocationRuleCostsToAllocate | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogCustomAllocationRuleCostsToAllocate | cdktn.IResolvable | undefined);
    get condition(): string;
    get tag(): string;
    get value(): string;
    get values(): string[];
}
export declare class DataDatadogCustomAllocationRuleCostsToAllocateList extends cdktn.ComplexList {
    internalValue?: DataDatadogCustomAllocationRuleCostsToAllocate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogCustomAllocationRuleCostsToAllocateOutputReference;
}
export interface DataDatadogCustomAllocationRuleStrategyAllocatedByAllocatedTags {
}
export declare function dataDatadogCustomAllocationRuleStrategyAllocatedByAllocatedTagsToTerraform(struct?: DataDatadogCustomAllocationRuleStrategyAllocatedByAllocatedTags | cdktn.IResolvable): any;
export declare function dataDatadogCustomAllocationRuleStrategyAllocatedByAllocatedTagsToHclTerraform(struct?: DataDatadogCustomAllocationRuleStrategyAllocatedByAllocatedTags | cdktn.IResolvable): any;
export declare class DataDatadogCustomAllocationRuleStrategyAllocatedByAllocatedTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogCustomAllocationRuleStrategyAllocatedByAllocatedTags | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogCustomAllocationRuleStrategyAllocatedByAllocatedTags | cdktn.IResolvable | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataDatadogCustomAllocationRuleStrategyAllocatedByAllocatedTagsList extends cdktn.ComplexList {
    internalValue?: DataDatadogCustomAllocationRuleStrategyAllocatedByAllocatedTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogCustomAllocationRuleStrategyAllocatedByAllocatedTagsOutputReference;
}
export interface DataDatadogCustomAllocationRuleStrategyAllocatedBy {
    /**
    * allocated_tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/custom_allocation_rule#allocated_tags DataDatadogCustomAllocationRule#allocated_tags}
    */
    readonly allocatedTags?: DataDatadogCustomAllocationRuleStrategyAllocatedByAllocatedTags[] | cdktn.IResolvable;
}
export declare function dataDatadogCustomAllocationRuleStrategyAllocatedByToTerraform(struct?: DataDatadogCustomAllocationRuleStrategyAllocatedBy | cdktn.IResolvable): any;
export declare function dataDatadogCustomAllocationRuleStrategyAllocatedByToHclTerraform(struct?: DataDatadogCustomAllocationRuleStrategyAllocatedBy | cdktn.IResolvable): any;
export declare class DataDatadogCustomAllocationRuleStrategyAllocatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogCustomAllocationRuleStrategyAllocatedBy | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogCustomAllocationRuleStrategyAllocatedBy | cdktn.IResolvable | undefined);
    get percentage(): number;
    private _allocatedTags;
    get allocatedTags(): DataDatadogCustomAllocationRuleStrategyAllocatedByAllocatedTagsList;
    putAllocatedTags(value: DataDatadogCustomAllocationRuleStrategyAllocatedByAllocatedTags[] | cdktn.IResolvable): void;
    resetAllocatedTags(): void;
    get allocatedTagsInput(): cdktn.IResolvable | DataDatadogCustomAllocationRuleStrategyAllocatedByAllocatedTags[] | undefined;
}
export declare class DataDatadogCustomAllocationRuleStrategyAllocatedByList extends cdktn.ComplexList {
    internalValue?: DataDatadogCustomAllocationRuleStrategyAllocatedBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogCustomAllocationRuleStrategyAllocatedByOutputReference;
}
export interface DataDatadogCustomAllocationRuleStrategyAllocatedByFilters {
}
export declare function dataDatadogCustomAllocationRuleStrategyAllocatedByFiltersToTerraform(struct?: DataDatadogCustomAllocationRuleStrategyAllocatedByFilters | cdktn.IResolvable): any;
export declare function dataDatadogCustomAllocationRuleStrategyAllocatedByFiltersToHclTerraform(struct?: DataDatadogCustomAllocationRuleStrategyAllocatedByFilters | cdktn.IResolvable): any;
export declare class DataDatadogCustomAllocationRuleStrategyAllocatedByFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogCustomAllocationRuleStrategyAllocatedByFilters | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogCustomAllocationRuleStrategyAllocatedByFilters | cdktn.IResolvable | undefined);
    get condition(): string;
    get tag(): string;
    get value(): string;
    get values(): string[];
}
export declare class DataDatadogCustomAllocationRuleStrategyAllocatedByFiltersList extends cdktn.ComplexList {
    internalValue?: DataDatadogCustomAllocationRuleStrategyAllocatedByFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogCustomAllocationRuleStrategyAllocatedByFiltersOutputReference;
}
export interface DataDatadogCustomAllocationRuleStrategyBasedOnCosts {
}
export declare function dataDatadogCustomAllocationRuleStrategyBasedOnCostsToTerraform(struct?: DataDatadogCustomAllocationRuleStrategyBasedOnCosts | cdktn.IResolvable): any;
export declare function dataDatadogCustomAllocationRuleStrategyBasedOnCostsToHclTerraform(struct?: DataDatadogCustomAllocationRuleStrategyBasedOnCosts | cdktn.IResolvable): any;
export declare class DataDatadogCustomAllocationRuleStrategyBasedOnCostsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogCustomAllocationRuleStrategyBasedOnCosts | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogCustomAllocationRuleStrategyBasedOnCosts | cdktn.IResolvable | undefined);
    get condition(): string;
    get tag(): string;
    get value(): string;
    get values(): string[];
}
export declare class DataDatadogCustomAllocationRuleStrategyBasedOnCostsList extends cdktn.ComplexList {
    internalValue?: DataDatadogCustomAllocationRuleStrategyBasedOnCosts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogCustomAllocationRuleStrategyBasedOnCostsOutputReference;
}
export interface DataDatadogCustomAllocationRuleStrategyBasedOnTimeseries {
}
export declare function dataDatadogCustomAllocationRuleStrategyBasedOnTimeseriesToTerraform(struct?: DataDatadogCustomAllocationRuleStrategyBasedOnTimeseries | cdktn.IResolvable): any;
export declare function dataDatadogCustomAllocationRuleStrategyBasedOnTimeseriesToHclTerraform(struct?: DataDatadogCustomAllocationRuleStrategyBasedOnTimeseries | cdktn.IResolvable): any;
export declare class DataDatadogCustomAllocationRuleStrategyBasedOnTimeseriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogCustomAllocationRuleStrategyBasedOnTimeseries | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogCustomAllocationRuleStrategyBasedOnTimeseries | cdktn.IResolvable | undefined);
}
export interface DataDatadogCustomAllocationRuleStrategyEvaluateGroupedByFilters {
}
export declare function dataDatadogCustomAllocationRuleStrategyEvaluateGroupedByFiltersToTerraform(struct?: DataDatadogCustomAllocationRuleStrategyEvaluateGroupedByFilters | cdktn.IResolvable): any;
export declare function dataDatadogCustomAllocationRuleStrategyEvaluateGroupedByFiltersToHclTerraform(struct?: DataDatadogCustomAllocationRuleStrategyEvaluateGroupedByFilters | cdktn.IResolvable): any;
export declare class DataDatadogCustomAllocationRuleStrategyEvaluateGroupedByFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogCustomAllocationRuleStrategyEvaluateGroupedByFilters | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogCustomAllocationRuleStrategyEvaluateGroupedByFilters | cdktn.IResolvable | undefined);
    get condition(): string;
    get tag(): string;
    get value(): string;
    get values(): string[];
}
export declare class DataDatadogCustomAllocationRuleStrategyEvaluateGroupedByFiltersList extends cdktn.ComplexList {
    internalValue?: DataDatadogCustomAllocationRuleStrategyEvaluateGroupedByFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogCustomAllocationRuleStrategyEvaluateGroupedByFiltersOutputReference;
}
export interface DataDatadogCustomAllocationRuleStrategy {
    /**
    * allocated_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/custom_allocation_rule#allocated_by DataDatadogCustomAllocationRule#allocated_by}
    */
    readonly allocatedBy?: DataDatadogCustomAllocationRuleStrategyAllocatedBy[] | cdktn.IResolvable;
    /**
    * allocated_by_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/custom_allocation_rule#allocated_by_filters DataDatadogCustomAllocationRule#allocated_by_filters}
    */
    readonly allocatedByFilters?: DataDatadogCustomAllocationRuleStrategyAllocatedByFilters[] | cdktn.IResolvable;
    /**
    * based_on_costs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/custom_allocation_rule#based_on_costs DataDatadogCustomAllocationRule#based_on_costs}
    */
    readonly basedOnCosts?: DataDatadogCustomAllocationRuleStrategyBasedOnCosts[] | cdktn.IResolvable;
    /**
    * based_on_timeseries block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/custom_allocation_rule#based_on_timeseries DataDatadogCustomAllocationRule#based_on_timeseries}
    */
    readonly basedOnTimeseries?: DataDatadogCustomAllocationRuleStrategyBasedOnTimeseries;
    /**
    * evaluate_grouped_by_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/custom_allocation_rule#evaluate_grouped_by_filters DataDatadogCustomAllocationRule#evaluate_grouped_by_filters}
    */
    readonly evaluateGroupedByFilters?: DataDatadogCustomAllocationRuleStrategyEvaluateGroupedByFilters[] | cdktn.IResolvable;
}
export declare function dataDatadogCustomAllocationRuleStrategyToTerraform(struct?: DataDatadogCustomAllocationRuleStrategy | cdktn.IResolvable): any;
export declare function dataDatadogCustomAllocationRuleStrategyToHclTerraform(struct?: DataDatadogCustomAllocationRuleStrategy | cdktn.IResolvable): any;
export declare class DataDatadogCustomAllocationRuleStrategyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogCustomAllocationRuleStrategy | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogCustomAllocationRuleStrategy | cdktn.IResolvable | undefined);
    get allocatedByTagKeys(): string[];
    get evaluateGroupedByTagKeys(): string[];
    get granularity(): string;
    get method(): string;
    private _allocatedBy;
    get allocatedBy(): DataDatadogCustomAllocationRuleStrategyAllocatedByList;
    putAllocatedBy(value: DataDatadogCustomAllocationRuleStrategyAllocatedBy[] | cdktn.IResolvable): void;
    resetAllocatedBy(): void;
    get allocatedByInput(): cdktn.IResolvable | DataDatadogCustomAllocationRuleStrategyAllocatedBy[] | undefined;
    private _allocatedByFilters;
    get allocatedByFilters(): DataDatadogCustomAllocationRuleStrategyAllocatedByFiltersList;
    putAllocatedByFilters(value: DataDatadogCustomAllocationRuleStrategyAllocatedByFilters[] | cdktn.IResolvable): void;
    resetAllocatedByFilters(): void;
    get allocatedByFiltersInput(): cdktn.IResolvable | DataDatadogCustomAllocationRuleStrategyAllocatedByFilters[] | undefined;
    private _basedOnCosts;
    get basedOnCosts(): DataDatadogCustomAllocationRuleStrategyBasedOnCostsList;
    putBasedOnCosts(value: DataDatadogCustomAllocationRuleStrategyBasedOnCosts[] | cdktn.IResolvable): void;
    resetBasedOnCosts(): void;
    get basedOnCostsInput(): cdktn.IResolvable | DataDatadogCustomAllocationRuleStrategyBasedOnCosts[] | undefined;
    private _basedOnTimeseries;
    get basedOnTimeseries(): DataDatadogCustomAllocationRuleStrategyBasedOnTimeseriesOutputReference;
    putBasedOnTimeseries(value: DataDatadogCustomAllocationRuleStrategyBasedOnTimeseries): void;
    get basedOnTimeseriesInput(): cdktn.IResolvable | DataDatadogCustomAllocationRuleStrategyBasedOnTimeseries | undefined;
    private _evaluateGroupedByFilters;
    get evaluateGroupedByFilters(): DataDatadogCustomAllocationRuleStrategyEvaluateGroupedByFiltersList;
    putEvaluateGroupedByFilters(value: DataDatadogCustomAllocationRuleStrategyEvaluateGroupedByFilters[] | cdktn.IResolvable): void;
    resetEvaluateGroupedByFilters(): void;
    get evaluateGroupedByFiltersInput(): cdktn.IResolvable | DataDatadogCustomAllocationRuleStrategyEvaluateGroupedByFilters[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/custom_allocation_rule datadog_custom_allocation_rule}
*/
export declare class DataDatadogCustomAllocationRule extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_custom_allocation_rule";
    /**
    * Generates CDKTN code for importing a DataDatadogCustomAllocationRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogCustomAllocationRule to import
    * @param importFromId The id of the existing DataDatadogCustomAllocationRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/custom_allocation_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogCustomAllocationRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/custom_allocation_rule datadog_custom_allocation_rule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogCustomAllocationRuleConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogCustomAllocationRuleConfig);
    get created(): string;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get lastModifiedUserUuid(): string;
    get orderId(): number;
    get providernames(): string[];
    get rejected(): cdktn.IResolvable;
    private _ruleId?;
    get ruleId(): number;
    set ruleId(value: number);
    resetRuleId(): void;
    get ruleIdInput(): number | undefined;
    get ruleName(): string;
    get type(): string;
    get updated(): string;
    get version(): string;
    private _costsToAllocate;
    get costsToAllocate(): DataDatadogCustomAllocationRuleCostsToAllocateList;
    putCostsToAllocate(value: DataDatadogCustomAllocationRuleCostsToAllocate[] | cdktn.IResolvable): void;
    resetCostsToAllocate(): void;
    get costsToAllocateInput(): cdktn.IResolvable | DataDatadogCustomAllocationRuleCostsToAllocate[] | undefined;
    private _strategy;
    get strategy(): DataDatadogCustomAllocationRuleStrategyOutputReference;
    putStrategy(value: DataDatadogCustomAllocationRuleStrategy): void;
    resetStrategy(): void;
    get strategyInput(): cdktn.IResolvable | DataDatadogCustomAllocationRuleStrategy | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
