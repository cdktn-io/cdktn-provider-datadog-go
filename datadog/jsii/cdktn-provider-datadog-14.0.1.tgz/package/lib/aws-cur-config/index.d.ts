/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCurConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * The AWS account ID of your billing/payer account. For AWS Organizations, this is typically the management account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/aws_cur_config#account_id AwsCurConfig#account_id}
    */
    readonly accountId: string;
    /**
    * The S3 bucket name where your AWS Cost and Usage Report files are stored. This bucket must have appropriate IAM permissions for Datadog access and should be in the same AWS account as the CUR report.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/aws_cur_config#bucket_name AwsCurConfig#bucket_name}
    */
    readonly bucketName: string;
    /**
    * The AWS region where the S3 bucket containing your Cost and Usage Report is located (e.g., us-east-1, eu-west-1).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/aws_cur_config#bucket_region AwsCurConfig#bucket_region}
    */
    readonly bucketRegion?: string;
    /**
    * The exact name of your AWS Cost and Usage Report as configured in AWS Billing preferences. This must match the report name exactly as it appears in your AWS billing settings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/aws_cur_config#report_name AwsCurConfig#report_name}
    */
    readonly reportName: string;
    /**
    * The S3 key prefix where your Cost and Usage Report files are stored within the bucket (e.g., 'cur-reports/', 'billing/cur/').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/aws_cur_config#report_prefix AwsCurConfig#report_prefix}
    */
    readonly reportPrefix: string;
    /**
    * account_filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/aws_cur_config#account_filters AwsCurConfig#account_filters}
    */
    readonly accountFilters?: AwsCurConfigAccountFilters;
}
export interface AwsCurConfigAccountFilters {
    /**
    * List of AWS account IDs to exclude from cost analysis. Only used when `include_new_accounts` is `true`. Cannot be used together with `included_accounts`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/aws_cur_config#excluded_accounts AwsCurConfig#excluded_accounts}
    */
    readonly excludedAccounts?: string[];
    /**
    * Whether to automatically include new member accounts in your cost analysis. When `true`, use `excluded_accounts` to specify accounts to exclude. When `false`, use `included_accounts` to specify only the accounts to include.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/aws_cur_config#include_new_accounts AwsCurConfig#include_new_accounts}
    */
    readonly includeNewAccounts?: boolean | cdktn.IResolvable;
    /**
    * List of AWS account IDs to include in cost analysis. Only used when `include_new_accounts` is `false`. Cannot be used together with `excluded_accounts`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/aws_cur_config#included_accounts AwsCurConfig#included_accounts}
    */
    readonly includedAccounts?: string[];
}
export declare function awsCurConfigAccountFiltersToTerraform(struct?: AwsCurConfigAccountFilters | cdktn.IResolvable): any;
export declare function awsCurConfigAccountFiltersToHclTerraform(struct?: AwsCurConfigAccountFilters | cdktn.IResolvable): any;
export declare class AwsCurConfigAccountFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AwsCurConfigAccountFilters | cdktn.IResolvable | undefined;
    set internalValue(value: AwsCurConfigAccountFilters | cdktn.IResolvable | undefined);
    private _excludedAccounts?;
    get excludedAccounts(): string[];
    set excludedAccounts(value: string[]);
    resetExcludedAccounts(): void;
    get excludedAccountsInput(): string[] | undefined;
    private _includeNewAccounts?;
    get includeNewAccounts(): boolean | cdktn.IResolvable;
    set includeNewAccounts(value: boolean | cdktn.IResolvable);
    resetIncludeNewAccounts(): void;
    get includeNewAccountsInput(): boolean | cdktn.IResolvable | undefined;
    private _includedAccounts?;
    get includedAccounts(): string[];
    set includedAccounts(value: string[]);
    resetIncludedAccounts(): void;
    get includedAccountsInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/aws_cur_config datadog_aws_cur_config}
*/
export declare class AwsCurConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_aws_cur_config";
    /**
    * Generates CDKTN code for importing a AwsCurConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCurConfig to import
    * @param importFromId The id of the existing AwsCurConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/aws_cur_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCurConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/aws_cur_config datadog_aws_cur_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCurConfigConfig
    */
    constructor(scope: Construct, id: string, config: AwsCurConfigConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    get bucketNameInput(): string | undefined;
    private _bucketRegion?;
    get bucketRegion(): string;
    set bucketRegion(value: string);
    resetBucketRegion(): void;
    get bucketRegionInput(): string | undefined;
    get createdAt(): string;
    get errorMessages(): string[];
    get id(): string;
    private _reportName?;
    get reportName(): string;
    set reportName(value: string);
    get reportNameInput(): string | undefined;
    private _reportPrefix?;
    get reportPrefix(): string;
    set reportPrefix(value: string);
    get reportPrefixInput(): string | undefined;
    get status(): string;
    get statusUpdatedAt(): string;
    get updatedAt(): string;
    private _accountFilters;
    get accountFilters(): AwsCurConfigAccountFiltersOutputReference;
    putAccountFilters(value: AwsCurConfigAccountFilters): void;
    resetAccountFilters(): void;
    get accountFiltersInput(): cdktn.IResolvable | AwsCurConfigAccountFilters | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
