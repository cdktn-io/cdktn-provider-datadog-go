/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LogsArchiveOrderConfig extends cdktn.TerraformMetaArguments {
    /**
    * The archive IDs list. The order of archive IDs in this attribute defines the overall archive order for logs. If `archive_ids` is empty or not specified, it will import the actual archive order, and create the resource. Otherwise, it will try to update the order.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_archive_order#archive_ids LogsArchiveOrder#archive_ids}
    */
    readonly archiveIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_archive_order#id LogsArchiveOrder#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_archive_order datadog_logs_archive_order}
*/
export declare class LogsArchiveOrder extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_logs_archive_order";
    /**
    * Generates CDKTN code for importing a LogsArchiveOrder resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LogsArchiveOrder to import
    * @param importFromId The id of the existing LogsArchiveOrder that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_archive_order#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LogsArchiveOrder to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/logs_archive_order datadog_logs_archive_order} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LogsArchiveOrderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: LogsArchiveOrderConfig);
    private _archiveIds?;
    get archiveIds(): string[];
    set archiveIds(value: string[]);
    resetArchiveIds(): void;
    get archiveIdsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
