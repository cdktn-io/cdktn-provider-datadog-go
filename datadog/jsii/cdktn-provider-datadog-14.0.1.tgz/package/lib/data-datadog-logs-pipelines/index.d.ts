/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogLogsPipelinesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/logs_pipelines#id DataDatadogLogsPipelines#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filter parameter for retrieved pipelines
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/logs_pipelines#is_read_only DataDatadogLogsPipelines#is_read_only}
    */
    readonly isReadOnly?: string;
}
export interface DataDatadogLogsPipelinesLogsPipelinesFilter {
}
export declare function dataDatadogLogsPipelinesLogsPipelinesFilterToTerraform(struct?: DataDatadogLogsPipelinesLogsPipelinesFilter): any;
export declare function dataDatadogLogsPipelinesLogsPipelinesFilterToHclTerraform(struct?: DataDatadogLogsPipelinesLogsPipelinesFilter): any;
export declare class DataDatadogLogsPipelinesLogsPipelinesFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogLogsPipelinesLogsPipelinesFilter | undefined;
    set internalValue(value: DataDatadogLogsPipelinesLogsPipelinesFilter | undefined);
    get query(): string;
}
export declare class DataDatadogLogsPipelinesLogsPipelinesFilterList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogLogsPipelinesLogsPipelinesFilterOutputReference;
}
export interface DataDatadogLogsPipelinesLogsPipelines {
}
export declare function dataDatadogLogsPipelinesLogsPipelinesToTerraform(struct?: DataDatadogLogsPipelinesLogsPipelines): any;
export declare function dataDatadogLogsPipelinesLogsPipelinesToHclTerraform(struct?: DataDatadogLogsPipelinesLogsPipelines): any;
export declare class DataDatadogLogsPipelinesLogsPipelinesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogLogsPipelinesLogsPipelines | undefined;
    set internalValue(value: DataDatadogLogsPipelinesLogsPipelines | undefined);
    get description(): string;
    private _filter;
    get filter(): DataDatadogLogsPipelinesLogsPipelinesFilterList;
    get id(): string;
    get isEnabled(): cdktn.IResolvable;
    get isReadOnly(): cdktn.IResolvable;
    get name(): string;
    get tags(): string[];
    get type(): string;
}
export declare class DataDatadogLogsPipelinesLogsPipelinesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogLogsPipelinesLogsPipelinesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/logs_pipelines datadog_logs_pipelines}
*/
export declare class DataDatadogLogsPipelines extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_logs_pipelines";
    /**
    * Generates CDKTN code for importing a DataDatadogLogsPipelines resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogLogsPipelines to import
    * @param importFromId The id of the existing DataDatadogLogsPipelines that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/logs_pipelines#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogLogsPipelines to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/logs_pipelines datadog_logs_pipelines} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogLogsPipelinesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogLogsPipelinesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isReadOnly?;
    get isReadOnly(): string;
    set isReadOnly(value: string);
    resetIsReadOnly(): void;
    get isReadOnlyInput(): string | undefined;
    private _logsPipelines;
    get logsPipelines(): DataDatadogLogsPipelinesLogsPipelinesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
