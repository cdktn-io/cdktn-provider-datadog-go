/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IntegrationConfluentAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * The API key associated with your Confluent account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_confluent_account#api_key IntegrationConfluentAccount#api_key}
    */
    readonly apiKey: string;
    /**
    * The API secret associated with your Confluent account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_confluent_account#api_secret IntegrationConfluentAccount#api_secret}
    */
    readonly apiSecret: string;
    /**
    * A list of strings representing tags. Can be a single key, or key-value pairs separated by a colon.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_confluent_account#tags IntegrationConfluentAccount#tags}
    */
    readonly tags?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_confluent_account datadog_integration_confluent_account}
*/
export declare class IntegrationConfluentAccount extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_integration_confluent_account";
    /**
    * Generates CDKTN code for importing a IntegrationConfluentAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IntegrationConfluentAccount to import
    * @param importFromId The id of the existing IntegrationConfluentAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_confluent_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IntegrationConfluentAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_confluent_account datadog_integration_confluent_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IntegrationConfluentAccountConfig
    */
    constructor(scope: Construct, id: string, config: IntegrationConfluentAccountConfig);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    get apiKeyInput(): string | undefined;
    private _apiSecret?;
    get apiSecret(): string;
    set apiSecret(value: string);
    get apiSecretInput(): string | undefined;
    get id(): string;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
