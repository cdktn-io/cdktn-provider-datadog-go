/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
import { ObservabilityPipelineConfigDestinationSumoLogicBufferDisk, ObservabilityPipelineConfigDestinationSumoLogicBufferDiskList, ObservabilityPipelineConfigDestinationAmazonOpensearch, ObservabilityPipelineConfigDestinationAmazonOpensearchList, ObservabilityPipelineConfigDestinationAmazonS3, ObservabilityPipelineConfigDestinationAmazonS3List, ObservabilityPipelineConfigDestinationAmazonSecurityLake, ObservabilityPipelineConfigDestinationAmazonSecurityLakeList, ObservabilityPipelineConfigDestinationAzureStorage, ObservabilityPipelineConfigDestinationAzureStorageList, ObservabilityPipelineConfigDestinationCloudPrem, ObservabilityPipelineConfigDestinationCloudPremList, ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiem, ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemList, ObservabilityPipelineConfigDestinationDatadogLogs, ObservabilityPipelineConfigDestinationDatadogLogsList, ObservabilityPipelineConfigDestinationDatadogMetrics, ObservabilityPipelineConfigDestinationDatadogMetricsList, ObservabilityPipelineConfigDestinationElasticsearch, ObservabilityPipelineConfigDestinationElasticsearchList, ObservabilityPipelineConfigDestinationGoogleCloudStorage, ObservabilityPipelineConfigDestinationGoogleCloudStorageList, ObservabilityPipelineConfigDestinationGooglePubsub, ObservabilityPipelineConfigDestinationGooglePubsubList, ObservabilityPipelineConfigDestinationGoogleSecops, ObservabilityPipelineConfigDestinationGoogleSecopsList, ObservabilityPipelineConfigDestinationHttpClient, ObservabilityPipelineConfigDestinationHttpClientList, ObservabilityPipelineConfigDestinationKafka, ObservabilityPipelineConfigDestinationKafkaList, ObservabilityPipelineConfigDestinationMicrosoftSentinel, ObservabilityPipelineConfigDestinationMicrosoftSentinelList, ObservabilityPipelineConfigDestinationNewRelic, ObservabilityPipelineConfigDestinationNewRelicList, ObservabilityPipelineConfigDestinationOpensearch, ObservabilityPipelineConfigDestinationOpensearchList, ObservabilityPipelineConfigDestinationRsyslog, ObservabilityPipelineConfigDestinationRsyslogList, ObservabilityPipelineConfigDestinationSentinelOne, ObservabilityPipelineConfigDestinationSentinelOneList, ObservabilityPipelineConfigDestinationSocket, ObservabilityPipelineConfigDestinationSocketList, ObservabilityPipelineConfigDestinationSplunkHec, ObservabilityPipelineConfigDestinationSplunkHecList } from './structs0';
export interface ObservabilityPipelineConfigDestinationSumoLogicBufferMemory {
    /**
    * Maximum events for the memory buffer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_events ObservabilityPipeline#max_events}
    */
    readonly maxEvents?: number;
    /**
    * Maximum size of the memory buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationSumoLogicBufferMemoryToTerraform(struct?: ObservabilityPipelineConfigDestinationSumoLogicBufferMemory | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSumoLogicBufferMemoryToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSumoLogicBufferMemory | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSumoLogicBufferMemoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSumoLogicBufferMemory | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSumoLogicBufferMemory | cdktn.IResolvable | undefined);
    private _maxEvents?;
    get maxEvents(): number;
    set maxEvents(value: number);
    resetMaxEvents(): void;
    get maxEventsInput(): number | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSumoLogicBufferMemoryList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSumoLogicBufferMemory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSumoLogicBufferMemoryOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSumoLogicBuffer {
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#disk ObservabilityPipeline#disk}
    */
    readonly disk?: ObservabilityPipelineConfigDestinationSumoLogicBufferDisk[] | cdktn.IResolvable;
    /**
    * memory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#memory ObservabilityPipeline#memory}
    */
    readonly memory?: ObservabilityPipelineConfigDestinationSumoLogicBufferMemory[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationSumoLogicBufferToTerraform(struct?: ObservabilityPipelineConfigDestinationSumoLogicBuffer | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSumoLogicBufferToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSumoLogicBuffer | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSumoLogicBufferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSumoLogicBuffer | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSumoLogicBuffer | cdktn.IResolvable | undefined);
    private _disk;
    get disk(): ObservabilityPipelineConfigDestinationSumoLogicBufferDiskList;
    putDisk(value: ObservabilityPipelineConfigDestinationSumoLogicBufferDisk[] | cdktn.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSumoLogicBufferDisk[] | undefined;
    private _memory;
    get memory(): ObservabilityPipelineConfigDestinationSumoLogicBufferMemoryList;
    putMemory(value: ObservabilityPipelineConfigDestinationSumoLogicBufferMemory[] | cdktn.IResolvable): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSumoLogicBufferMemory[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSumoLogicBufferList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSumoLogicBuffer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSumoLogicBufferOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSumoLogicHeaderCustomField {
    /**
    * The header field name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#name ObservabilityPipeline#name}
    */
    readonly name?: string;
    /**
    * The header field value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#value ObservabilityPipeline#value}
    */
    readonly value?: string;
}
export declare function observabilityPipelineConfigDestinationSumoLogicHeaderCustomFieldToTerraform(struct?: ObservabilityPipelineConfigDestinationSumoLogicHeaderCustomField | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSumoLogicHeaderCustomFieldToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSumoLogicHeaderCustomField | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSumoLogicHeaderCustomFieldOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSumoLogicHeaderCustomField | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSumoLogicHeaderCustomField | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSumoLogicHeaderCustomFieldList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSumoLogicHeaderCustomField[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSumoLogicHeaderCustomFieldOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSumoLogic {
    /**
    * The output encoding format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#encoding ObservabilityPipeline#encoding}
    */
    readonly encoding?: string;
    /**
    * Name of the environment variable or secret that holds the Sumo Logic endpoint URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#endpoint_url_key ObservabilityPipeline#endpoint_url_key}
    */
    readonly endpointUrlKey?: string;
    /**
    * Optional override for the host name header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#header_host_name ObservabilityPipeline#header_host_name}
    */
    readonly headerHostName?: string;
    /**
    * Optional override for the source category header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#header_source_category ObservabilityPipeline#header_source_category}
    */
    readonly headerSourceCategory?: string;
    /**
    * Optional override for the source name header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#header_source_name ObservabilityPipeline#header_source_name}
    */
    readonly headerSourceName?: string;
    /**
    * buffer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#buffer ObservabilityPipeline#buffer}
    */
    readonly buffer?: ObservabilityPipelineConfigDestinationSumoLogicBuffer[] | cdktn.IResolvable;
    /**
    * header_custom_field block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#header_custom_field ObservabilityPipeline#header_custom_field}
    */
    readonly headerCustomField?: ObservabilityPipelineConfigDestinationSumoLogicHeaderCustomField[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationSumoLogicToTerraform(struct?: ObservabilityPipelineConfigDestinationSumoLogic | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSumoLogicToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSumoLogic | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSumoLogicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSumoLogic | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSumoLogic | cdktn.IResolvable | undefined);
    private _encoding?;
    get encoding(): string;
    set encoding(value: string);
    resetEncoding(): void;
    get encodingInput(): string | undefined;
    private _endpointUrlKey?;
    get endpointUrlKey(): string;
    set endpointUrlKey(value: string);
    resetEndpointUrlKey(): void;
    get endpointUrlKeyInput(): string | undefined;
    private _headerHostName?;
    get headerHostName(): string;
    set headerHostName(value: string);
    resetHeaderHostName(): void;
    get headerHostNameInput(): string | undefined;
    private _headerSourceCategory?;
    get headerSourceCategory(): string;
    set headerSourceCategory(value: string);
    resetHeaderSourceCategory(): void;
    get headerSourceCategoryInput(): string | undefined;
    private _headerSourceName?;
    get headerSourceName(): string;
    set headerSourceName(value: string);
    resetHeaderSourceName(): void;
    get headerSourceNameInput(): string | undefined;
    private _buffer;
    get buffer(): ObservabilityPipelineConfigDestinationSumoLogicBufferList;
    putBuffer(value: ObservabilityPipelineConfigDestinationSumoLogicBuffer[] | cdktn.IResolvable): void;
    resetBuffer(): void;
    get bufferInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSumoLogicBuffer[] | undefined;
    private _headerCustomField;
    get headerCustomField(): ObservabilityPipelineConfigDestinationSumoLogicHeaderCustomFieldList;
    putHeaderCustomField(value: ObservabilityPipelineConfigDestinationSumoLogicHeaderCustomField[] | cdktn.IResolvable): void;
    resetHeaderCustomField(): void;
    get headerCustomFieldInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSumoLogicHeaderCustomField[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSumoLogicList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSumoLogic[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSumoLogicOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSyslogNgBufferDisk {
    /**
    * Maximum size of the disk buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationSyslogNgBufferDiskToTerraform(struct?: ObservabilityPipelineConfigDestinationSyslogNgBufferDisk | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSyslogNgBufferDiskToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSyslogNgBufferDisk | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSyslogNgBufferDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSyslogNgBufferDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSyslogNgBufferDisk | cdktn.IResolvable | undefined);
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSyslogNgBufferDiskList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSyslogNgBufferDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSyslogNgBufferDiskOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSyslogNgBufferMemory {
    /**
    * Maximum events for the memory buffer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_events ObservabilityPipeline#max_events}
    */
    readonly maxEvents?: number;
    /**
    * Maximum size of the memory buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationSyslogNgBufferMemoryToTerraform(struct?: ObservabilityPipelineConfigDestinationSyslogNgBufferMemory | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSyslogNgBufferMemoryToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSyslogNgBufferMemory | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSyslogNgBufferMemoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSyslogNgBufferMemory | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSyslogNgBufferMemory | cdktn.IResolvable | undefined);
    private _maxEvents?;
    get maxEvents(): number;
    set maxEvents(value: number);
    resetMaxEvents(): void;
    get maxEventsInput(): number | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSyslogNgBufferMemoryList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSyslogNgBufferMemory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSyslogNgBufferMemoryOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSyslogNgBuffer {
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#disk ObservabilityPipeline#disk}
    */
    readonly disk?: ObservabilityPipelineConfigDestinationSyslogNgBufferDisk[] | cdktn.IResolvable;
    /**
    * memory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#memory ObservabilityPipeline#memory}
    */
    readonly memory?: ObservabilityPipelineConfigDestinationSyslogNgBufferMemory[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationSyslogNgBufferToTerraform(struct?: ObservabilityPipelineConfigDestinationSyslogNgBuffer | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSyslogNgBufferToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSyslogNgBuffer | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSyslogNgBufferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSyslogNgBuffer | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSyslogNgBuffer | cdktn.IResolvable | undefined);
    private _disk;
    get disk(): ObservabilityPipelineConfigDestinationSyslogNgBufferDiskList;
    putDisk(value: ObservabilityPipelineConfigDestinationSyslogNgBufferDisk[] | cdktn.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSyslogNgBufferDisk[] | undefined;
    private _memory;
    get memory(): ObservabilityPipelineConfigDestinationSyslogNgBufferMemoryList;
    putMemory(value: ObservabilityPipelineConfigDestinationSyslogNgBufferMemory[] | cdktn.IResolvable): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSyslogNgBufferMemory[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSyslogNgBufferList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSyslogNgBuffer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSyslogNgBufferOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSyslogNgTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigDestinationSyslogNgTlsToTerraform(struct?: ObservabilityPipelineConfigDestinationSyslogNgTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSyslogNgTlsToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSyslogNgTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSyslogNgTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSyslogNgTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSyslogNgTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSyslogNgTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSyslogNgTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSyslogNgTlsOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSyslogNg {
    /**
    * Name of the environment variable or secret that holds the syslog-ng endpoint URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#endpoint_url_key ObservabilityPipeline#endpoint_url_key}
    */
    readonly endpointUrlKey?: string;
    /**
    * Optional socket keepalive duration in milliseconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#keepalive ObservabilityPipeline#keepalive}
    */
    readonly keepalive?: number;
    /**
    * buffer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#buffer ObservabilityPipeline#buffer}
    */
    readonly buffer?: ObservabilityPipelineConfigDestinationSyslogNgBuffer[] | cdktn.IResolvable;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigDestinationSyslogNgTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationSyslogNgToTerraform(struct?: ObservabilityPipelineConfigDestinationSyslogNg | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSyslogNgToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSyslogNg | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSyslogNgOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSyslogNg | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSyslogNg | cdktn.IResolvable | undefined);
    private _endpointUrlKey?;
    get endpointUrlKey(): string;
    set endpointUrlKey(value: string);
    resetEndpointUrlKey(): void;
    get endpointUrlKeyInput(): string | undefined;
    private _keepalive?;
    get keepalive(): number;
    set keepalive(value: number);
    resetKeepalive(): void;
    get keepaliveInput(): number | undefined;
    private _buffer;
    get buffer(): ObservabilityPipelineConfigDestinationSyslogNgBufferList;
    putBuffer(value: ObservabilityPipelineConfigDestinationSyslogNgBuffer[] | cdktn.IResolvable): void;
    resetBuffer(): void;
    get bufferInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSyslogNgBuffer[] | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigDestinationSyslogNgTlsList;
    putTls(value: ObservabilityPipelineConfigDestinationSyslogNgTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSyslogNgTls[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSyslogNgList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSyslogNg[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSyslogNgOutputReference;
}
export interface ObservabilityPipelineConfigDestination {
    /**
    * The unique identifier for this destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#id ObservabilityPipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * A list of component IDs whose output is used as the `input` for this component.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#inputs ObservabilityPipeline#inputs}
    */
    readonly inputs: string[];
    /**
    * amazon_opensearch block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#amazon_opensearch ObservabilityPipeline#amazon_opensearch}
    */
    readonly amazonOpensearch?: ObservabilityPipelineConfigDestinationAmazonOpensearch[] | cdktn.IResolvable;
    /**
    * amazon_s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#amazon_s3 ObservabilityPipeline#amazon_s3}
    */
    readonly amazonS3?: ObservabilityPipelineConfigDestinationAmazonS3[] | cdktn.IResolvable;
    /**
    * amazon_security_lake block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#amazon_security_lake ObservabilityPipeline#amazon_security_lake}
    */
    readonly amazonSecurityLake?: ObservabilityPipelineConfigDestinationAmazonSecurityLake[] | cdktn.IResolvable;
    /**
    * azure_storage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#azure_storage ObservabilityPipeline#azure_storage}
    */
    readonly azureStorage?: ObservabilityPipelineConfigDestinationAzureStorage[] | cdktn.IResolvable;
    /**
    * cloud_prem block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#cloud_prem ObservabilityPipeline#cloud_prem}
    */
    readonly cloudPrem?: ObservabilityPipelineConfigDestinationCloudPrem[] | cdktn.IResolvable;
    /**
    * crowdstrike_next_gen_siem block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crowdstrike_next_gen_siem ObservabilityPipeline#crowdstrike_next_gen_siem}
    */
    readonly crowdstrikeNextGenSiem?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiem[] | cdktn.IResolvable;
    /**
    * datadog_logs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#datadog_logs ObservabilityPipeline#datadog_logs}
    */
    readonly datadogLogs?: ObservabilityPipelineConfigDestinationDatadogLogs[] | cdktn.IResolvable;
    /**
    * datadog_metrics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#datadog_metrics ObservabilityPipeline#datadog_metrics}
    */
    readonly datadogMetrics?: ObservabilityPipelineConfigDestinationDatadogMetrics[] | cdktn.IResolvable;
    /**
    * elasticsearch block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#elasticsearch ObservabilityPipeline#elasticsearch}
    */
    readonly elasticsearch?: ObservabilityPipelineConfigDestinationElasticsearch[] | cdktn.IResolvable;
    /**
    * google_cloud_storage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#google_cloud_storage ObservabilityPipeline#google_cloud_storage}
    */
    readonly googleCloudStorage?: ObservabilityPipelineConfigDestinationGoogleCloudStorage[] | cdktn.IResolvable;
    /**
    * google_pubsub block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#google_pubsub ObservabilityPipeline#google_pubsub}
    */
    readonly googlePubsub?: ObservabilityPipelineConfigDestinationGooglePubsub[] | cdktn.IResolvable;
    /**
    * google_secops block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#google_secops ObservabilityPipeline#google_secops}
    */
    readonly googleSecops?: ObservabilityPipelineConfigDestinationGoogleSecops[] | cdktn.IResolvable;
    /**
    * http_client block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#http_client ObservabilityPipeline#http_client}
    */
    readonly httpClient?: ObservabilityPipelineConfigDestinationHttpClient[] | cdktn.IResolvable;
    /**
    * kafka block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#kafka ObservabilityPipeline#kafka}
    */
    readonly kafka?: ObservabilityPipelineConfigDestinationKafka[] | cdktn.IResolvable;
    /**
    * microsoft_sentinel block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#microsoft_sentinel ObservabilityPipeline#microsoft_sentinel}
    */
    readonly microsoftSentinel?: ObservabilityPipelineConfigDestinationMicrosoftSentinel[] | cdktn.IResolvable;
    /**
    * new_relic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#new_relic ObservabilityPipeline#new_relic}
    */
    readonly newRelic?: ObservabilityPipelineConfigDestinationNewRelic[] | cdktn.IResolvable;
    /**
    * opensearch block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#opensearch ObservabilityPipeline#opensearch}
    */
    readonly opensearch?: ObservabilityPipelineConfigDestinationOpensearch[] | cdktn.IResolvable;
    /**
    * rsyslog block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#rsyslog ObservabilityPipeline#rsyslog}
    */
    readonly rsyslog?: ObservabilityPipelineConfigDestinationRsyslog[] | cdktn.IResolvable;
    /**
    * sentinel_one block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#sentinel_one ObservabilityPipeline#sentinel_one}
    */
    readonly sentinelOne?: ObservabilityPipelineConfigDestinationSentinelOne[] | cdktn.IResolvable;
    /**
    * socket block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#socket ObservabilityPipeline#socket}
    */
    readonly socket?: ObservabilityPipelineConfigDestinationSocket[] | cdktn.IResolvable;
    /**
    * splunk_hec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#splunk_hec ObservabilityPipeline#splunk_hec}
    */
    readonly splunkHec?: ObservabilityPipelineConfigDestinationSplunkHec[] | cdktn.IResolvable;
    /**
    * sumo_logic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#sumo_logic ObservabilityPipeline#sumo_logic}
    */
    readonly sumoLogic?: ObservabilityPipelineConfigDestinationSumoLogic[] | cdktn.IResolvable;
    /**
    * syslog_ng block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#syslog_ng ObservabilityPipeline#syslog_ng}
    */
    readonly syslogNg?: ObservabilityPipelineConfigDestinationSyslogNg[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationToTerraform(struct?: ObservabilityPipelineConfigDestination | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationToHclTerraform(struct?: ObservabilityPipelineConfigDestination | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestination | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestination | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _inputs?;
    get inputs(): string[];
    set inputs(value: string[]);
    get inputsInput(): string[] | undefined;
    private _amazonOpensearch;
    get amazonOpensearch(): ObservabilityPipelineConfigDestinationAmazonOpensearchList;
    putAmazonOpensearch(value: ObservabilityPipelineConfigDestinationAmazonOpensearch[] | cdktn.IResolvable): void;
    resetAmazonOpensearch(): void;
    get amazonOpensearchInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationAmazonOpensearch[] | undefined;
    private _amazonS3;
    get amazonS3(): ObservabilityPipelineConfigDestinationAmazonS3List;
    putAmazonS3(value: ObservabilityPipelineConfigDestinationAmazonS3[] | cdktn.IResolvable): void;
    resetAmazonS3(): void;
    get amazonS3Input(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationAmazonS3[] | undefined;
    private _amazonSecurityLake;
    get amazonSecurityLake(): ObservabilityPipelineConfigDestinationAmazonSecurityLakeList;
    putAmazonSecurityLake(value: ObservabilityPipelineConfigDestinationAmazonSecurityLake[] | cdktn.IResolvable): void;
    resetAmazonSecurityLake(): void;
    get amazonSecurityLakeInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationAmazonSecurityLake[] | undefined;
    private _azureStorage;
    get azureStorage(): ObservabilityPipelineConfigDestinationAzureStorageList;
    putAzureStorage(value: ObservabilityPipelineConfigDestinationAzureStorage[] | cdktn.IResolvable): void;
    resetAzureStorage(): void;
    get azureStorageInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationAzureStorage[] | undefined;
    private _cloudPrem;
    get cloudPrem(): ObservabilityPipelineConfigDestinationCloudPremList;
    putCloudPrem(value: ObservabilityPipelineConfigDestinationCloudPrem[] | cdktn.IResolvable): void;
    resetCloudPrem(): void;
    get cloudPremInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationCloudPrem[] | undefined;
    private _crowdstrikeNextGenSiem;
    get crowdstrikeNextGenSiem(): ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemList;
    putCrowdstrikeNextGenSiem(value: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiem[] | cdktn.IResolvable): void;
    resetCrowdstrikeNextGenSiem(): void;
    get crowdstrikeNextGenSiemInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiem[] | undefined;
    private _datadogLogs;
    get datadogLogs(): ObservabilityPipelineConfigDestinationDatadogLogsList;
    putDatadogLogs(value: ObservabilityPipelineConfigDestinationDatadogLogs[] | cdktn.IResolvable): void;
    resetDatadogLogs(): void;
    get datadogLogsInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationDatadogLogs[] | undefined;
    private _datadogMetrics;
    get datadogMetrics(): ObservabilityPipelineConfigDestinationDatadogMetricsList;
    putDatadogMetrics(value: ObservabilityPipelineConfigDestinationDatadogMetrics[] | cdktn.IResolvable): void;
    resetDatadogMetrics(): void;
    get datadogMetricsInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationDatadogMetrics[] | undefined;
    private _elasticsearch;
    get elasticsearch(): ObservabilityPipelineConfigDestinationElasticsearchList;
    putElasticsearch(value: ObservabilityPipelineConfigDestinationElasticsearch[] | cdktn.IResolvable): void;
    resetElasticsearch(): void;
    get elasticsearchInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationElasticsearch[] | undefined;
    private _googleCloudStorage;
    get googleCloudStorage(): ObservabilityPipelineConfigDestinationGoogleCloudStorageList;
    putGoogleCloudStorage(value: ObservabilityPipelineConfigDestinationGoogleCloudStorage[] | cdktn.IResolvable): void;
    resetGoogleCloudStorage(): void;
    get googleCloudStorageInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationGoogleCloudStorage[] | undefined;
    private _googlePubsub;
    get googlePubsub(): ObservabilityPipelineConfigDestinationGooglePubsubList;
    putGooglePubsub(value: ObservabilityPipelineConfigDestinationGooglePubsub[] | cdktn.IResolvable): void;
    resetGooglePubsub(): void;
    get googlePubsubInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationGooglePubsub[] | undefined;
    private _googleSecops;
    get googleSecops(): ObservabilityPipelineConfigDestinationGoogleSecopsList;
    putGoogleSecops(value: ObservabilityPipelineConfigDestinationGoogleSecops[] | cdktn.IResolvable): void;
    resetGoogleSecops(): void;
    get googleSecopsInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationGoogleSecops[] | undefined;
    private _httpClient;
    get httpClient(): ObservabilityPipelineConfigDestinationHttpClientList;
    putHttpClient(value: ObservabilityPipelineConfigDestinationHttpClient[] | cdktn.IResolvable): void;
    resetHttpClient(): void;
    get httpClientInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationHttpClient[] | undefined;
    private _kafka;
    get kafka(): ObservabilityPipelineConfigDestinationKafkaList;
    putKafka(value: ObservabilityPipelineConfigDestinationKafka[] | cdktn.IResolvable): void;
    resetKafka(): void;
    get kafkaInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationKafka[] | undefined;
    private _microsoftSentinel;
    get microsoftSentinel(): ObservabilityPipelineConfigDestinationMicrosoftSentinelList;
    putMicrosoftSentinel(value: ObservabilityPipelineConfigDestinationMicrosoftSentinel[] | cdktn.IResolvable): void;
    resetMicrosoftSentinel(): void;
    get microsoftSentinelInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationMicrosoftSentinel[] | undefined;
    private _newRelic;
    get newRelic(): ObservabilityPipelineConfigDestinationNewRelicList;
    putNewRelic(value: ObservabilityPipelineConfigDestinationNewRelic[] | cdktn.IResolvable): void;
    resetNewRelic(): void;
    get newRelicInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationNewRelic[] | undefined;
    private _opensearch;
    get opensearch(): ObservabilityPipelineConfigDestinationOpensearchList;
    putOpensearch(value: ObservabilityPipelineConfigDestinationOpensearch[] | cdktn.IResolvable): void;
    resetOpensearch(): void;
    get opensearchInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationOpensearch[] | undefined;
    private _rsyslog;
    get rsyslog(): ObservabilityPipelineConfigDestinationRsyslogList;
    putRsyslog(value: ObservabilityPipelineConfigDestinationRsyslog[] | cdktn.IResolvable): void;
    resetRsyslog(): void;
    get rsyslogInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationRsyslog[] | undefined;
    private _sentinelOne;
    get sentinelOne(): ObservabilityPipelineConfigDestinationSentinelOneList;
    putSentinelOne(value: ObservabilityPipelineConfigDestinationSentinelOne[] | cdktn.IResolvable): void;
    resetSentinelOne(): void;
    get sentinelOneInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSentinelOne[] | undefined;
    private _socket;
    get socket(): ObservabilityPipelineConfigDestinationSocketList;
    putSocket(value: ObservabilityPipelineConfigDestinationSocket[] | cdktn.IResolvable): void;
    resetSocket(): void;
    get socketInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSocket[] | undefined;
    private _splunkHec;
    get splunkHec(): ObservabilityPipelineConfigDestinationSplunkHecList;
    putSplunkHec(value: ObservabilityPipelineConfigDestinationSplunkHec[] | cdktn.IResolvable): void;
    resetSplunkHec(): void;
    get splunkHecInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSplunkHec[] | undefined;
    private _sumoLogic;
    get sumoLogic(): ObservabilityPipelineConfigDestinationSumoLogicList;
    putSumoLogic(value: ObservabilityPipelineConfigDestinationSumoLogic[] | cdktn.IResolvable): void;
    resetSumoLogic(): void;
    get sumoLogicInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSumoLogic[] | undefined;
    private _syslogNg;
    get syslogNg(): ObservabilityPipelineConfigDestinationSyslogNgList;
    putSyslogNg(value: ObservabilityPipelineConfigDestinationSyslogNg[] | cdktn.IResolvable): void;
    resetSyslogNg(): void;
    get syslogNgInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSyslogNg[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestination[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVarsVariable {
    /**
    * The target field in the log event.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#field ObservabilityPipeline#field}
    */
    readonly field: string;
    /**
    * The name of the environment variable to read.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#name ObservabilityPipeline#name}
    */
    readonly name: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorAddEnvVarsVariableToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVarsVariable | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorAddEnvVarsVariableToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVarsVariable | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVarsVariableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVarsVariable | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVarsVariable | cdktn.IResolvable | undefined);
    private _field?;
    get field(): string;
    set field(value: string);
    get fieldInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVarsVariableList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVarsVariable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVarsVariableOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVars {
    /**
    * variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#variable ObservabilityPipeline#variable}
    */
    readonly variable?: ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVarsVariable[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorAddEnvVarsToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVars | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorAddEnvVarsToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVars | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVarsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVars | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVars | cdktn.IResolvable | undefined);
    private _variable;
    get variable(): ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVarsVariableList;
    putVariable(value: ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVarsVariable[] | cdktn.IResolvable): void;
    resetVariable(): void;
    get variableInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVarsVariable[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVarsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVars[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVarsOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorAddFieldsField {
    /**
    * The field name to add.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#name ObservabilityPipeline#name}
    */
    readonly name: string;
    /**
    * The value to assign to the field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#value ObservabilityPipeline#value}
    */
    readonly value: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorAddFieldsFieldToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorAddFieldsField | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorAddFieldsFieldToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorAddFieldsField | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorAddFieldsFieldOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorAddFieldsField | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorAddFieldsField | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorAddFieldsFieldList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorAddFieldsField[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorAddFieldsFieldOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorAddFields {
    /**
    * field block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#field ObservabilityPipeline#field}
    */
    readonly field?: ObservabilityPipelineConfigProcessorGroupProcessorAddFieldsField[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorAddFieldsToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorAddFields | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorAddFieldsToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorAddFields | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorAddFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorAddFields | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorAddFields | cdktn.IResolvable | undefined);
    private _field;
    get field(): ObservabilityPipelineConfigProcessorGroupProcessorAddFieldsFieldList;
    putField(value: ObservabilityPipelineConfigProcessorGroupProcessorAddFieldsField[] | cdktn.IResolvable): void;
    resetField(): void;
    get fieldInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorAddFieldsField[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorAddFieldsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorAddFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorAddFieldsOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorAddHostname {
}
export declare function observabilityPipelineConfigProcessorGroupProcessorAddHostnameToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorAddHostname | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorAddHostnameToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorAddHostname | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorAddHostnameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorAddHostname | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorAddHostname | cdktn.IResolvable | undefined);
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorAddHostnameList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorAddHostname[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorAddHostnameOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessorRemap {
    /**
    * Whether to drop events that cause errors during transformation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#drop_on_error ObservabilityPipeline#drop_on_error}
    */
    readonly dropOnError: boolean | cdktn.IResolvable;
    /**
    * Whether this remap rule is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#enabled ObservabilityPipeline#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * A Datadog search query used to filter events for this specific remap rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#include ObservabilityPipeline#include}
    */
    readonly include: string;
    /**
    * A descriptive name for this remap rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#name ObservabilityPipeline#name}
    */
    readonly name: string;
    /**
    * The VRL script source code that defines the transformation logic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#source ObservabilityPipeline#source}
    */
    readonly source: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorCustomProcessorRemapToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessorRemap | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorCustomProcessorRemapToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessorRemap | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessorRemapOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessorRemap | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessorRemap | cdktn.IResolvable | undefined);
    private _dropOnError?;
    get dropOnError(): boolean | cdktn.IResolvable;
    set dropOnError(value: boolean | cdktn.IResolvable);
    get dropOnErrorInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _include?;
    get include(): string;
    set include(value: string);
    get includeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessorRemapList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessorRemap[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessorRemapOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessor {
    /**
    * remap block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#remap ObservabilityPipeline#remap}
    */
    readonly remap?: ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessorRemap[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorCustomProcessorToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessor | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorCustomProcessorToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessor | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessor | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessor | cdktn.IResolvable | undefined);
    private _remap;
    get remap(): ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessorRemapList;
    putRemap(value: ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessorRemap[] | cdktn.IResolvable): void;
    resetRemap(): void;
    get remapInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessorRemap[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessorList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessor[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessorOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorDatadogTags {
    /**
    *  Valid values are `include`, `exclude`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#action ObservabilityPipeline#action}
    */
    readonly action: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#keys ObservabilityPipeline#keys}
    */
    readonly keys: string[];
    /**
    *  Valid values are `filter`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#mode ObservabilityPipeline#mode}
    */
    readonly mode: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorDatadogTagsToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorDatadogTags | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorDatadogTagsToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorDatadogTags | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorDatadogTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorDatadogTags | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorDatadogTags | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _keys?;
    get keys(): string[];
    set keys(value: string[]);
    get keysInput(): string[] | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorDatadogTagsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorDatadogTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorDatadogTagsOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorDedupe {
    /**
    * A list of log field paths to check for duplicates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#fields ObservabilityPipeline#fields}
    */
    readonly fields: string[];
    /**
    * The deduplication mode to apply to the fields.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#mode ObservabilityPipeline#mode}
    */
    readonly mode: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorDedupeToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorDedupe | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorDedupeToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorDedupe | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorDedupeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorDedupe | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorDedupe | cdktn.IResolvable | undefined);
    private _fields?;
    get fields(): string[];
    set fields(value: string[]);
    get fieldsInput(): string[] | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorDedupeList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorDedupe[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorDedupeOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileEncoding {
    /**
    * The `encoding` `delimiter`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#delimiter ObservabilityPipeline#delimiter}
    */
    readonly delimiter: string;
    /**
    * The `encoding` `includes_headers`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#includes_headers ObservabilityPipeline#includes_headers}
    */
    readonly includesHeaders?: boolean | cdktn.IResolvable;
    /**
    * File encoding format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#type ObservabilityPipeline#type}
    */
    readonly type: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileEncodingToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileEncoding | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileEncodingToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileEncoding | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileEncodingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileEncoding | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileEncoding | cdktn.IResolvable | undefined);
    private _delimiter?;
    get delimiter(): string;
    set delimiter(value: string);
    get delimiterInput(): string | undefined;
    private _includesHeaders?;
    get includesHeaders(): boolean | cdktn.IResolvable;
    set includesHeaders(value: boolean | cdktn.IResolvable);
    resetIncludesHeaders(): void;
    get includesHeadersInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileEncodingList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileEncoding[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileEncodingOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileKey {
    /**
    * The `items` `column`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#column ObservabilityPipeline#column}
    */
    readonly column?: string;
    /**
    * The comparison method (e.g. equals).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#comparison ObservabilityPipeline#comparison}
    */
    readonly comparison?: string;
    /**
    * The `items` `field`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#field ObservabilityPipeline#field}
    */
    readonly field?: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileKeyToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileKey | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileKeyToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileKey | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileKey | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileKey | cdktn.IResolvable | undefined);
    private _column?;
    get column(): string;
    set column(value: string);
    resetColumn(): void;
    get columnInput(): string | undefined;
    private _comparison?;
    get comparison(): string;
    set comparison(value: string);
    resetComparison(): void;
    get comparisonInput(): string | undefined;
    private _field?;
    get field(): string;
    set field(value: string);
    resetField(): void;
    get fieldInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileKeyList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileKey[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileKeyOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFile {
    /**
    * Path to the CSV file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#path ObservabilityPipeline#path}
    */
    readonly path?: string;
    /**
    * encoding block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#encoding ObservabilityPipeline#encoding}
    */
    readonly encoding?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileEncoding[] | cdktn.IResolvable;
    /**
    * key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key ObservabilityPipeline#key}
    */
    readonly key?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileKey[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFile | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFile | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFile | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFile | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _encoding;
    get encoding(): ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileEncodingList;
    putEncoding(value: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileEncoding[] | cdktn.IResolvable): void;
    resetEncoding(): void;
    get encodingInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileEncoding[] | undefined;
    private _key;
    get key(): ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileKeyList;
    putKey(value: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileKey[] | cdktn.IResolvable): void;
    resetKey(): void;
    get keyInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileKey[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFile[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableGeoip {
    /**
    * Path to the IP field in the log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_field ObservabilityPipeline#key_field}
    */
    readonly keyField?: string;
    /**
    * Locale used to resolve geographical names.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#locale ObservabilityPipeline#locale}
    */
    readonly locale?: string;
    /**
    * Path to the GeoIP database file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#path ObservabilityPipeline#path}
    */
    readonly path?: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorEnrichmentTableGeoipToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableGeoip | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorEnrichmentTableGeoipToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableGeoip | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableGeoipOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableGeoip | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableGeoip | cdktn.IResolvable | undefined);
    private _keyField?;
    get keyField(): string;
    set keyField(value: string);
    resetKeyField(): void;
    get keyFieldInput(): string | undefined;
    private _locale?;
    get locale(): string;
    set locale(value: string);
    resetLocale(): void;
    get localeInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableGeoipList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableGeoip[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableGeoipOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableReferenceTable {
    /**
    * Name of the environment variable or secret that holds the Datadog application key for the reference table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#app_key_key ObservabilityPipeline#app_key_key}
    */
    readonly appKeyKey?: string;
    /**
    * List of column names to include from the reference table. If not provided, all columns are included.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#columns ObservabilityPipeline#columns}
    */
    readonly columns?: string[];
    /**
    * Path to the field in the log event to match against the reference table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_field ObservabilityPipeline#key_field}
    */
    readonly keyField: string;
    /**
    * The unique identifier of the reference table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#table_id ObservabilityPipeline#table_id}
    */
    readonly tableId: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorEnrichmentTableReferenceTableToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableReferenceTable | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorEnrichmentTableReferenceTableToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableReferenceTable | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableReferenceTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableReferenceTable | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableReferenceTable | cdktn.IResolvable | undefined);
    private _appKeyKey?;
    get appKeyKey(): string;
    set appKeyKey(value: string);
    resetAppKeyKey(): void;
    get appKeyKeyInput(): string | undefined;
    private _columns?;
    get columns(): string[];
    set columns(value: string[]);
    resetColumns(): void;
    get columnsInput(): string[] | undefined;
    private _keyField?;
    get keyField(): string;
    set keyField(value: string);
    get keyFieldInput(): string | undefined;
    private _tableId?;
    get tableId(): string;
    set tableId(value: string);
    get tableIdInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableReferenceTableList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableReferenceTable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableReferenceTableOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTable {
    /**
    * Path where enrichment results should be stored in the log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#target ObservabilityPipeline#target}
    */
    readonly target: string;
    /**
    * file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#file ObservabilityPipeline#file}
    */
    readonly file?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFile[] | cdktn.IResolvable;
    /**
    * geoip block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#geoip ObservabilityPipeline#geoip}
    */
    readonly geoip?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableGeoip[] | cdktn.IResolvable;
    /**
    * reference_table block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#reference_table ObservabilityPipeline#reference_table}
    */
    readonly referenceTable?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableReferenceTable[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorEnrichmentTableToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTable | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorEnrichmentTableToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTable | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTable | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTable | cdktn.IResolvable | undefined);
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _file;
    get file(): ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFileList;
    putFile(value: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFile[] | cdktn.IResolvable): void;
    resetFile(): void;
    get fileInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableFile[] | undefined;
    private _geoip;
    get geoip(): ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableGeoipList;
    putGeoip(value: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableGeoip[] | cdktn.IResolvable): void;
    resetGeoip(): void;
    get geoipInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableGeoip[] | undefined;
    private _referenceTable;
    get referenceTable(): ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableReferenceTableList;
    putReferenceTable(value: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableReferenceTable[] | cdktn.IResolvable): void;
    resetReferenceTable(): void;
    get referenceTableInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableReferenceTable[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorFilter {
}
export declare function observabilityPipelineConfigProcessorGroupProcessorFilterToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorFilter | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorFilterToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorFilter | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorFilter | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorFilter | cdktn.IResolvable | undefined);
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorFilterList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorFilterOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetricValue {
    /**
    * Name of the log field containing the numeric value to increment the metric by (used only for `increment_by_field`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#field ObservabilityPipeline#field}
    */
    readonly field?: string;
    /**
    * Metric value strategy: `increment_by_one` or `increment_by_field`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#strategy ObservabilityPipeline#strategy}
    */
    readonly strategy: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetricValueToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetricValue | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetricValueToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetricValue | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetricValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetricValue | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetricValue | cdktn.IResolvable | undefined);
    private _field?;
    get field(): string;
    set field(value: string);
    resetField(): void;
    get fieldInput(): string | undefined;
    private _strategy?;
    get strategy(): string;
    set strategy(value: string);
    get strategyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetricValueList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetricValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetricValueOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetric {
    /**
    * Optional fields used to group the metric series.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#group_by ObservabilityPipeline#group_by}
    */
    readonly groupBy?: string[];
    /**
    * Datadog filter query to match logs for metric generation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#include ObservabilityPipeline#include}
    */
    readonly include: string;
    /**
    * Type of metric to create.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#metric_type ObservabilityPipeline#metric_type}
    */
    readonly metricType: string;
    /**
    * Name of the custom metric to be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#name ObservabilityPipeline#name}
    */
    readonly name: string;
    /**
    * value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#value ObservabilityPipeline#value}
    */
    readonly value?: ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetricValue[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetricToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetric | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetricToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetric | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetric | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetric | cdktn.IResolvable | undefined);
    private _groupBy?;
    get groupBy(): string[];
    set groupBy(value: string[]);
    resetGroupBy(): void;
    get groupByInput(): string[] | undefined;
    private _include?;
    get include(): string;
    set include(value: string);
    get includeInput(): string | undefined;
    private _metricType?;
    get metricType(): string;
    set metricType(value: string);
    get metricTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value;
    get value(): ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetricValueList;
    putValue(value: ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetricValue[] | cdktn.IResolvable): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetricValue[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetricList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetric[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetricOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetrics {
    /**
    * metric block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#metric ObservabilityPipeline#metric}
    */
    readonly metric?: ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetric[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetrics | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetrics | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetrics | cdktn.IResolvable | undefined);
    private _metric;
    get metric(): ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetricList;
    putMetric(value: ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetric[] | cdktn.IResolvable): void;
    resetMetric(): void;
    get metricInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsMetric[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorMetricTagsRule {
    /**
    * The action to take on tags with matching keys. Valid values are `include`, `exclude`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#action ObservabilityPipeline#action}
    */
    readonly action: string;
    /**
    * A Datadog search query used to determine which metrics this rule targets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#include ObservabilityPipeline#include}
    */
    readonly include: string;
    /**
    * A list of tag keys to include or exclude.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#keys ObservabilityPipeline#keys}
    */
    readonly keys: string[];
    /**
    * The processing mode for tag filtering. Valid values are `filter`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#mode ObservabilityPipeline#mode}
    */
    readonly mode: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorMetricTagsRuleToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorMetricTagsRule | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorMetricTagsRuleToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorMetricTagsRule | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorMetricTagsRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorMetricTagsRule | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorMetricTagsRule | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _include?;
    get include(): string;
    set include(value: string);
    get includeInput(): string | undefined;
    private _keys?;
    get keys(): string[];
    set keys(value: string[]);
    get keysInput(): string[] | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorMetricTagsRuleList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorMetricTagsRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorMetricTagsRuleOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorMetricTags {
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#rule ObservabilityPipeline#rule}
    */
    readonly rule?: ObservabilityPipelineConfigProcessorGroupProcessorMetricTagsRule[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorMetricTagsToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorMetricTags | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorMetricTagsToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorMetricTags | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorMetricTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorMetricTags | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorMetricTags | cdktn.IResolvable | undefined);
    private _rule;
    get rule(): ObservabilityPipelineConfigProcessorGroupProcessorMetricTagsRuleList;
    putRule(value: ObservabilityPipelineConfigProcessorGroupProcessorMetricTagsRule[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorMetricTagsRule[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorMetricTagsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorMetricTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorMetricTagsOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookupTable {
    /**
    * The substring to match in the source value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#contains ObservabilityPipeline#contains}
    */
    readonly contains?: string;
    /**
    * The exact value to match in the source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#equals ObservabilityPipeline#equals}
    */
    readonly equalTo?: string;
    /**
    * The source field to match against.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#equals_source ObservabilityPipeline#equals_source}
    */
    readonly equalsSource?: string;
    /**
    * A regex pattern to match in the source value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#matches ObservabilityPipeline#matches}
    */
    readonly matches?: string;
    /**
    * A regex pattern that must not match the source value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#not_matches ObservabilityPipeline#not_matches}
    */
    readonly notMatches?: string;
    /**
    * The value to use when a match is found.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#value ObservabilityPipeline#value}
    */
    readonly value?: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookupTableToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookupTable | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookupTableToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookupTable | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookupTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookupTable | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookupTable | cdktn.IResolvable | undefined);
    private _contains?;
    get contains(): string;
    set contains(value: string);
    resetContains(): void;
    get containsInput(): string | undefined;
    private _equals?;
    get equalTo(): string;
    set equalTo(value: string);
    resetEqualTo(): void;
    get equalToInput(): string | undefined;
    private _equalsSource?;
    get equalsSource(): string;
    set equalsSource(value: string);
    resetEqualsSource(): void;
    get equalsSourceInput(): string | undefined;
    private _matches?;
    get matches(): string;
    set matches(value: string);
    resetMatches(): void;
    get matchesInput(): string | undefined;
    private _notMatches?;
    get notMatches(): string;
    set notMatches(value: string);
    resetNotMatches(): void;
    get notMatchesInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookupTableList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookupTable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookupTableOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookup {
    /**
    * The default value to use if no lookup match is found.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#default ObservabilityPipeline#default}
    */
    readonly default?: string;
    /**
    * table block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#table ObservabilityPipeline#table}
    */
    readonly table?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookupTable[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookupToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookup | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookupToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookup | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookup | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookup | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _table;
    get table(): ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookupTableList;
    putTable(value: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookupTable[] | cdktn.IResolvable): void;
    resetTable(): void;
    get tableInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookupTable[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookupList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookup[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookupOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMapping {
    /**
    * The default value to use if the source field is missing or empty.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#default ObservabilityPipeline#default}
    */
    readonly default?: string;
    /**
    * The destination OCSF field path.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#dest ObservabilityPipeline#dest}
    */
    readonly dest: string;
    /**
    * The source field path from the log event.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#source ObservabilityPipeline#source}
    */
    readonly source?: string;
    /**
    * Multiple source field paths for combined mapping.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#sources ObservabilityPipeline#sources}
    */
    readonly sources?: string[];
    /**
    * A static value to use for the destination field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#value ObservabilityPipeline#value}
    */
    readonly value?: string;
    /**
    * lookup block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#lookup ObservabilityPipeline#lookup}
    */
    readonly lookup?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookup[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMapping | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMapping | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMapping | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMapping | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _dest?;
    get dest(): string;
    set dest(value: string);
    get destInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _sources?;
    get sources(): string[];
    set sources(value: string[]);
    resetSources(): void;
    get sourcesInput(): string[] | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _lookup;
    get lookup(): ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookupList;
    putLookup(value: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookup[] | cdktn.IResolvable): void;
    resetLookup(): void;
    get lookupInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingLookup[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMapping[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMetadata {
    /**
    * The OCSF event class name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#class ObservabilityPipeline#class}
    */
    readonly class: string;
    /**
    * A list of OCSF profiles to apply.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#profiles ObservabilityPipeline#profiles}
    */
    readonly profiles?: string[];
    /**
    * The OCSF schema version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#version ObservabilityPipeline#version}
    */
    readonly version: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMetadataToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMetadata | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMetadataToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMetadata | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMetadata | cdktn.IResolvable | undefined);
    private _class?;
    get class(): string;
    set class(value: string);
    get classInput(): string | undefined;
    private _profiles?;
    get profiles(): string[];
    set profiles(value: string[]);
    resetProfiles(): void;
    get profilesInput(): string[] | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMetadataList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMetadata[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMetadataOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMapping {
    /**
    * The version of the custom mapping configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#version ObservabilityPipeline#version}
    */
    readonly version: number;
    /**
    * mapping block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#mapping ObservabilityPipeline#mapping}
    */
    readonly mapping?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMapping[] | cdktn.IResolvable;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#metadata ObservabilityPipeline#metadata}
    */
    readonly metadata?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMetadata[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMapping | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMapping | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMapping | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMapping | cdktn.IResolvable | undefined);
    private _version?;
    get version(): number;
    set version(value: number);
    get versionInput(): number | undefined;
    private _mapping;
    get mapping(): ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMappingList;
    putMapping(value: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMapping[] | cdktn.IResolvable): void;
    resetMapping(): void;
    get mappingInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMapping[] | undefined;
    private _metadata;
    get metadata(): ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMetadataList;
    putMetadata(value: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMetadata[] | cdktn.IResolvable): void;
    resetMetadata(): void;
    get metadataInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingMetadata[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMapping[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMapping {
    /**
    * Search query for selecting which logs the mapping applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#include ObservabilityPipeline#include}
    */
    readonly include: string;
    /**
    * Predefined library mapping for log transformation. Use this or custom_mapping, not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#library_mapping ObservabilityPipeline#library_mapping}
    */
    readonly libraryMapping?: string;
    /**
    * custom_mapping block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#custom_mapping ObservabilityPipeline#custom_mapping}
    */
    readonly customMapping?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMapping[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMapping | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMapping | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMapping | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMapping | cdktn.IResolvable | undefined);
    private _include?;
    get include(): string;
    set include(value: string);
    get includeInput(): string | undefined;
    private _libraryMapping?;
    get libraryMapping(): string;
    set libraryMapping(value: string);
    resetLibraryMapping(): void;
    get libraryMappingInput(): string | undefined;
    private _customMapping;
    get customMapping(): ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMappingList;
    putCustomMapping(value: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMapping[] | cdktn.IResolvable): void;
    resetCustomMapping(): void;
    get customMappingInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingCustomMapping[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMapping[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapper {
    /**
    * mapping block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#mapping ObservabilityPipeline#mapping}
    */
    readonly mapping?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMapping[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorOcsfMapperToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapper | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorOcsfMapperToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapper | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapper | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapper | cdktn.IResolvable | undefined);
    private _mapping;
    get mapping(): ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMappingList;
    putMapping(value: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMapping[] | cdktn.IResolvable): void;
    resetMapping(): void;
    get mappingInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperMapping[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapper[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleMatchRule {
    /**
    * The name of the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#name ObservabilityPipeline#name}
    */
    readonly name: string;
    /**
    * The definition of the Grok rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#rule ObservabilityPipeline#rule}
    */
    readonly rule: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorParseGrokRuleMatchRuleToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleMatchRule | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorParseGrokRuleMatchRuleToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleMatchRule | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleMatchRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleMatchRule | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleMatchRule | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _rule?;
    get rule(): string;
    set rule(value: string);
    get ruleInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleMatchRuleList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleMatchRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleMatchRuleOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleSupportRule {
    /**
    * The name of the helper Grok rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#name ObservabilityPipeline#name}
    */
    readonly name: string;
    /**
    * The definition of the helper Grok rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#rule ObservabilityPipeline#rule}
    */
    readonly rule: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorParseGrokRuleSupportRuleToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleSupportRule | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorParseGrokRuleSupportRuleToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleSupportRule | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleSupportRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleSupportRule | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleSupportRule | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _rule?;
    get rule(): string;
    set rule(value: string);
    get ruleInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleSupportRuleList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleSupportRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleSupportRuleOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRule {
    /**
    * The name of the field in the log event to apply the Grok rules to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#source ObservabilityPipeline#source}
    */
    readonly source: string;
    /**
    * match_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#match_rule ObservabilityPipeline#match_rule}
    */
    readonly matchRule?: ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleMatchRule[] | cdktn.IResolvable;
    /**
    * support_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#support_rule ObservabilityPipeline#support_rule}
    */
    readonly supportRule?: ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleSupportRule[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorParseGrokRuleToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRule | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorParseGrokRuleToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRule | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRule | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRule | cdktn.IResolvable | undefined);
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _matchRule;
    get matchRule(): ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleMatchRuleList;
    putMatchRule(value: ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleMatchRule[] | cdktn.IResolvable): void;
    resetMatchRule(): void;
    get matchRuleInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleMatchRule[] | undefined;
    private _supportRule;
    get supportRule(): ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleSupportRuleList;
    putSupportRule(value: ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleSupportRule[] | cdktn.IResolvable): void;
    resetSupportRule(): void;
    get supportRuleInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleSupportRule[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorParseGrok {
    /**
    * If set to `true`, disables the default Grok rules provided by Datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#disable_library_rules ObservabilityPipeline#disable_library_rules}
    */
    readonly disableLibraryRules?: boolean | cdktn.IResolvable;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#rule ObservabilityPipeline#rule}
    */
    readonly rule?: ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRule[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorParseGrokToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorParseGrok | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorParseGrokToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorParseGrok | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorParseGrokOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorParseGrok | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorParseGrok | cdktn.IResolvable | undefined);
    private _disableLibraryRules?;
    get disableLibraryRules(): boolean | cdktn.IResolvable;
    set disableLibraryRules(value: boolean | cdktn.IResolvable);
    resetDisableLibraryRules(): void;
    get disableLibraryRulesInput(): boolean | cdktn.IResolvable | undefined;
    private _rule;
    get rule(): ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRuleList;
    putRule(value: ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRule[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorParseGrokRule[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorParseGrokList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorParseGrok[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorParseGrokOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorParseJson {
    /**
    * The field to parse.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#field ObservabilityPipeline#field}
    */
    readonly field: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorParseJsonToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorParseJson | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorParseJsonToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorParseJson | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorParseJsonOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorParseJson | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorParseJson | cdktn.IResolvable | undefined);
    private _field?;
    get field(): string;
    set field(value: string);
    get fieldInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorParseJsonList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorParseJson[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorParseJsonOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorParseXml {
    /**
    * Whether to always store text inside an object using the text key even when no attributes exist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#always_use_text_key ObservabilityPipeline#always_use_text_key}
    */
    readonly alwaysUseTextKey?: boolean | cdktn.IResolvable;
    /**
    * The prefix to use for XML attributes in the parsed output. If the field is left empty, the original attribute key is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#attr_prefix ObservabilityPipeline#attr_prefix}
    */
    readonly attrPrefix?: string;
    /**
    * The path to the log field on which you want to parse XML.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#field ObservabilityPipeline#field}
    */
    readonly field: string;
    /**
    * Whether to include XML attributes in the parsed output.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#include_attr ObservabilityPipeline#include_attr}
    */
    readonly includeAttr?: boolean | cdktn.IResolvable;
    /**
    * Whether to parse boolean values from strings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#parse_bool ObservabilityPipeline#parse_bool}
    */
    readonly parseBool?: boolean | cdktn.IResolvable;
    /**
    * Whether to parse null values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#parse_null ObservabilityPipeline#parse_null}
    */
    readonly parseNull?: boolean | cdktn.IResolvable;
    /**
    * Whether to parse numeric values from strings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#parse_number ObservabilityPipeline#parse_number}
    */
    readonly parseNumber?: boolean | cdktn.IResolvable;
    /**
    * The key name to use for the text node when XML attributes are appended.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#text_key ObservabilityPipeline#text_key}
    */
    readonly textKey?: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorParseXmlToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorParseXml | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorParseXmlToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorParseXml | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorParseXmlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorParseXml | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorParseXml | cdktn.IResolvable | undefined);
    private _alwaysUseTextKey?;
    get alwaysUseTextKey(): boolean | cdktn.IResolvable;
    set alwaysUseTextKey(value: boolean | cdktn.IResolvable);
    resetAlwaysUseTextKey(): void;
    get alwaysUseTextKeyInput(): boolean | cdktn.IResolvable | undefined;
    private _attrPrefix?;
    get attrPrefix(): string;
    set attrPrefix(value: string);
    resetAttrPrefix(): void;
    get attrPrefixInput(): string | undefined;
    private _field?;
    get field(): string;
    set field(value: string);
    get fieldInput(): string | undefined;
    private _includeAttr?;
    get includeAttr(): boolean | cdktn.IResolvable;
    set includeAttr(value: boolean | cdktn.IResolvable);
    resetIncludeAttr(): void;
    get includeAttrInput(): boolean | cdktn.IResolvable | undefined;
    private _parseBool?;
    get parseBool(): boolean | cdktn.IResolvable;
    set parseBool(value: boolean | cdktn.IResolvable);
    resetParseBool(): void;
    get parseBoolInput(): boolean | cdktn.IResolvable | undefined;
    private _parseNull?;
    get parseNull(): boolean | cdktn.IResolvable;
    set parseNull(value: boolean | cdktn.IResolvable);
    resetParseNull(): void;
    get parseNullInput(): boolean | cdktn.IResolvable | undefined;
    private _parseNumber?;
    get parseNumber(): boolean | cdktn.IResolvable;
    set parseNumber(value: boolean | cdktn.IResolvable);
    resetParseNumber(): void;
    get parseNumberInput(): boolean | cdktn.IResolvable | undefined;
    private _textKey?;
    get textKey(): string;
    set textKey(value: string);
    resetTextKey(): void;
    get textKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorParseXmlList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorParseXml[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorParseXmlOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorQuotaLimit {
    /**
    * Whether to enforce by 'bytes' or 'events'. Valid values are `bytes`, `events`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#enforce ObservabilityPipeline#enforce}
    */
    readonly enforce: string;
    /**
    * The daily quota limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#limit ObservabilityPipeline#limit}
    */
    readonly limit: number;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorQuotaLimitToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorQuotaLimit | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorQuotaLimitToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorQuotaLimit | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorQuotaLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorQuotaLimit | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorQuotaLimit | cdktn.IResolvable | undefined);
    private _enforce?;
    get enforce(): string;
    set enforce(value: string);
    get enforceInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    get limitInput(): number | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorQuotaLimitList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorQuotaLimit[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorQuotaLimitOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideField {
    /**
    * The field name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#name ObservabilityPipeline#name}
    */
    readonly name: string;
    /**
    * The field value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#value ObservabilityPipeline#value}
    */
    readonly value: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorQuotaOverrideFieldToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideField | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorQuotaOverrideFieldToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideField | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideFieldOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideField | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideField | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideFieldList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideField[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideFieldOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideLimit {
    /**
    * Whether to enforce by 'bytes' or 'events'. Valid values are `bytes`, `events`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#enforce ObservabilityPipeline#enforce}
    */
    readonly enforce: string;
    /**
    * The daily quota limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#limit ObservabilityPipeline#limit}
    */
    readonly limit: number;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorQuotaOverrideLimitToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideLimit | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorQuotaOverrideLimitToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideLimit | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideLimit | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideLimit | cdktn.IResolvable | undefined);
    private _enforce?;
    get enforce(): string;
    set enforce(value: string);
    get enforceInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    get limitInput(): number | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideLimitList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideLimit[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideLimitOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverride {
    /**
    * field block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#field ObservabilityPipeline#field}
    */
    readonly field?: ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideField[] | cdktn.IResolvable;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#limit ObservabilityPipeline#limit}
    */
    readonly limit?: ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideLimit[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorQuotaOverrideToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverride | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorQuotaOverrideToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverride | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverride | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverride | cdktn.IResolvable | undefined);
    private _field;
    get field(): ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideFieldList;
    putField(value: ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideField[] | cdktn.IResolvable): void;
    resetField(): void;
    get fieldInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideField[] | undefined;
    private _limit;
    get limit(): ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideLimitList;
    putLimit(value: ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideLimit[] | cdktn.IResolvable): void;
    resetLimit(): void;
    get limitInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideLimit[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverride[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorQuota {
    /**
    * Whether to drop events exceeding the limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#drop_events ObservabilityPipeline#drop_events}
    */
    readonly dropEvents?: boolean | cdktn.IResolvable;
    /**
    * Whether to ignore when partition fields are missing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ignore_when_missing_partitions ObservabilityPipeline#ignore_when_missing_partitions}
    */
    readonly ignoreWhenMissingPartitions?: boolean | cdktn.IResolvable;
    /**
    * The name of the quota.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#name ObservabilityPipeline#name}
    */
    readonly name: string;
    /**
    * The action to take when the quota is exceeded: `drop`, `no_action`, or `overflow_routing`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#overflow_action ObservabilityPipeline#overflow_action}
    */
    readonly overflowAction?: string;
    /**
    * List of partition fields.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#partition_fields ObservabilityPipeline#partition_fields}
    */
    readonly partitionFields?: string[];
    /**
    * The action to take when the max number of buckets is exceeded: `drop`, `no_action`, or `overflow_routing`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#too_many_buckets_action ObservabilityPipeline#too_many_buckets_action}
    */
    readonly tooManyBucketsAction?: string;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#limit ObservabilityPipeline#limit}
    */
    readonly limit?: ObservabilityPipelineConfigProcessorGroupProcessorQuotaLimit[] | cdktn.IResolvable;
    /**
    * override block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#override ObservabilityPipeline#override}
    */
    readonly override?: ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverride[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorQuotaToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorQuota | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorQuotaToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorQuota | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorQuotaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorQuota | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorQuota | cdktn.IResolvable | undefined);
    private _dropEvents?;
    get dropEvents(): boolean | cdktn.IResolvable;
    set dropEvents(value: boolean | cdktn.IResolvable);
    resetDropEvents(): void;
    get dropEventsInput(): boolean | cdktn.IResolvable | undefined;
    private _ignoreWhenMissingPartitions?;
    get ignoreWhenMissingPartitions(): boolean | cdktn.IResolvable;
    set ignoreWhenMissingPartitions(value: boolean | cdktn.IResolvable);
    resetIgnoreWhenMissingPartitions(): void;
    get ignoreWhenMissingPartitionsInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _overflowAction?;
    get overflowAction(): string;
    set overflowAction(value: string);
    resetOverflowAction(): void;
    get overflowActionInput(): string | undefined;
    private _partitionFields?;
    get partitionFields(): string[];
    set partitionFields(value: string[]);
    resetPartitionFields(): void;
    get partitionFieldsInput(): string[] | undefined;
    private _tooManyBucketsAction?;
    get tooManyBucketsAction(): string;
    set tooManyBucketsAction(value: string);
    resetTooManyBucketsAction(): void;
    get tooManyBucketsActionInput(): string | undefined;
    private _limit;
    get limit(): ObservabilityPipelineConfigProcessorGroupProcessorQuotaLimitList;
    putLimit(value: ObservabilityPipelineConfigProcessorGroupProcessorQuotaLimit[] | cdktn.IResolvable): void;
    resetLimit(): void;
    get limitInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorQuotaLimit[] | undefined;
    private _override;
    get override(): ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverrideList;
    putOverride(value: ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverride[] | cdktn.IResolvable): void;
    resetOverride(): void;
    get overrideInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorQuotaOverride[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorQuotaList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorQuota[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorQuotaOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorReduceMergeStrategy {
    /**
    * The field path in the log event.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#path ObservabilityPipeline#path}
    */
    readonly path: string;
    /**
    * The merge strategy to apply.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#strategy ObservabilityPipeline#strategy}
    */
    readonly strategy: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorReduceMergeStrategyToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorReduceMergeStrategy | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorReduceMergeStrategyToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorReduceMergeStrategy | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorReduceMergeStrategyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorReduceMergeStrategy | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorReduceMergeStrategy | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _strategy?;
    get strategy(): string;
    set strategy(value: string);
    get strategyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorReduceMergeStrategyList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorReduceMergeStrategy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorReduceMergeStrategyOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorReduce {
    /**
    * A list of fields used to group log events for merging.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#group_by ObservabilityPipeline#group_by}
    */
    readonly groupBy: string[];
    /**
    * merge_strategy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#merge_strategy ObservabilityPipeline#merge_strategy}
    */
    readonly mergeStrategy?: ObservabilityPipelineConfigProcessorGroupProcessorReduceMergeStrategy[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorReduceToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorReduce | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorReduceToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorReduce | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorReduceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorReduce | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorReduce | cdktn.IResolvable | undefined);
    private _groupBy?;
    get groupBy(): string[];
    set groupBy(value: string[]);
    get groupByInput(): string[] | undefined;
    private _mergeStrategy;
    get mergeStrategy(): ObservabilityPipelineConfigProcessorGroupProcessorReduceMergeStrategyList;
    putMergeStrategy(value: ObservabilityPipelineConfigProcessorGroupProcessorReduceMergeStrategy[] | cdktn.IResolvable): void;
    resetMergeStrategy(): void;
    get mergeStrategyInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorReduceMergeStrategy[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorReduceList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorReduce[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorReduceOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorRemoveFields {
    /**
    * List of fields to remove from the events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#fields ObservabilityPipeline#fields}
    */
    readonly fields: string[];
}
export declare function observabilityPipelineConfigProcessorGroupProcessorRemoveFieldsToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorRemoveFields | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorRemoveFieldsToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorRemoveFields | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorRemoveFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorRemoveFields | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorRemoveFields | cdktn.IResolvable | undefined);
    private _fields?;
    get fields(): string[];
    set fields(value: string[]);
    get fieldsInput(): string[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorRemoveFieldsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorRemoveFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorRemoveFieldsOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorRenameFieldsField {
    /**
    * Destination field name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#destination ObservabilityPipeline#destination}
    */
    readonly destination: string;
    /**
    * Whether to keep the original field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#preserve_source ObservabilityPipeline#preserve_source}
    */
    readonly preserveSource: boolean | cdktn.IResolvable;
    /**
    * Source field to rename.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#source ObservabilityPipeline#source}
    */
    readonly source: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorRenameFieldsFieldToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorRenameFieldsField | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorRenameFieldsFieldToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorRenameFieldsField | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorRenameFieldsFieldOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorRenameFieldsField | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorRenameFieldsField | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _preserveSource?;
    get preserveSource(): boolean | cdktn.IResolvable;
    set preserveSource(value: boolean | cdktn.IResolvable);
    get preserveSourceInput(): boolean | cdktn.IResolvable | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorRenameFieldsFieldList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorRenameFieldsField[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorRenameFieldsFieldOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorRenameFields {
    /**
    * field block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#field ObservabilityPipeline#field}
    */
    readonly field?: ObservabilityPipelineConfigProcessorGroupProcessorRenameFieldsField[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorRenameFieldsToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorRenameFields | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorRenameFieldsToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorRenameFields | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorRenameFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorRenameFields | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorRenameFields | cdktn.IResolvable | undefined);
    private _field;
    get field(): ObservabilityPipelineConfigProcessorGroupProcessorRenameFieldsFieldList;
    putField(value: ObservabilityPipelineConfigProcessorGroupProcessorRenameFieldsField[] | cdktn.IResolvable): void;
    resetField(): void;
    get fieldInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorRenameFieldsField[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorRenameFieldsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorRenameFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorRenameFieldsOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorSample {
    /**
    * Optional list of fields to group events by. Each group is sampled independently.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#group_by ObservabilityPipeline#group_by}
    */
    readonly groupBy?: string[];
    /**
    * The percentage of logs to sample.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#percentage ObservabilityPipeline#percentage}
    */
    readonly percentage: number;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorSampleToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSample | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorSampleToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSample | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSampleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorSample | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorSample | cdktn.IResolvable | undefined);
    private _groupBy?;
    get groupBy(): string[];
    set groupBy(value: string[]);
    resetGroupBy(): void;
    get groupByInput(): string[] | undefined;
    private _percentage?;
    get percentage(): number;
    set percentage(value: number);
    get percentageInput(): number | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSampleList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorSample[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorSampleOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleKeywordOptions {
    /**
    * A list of keywords to match near the sensitive pattern.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#keywords ObservabilityPipeline#keywords}
    */
    readonly keywords?: string[];
    /**
    * Maximum number of tokens between a keyword and a sensitive value match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#proximity ObservabilityPipeline#proximity}
    */
    readonly proximity?: number;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleKeywordOptionsToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleKeywordOptions | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleKeywordOptionsToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleKeywordOptions | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleKeywordOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleKeywordOptions | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleKeywordOptions | cdktn.IResolvable | undefined);
    private _keywords?;
    get keywords(): string[];
    set keywords(value: string[]);
    resetKeywords(): void;
    get keywordsInput(): string[] | undefined;
    private _proximity?;
    get proximity(): number;
    set proximity(value: number);
    resetProximity(): void;
    get proximityInput(): number | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleKeywordOptionsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleKeywordOptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleKeywordOptionsOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchHash {
}
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchHashToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchHash | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchHashToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchHash | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchHashOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchHash | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchHash | cdktn.IResolvable | undefined);
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchHashList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchHash[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchHashOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchPartialRedact {
    /**
    * Number of characters to keep.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#characters ObservabilityPipeline#characters}
    */
    readonly characters?: number;
    /**
    * Direction from which to keep characters: `first` or `last`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#direction ObservabilityPipeline#direction}
    */
    readonly direction?: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchPartialRedactToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchPartialRedact | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchPartialRedactToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchPartialRedact | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchPartialRedactOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchPartialRedact | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchPartialRedact | cdktn.IResolvable | undefined);
    private _characters?;
    get characters(): number;
    set characters(value: number);
    resetCharacters(): void;
    get charactersInput(): number | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchPartialRedactList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchPartialRedact[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchPartialRedactOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchRedact {
    /**
    * Replacement string for redacted values (e.g., `***`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#replace ObservabilityPipeline#replace}
    */
    readonly replace?: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchRedactToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchRedact | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchRedactToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchRedact | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchRedactOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchRedact | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchRedact | cdktn.IResolvable | undefined);
    private _replace?;
    get replace(): string;
    set replace(value: string);
    resetReplace(): void;
    get replaceInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchRedactList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchRedact[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchRedactOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatch {
    /**
    * hash block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#hash ObservabilityPipeline#hash}
    */
    readonly hash?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchHash[] | cdktn.IResolvable;
    /**
    * partial_redact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#partial_redact ObservabilityPipeline#partial_redact}
    */
    readonly partialRedact?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchPartialRedact[] | cdktn.IResolvable;
    /**
    * redact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#redact ObservabilityPipeline#redact}
    */
    readonly redact?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchRedact[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatch | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatch | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatch | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatch | cdktn.IResolvable | undefined);
    private _hash;
    get hash(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchHashList;
    putHash(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchHash[] | cdktn.IResolvable): void;
    resetHash(): void;
    get hashInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchHash[] | undefined;
    private _partialRedact;
    get partialRedact(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchPartialRedactList;
    putPartialRedact(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchPartialRedact[] | cdktn.IResolvable): void;
    resetPartialRedact(): void;
    get partialRedactInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchPartialRedact[] | undefined;
    private _redact;
    get redact(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchRedactList;
    putRedact(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchRedact[] | cdktn.IResolvable): void;
    resetRedact(): void;
    get redactInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchRedact[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatch[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternCustom {
    /**
    * Human-readable description providing context about a sensitive data scanner rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#description ObservabilityPipeline#description}
    */
    readonly description?: string;
    /**
    * A regular expression used to detect sensitive values. Must be a valid regex.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#rule ObservabilityPipeline#rule}
    */
    readonly rule?: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternCustomToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternCustom | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternCustomToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternCustom | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternCustom | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternCustom | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _rule?;
    get rule(): string;
    set rule(value: string);
    resetRule(): void;
    get ruleInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternCustomList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternCustom[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternCustomOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternLibrary {
    /**
    * Human-readable description providing context about a sensitive data scanner rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#description ObservabilityPipeline#description}
    */
    readonly description?: string;
    /**
    * Identifier for a predefined pattern from the sensitive data scanner pattern library.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#id ObservabilityPipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Whether to augment the pattern with recommended keywords (optional).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#use_recommended_keywords ObservabilityPipeline#use_recommended_keywords}
    */
    readonly useRecommendedKeywords?: boolean | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternLibraryToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternLibrary | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternLibraryToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternLibrary | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternLibraryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternLibrary | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternLibrary | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _useRecommendedKeywords?;
    get useRecommendedKeywords(): boolean | cdktn.IResolvable;
    set useRecommendedKeywords(value: boolean | cdktn.IResolvable);
    resetUseRecommendedKeywords(): void;
    get useRecommendedKeywordsInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternLibraryList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternLibrary[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternLibraryOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePattern {
    /**
    * custom block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#custom ObservabilityPipeline#custom}
    */
    readonly custom?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternCustom[] | cdktn.IResolvable;
    /**
    * library block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#library ObservabilityPipeline#library}
    */
    readonly library?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternLibrary[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePattern | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePattern | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePattern | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePattern | cdktn.IResolvable | undefined);
    private _custom;
    get custom(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternCustomList;
    putCustom(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternCustom[] | cdktn.IResolvable): void;
    resetCustom(): void;
    get customInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternCustom[] | undefined;
    private _library;
    get library(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternLibraryList;
    putLibrary(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternLibrary[] | cdktn.IResolvable): void;
    resetLibrary(): void;
    get libraryInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternLibrary[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePattern[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeExclude {
    /**
    * The fields to exclude from scanning.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#fields ObservabilityPipeline#fields}
    */
    readonly fields?: string[];
}
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeExcludeToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeExclude | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeExcludeToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeExclude | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeExcludeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeExclude | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeExclude | cdktn.IResolvable | undefined);
    private _fields?;
    get fields(): string[];
    set fields(value: string[]);
    resetFields(): void;
    get fieldsInput(): string[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeExcludeList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeExclude[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeExcludeOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeInclude {
    /**
    * The fields to include in scanning.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#fields ObservabilityPipeline#fields}
    */
    readonly fields?: string[];
}
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeIncludeToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeInclude | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeIncludeToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeInclude | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeIncludeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeInclude | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeInclude | cdktn.IResolvable | undefined);
    private _fields?;
    get fields(): string[];
    set fields(value: string[]);
    resetFields(): void;
    get fieldsInput(): string[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeIncludeList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeInclude[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeIncludeOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScope {
    /**
    * Scan all fields.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#all ObservabilityPipeline#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * exclude block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#exclude ObservabilityPipeline#exclude}
    */
    readonly exclude?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeExclude[] | cdktn.IResolvable;
    /**
    * include block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#include ObservabilityPipeline#include}
    */
    readonly include?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeInclude[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScope | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScope | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScope | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScope | cdktn.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _exclude;
    get exclude(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeExcludeList;
    putExclude(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeExclude[] | cdktn.IResolvable): void;
    resetExclude(): void;
    get excludeInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeExclude[] | undefined;
    private _include;
    get include(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeIncludeList;
    putInclude(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeInclude[] | cdktn.IResolvable): void;
    resetInclude(): void;
    get includeInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeInclude[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScope[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRule {
    /**
    * A name identifying the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#name ObservabilityPipeline#name}
    */
    readonly name: string;
    /**
    * Tags assigned to this rule for filtering and classification.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tags ObservabilityPipeline#tags}
    */
    readonly tags: string[];
    /**
    * keyword_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#keyword_options ObservabilityPipeline#keyword_options}
    */
    readonly keywordOptions?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleKeywordOptions[] | cdktn.IResolvable;
    /**
    * on_match block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#on_match ObservabilityPipeline#on_match}
    */
    readonly onMatch?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatch[] | cdktn.IResolvable;
    /**
    * pattern block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#pattern ObservabilityPipeline#pattern}
    */
    readonly pattern?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePattern[] | cdktn.IResolvable;
    /**
    * scope block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#scope ObservabilityPipeline#scope}
    */
    readonly scope?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScope[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRule | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRule | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRule | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRule | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    get tagsInput(): string[] | undefined;
    private _keywordOptions;
    get keywordOptions(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleKeywordOptionsList;
    putKeywordOptions(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleKeywordOptions[] | cdktn.IResolvable): void;
    resetKeywordOptions(): void;
    get keywordOptionsInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleKeywordOptions[] | undefined;
    private _onMatch;
    get onMatch(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatchList;
    putOnMatch(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatch[] | cdktn.IResolvable): void;
    resetOnMatch(): void;
    get onMatchInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOnMatch[] | undefined;
    private _pattern;
    get pattern(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePatternList;
    putPattern(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePattern[] | cdktn.IResolvable): void;
    resetPattern(): void;
    get patternInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRulePattern[] | undefined;
    private _scope;
    get scope(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScopeList;
    putScope(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScope[] | cdktn.IResolvable): void;
    resetScope(): void;
    get scopeInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleScope[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScanner {
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#rule ObservabilityPipeline#rule}
    */
    readonly rule?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRule[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScanner | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScanner | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScanner | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScanner | cdktn.IResolvable | undefined);
    private _rule;
    get rule(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRuleList;
    putRule(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRule[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerRule[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScanner[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorSplitArrayArray {
    /**
    * The path to the array field to split.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#field ObservabilityPipeline#field}
    */
    readonly field: string;
    /**
    * A Datadog search query used to determine which logs this array split operation targets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#include ObservabilityPipeline#include}
    */
    readonly include: string;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorSplitArrayArrayToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSplitArrayArray | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorSplitArrayArrayToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSplitArrayArray | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSplitArrayArrayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorSplitArrayArray | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorSplitArrayArray | cdktn.IResolvable | undefined);
    private _field?;
    get field(): string;
    set field(value: string);
    get fieldInput(): string | undefined;
    private _include?;
    get include(): string;
    set include(value: string);
    get includeInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSplitArrayArrayList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorSplitArrayArray[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorSplitArrayArrayOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorSplitArray {
    /**
    * array block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#array ObservabilityPipeline#array}
    */
    readonly array?: ObservabilityPipelineConfigProcessorGroupProcessorSplitArrayArray[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorSplitArrayToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSplitArray | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorSplitArrayToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorSplitArray | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSplitArrayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorSplitArray | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorSplitArray | cdktn.IResolvable | undefined);
    private _array;
    get array(): ObservabilityPipelineConfigProcessorGroupProcessorSplitArrayArrayList;
    putArray(value: ObservabilityPipelineConfigProcessorGroupProcessorSplitArrayArray[] | cdktn.IResolvable): void;
    resetArray(): void;
    get arrayInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorSplitArrayArray[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorSplitArrayList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorSplitArray[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorSplitArrayOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessorThrottle {
    /**
    * Optional list of fields used to group events before applying throttling.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#group_by ObservabilityPipeline#group_by}
    */
    readonly groupBy?: string[];
    /**
    * The number of events to allow before throttling is applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#threshold ObservabilityPipeline#threshold}
    */
    readonly threshold: number;
    /**
    * The time window in seconds over which the threshold applies.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#window ObservabilityPipeline#window}
    */
    readonly window: number;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorThrottleToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorThrottle | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorThrottleToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessorThrottle | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorThrottleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessorThrottle | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessorThrottle | cdktn.IResolvable | undefined);
    private _groupBy?;
    get groupBy(): string[];
    set groupBy(value: string[]);
    resetGroupBy(): void;
    get groupByInput(): string[] | undefined;
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    get thresholdInput(): number | undefined;
    private _window?;
    get window(): number;
    set window(value: number);
    get windowInput(): number | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorThrottleList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessorThrottle[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorThrottleOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroupProcessor {
    /**
    * A human-friendly name for this processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#display_name ObservabilityPipeline#display_name}
    */
    readonly displayName?: string;
    /**
    * Whether this processor is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#enabled ObservabilityPipeline#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * The unique identifier for this processor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#id ObservabilityPipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * A Datadog search query used to determine which logs this processor targets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#include ObservabilityPipeline#include}
    */
    readonly include: string;
    /**
    * add_env_vars block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#add_env_vars ObservabilityPipeline#add_env_vars}
    */
    readonly addEnvVars?: ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVars[] | cdktn.IResolvable;
    /**
    * add_fields block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#add_fields ObservabilityPipeline#add_fields}
    */
    readonly addFields?: ObservabilityPipelineConfigProcessorGroupProcessorAddFields[] | cdktn.IResolvable;
    /**
    * add_hostname block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#add_hostname ObservabilityPipeline#add_hostname}
    */
    readonly addHostname?: ObservabilityPipelineConfigProcessorGroupProcessorAddHostname[] | cdktn.IResolvable;
    /**
    * custom_processor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#custom_processor ObservabilityPipeline#custom_processor}
    */
    readonly customProcessor?: ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessor[] | cdktn.IResolvable;
    /**
    * datadog_tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#datadog_tags ObservabilityPipeline#datadog_tags}
    */
    readonly datadogTags?: ObservabilityPipelineConfigProcessorGroupProcessorDatadogTags[] | cdktn.IResolvable;
    /**
    * dedupe block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#dedupe ObservabilityPipeline#dedupe}
    */
    readonly dedupe?: ObservabilityPipelineConfigProcessorGroupProcessorDedupe[] | cdktn.IResolvable;
    /**
    * enrichment_table block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#enrichment_table ObservabilityPipeline#enrichment_table}
    */
    readonly enrichmentTable?: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTable[] | cdktn.IResolvable;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#filter ObservabilityPipeline#filter}
    */
    readonly filter?: ObservabilityPipelineConfigProcessorGroupProcessorFilter[] | cdktn.IResolvable;
    /**
    * generate_datadog_metrics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#generate_datadog_metrics ObservabilityPipeline#generate_datadog_metrics}
    */
    readonly generateDatadogMetrics?: ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetrics[] | cdktn.IResolvable;
    /**
    * metric_tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#metric_tags ObservabilityPipeline#metric_tags}
    */
    readonly metricTags?: ObservabilityPipelineConfigProcessorGroupProcessorMetricTags[] | cdktn.IResolvable;
    /**
    * ocsf_mapper block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ocsf_mapper ObservabilityPipeline#ocsf_mapper}
    */
    readonly ocsfMapper?: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapper[] | cdktn.IResolvable;
    /**
    * parse_grok block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#parse_grok ObservabilityPipeline#parse_grok}
    */
    readonly parseGrok?: ObservabilityPipelineConfigProcessorGroupProcessorParseGrok[] | cdktn.IResolvable;
    /**
    * parse_json block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#parse_json ObservabilityPipeline#parse_json}
    */
    readonly parseJson?: ObservabilityPipelineConfigProcessorGroupProcessorParseJson[] | cdktn.IResolvable;
    /**
    * parse_xml block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#parse_xml ObservabilityPipeline#parse_xml}
    */
    readonly parseXml?: ObservabilityPipelineConfigProcessorGroupProcessorParseXml[] | cdktn.IResolvable;
    /**
    * quota block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#quota ObservabilityPipeline#quota}
    */
    readonly quota?: ObservabilityPipelineConfigProcessorGroupProcessorQuota[] | cdktn.IResolvable;
    /**
    * reduce block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#reduce ObservabilityPipeline#reduce}
    */
    readonly reduce?: ObservabilityPipelineConfigProcessorGroupProcessorReduce[] | cdktn.IResolvable;
    /**
    * remove_fields block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#remove_fields ObservabilityPipeline#remove_fields}
    */
    readonly removeFields?: ObservabilityPipelineConfigProcessorGroupProcessorRemoveFields[] | cdktn.IResolvable;
    /**
    * rename_fields block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#rename_fields ObservabilityPipeline#rename_fields}
    */
    readonly renameFields?: ObservabilityPipelineConfigProcessorGroupProcessorRenameFields[] | cdktn.IResolvable;
    /**
    * sample block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#sample ObservabilityPipeline#sample}
    */
    readonly sample?: ObservabilityPipelineConfigProcessorGroupProcessorSample[] | cdktn.IResolvable;
    /**
    * sensitive_data_scanner block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#sensitive_data_scanner ObservabilityPipeline#sensitive_data_scanner}
    */
    readonly sensitiveDataScanner?: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScanner[] | cdktn.IResolvable;
    /**
    * split_array block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#split_array ObservabilityPipeline#split_array}
    */
    readonly splitArray?: ObservabilityPipelineConfigProcessorGroupProcessorSplitArray[] | cdktn.IResolvable;
    /**
    * throttle block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#throttle ObservabilityPipeline#throttle}
    */
    readonly throttle?: ObservabilityPipelineConfigProcessorGroupProcessorThrottle[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupProcessorToTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessor | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupProcessorToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroupProcessor | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupProcessorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroupProcessor | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroupProcessor | cdktn.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _include?;
    get include(): string;
    set include(value: string);
    get includeInput(): string | undefined;
    private _addEnvVars;
    get addEnvVars(): ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVarsList;
    putAddEnvVars(value: ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVars[] | cdktn.IResolvable): void;
    resetAddEnvVars(): void;
    get addEnvVarsInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorAddEnvVars[] | undefined;
    private _addFields;
    get addFields(): ObservabilityPipelineConfigProcessorGroupProcessorAddFieldsList;
    putAddFields(value: ObservabilityPipelineConfigProcessorGroupProcessorAddFields[] | cdktn.IResolvable): void;
    resetAddFields(): void;
    get addFieldsInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorAddFields[] | undefined;
    private _addHostname;
    get addHostname(): ObservabilityPipelineConfigProcessorGroupProcessorAddHostnameList;
    putAddHostname(value: ObservabilityPipelineConfigProcessorGroupProcessorAddHostname[] | cdktn.IResolvable): void;
    resetAddHostname(): void;
    get addHostnameInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorAddHostname[] | undefined;
    private _customProcessor;
    get customProcessor(): ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessorList;
    putCustomProcessor(value: ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessor[] | cdktn.IResolvable): void;
    resetCustomProcessor(): void;
    get customProcessorInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorCustomProcessor[] | undefined;
    private _datadogTags;
    get datadogTags(): ObservabilityPipelineConfigProcessorGroupProcessorDatadogTagsList;
    putDatadogTags(value: ObservabilityPipelineConfigProcessorGroupProcessorDatadogTags[] | cdktn.IResolvable): void;
    resetDatadogTags(): void;
    get datadogTagsInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorDatadogTags[] | undefined;
    private _dedupe;
    get dedupe(): ObservabilityPipelineConfigProcessorGroupProcessorDedupeList;
    putDedupe(value: ObservabilityPipelineConfigProcessorGroupProcessorDedupe[] | cdktn.IResolvable): void;
    resetDedupe(): void;
    get dedupeInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorDedupe[] | undefined;
    private _enrichmentTable;
    get enrichmentTable(): ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTableList;
    putEnrichmentTable(value: ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTable[] | cdktn.IResolvable): void;
    resetEnrichmentTable(): void;
    get enrichmentTableInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorEnrichmentTable[] | undefined;
    private _filter;
    get filter(): ObservabilityPipelineConfigProcessorGroupProcessorFilterList;
    putFilter(value: ObservabilityPipelineConfigProcessorGroupProcessorFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorFilter[] | undefined;
    private _generateDatadogMetrics;
    get generateDatadogMetrics(): ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetricsList;
    putGenerateDatadogMetrics(value: ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetrics[] | cdktn.IResolvable): void;
    resetGenerateDatadogMetrics(): void;
    get generateDatadogMetricsInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorGenerateDatadogMetrics[] | undefined;
    private _metricTags;
    get metricTags(): ObservabilityPipelineConfigProcessorGroupProcessorMetricTagsList;
    putMetricTags(value: ObservabilityPipelineConfigProcessorGroupProcessorMetricTags[] | cdktn.IResolvable): void;
    resetMetricTags(): void;
    get metricTagsInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorMetricTags[] | undefined;
    private _ocsfMapper;
    get ocsfMapper(): ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapperList;
    putOcsfMapper(value: ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapper[] | cdktn.IResolvable): void;
    resetOcsfMapper(): void;
    get ocsfMapperInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorOcsfMapper[] | undefined;
    private _parseGrok;
    get parseGrok(): ObservabilityPipelineConfigProcessorGroupProcessorParseGrokList;
    putParseGrok(value: ObservabilityPipelineConfigProcessorGroupProcessorParseGrok[] | cdktn.IResolvable): void;
    resetParseGrok(): void;
    get parseGrokInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorParseGrok[] | undefined;
    private _parseJson;
    get parseJson(): ObservabilityPipelineConfigProcessorGroupProcessorParseJsonList;
    putParseJson(value: ObservabilityPipelineConfigProcessorGroupProcessorParseJson[] | cdktn.IResolvable): void;
    resetParseJson(): void;
    get parseJsonInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorParseJson[] | undefined;
    private _parseXml;
    get parseXml(): ObservabilityPipelineConfigProcessorGroupProcessorParseXmlList;
    putParseXml(value: ObservabilityPipelineConfigProcessorGroupProcessorParseXml[] | cdktn.IResolvable): void;
    resetParseXml(): void;
    get parseXmlInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorParseXml[] | undefined;
    private _quota;
    get quota(): ObservabilityPipelineConfigProcessorGroupProcessorQuotaList;
    putQuota(value: ObservabilityPipelineConfigProcessorGroupProcessorQuota[] | cdktn.IResolvable): void;
    resetQuota(): void;
    get quotaInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorQuota[] | undefined;
    private _reduce;
    get reduce(): ObservabilityPipelineConfigProcessorGroupProcessorReduceList;
    putReduce(value: ObservabilityPipelineConfigProcessorGroupProcessorReduce[] | cdktn.IResolvable): void;
    resetReduce(): void;
    get reduceInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorReduce[] | undefined;
    private _removeFields;
    get removeFields(): ObservabilityPipelineConfigProcessorGroupProcessorRemoveFieldsList;
    putRemoveFields(value: ObservabilityPipelineConfigProcessorGroupProcessorRemoveFields[] | cdktn.IResolvable): void;
    resetRemoveFields(): void;
    get removeFieldsInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorRemoveFields[] | undefined;
    private _renameFields;
    get renameFields(): ObservabilityPipelineConfigProcessorGroupProcessorRenameFieldsList;
    putRenameFields(value: ObservabilityPipelineConfigProcessorGroupProcessorRenameFields[] | cdktn.IResolvable): void;
    resetRenameFields(): void;
    get renameFieldsInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorRenameFields[] | undefined;
    private _sample;
    get sample(): ObservabilityPipelineConfigProcessorGroupProcessorSampleList;
    putSample(value: ObservabilityPipelineConfigProcessorGroupProcessorSample[] | cdktn.IResolvable): void;
    resetSample(): void;
    get sampleInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorSample[] | undefined;
    private _sensitiveDataScanner;
    get sensitiveDataScanner(): ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScannerList;
    putSensitiveDataScanner(value: ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScanner[] | cdktn.IResolvable): void;
    resetSensitiveDataScanner(): void;
    get sensitiveDataScannerInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorSensitiveDataScanner[] | undefined;
    private _splitArray;
    get splitArray(): ObservabilityPipelineConfigProcessorGroupProcessorSplitArrayList;
    putSplitArray(value: ObservabilityPipelineConfigProcessorGroupProcessorSplitArray[] | cdktn.IResolvable): void;
    resetSplitArray(): void;
    get splitArrayInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorSplitArray[] | undefined;
    private _throttle;
    get throttle(): ObservabilityPipelineConfigProcessorGroupProcessorThrottleList;
    putThrottle(value: ObservabilityPipelineConfigProcessorGroupProcessorThrottle[] | cdktn.IResolvable): void;
    resetThrottle(): void;
    get throttleInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessorThrottle[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupProcessorList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroupProcessor[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupProcessorOutputReference;
}
export interface ObservabilityPipelineConfigProcessorGroup {
    /**
    * A human-friendly name of the processor group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#display_name ObservabilityPipeline#display_name}
    */
    readonly displayName?: string;
    /**
    * Whether this processor group is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#enabled ObservabilityPipeline#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * The unique ID of the processor group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#id ObservabilityPipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * A Datadog search query used to determine which logs this processor group targets.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#include ObservabilityPipeline#include}
    */
    readonly include: string;
    /**
    * A list of component IDs whose output is used as the input for this processor group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#inputs ObservabilityPipeline#inputs}
    */
    readonly inputs: string[];
    /**
    * processor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#processor ObservabilityPipeline#processor}
    */
    readonly processor?: ObservabilityPipelineConfigProcessorGroupProcessor[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigProcessorGroupToTerraform(struct?: ObservabilityPipelineConfigProcessorGroup | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigProcessorGroupToHclTerraform(struct?: ObservabilityPipelineConfigProcessorGroup | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigProcessorGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigProcessorGroup | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigProcessorGroup | cdktn.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _include?;
    get include(): string;
    set include(value: string);
    get includeInput(): string | undefined;
    private _inputs?;
    get inputs(): string[];
    set inputs(value: string[]);
    get inputsInput(): string[] | undefined;
    private _processor;
    get processor(): ObservabilityPipelineConfigProcessorGroupProcessorList;
    putProcessor(value: ObservabilityPipelineConfigProcessorGroupProcessor[] | cdktn.IResolvable): void;
    resetProcessor(): void;
    get processorInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroupProcessor[] | undefined;
}
export declare class ObservabilityPipelineConfigProcessorGroupList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigProcessorGroup[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigProcessorGroupOutputReference;
}
export interface ObservabilityPipelineConfigSourceAmazonDataFirehoseAuth {
    /**
    * The Amazon Resource Name (ARN) of the role to assume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#assume_role ObservabilityPipeline#assume_role}
    */
    readonly assumeRole?: string;
    /**
    * A unique identifier for cross-account role assumption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#external_id ObservabilityPipeline#external_id}
    */
    readonly externalId?: string;
    /**
    * A session identifier used for logging and tracing the assumed role session.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#session_name ObservabilityPipeline#session_name}
    */
    readonly sessionName?: string;
}
export declare function observabilityPipelineConfigSourceAmazonDataFirehoseAuthToTerraform(struct?: ObservabilityPipelineConfigSourceAmazonDataFirehoseAuth | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceAmazonDataFirehoseAuthToHclTerraform(struct?: ObservabilityPipelineConfigSourceAmazonDataFirehoseAuth | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceAmazonDataFirehoseAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceAmazonDataFirehoseAuth | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceAmazonDataFirehoseAuth | cdktn.IResolvable | undefined);
    private _assumeRole?;
    get assumeRole(): string;
    set assumeRole(value: string);
    resetAssumeRole(): void;
    get assumeRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _sessionName?;
    get sessionName(): string;
    set sessionName(value: string);
    resetSessionName(): void;
    get sessionNameInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceAmazonDataFirehoseAuthList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceAmazonDataFirehoseAuth[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceAmazonDataFirehoseAuthOutputReference;
}
export interface ObservabilityPipelineConfigSourceAmazonDataFirehoseTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigSourceAmazonDataFirehoseTlsToTerraform(struct?: ObservabilityPipelineConfigSourceAmazonDataFirehoseTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceAmazonDataFirehoseTlsToHclTerraform(struct?: ObservabilityPipelineConfigSourceAmazonDataFirehoseTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceAmazonDataFirehoseTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceAmazonDataFirehoseTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceAmazonDataFirehoseTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceAmazonDataFirehoseTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceAmazonDataFirehoseTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceAmazonDataFirehoseTlsOutputReference;
}
export interface ObservabilityPipelineConfigSourceAmazonDataFirehose {
    /**
    * Name of the environment variable or secret that holds the listen address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#address_key ObservabilityPipeline#address_key}
    */
    readonly addressKey?: string;
    /**
    * auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#auth ObservabilityPipeline#auth}
    */
    readonly auth?: ObservabilityPipelineConfigSourceAmazonDataFirehoseAuth[] | cdktn.IResolvable;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigSourceAmazonDataFirehoseTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigSourceAmazonDataFirehoseToTerraform(struct?: ObservabilityPipelineConfigSourceAmazonDataFirehose | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceAmazonDataFirehoseToHclTerraform(struct?: ObservabilityPipelineConfigSourceAmazonDataFirehose | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceAmazonDataFirehoseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceAmazonDataFirehose | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceAmazonDataFirehose | cdktn.IResolvable | undefined);
    private _addressKey?;
    get addressKey(): string;
    set addressKey(value: string);
    resetAddressKey(): void;
    get addressKeyInput(): string | undefined;
    private _auth;
    get auth(): ObservabilityPipelineConfigSourceAmazonDataFirehoseAuthList;
    putAuth(value: ObservabilityPipelineConfigSourceAmazonDataFirehoseAuth[] | cdktn.IResolvable): void;
    resetAuth(): void;
    get authInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceAmazonDataFirehoseAuth[] | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigSourceAmazonDataFirehoseTlsList;
    putTls(value: ObservabilityPipelineConfigSourceAmazonDataFirehoseTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceAmazonDataFirehoseTls[] | undefined;
}
export declare class ObservabilityPipelineConfigSourceAmazonDataFirehoseList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceAmazonDataFirehose[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceAmazonDataFirehoseOutputReference;
}
export interface ObservabilityPipelineConfigSourceAmazonS3Auth {
    /**
    * The Amazon Resource Name (ARN) of the role to assume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#assume_role ObservabilityPipeline#assume_role}
    */
    readonly assumeRole?: string;
    /**
    * A unique identifier for cross-account role assumption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#external_id ObservabilityPipeline#external_id}
    */
    readonly externalId?: string;
    /**
    * A session identifier used for logging and tracing the assumed role session.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#session_name ObservabilityPipeline#session_name}
    */
    readonly sessionName?: string;
}
export declare function observabilityPipelineConfigSourceAmazonS3AuthToTerraform(struct?: ObservabilityPipelineConfigSourceAmazonS3Auth | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceAmazonS3AuthToHclTerraform(struct?: ObservabilityPipelineConfigSourceAmazonS3Auth | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceAmazonS3AuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceAmazonS3Auth | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceAmazonS3Auth | cdktn.IResolvable | undefined);
    private _assumeRole?;
    get assumeRole(): string;
    set assumeRole(value: string);
    resetAssumeRole(): void;
    get assumeRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _sessionName?;
    get sessionName(): string;
    set sessionName(value: string);
    resetSessionName(): void;
    get sessionNameInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceAmazonS3AuthList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceAmazonS3Auth[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceAmazonS3AuthOutputReference;
}
export interface ObservabilityPipelineConfigSourceAmazonS3Tls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigSourceAmazonS3TlsToTerraform(struct?: ObservabilityPipelineConfigSourceAmazonS3Tls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceAmazonS3TlsToHclTerraform(struct?: ObservabilityPipelineConfigSourceAmazonS3Tls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceAmazonS3TlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceAmazonS3Tls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceAmazonS3Tls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceAmazonS3TlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceAmazonS3Tls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceAmazonS3TlsOutputReference;
}
export interface ObservabilityPipelineConfigSourceAmazonS3 {
    /**
    * AWS region where the S3 bucket resides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#region ObservabilityPipeline#region}
    */
    readonly region: string;
    /**
    * Name of the environment variable or secret that holds the S3 bucket URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#url_key ObservabilityPipeline#url_key}
    */
    readonly urlKey?: string;
    /**
    * auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#auth ObservabilityPipeline#auth}
    */
    readonly auth?: ObservabilityPipelineConfigSourceAmazonS3Auth[] | cdktn.IResolvable;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigSourceAmazonS3Tls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigSourceAmazonS3ToTerraform(struct?: ObservabilityPipelineConfigSourceAmazonS3 | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceAmazonS3ToHclTerraform(struct?: ObservabilityPipelineConfigSourceAmazonS3 | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceAmazonS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceAmazonS3 | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceAmazonS3 | cdktn.IResolvable | undefined);
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _urlKey?;
    get urlKey(): string;
    set urlKey(value: string);
    resetUrlKey(): void;
    get urlKeyInput(): string | undefined;
    private _auth;
    get auth(): ObservabilityPipelineConfigSourceAmazonS3AuthList;
    putAuth(value: ObservabilityPipelineConfigSourceAmazonS3Auth[] | cdktn.IResolvable): void;
    resetAuth(): void;
    get authInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceAmazonS3Auth[] | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigSourceAmazonS3TlsList;
    putTls(value: ObservabilityPipelineConfigSourceAmazonS3Tls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceAmazonS3Tls[] | undefined;
}
export declare class ObservabilityPipelineConfigSourceAmazonS3List extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceAmazonS3[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceAmazonS3OutputReference;
}
export interface ObservabilityPipelineConfigSourceDatadogAgentTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigSourceDatadogAgentTlsToTerraform(struct?: ObservabilityPipelineConfigSourceDatadogAgentTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceDatadogAgentTlsToHclTerraform(struct?: ObservabilityPipelineConfigSourceDatadogAgentTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceDatadogAgentTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceDatadogAgentTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceDatadogAgentTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceDatadogAgentTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceDatadogAgentTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceDatadogAgentTlsOutputReference;
}
export interface ObservabilityPipelineConfigSourceDatadogAgent {
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigSourceDatadogAgentTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigSourceDatadogAgentToTerraform(struct?: ObservabilityPipelineConfigSourceDatadogAgent | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceDatadogAgentToHclTerraform(struct?: ObservabilityPipelineConfigSourceDatadogAgent | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceDatadogAgentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceDatadogAgent | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceDatadogAgent | cdktn.IResolvable | undefined);
    private _tls;
    get tls(): ObservabilityPipelineConfigSourceDatadogAgentTlsList;
    putTls(value: ObservabilityPipelineConfigSourceDatadogAgentTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceDatadogAgentTls[] | undefined;
}
export declare class ObservabilityPipelineConfigSourceDatadogAgentList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceDatadogAgent[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceDatadogAgentOutputReference;
}
export interface ObservabilityPipelineConfigSourceFluentBitTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigSourceFluentBitTlsToTerraform(struct?: ObservabilityPipelineConfigSourceFluentBitTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceFluentBitTlsToHclTerraform(struct?: ObservabilityPipelineConfigSourceFluentBitTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceFluentBitTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceFluentBitTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceFluentBitTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceFluentBitTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceFluentBitTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceFluentBitTlsOutputReference;
}
export interface ObservabilityPipelineConfigSourceFluentBit {
    /**
    * Name of the environment variable or secret that holds the listen address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#address_key ObservabilityPipeline#address_key}
    */
    readonly addressKey?: string;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigSourceFluentBitTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigSourceFluentBitToTerraform(struct?: ObservabilityPipelineConfigSourceFluentBit | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceFluentBitToHclTerraform(struct?: ObservabilityPipelineConfigSourceFluentBit | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceFluentBitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceFluentBit | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceFluentBit | cdktn.IResolvable | undefined);
    private _addressKey?;
    get addressKey(): string;
    set addressKey(value: string);
    resetAddressKey(): void;
    get addressKeyInput(): string | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigSourceFluentBitTlsList;
    putTls(value: ObservabilityPipelineConfigSourceFluentBitTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceFluentBitTls[] | undefined;
}
export declare class ObservabilityPipelineConfigSourceFluentBitList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceFluentBit[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceFluentBitOutputReference;
}
export interface ObservabilityPipelineConfigSourceFluentdTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigSourceFluentdTlsToTerraform(struct?: ObservabilityPipelineConfigSourceFluentdTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceFluentdTlsToHclTerraform(struct?: ObservabilityPipelineConfigSourceFluentdTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceFluentdTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceFluentdTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceFluentdTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceFluentdTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceFluentdTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceFluentdTlsOutputReference;
}
export interface ObservabilityPipelineConfigSourceFluentd {
    /**
    * Name of the environment variable or secret that holds the listen address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#address_key ObservabilityPipeline#address_key}
    */
    readonly addressKey?: string;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigSourceFluentdTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigSourceFluentdToTerraform(struct?: ObservabilityPipelineConfigSourceFluentd | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceFluentdToHclTerraform(struct?: ObservabilityPipelineConfigSourceFluentd | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceFluentdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceFluentd | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceFluentd | cdktn.IResolvable | undefined);
    private _addressKey?;
    get addressKey(): string;
    set addressKey(value: string);
    resetAddressKey(): void;
    get addressKeyInput(): string | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigSourceFluentdTlsList;
    putTls(value: ObservabilityPipelineConfigSourceFluentdTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceFluentdTls[] | undefined;
}
export declare class ObservabilityPipelineConfigSourceFluentdList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceFluentd[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceFluentdOutputReference;
}
export interface ObservabilityPipelineConfigSourceGooglePubsubAuth {
    /**
    * Path to the Google Cloud service account key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#credentials_file ObservabilityPipeline#credentials_file}
    */
    readonly credentialsFile: string;
}
export declare function observabilityPipelineConfigSourceGooglePubsubAuthToTerraform(struct?: ObservabilityPipelineConfigSourceGooglePubsubAuth | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceGooglePubsubAuthToHclTerraform(struct?: ObservabilityPipelineConfigSourceGooglePubsubAuth | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceGooglePubsubAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceGooglePubsubAuth | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceGooglePubsubAuth | cdktn.IResolvable | undefined);
    private _credentialsFile?;
    get credentialsFile(): string;
    set credentialsFile(value: string);
    get credentialsFileInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceGooglePubsubAuthList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceGooglePubsubAuth[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceGooglePubsubAuthOutputReference;
}
export interface ObservabilityPipelineConfigSourceGooglePubsubTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigSourceGooglePubsubTlsToTerraform(struct?: ObservabilityPipelineConfigSourceGooglePubsubTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceGooglePubsubTlsToHclTerraform(struct?: ObservabilityPipelineConfigSourceGooglePubsubTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceGooglePubsubTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceGooglePubsubTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceGooglePubsubTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceGooglePubsubTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceGooglePubsubTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceGooglePubsubTlsOutputReference;
}
export interface ObservabilityPipelineConfigSourceGooglePubsub {
    /**
    * The decoding format used to interpret incoming logs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#decoding ObservabilityPipeline#decoding}
    */
    readonly decoding: string;
    /**
    * The Google Cloud project ID that owns the Pub/Sub subscription.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#project ObservabilityPipeline#project}
    */
    readonly project: string;
    /**
    * The Pub/Sub subscription name from which messages are consumed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#subscription ObservabilityPipeline#subscription}
    */
    readonly subscription: string;
    /**
    * auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#auth ObservabilityPipeline#auth}
    */
    readonly auth?: ObservabilityPipelineConfigSourceGooglePubsubAuth[] | cdktn.IResolvable;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigSourceGooglePubsubTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigSourceGooglePubsubToTerraform(struct?: ObservabilityPipelineConfigSourceGooglePubsub | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceGooglePubsubToHclTerraform(struct?: ObservabilityPipelineConfigSourceGooglePubsub | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceGooglePubsubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceGooglePubsub | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceGooglePubsub | cdktn.IResolvable | undefined);
    private _decoding?;
    get decoding(): string;
    set decoding(value: string);
    get decodingInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _subscription?;
    get subscription(): string;
    set subscription(value: string);
    get subscriptionInput(): string | undefined;
    private _auth;
    get auth(): ObservabilityPipelineConfigSourceGooglePubsubAuthList;
    putAuth(value: ObservabilityPipelineConfigSourceGooglePubsubAuth[] | cdktn.IResolvable): void;
    resetAuth(): void;
    get authInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceGooglePubsubAuth[] | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigSourceGooglePubsubTlsList;
    putTls(value: ObservabilityPipelineConfigSourceGooglePubsubTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceGooglePubsubTls[] | undefined;
}
export declare class ObservabilityPipelineConfigSourceGooglePubsubList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceGooglePubsub[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceGooglePubsubOutputReference;
}
export interface ObservabilityPipelineConfigSourceHttpClientTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigSourceHttpClientTlsToTerraform(struct?: ObservabilityPipelineConfigSourceHttpClientTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceHttpClientTlsToHclTerraform(struct?: ObservabilityPipelineConfigSourceHttpClientTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceHttpClientTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceHttpClientTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceHttpClientTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceHttpClientTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceHttpClientTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceHttpClientTlsOutputReference;
}
export interface ObservabilityPipelineConfigSourceHttpClient {
    /**
    * Optional authentication strategy for HTTP requests. Valid values are `none`, `basic`, `bearer`, `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#auth_strategy ObservabilityPipeline#auth_strategy}
    */
    readonly authStrategy?: string;
    /**
    * Name of the environment variable or secret that holds a custom header value (used with custom auth strategies).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#custom_key ObservabilityPipeline#custom_key}
    */
    readonly customKey?: string;
    /**
    * The decoding format used to interpret incoming logs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#decoding ObservabilityPipeline#decoding}
    */
    readonly decoding: string;
    /**
    * Name of the environment variable or secret that holds the HTTP endpoint URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#endpoint_url_key ObservabilityPipeline#endpoint_url_key}
    */
    readonly endpointUrlKey?: string;
    /**
    * Name of the environment variable or secret that holds the password.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#password_key ObservabilityPipeline#password_key}
    */
    readonly passwordKey?: string;
    /**
    * The interval (in seconds) between HTTP scrape requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#scrape_interval_secs ObservabilityPipeline#scrape_interval_secs}
    */
    readonly scrapeIntervalSecs?: number;
    /**
    * The timeout (in seconds) for each scrape request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#scrape_timeout_secs ObservabilityPipeline#scrape_timeout_secs}
    */
    readonly scrapeTimeoutSecs?: number;
    /**
    * Name of the environment variable or secret that holds the authentication token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#token_key ObservabilityPipeline#token_key}
    */
    readonly tokenKey?: string;
    /**
    * Name of the environment variable or secret that holds the username.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#username_key ObservabilityPipeline#username_key}
    */
    readonly usernameKey?: string;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigSourceHttpClientTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigSourceHttpClientToTerraform(struct?: ObservabilityPipelineConfigSourceHttpClient | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceHttpClientToHclTerraform(struct?: ObservabilityPipelineConfigSourceHttpClient | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceHttpClientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceHttpClient | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceHttpClient | cdktn.IResolvable | undefined);
    private _authStrategy?;
    get authStrategy(): string;
    set authStrategy(value: string);
    resetAuthStrategy(): void;
    get authStrategyInput(): string | undefined;
    private _customKey?;
    get customKey(): string;
    set customKey(value: string);
    resetCustomKey(): void;
    get customKeyInput(): string | undefined;
    private _decoding?;
    get decoding(): string;
    set decoding(value: string);
    get decodingInput(): string | undefined;
    private _endpointUrlKey?;
    get endpointUrlKey(): string;
    set endpointUrlKey(value: string);
    resetEndpointUrlKey(): void;
    get endpointUrlKeyInput(): string | undefined;
    private _passwordKey?;
    get passwordKey(): string;
    set passwordKey(value: string);
    resetPasswordKey(): void;
    get passwordKeyInput(): string | undefined;
    private _scrapeIntervalSecs?;
    get scrapeIntervalSecs(): number;
    set scrapeIntervalSecs(value: number);
    resetScrapeIntervalSecs(): void;
    get scrapeIntervalSecsInput(): number | undefined;
    private _scrapeTimeoutSecs?;
    get scrapeTimeoutSecs(): number;
    set scrapeTimeoutSecs(value: number);
    resetScrapeTimeoutSecs(): void;
    get scrapeTimeoutSecsInput(): number | undefined;
    private _tokenKey?;
    get tokenKey(): string;
    set tokenKey(value: string);
    resetTokenKey(): void;
    get tokenKeyInput(): string | undefined;
    private _usernameKey?;
    get usernameKey(): string;
    set usernameKey(value: string);
    resetUsernameKey(): void;
    get usernameKeyInput(): string | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigSourceHttpClientTlsList;
    putTls(value: ObservabilityPipelineConfigSourceHttpClientTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceHttpClientTls[] | undefined;
}
export declare class ObservabilityPipelineConfigSourceHttpClientList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceHttpClient[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceHttpClientOutputReference;
}
export interface ObservabilityPipelineConfigSourceHttpServerTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigSourceHttpServerTlsToTerraform(struct?: ObservabilityPipelineConfigSourceHttpServerTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceHttpServerTlsToHclTerraform(struct?: ObservabilityPipelineConfigSourceHttpServerTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceHttpServerTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceHttpServerTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceHttpServerTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceHttpServerTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceHttpServerTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceHttpServerTlsOutputReference;
}
export interface ObservabilityPipelineConfigSourceHttpServer {
    /**
    * Name of the environment variable or secret that holds the listen address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#address_key ObservabilityPipeline#address_key}
    */
    readonly addressKey?: string;
    /**
    * HTTP authentication method. Valid values are `none`, `plain`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#auth_strategy ObservabilityPipeline#auth_strategy}
    */
    readonly authStrategy: string;
    /**
    * The decoding format used to interpret incoming logs. Valid values are `json`, `gelf`, `syslog`, `bytes`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#decoding ObservabilityPipeline#decoding}
    */
    readonly decoding: string;
    /**
    * Name of the environment variable or secret that holds the password.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#password_key ObservabilityPipeline#password_key}
    */
    readonly passwordKey?: string;
    /**
    * Name of the environment variable or secret that holds the username.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#username_key ObservabilityPipeline#username_key}
    */
    readonly usernameKey?: string;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigSourceHttpServerTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigSourceHttpServerToTerraform(struct?: ObservabilityPipelineConfigSourceHttpServer | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceHttpServerToHclTerraform(struct?: ObservabilityPipelineConfigSourceHttpServer | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceHttpServerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceHttpServer | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceHttpServer | cdktn.IResolvable | undefined);
    private _addressKey?;
    get addressKey(): string;
    set addressKey(value: string);
    resetAddressKey(): void;
    get addressKeyInput(): string | undefined;
    private _authStrategy?;
    get authStrategy(): string;
    set authStrategy(value: string);
    get authStrategyInput(): string | undefined;
    private _decoding?;
    get decoding(): string;
    set decoding(value: string);
    get decodingInput(): string | undefined;
    private _passwordKey?;
    get passwordKey(): string;
    set passwordKey(value: string);
    resetPasswordKey(): void;
    get passwordKeyInput(): string | undefined;
    private _usernameKey?;
    get usernameKey(): string;
    set usernameKey(value: string);
    resetUsernameKey(): void;
    get usernameKeyInput(): string | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigSourceHttpServerTlsList;
    putTls(value: ObservabilityPipelineConfigSourceHttpServerTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceHttpServerTls[] | undefined;
}
export declare class ObservabilityPipelineConfigSourceHttpServerList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceHttpServer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceHttpServerOutputReference;
}
export interface ObservabilityPipelineConfigSourceKafkaLibrdkafkaOption {
    /**
    * The name of the librdkafka option.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#name ObservabilityPipeline#name}
    */
    readonly name: string;
    /**
    * The value of the librdkafka option.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#value ObservabilityPipeline#value}
    */
    readonly value: string;
}
export declare function observabilityPipelineConfigSourceKafkaLibrdkafkaOptionToTerraform(struct?: ObservabilityPipelineConfigSourceKafkaLibrdkafkaOption | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceKafkaLibrdkafkaOptionToHclTerraform(struct?: ObservabilityPipelineConfigSourceKafkaLibrdkafkaOption | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceKafkaLibrdkafkaOptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceKafkaLibrdkafkaOption | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceKafkaLibrdkafkaOption | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceKafkaLibrdkafkaOptionList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceKafkaLibrdkafkaOption[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceKafkaLibrdkafkaOptionOutputReference;
}
export interface ObservabilityPipelineConfigSourceKafkaSasl {
    /**
    * SASL mechanism to use (e.g., PLAIN, SCRAM-SHA-256, SCRAM-SHA-512). Valid values are `PLAIN`, `SCRAM-SHA-256`, `SCRAM-SHA-512`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#mechanism ObservabilityPipeline#mechanism}
    */
    readonly mechanism: string;
    /**
    * Name of the environment variable or secret that holds the SASL password.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#password_key ObservabilityPipeline#password_key}
    */
    readonly passwordKey?: string;
    /**
    * Name of the environment variable or secret that holds the SASL username.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#username_key ObservabilityPipeline#username_key}
    */
    readonly usernameKey?: string;
}
export declare function observabilityPipelineConfigSourceKafkaSaslToTerraform(struct?: ObservabilityPipelineConfigSourceKafkaSasl | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceKafkaSaslToHclTerraform(struct?: ObservabilityPipelineConfigSourceKafkaSasl | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceKafkaSaslOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceKafkaSasl | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceKafkaSasl | cdktn.IResolvable | undefined);
    private _mechanism?;
    get mechanism(): string;
    set mechanism(value: string);
    get mechanismInput(): string | undefined;
    private _passwordKey?;
    get passwordKey(): string;
    set passwordKey(value: string);
    resetPasswordKey(): void;
    get passwordKeyInput(): string | undefined;
    private _usernameKey?;
    get usernameKey(): string;
    set usernameKey(value: string);
    resetUsernameKey(): void;
    get usernameKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceKafkaSaslList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceKafkaSasl[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceKafkaSaslOutputReference;
}
export interface ObservabilityPipelineConfigSourceKafkaTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigSourceKafkaTlsToTerraform(struct?: ObservabilityPipelineConfigSourceKafkaTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceKafkaTlsToHclTerraform(struct?: ObservabilityPipelineConfigSourceKafkaTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceKafkaTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceKafkaTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceKafkaTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceKafkaTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceKafkaTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceKafkaTlsOutputReference;
}
export interface ObservabilityPipelineConfigSourceKafka {
    /**
    * Name of the environment variable or secret that holds the Kafka bootstrap servers connection string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#bootstrap_servers_key ObservabilityPipeline#bootstrap_servers_key}
    */
    readonly bootstrapServersKey?: string;
    /**
    * The Kafka consumer group ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#group_id ObservabilityPipeline#group_id}
    */
    readonly groupId: string;
    /**
    * A list of Kafka topic names to subscribe to. The source ingests messages from each topic specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#topics ObservabilityPipeline#topics}
    */
    readonly topics: string[];
    /**
    * librdkafka_option block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#librdkafka_option ObservabilityPipeline#librdkafka_option}
    */
    readonly librdkafkaOption?: ObservabilityPipelineConfigSourceKafkaLibrdkafkaOption[] | cdktn.IResolvable;
    /**
    * sasl block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#sasl ObservabilityPipeline#sasl}
    */
    readonly sasl?: ObservabilityPipelineConfigSourceKafkaSasl[] | cdktn.IResolvable;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigSourceKafkaTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigSourceKafkaToTerraform(struct?: ObservabilityPipelineConfigSourceKafka | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceKafkaToHclTerraform(struct?: ObservabilityPipelineConfigSourceKafka | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceKafkaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceKafka | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceKafka | cdktn.IResolvable | undefined);
    private _bootstrapServersKey?;
    get bootstrapServersKey(): string;
    set bootstrapServersKey(value: string);
    resetBootstrapServersKey(): void;
    get bootstrapServersKeyInput(): string | undefined;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    get groupIdInput(): string | undefined;
    private _topics?;
    get topics(): string[];
    set topics(value: string[]);
    get topicsInput(): string[] | undefined;
    private _librdkafkaOption;
    get librdkafkaOption(): ObservabilityPipelineConfigSourceKafkaLibrdkafkaOptionList;
    putLibrdkafkaOption(value: ObservabilityPipelineConfigSourceKafkaLibrdkafkaOption[] | cdktn.IResolvable): void;
    resetLibrdkafkaOption(): void;
    get librdkafkaOptionInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceKafkaLibrdkafkaOption[] | undefined;
    private _sasl;
    get sasl(): ObservabilityPipelineConfigSourceKafkaSaslList;
    putSasl(value: ObservabilityPipelineConfigSourceKafkaSasl[] | cdktn.IResolvable): void;
    resetSasl(): void;
    get saslInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceKafkaSasl[] | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigSourceKafkaTlsList;
    putTls(value: ObservabilityPipelineConfigSourceKafkaTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceKafkaTls[] | undefined;
}
export declare class ObservabilityPipelineConfigSourceKafkaList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceKafka[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceKafkaOutputReference;
}
export interface ObservabilityPipelineConfigSourceLogstashTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigSourceLogstashTlsToTerraform(struct?: ObservabilityPipelineConfigSourceLogstashTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceLogstashTlsToHclTerraform(struct?: ObservabilityPipelineConfigSourceLogstashTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceLogstashTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceLogstashTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceLogstashTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceLogstashTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceLogstashTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceLogstashTlsOutputReference;
}
export interface ObservabilityPipelineConfigSourceLogstash {
    /**
    * Name of the environment variable or secret that holds the listen address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#address_key ObservabilityPipeline#address_key}
    */
    readonly addressKey?: string;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigSourceLogstashTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigSourceLogstashToTerraform(struct?: ObservabilityPipelineConfigSourceLogstash | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceLogstashToHclTerraform(struct?: ObservabilityPipelineConfigSourceLogstash | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceLogstashOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceLogstash | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceLogstash | cdktn.IResolvable | undefined);
    private _addressKey?;
    get addressKey(): string;
    set addressKey(value: string);
    resetAddressKey(): void;
    get addressKeyInput(): string | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigSourceLogstashTlsList;
    putTls(value: ObservabilityPipelineConfigSourceLogstashTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceLogstashTls[] | undefined;
}
export declare class ObservabilityPipelineConfigSourceLogstashList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceLogstash[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceLogstashOutputReference;
}
export interface ObservabilityPipelineConfigSourceOpentelemetryTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigSourceOpentelemetryTlsToTerraform(struct?: ObservabilityPipelineConfigSourceOpentelemetryTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceOpentelemetryTlsToHclTerraform(struct?: ObservabilityPipelineConfigSourceOpentelemetryTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceOpentelemetryTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceOpentelemetryTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceOpentelemetryTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceOpentelemetryTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceOpentelemetryTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceOpentelemetryTlsOutputReference;
}
export interface ObservabilityPipelineConfigSourceOpentelemetry {
    /**
    * Environment variable name containing the gRPC server address for receiving OTLP data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#grpc_address_key ObservabilityPipeline#grpc_address_key}
    */
    readonly grpcAddressKey?: string;
    /**
    * Environment variable name containing the HTTP server address for receiving OTLP data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#http_address_key ObservabilityPipeline#http_address_key}
    */
    readonly httpAddressKey?: string;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigSourceOpentelemetryTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigSourceOpentelemetryToTerraform(struct?: ObservabilityPipelineConfigSourceOpentelemetry | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceOpentelemetryToHclTerraform(struct?: ObservabilityPipelineConfigSourceOpentelemetry | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceOpentelemetryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceOpentelemetry | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceOpentelemetry | cdktn.IResolvable | undefined);
    private _grpcAddressKey?;
    get grpcAddressKey(): string;
    set grpcAddressKey(value: string);
    resetGrpcAddressKey(): void;
    get grpcAddressKeyInput(): string | undefined;
    private _httpAddressKey?;
    get httpAddressKey(): string;
    set httpAddressKey(value: string);
    resetHttpAddressKey(): void;
    get httpAddressKeyInput(): string | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigSourceOpentelemetryTlsList;
    putTls(value: ObservabilityPipelineConfigSourceOpentelemetryTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceOpentelemetryTls[] | undefined;
}
export declare class ObservabilityPipelineConfigSourceOpentelemetryList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceOpentelemetry[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceOpentelemetryOutputReference;
}
