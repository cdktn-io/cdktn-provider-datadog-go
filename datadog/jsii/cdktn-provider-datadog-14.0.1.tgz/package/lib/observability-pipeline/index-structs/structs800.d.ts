/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
import { ObservabilityPipelineConfigSourceAmazonDataFirehose, ObservabilityPipelineConfigSourceAmazonDataFirehoseList, ObservabilityPipelineConfigSourceAmazonS3, ObservabilityPipelineConfigSourceAmazonS3List, ObservabilityPipelineConfigSourceDatadogAgent, ObservabilityPipelineConfigSourceDatadogAgentList, ObservabilityPipelineConfigSourceFluentBit, ObservabilityPipelineConfigSourceFluentBitList, ObservabilityPipelineConfigSourceFluentd, ObservabilityPipelineConfigSourceFluentdList, ObservabilityPipelineConfigSourceGooglePubsub, ObservabilityPipelineConfigSourceGooglePubsubList, ObservabilityPipelineConfigSourceHttpClient, ObservabilityPipelineConfigSourceHttpClientList, ObservabilityPipelineConfigSourceHttpServer, ObservabilityPipelineConfigSourceHttpServerList, ObservabilityPipelineConfigSourceKafka, ObservabilityPipelineConfigSourceKafkaList, ObservabilityPipelineConfigSourceLogstash, ObservabilityPipelineConfigSourceLogstashList, ObservabilityPipelineConfigSourceOpentelemetry, ObservabilityPipelineConfigSourceOpentelemetryList, ObservabilityPipelineConfigDestination, ObservabilityPipelineConfigDestinationList, ObservabilityPipelineConfigProcessorGroup, ObservabilityPipelineConfigProcessorGroupList } from './structs400';
export interface ObservabilityPipelineConfigSourceRsyslogTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigSourceRsyslogTlsToTerraform(struct?: ObservabilityPipelineConfigSourceRsyslogTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceRsyslogTlsToHclTerraform(struct?: ObservabilityPipelineConfigSourceRsyslogTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceRsyslogTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceRsyslogTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceRsyslogTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceRsyslogTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceRsyslogTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceRsyslogTlsOutputReference;
}
export interface ObservabilityPipelineConfigSourceRsyslog {
    /**
    * Name of the environment variable or secret that holds the listen address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#address_key ObservabilityPipeline#address_key}
    */
    readonly addressKey?: string;
    /**
    * Protocol used by the syslog source to receive messages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#mode ObservabilityPipeline#mode}
    */
    readonly mode?: string;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigSourceRsyslogTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigSourceRsyslogToTerraform(struct?: ObservabilityPipelineConfigSourceRsyslog | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceRsyslogToHclTerraform(struct?: ObservabilityPipelineConfigSourceRsyslog | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceRsyslogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceRsyslog | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceRsyslog | cdktn.IResolvable | undefined);
    private _addressKey?;
    get addressKey(): string;
    set addressKey(value: string);
    resetAddressKey(): void;
    get addressKeyInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigSourceRsyslogTlsList;
    putTls(value: ObservabilityPipelineConfigSourceRsyslogTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceRsyslogTls[] | undefined;
}
export declare class ObservabilityPipelineConfigSourceRsyslogList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceRsyslog[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceRsyslogOutputReference;
}
export interface ObservabilityPipelineConfigSourceSocketFramingCharacterDelimited {
    /**
    * A single ASCII character used as a delimiter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#delimiter ObservabilityPipeline#delimiter}
    */
    readonly delimiter: string;
}
export declare function observabilityPipelineConfigSourceSocketFramingCharacterDelimitedToTerraform(struct?: ObservabilityPipelineConfigSourceSocketFramingCharacterDelimited | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceSocketFramingCharacterDelimitedToHclTerraform(struct?: ObservabilityPipelineConfigSourceSocketFramingCharacterDelimited | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceSocketFramingCharacterDelimitedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceSocketFramingCharacterDelimited | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceSocketFramingCharacterDelimited | cdktn.IResolvable | undefined);
    private _delimiter?;
    get delimiter(): string;
    set delimiter(value: string);
    get delimiterInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceSocketFramingCharacterDelimitedList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceSocketFramingCharacterDelimited[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceSocketFramingCharacterDelimitedOutputReference;
}
export interface ObservabilityPipelineConfigSourceSocketFraming {
    /**
    * The framing method. Valid values are `newline_delimited`, `bytes`, `character_delimited`, `octet_counting`, `chunked_gelf`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#method ObservabilityPipeline#method}
    */
    readonly method: string;
    /**
    * character_delimited block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#character_delimited ObservabilityPipeline#character_delimited}
    */
    readonly characterDelimited?: ObservabilityPipelineConfigSourceSocketFramingCharacterDelimited[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigSourceSocketFramingToTerraform(struct?: ObservabilityPipelineConfigSourceSocketFraming | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceSocketFramingToHclTerraform(struct?: ObservabilityPipelineConfigSourceSocketFraming | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceSocketFramingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceSocketFraming | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceSocketFraming | cdktn.IResolvable | undefined);
    private _method?;
    get method(): string;
    set method(value: string);
    get methodInput(): string | undefined;
    private _characterDelimited;
    get characterDelimited(): ObservabilityPipelineConfigSourceSocketFramingCharacterDelimitedList;
    putCharacterDelimited(value: ObservabilityPipelineConfigSourceSocketFramingCharacterDelimited[] | cdktn.IResolvable): void;
    resetCharacterDelimited(): void;
    get characterDelimitedInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceSocketFramingCharacterDelimited[] | undefined;
}
export declare class ObservabilityPipelineConfigSourceSocketFramingList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceSocketFraming[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceSocketFramingOutputReference;
}
export interface ObservabilityPipelineConfigSourceSocketTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigSourceSocketTlsToTerraform(struct?: ObservabilityPipelineConfigSourceSocketTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceSocketTlsToHclTerraform(struct?: ObservabilityPipelineConfigSourceSocketTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceSocketTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceSocketTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceSocketTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceSocketTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceSocketTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceSocketTlsOutputReference;
}
export interface ObservabilityPipelineConfigSourceSocket {
    /**
    * Name of the environment variable or secret that holds the listen address for the socket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#address_key ObservabilityPipeline#address_key}
    */
    readonly addressKey?: string;
    /**
    * The protocol used to receive logs. Valid values are `tcp`, `udp`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#mode ObservabilityPipeline#mode}
    */
    readonly mode: string;
    /**
    * framing block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#framing ObservabilityPipeline#framing}
    */
    readonly framing?: ObservabilityPipelineConfigSourceSocketFraming[] | cdktn.IResolvable;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigSourceSocketTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigSourceSocketToTerraform(struct?: ObservabilityPipelineConfigSourceSocket | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceSocketToHclTerraform(struct?: ObservabilityPipelineConfigSourceSocket | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceSocket | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceSocket | cdktn.IResolvable | undefined);
    private _addressKey?;
    get addressKey(): string;
    set addressKey(value: string);
    resetAddressKey(): void;
    get addressKeyInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _framing;
    get framing(): ObservabilityPipelineConfigSourceSocketFramingList;
    putFraming(value: ObservabilityPipelineConfigSourceSocketFraming[] | cdktn.IResolvable): void;
    resetFraming(): void;
    get framingInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceSocketFraming[] | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigSourceSocketTlsList;
    putTls(value: ObservabilityPipelineConfigSourceSocketTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceSocketTls[] | undefined;
}
export declare class ObservabilityPipelineConfigSourceSocketList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceSocket[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceSocketOutputReference;
}
export interface ObservabilityPipelineConfigSourceSplunkHecTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigSourceSplunkHecTlsToTerraform(struct?: ObservabilityPipelineConfigSourceSplunkHecTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceSplunkHecTlsToHclTerraform(struct?: ObservabilityPipelineConfigSourceSplunkHecTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceSplunkHecTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceSplunkHecTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceSplunkHecTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceSplunkHecTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceSplunkHecTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceSplunkHecTlsOutputReference;
}
export interface ObservabilityPipelineConfigSourceSplunkHec {
    /**
    * Name of the environment variable or secret that holds the listen address for the HEC API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#address_key ObservabilityPipeline#address_key}
    */
    readonly addressKey?: string;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigSourceSplunkHecTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigSourceSplunkHecToTerraform(struct?: ObservabilityPipelineConfigSourceSplunkHec | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceSplunkHecToHclTerraform(struct?: ObservabilityPipelineConfigSourceSplunkHec | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceSplunkHecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceSplunkHec | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceSplunkHec | cdktn.IResolvable | undefined);
    private _addressKey?;
    get addressKey(): string;
    set addressKey(value: string);
    resetAddressKey(): void;
    get addressKeyInput(): string | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigSourceSplunkHecTlsList;
    putTls(value: ObservabilityPipelineConfigSourceSplunkHecTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceSplunkHecTls[] | undefined;
}
export declare class ObservabilityPipelineConfigSourceSplunkHecList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceSplunkHec[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceSplunkHecOutputReference;
}
export interface ObservabilityPipelineConfigSourceSplunkTcpTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigSourceSplunkTcpTlsToTerraform(struct?: ObservabilityPipelineConfigSourceSplunkTcpTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceSplunkTcpTlsToHclTerraform(struct?: ObservabilityPipelineConfigSourceSplunkTcpTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceSplunkTcpTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceSplunkTcpTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceSplunkTcpTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceSplunkTcpTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceSplunkTcpTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceSplunkTcpTlsOutputReference;
}
export interface ObservabilityPipelineConfigSourceSplunkTcp {
    /**
    * Name of the environment variable or secret that holds the listen address for the Splunk TCP receiver.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#address_key ObservabilityPipeline#address_key}
    */
    readonly addressKey?: string;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigSourceSplunkTcpTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigSourceSplunkTcpToTerraform(struct?: ObservabilityPipelineConfigSourceSplunkTcp | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceSplunkTcpToHclTerraform(struct?: ObservabilityPipelineConfigSourceSplunkTcp | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceSplunkTcpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceSplunkTcp | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceSplunkTcp | cdktn.IResolvable | undefined);
    private _addressKey?;
    get addressKey(): string;
    set addressKey(value: string);
    resetAddressKey(): void;
    get addressKeyInput(): string | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigSourceSplunkTcpTlsList;
    putTls(value: ObservabilityPipelineConfigSourceSplunkTcpTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceSplunkTcpTls[] | undefined;
}
export declare class ObservabilityPipelineConfigSourceSplunkTcpList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceSplunkTcp[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceSplunkTcpOutputReference;
}
export interface ObservabilityPipelineConfigSourceSumoLogic {
    /**
    * Name of the environment variable or secret that holds the listen address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#address_key ObservabilityPipeline#address_key}
    */
    readonly addressKey?: string;
}
export declare function observabilityPipelineConfigSourceSumoLogicToTerraform(struct?: ObservabilityPipelineConfigSourceSumoLogic | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceSumoLogicToHclTerraform(struct?: ObservabilityPipelineConfigSourceSumoLogic | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceSumoLogicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceSumoLogic | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceSumoLogic | cdktn.IResolvable | undefined);
    private _addressKey?;
    get addressKey(): string;
    set addressKey(value: string);
    resetAddressKey(): void;
    get addressKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceSumoLogicList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceSumoLogic[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceSumoLogicOutputReference;
}
export interface ObservabilityPipelineConfigSourceSyslogNgTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigSourceSyslogNgTlsToTerraform(struct?: ObservabilityPipelineConfigSourceSyslogNgTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceSyslogNgTlsToHclTerraform(struct?: ObservabilityPipelineConfigSourceSyslogNgTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceSyslogNgTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceSyslogNgTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceSyslogNgTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigSourceSyslogNgTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceSyslogNgTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceSyslogNgTlsOutputReference;
}
export interface ObservabilityPipelineConfigSourceSyslogNg {
    /**
    * Name of the environment variable or secret that holds the listen address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#address_key ObservabilityPipeline#address_key}
    */
    readonly addressKey?: string;
    /**
    * Protocol used by the syslog source to receive messages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#mode ObservabilityPipeline#mode}
    */
    readonly mode?: string;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigSourceSyslogNgTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigSourceSyslogNgToTerraform(struct?: ObservabilityPipelineConfigSourceSyslogNg | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceSyslogNgToHclTerraform(struct?: ObservabilityPipelineConfigSourceSyslogNg | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceSyslogNgOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSourceSyslogNg | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSourceSyslogNg | cdktn.IResolvable | undefined);
    private _addressKey?;
    get addressKey(): string;
    set addressKey(value: string);
    resetAddressKey(): void;
    get addressKeyInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigSourceSyslogNgTlsList;
    putTls(value: ObservabilityPipelineConfigSourceSyslogNgTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceSyslogNgTls[] | undefined;
}
export declare class ObservabilityPipelineConfigSourceSyslogNgList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSourceSyslogNg[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceSyslogNgOutputReference;
}
export interface ObservabilityPipelineConfigSource {
    /**
    * The unique identifier for this source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#id ObservabilityPipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * amazon_data_firehose block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#amazon_data_firehose ObservabilityPipeline#amazon_data_firehose}
    */
    readonly amazonDataFirehose?: ObservabilityPipelineConfigSourceAmazonDataFirehose[] | cdktn.IResolvable;
    /**
    * amazon_s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#amazon_s3 ObservabilityPipeline#amazon_s3}
    */
    readonly amazonS3?: ObservabilityPipelineConfigSourceAmazonS3[] | cdktn.IResolvable;
    /**
    * datadog_agent block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#datadog_agent ObservabilityPipeline#datadog_agent}
    */
    readonly datadogAgent?: ObservabilityPipelineConfigSourceDatadogAgent[] | cdktn.IResolvable;
    /**
    * fluent_bit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#fluent_bit ObservabilityPipeline#fluent_bit}
    */
    readonly fluentBit?: ObservabilityPipelineConfigSourceFluentBit[] | cdktn.IResolvable;
    /**
    * fluentd block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#fluentd ObservabilityPipeline#fluentd}
    */
    readonly fluentd?: ObservabilityPipelineConfigSourceFluentd[] | cdktn.IResolvable;
    /**
    * google_pubsub block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#google_pubsub ObservabilityPipeline#google_pubsub}
    */
    readonly googlePubsub?: ObservabilityPipelineConfigSourceGooglePubsub[] | cdktn.IResolvable;
    /**
    * http_client block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#http_client ObservabilityPipeline#http_client}
    */
    readonly httpClient?: ObservabilityPipelineConfigSourceHttpClient[] | cdktn.IResolvable;
    /**
    * http_server block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#http_server ObservabilityPipeline#http_server}
    */
    readonly httpServer?: ObservabilityPipelineConfigSourceHttpServer[] | cdktn.IResolvable;
    /**
    * kafka block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#kafka ObservabilityPipeline#kafka}
    */
    readonly kafka?: ObservabilityPipelineConfigSourceKafka[] | cdktn.IResolvable;
    /**
    * logstash block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#logstash ObservabilityPipeline#logstash}
    */
    readonly logstash?: ObservabilityPipelineConfigSourceLogstash[] | cdktn.IResolvable;
    /**
    * opentelemetry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#opentelemetry ObservabilityPipeline#opentelemetry}
    */
    readonly opentelemetry?: ObservabilityPipelineConfigSourceOpentelemetry[] | cdktn.IResolvable;
    /**
    * rsyslog block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#rsyslog ObservabilityPipeline#rsyslog}
    */
    readonly rsyslog?: ObservabilityPipelineConfigSourceRsyslog[] | cdktn.IResolvable;
    /**
    * socket block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#socket ObservabilityPipeline#socket}
    */
    readonly socket?: ObservabilityPipelineConfigSourceSocket[] | cdktn.IResolvable;
    /**
    * splunk_hec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#splunk_hec ObservabilityPipeline#splunk_hec}
    */
    readonly splunkHec?: ObservabilityPipelineConfigSourceSplunkHec[] | cdktn.IResolvable;
    /**
    * splunk_tcp block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#splunk_tcp ObservabilityPipeline#splunk_tcp}
    */
    readonly splunkTcp?: ObservabilityPipelineConfigSourceSplunkTcp[] | cdktn.IResolvable;
    /**
    * sumo_logic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#sumo_logic ObservabilityPipeline#sumo_logic}
    */
    readonly sumoLogic?: ObservabilityPipelineConfigSourceSumoLogic[] | cdktn.IResolvable;
    /**
    * syslog_ng block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#syslog_ng ObservabilityPipeline#syslog_ng}
    */
    readonly syslogNg?: ObservabilityPipelineConfigSourceSyslogNg[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigSourceToTerraform(struct?: ObservabilityPipelineConfigSource | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigSourceToHclTerraform(struct?: ObservabilityPipelineConfigSource | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigSource | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigSource | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _amazonDataFirehose;
    get amazonDataFirehose(): ObservabilityPipelineConfigSourceAmazonDataFirehoseList;
    putAmazonDataFirehose(value: ObservabilityPipelineConfigSourceAmazonDataFirehose[] | cdktn.IResolvable): void;
    resetAmazonDataFirehose(): void;
    get amazonDataFirehoseInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceAmazonDataFirehose[] | undefined;
    private _amazonS3;
    get amazonS3(): ObservabilityPipelineConfigSourceAmazonS3List;
    putAmazonS3(value: ObservabilityPipelineConfigSourceAmazonS3[] | cdktn.IResolvable): void;
    resetAmazonS3(): void;
    get amazonS3Input(): cdktn.IResolvable | ObservabilityPipelineConfigSourceAmazonS3[] | undefined;
    private _datadogAgent;
    get datadogAgent(): ObservabilityPipelineConfigSourceDatadogAgentList;
    putDatadogAgent(value: ObservabilityPipelineConfigSourceDatadogAgent[] | cdktn.IResolvable): void;
    resetDatadogAgent(): void;
    get datadogAgentInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceDatadogAgent[] | undefined;
    private _fluentBit;
    get fluentBit(): ObservabilityPipelineConfigSourceFluentBitList;
    putFluentBit(value: ObservabilityPipelineConfigSourceFluentBit[] | cdktn.IResolvable): void;
    resetFluentBit(): void;
    get fluentBitInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceFluentBit[] | undefined;
    private _fluentd;
    get fluentd(): ObservabilityPipelineConfigSourceFluentdList;
    putFluentd(value: ObservabilityPipelineConfigSourceFluentd[] | cdktn.IResolvable): void;
    resetFluentd(): void;
    get fluentdInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceFluentd[] | undefined;
    private _googlePubsub;
    get googlePubsub(): ObservabilityPipelineConfigSourceGooglePubsubList;
    putGooglePubsub(value: ObservabilityPipelineConfigSourceGooglePubsub[] | cdktn.IResolvable): void;
    resetGooglePubsub(): void;
    get googlePubsubInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceGooglePubsub[] | undefined;
    private _httpClient;
    get httpClient(): ObservabilityPipelineConfigSourceHttpClientList;
    putHttpClient(value: ObservabilityPipelineConfigSourceHttpClient[] | cdktn.IResolvable): void;
    resetHttpClient(): void;
    get httpClientInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceHttpClient[] | undefined;
    private _httpServer;
    get httpServer(): ObservabilityPipelineConfigSourceHttpServerList;
    putHttpServer(value: ObservabilityPipelineConfigSourceHttpServer[] | cdktn.IResolvable): void;
    resetHttpServer(): void;
    get httpServerInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceHttpServer[] | undefined;
    private _kafka;
    get kafka(): ObservabilityPipelineConfigSourceKafkaList;
    putKafka(value: ObservabilityPipelineConfigSourceKafka[] | cdktn.IResolvable): void;
    resetKafka(): void;
    get kafkaInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceKafka[] | undefined;
    private _logstash;
    get logstash(): ObservabilityPipelineConfigSourceLogstashList;
    putLogstash(value: ObservabilityPipelineConfigSourceLogstash[] | cdktn.IResolvable): void;
    resetLogstash(): void;
    get logstashInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceLogstash[] | undefined;
    private _opentelemetry;
    get opentelemetry(): ObservabilityPipelineConfigSourceOpentelemetryList;
    putOpentelemetry(value: ObservabilityPipelineConfigSourceOpentelemetry[] | cdktn.IResolvable): void;
    resetOpentelemetry(): void;
    get opentelemetryInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceOpentelemetry[] | undefined;
    private _rsyslog;
    get rsyslog(): ObservabilityPipelineConfigSourceRsyslogList;
    putRsyslog(value: ObservabilityPipelineConfigSourceRsyslog[] | cdktn.IResolvable): void;
    resetRsyslog(): void;
    get rsyslogInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceRsyslog[] | undefined;
    private _socket;
    get socket(): ObservabilityPipelineConfigSourceSocketList;
    putSocket(value: ObservabilityPipelineConfigSourceSocket[] | cdktn.IResolvable): void;
    resetSocket(): void;
    get socketInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceSocket[] | undefined;
    private _splunkHec;
    get splunkHec(): ObservabilityPipelineConfigSourceSplunkHecList;
    putSplunkHec(value: ObservabilityPipelineConfigSourceSplunkHec[] | cdktn.IResolvable): void;
    resetSplunkHec(): void;
    get splunkHecInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceSplunkHec[] | undefined;
    private _splunkTcp;
    get splunkTcp(): ObservabilityPipelineConfigSourceSplunkTcpList;
    putSplunkTcp(value: ObservabilityPipelineConfigSourceSplunkTcp[] | cdktn.IResolvable): void;
    resetSplunkTcp(): void;
    get splunkTcpInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceSplunkTcp[] | undefined;
    private _sumoLogic;
    get sumoLogic(): ObservabilityPipelineConfigSourceSumoLogicList;
    putSumoLogic(value: ObservabilityPipelineConfigSourceSumoLogic[] | cdktn.IResolvable): void;
    resetSumoLogic(): void;
    get sumoLogicInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceSumoLogic[] | undefined;
    private _syslogNg;
    get syslogNg(): ObservabilityPipelineConfigSourceSyslogNgList;
    putSyslogNg(value: ObservabilityPipelineConfigSourceSyslogNg[] | cdktn.IResolvable): void;
    resetSyslogNg(): void;
    get syslogNgInput(): cdktn.IResolvable | ObservabilityPipelineConfigSourceSyslogNg[] | undefined;
}
export declare class ObservabilityPipelineConfigSourceList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigSource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigSourceOutputReference;
}
export interface ObservabilityPipelineConfigA {
    /**
    * The type of data being ingested. Defaults to `logs` if not specified. Valid values are `logs`, `metrics`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#pipeline_type ObservabilityPipeline#pipeline_type}
    */
    readonly pipelineType?: string;
    /**
    * Set to `true` to continue using the legacy search syntax while migrating filter queries. After migrating all queries to the new syntax, set to `false`. The legacy syntax is deprecated and will eventually be removed. Requires Observability Pipelines Worker 2.11 or later. See https://docs.datadoghq.com/observability_pipelines/guide/upgrade_your_filter_queries_to_the_new_search_syntax/ for more information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#use_legacy_search_syntax ObservabilityPipeline#use_legacy_search_syntax}
    */
    readonly useLegacySearchSyntax?: boolean | cdktn.IResolvable;
    /**
    * destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#destination ObservabilityPipeline#destination}
    */
    readonly destination?: ObservabilityPipelineConfigDestination[] | cdktn.IResolvable;
    /**
    * processor_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#processor_group ObservabilityPipeline#processor_group}
    */
    readonly processorGroup?: ObservabilityPipelineConfigProcessorGroup[] | cdktn.IResolvable;
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#source ObservabilityPipeline#source}
    */
    readonly source?: ObservabilityPipelineConfigSource[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigAToTerraform(struct?: ObservabilityPipelineConfigA | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigAToHclTerraform(struct?: ObservabilityPipelineConfigA | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigA | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigA | cdktn.IResolvable | undefined);
    private _pipelineType?;
    get pipelineType(): string;
    set pipelineType(value: string);
    resetPipelineType(): void;
    get pipelineTypeInput(): string | undefined;
    private _useLegacySearchSyntax?;
    get useLegacySearchSyntax(): boolean | cdktn.IResolvable;
    set useLegacySearchSyntax(value: boolean | cdktn.IResolvable);
    resetUseLegacySearchSyntax(): void;
    get useLegacySearchSyntaxInput(): boolean | cdktn.IResolvable | undefined;
    private _destination;
    get destination(): ObservabilityPipelineConfigDestinationList;
    putDestination(value: ObservabilityPipelineConfigDestination[] | cdktn.IResolvable): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestination[] | undefined;
    private _processorGroup;
    get processorGroup(): ObservabilityPipelineConfigProcessorGroupList;
    putProcessorGroup(value: ObservabilityPipelineConfigProcessorGroup[] | cdktn.IResolvable): void;
    resetProcessorGroup(): void;
    get processorGroupInput(): cdktn.IResolvable | ObservabilityPipelineConfigProcessorGroup[] | undefined;
    private _source;
    get source(): ObservabilityPipelineConfigSourceList;
    putSource(value: ObservabilityPipelineConfigSource[] | cdktn.IResolvable): void;
    resetSource(): void;
    get sourceInput(): cdktn.IResolvable | ObservabilityPipelineConfigSource[] | undefined;
}
export declare class ObservabilityPipelineConfigAList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigA[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigAOutputReference;
}
