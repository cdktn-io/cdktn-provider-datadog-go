/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
export interface ObservabilityPipelineConfigDestinationAmazonOpensearchAuth {
    /**
    * ARN of the role to assume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#assume_role ObservabilityPipeline#assume_role}
    */
    readonly assumeRole?: string;
    /**
    * AWS region override (if applicable).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#aws_region ObservabilityPipeline#aws_region}
    */
    readonly awsRegion?: string;
    /**
    * External ID for assumed role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#external_id ObservabilityPipeline#external_id}
    */
    readonly externalId?: string;
    /**
    * Session name for assumed role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#session_name ObservabilityPipeline#session_name}
    */
    readonly sessionName?: string;
    /**
    * The authentication strategy to use (e.g. aws or basic).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#strategy ObservabilityPipeline#strategy}
    */
    readonly strategy: string;
}
export declare function observabilityPipelineConfigDestinationAmazonOpensearchAuthToTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonOpensearchAuth | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationAmazonOpensearchAuthToHclTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonOpensearchAuth | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationAmazonOpensearchAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationAmazonOpensearchAuth | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationAmazonOpensearchAuth | cdktn.IResolvable | undefined);
    private _assumeRole?;
    get assumeRole(): string;
    set assumeRole(value: string);
    resetAssumeRole(): void;
    get assumeRoleInput(): string | undefined;
    private _awsRegion?;
    get awsRegion(): string;
    set awsRegion(value: string);
    resetAwsRegion(): void;
    get awsRegionInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _sessionName?;
    get sessionName(): string;
    set sessionName(value: string);
    resetSessionName(): void;
    get sessionNameInput(): string | undefined;
    private _strategy?;
    get strategy(): string;
    set strategy(value: string);
    get strategyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationAmazonOpensearchAuthList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationAmazonOpensearchAuth[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationAmazonOpensearchAuthOutputReference;
}
export interface ObservabilityPipelineConfigDestinationAmazonOpensearchBufferDisk {
    /**
    * Maximum size of the disk buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationAmazonOpensearchBufferDiskToTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonOpensearchBufferDisk | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationAmazonOpensearchBufferDiskToHclTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonOpensearchBufferDisk | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationAmazonOpensearchBufferDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationAmazonOpensearchBufferDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationAmazonOpensearchBufferDisk | cdktn.IResolvable | undefined);
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationAmazonOpensearchBufferDiskList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationAmazonOpensearchBufferDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationAmazonOpensearchBufferDiskOutputReference;
}
export interface ObservabilityPipelineConfigDestinationAmazonOpensearchBufferMemory {
    /**
    * Maximum events for the memory buffer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_events ObservabilityPipeline#max_events}
    */
    readonly maxEvents?: number;
    /**
    * Maximum size of the memory buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationAmazonOpensearchBufferMemoryToTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonOpensearchBufferMemory | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationAmazonOpensearchBufferMemoryToHclTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonOpensearchBufferMemory | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationAmazonOpensearchBufferMemoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationAmazonOpensearchBufferMemory | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationAmazonOpensearchBufferMemory | cdktn.IResolvable | undefined);
    private _maxEvents?;
    get maxEvents(): number;
    set maxEvents(value: number);
    resetMaxEvents(): void;
    get maxEventsInput(): number | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationAmazonOpensearchBufferMemoryList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationAmazonOpensearchBufferMemory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationAmazonOpensearchBufferMemoryOutputReference;
}
export interface ObservabilityPipelineConfigDestinationAmazonOpensearchBuffer {
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#disk ObservabilityPipeline#disk}
    */
    readonly disk?: ObservabilityPipelineConfigDestinationAmazonOpensearchBufferDisk[] | cdktn.IResolvable;
    /**
    * memory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#memory ObservabilityPipeline#memory}
    */
    readonly memory?: ObservabilityPipelineConfigDestinationAmazonOpensearchBufferMemory[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationAmazonOpensearchBufferToTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonOpensearchBuffer | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationAmazonOpensearchBufferToHclTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonOpensearchBuffer | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationAmazonOpensearchBufferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationAmazonOpensearchBuffer | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationAmazonOpensearchBuffer | cdktn.IResolvable | undefined);
    private _disk;
    get disk(): ObservabilityPipelineConfigDestinationAmazonOpensearchBufferDiskList;
    putDisk(value: ObservabilityPipelineConfigDestinationAmazonOpensearchBufferDisk[] | cdktn.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationAmazonOpensearchBufferDisk[] | undefined;
    private _memory;
    get memory(): ObservabilityPipelineConfigDestinationAmazonOpensearchBufferMemoryList;
    putMemory(value: ObservabilityPipelineConfigDestinationAmazonOpensearchBufferMemory[] | cdktn.IResolvable): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationAmazonOpensearchBufferMemory[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationAmazonOpensearchBufferList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationAmazonOpensearchBuffer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationAmazonOpensearchBufferOutputReference;
}
export interface ObservabilityPipelineConfigDestinationAmazonOpensearch {
    /**
    * The index or datastream to write logs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#bulk_index ObservabilityPipeline#bulk_index}
    */
    readonly bulkIndex?: string;
    /**
    * auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#auth ObservabilityPipeline#auth}
    */
    readonly auth?: ObservabilityPipelineConfigDestinationAmazonOpensearchAuth[] | cdktn.IResolvable;
    /**
    * buffer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#buffer ObservabilityPipeline#buffer}
    */
    readonly buffer?: ObservabilityPipelineConfigDestinationAmazonOpensearchBuffer[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationAmazonOpensearchToTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonOpensearch | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationAmazonOpensearchToHclTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonOpensearch | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationAmazonOpensearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationAmazonOpensearch | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationAmazonOpensearch | cdktn.IResolvable | undefined);
    private _bulkIndex?;
    get bulkIndex(): string;
    set bulkIndex(value: string);
    resetBulkIndex(): void;
    get bulkIndexInput(): string | undefined;
    private _auth;
    get auth(): ObservabilityPipelineConfigDestinationAmazonOpensearchAuthList;
    putAuth(value: ObservabilityPipelineConfigDestinationAmazonOpensearchAuth[] | cdktn.IResolvable): void;
    resetAuth(): void;
    get authInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationAmazonOpensearchAuth[] | undefined;
    private _buffer;
    get buffer(): ObservabilityPipelineConfigDestinationAmazonOpensearchBufferList;
    putBuffer(value: ObservabilityPipelineConfigDestinationAmazonOpensearchBuffer[] | cdktn.IResolvable): void;
    resetBuffer(): void;
    get bufferInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationAmazonOpensearchBuffer[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationAmazonOpensearchList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationAmazonOpensearch[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationAmazonOpensearchOutputReference;
}
export interface ObservabilityPipelineConfigDestinationAmazonS3Auth {
    /**
    * The Amazon Resource Name (ARN) of the role to assume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#assume_role ObservabilityPipeline#assume_role}
    */
    readonly assumeRole?: string;
    /**
    * A unique identifier for cross-account role assumption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#external_id ObservabilityPipeline#external_id}
    */
    readonly externalId?: string;
    /**
    * A session identifier used for logging and tracing the assumed role session.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#session_name ObservabilityPipeline#session_name}
    */
    readonly sessionName?: string;
}
export declare function observabilityPipelineConfigDestinationAmazonS3AuthToTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonS3Auth | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationAmazonS3AuthToHclTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonS3Auth | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationAmazonS3AuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationAmazonS3Auth | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationAmazonS3Auth | cdktn.IResolvable | undefined);
    private _assumeRole?;
    get assumeRole(): string;
    set assumeRole(value: string);
    resetAssumeRole(): void;
    get assumeRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _sessionName?;
    get sessionName(): string;
    set sessionName(value: string);
    resetSessionName(): void;
    get sessionNameInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationAmazonS3AuthList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationAmazonS3Auth[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationAmazonS3AuthOutputReference;
}
export interface ObservabilityPipelineConfigDestinationAmazonS3BufferDisk {
    /**
    * Maximum size of the disk buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationAmazonS3BufferDiskToTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonS3BufferDisk | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationAmazonS3BufferDiskToHclTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonS3BufferDisk | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationAmazonS3BufferDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationAmazonS3BufferDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationAmazonS3BufferDisk | cdktn.IResolvable | undefined);
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationAmazonS3BufferDiskList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationAmazonS3BufferDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationAmazonS3BufferDiskOutputReference;
}
export interface ObservabilityPipelineConfigDestinationAmazonS3BufferMemory {
    /**
    * Maximum events for the memory buffer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_events ObservabilityPipeline#max_events}
    */
    readonly maxEvents?: number;
    /**
    * Maximum size of the memory buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationAmazonS3BufferMemoryToTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonS3BufferMemory | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationAmazonS3BufferMemoryToHclTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonS3BufferMemory | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationAmazonS3BufferMemoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationAmazonS3BufferMemory | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationAmazonS3BufferMemory | cdktn.IResolvable | undefined);
    private _maxEvents?;
    get maxEvents(): number;
    set maxEvents(value: number);
    resetMaxEvents(): void;
    get maxEventsInput(): number | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationAmazonS3BufferMemoryList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationAmazonS3BufferMemory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationAmazonS3BufferMemoryOutputReference;
}
export interface ObservabilityPipelineConfigDestinationAmazonS3Buffer {
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#disk ObservabilityPipeline#disk}
    */
    readonly disk?: ObservabilityPipelineConfigDestinationAmazonS3BufferDisk[] | cdktn.IResolvable;
    /**
    * memory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#memory ObservabilityPipeline#memory}
    */
    readonly memory?: ObservabilityPipelineConfigDestinationAmazonS3BufferMemory[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationAmazonS3BufferToTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonS3Buffer | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationAmazonS3BufferToHclTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonS3Buffer | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationAmazonS3BufferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationAmazonS3Buffer | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationAmazonS3Buffer | cdktn.IResolvable | undefined);
    private _disk;
    get disk(): ObservabilityPipelineConfigDestinationAmazonS3BufferDiskList;
    putDisk(value: ObservabilityPipelineConfigDestinationAmazonS3BufferDisk[] | cdktn.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationAmazonS3BufferDisk[] | undefined;
    private _memory;
    get memory(): ObservabilityPipelineConfigDestinationAmazonS3BufferMemoryList;
    putMemory(value: ObservabilityPipelineConfigDestinationAmazonS3BufferMemory[] | cdktn.IResolvable): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationAmazonS3BufferMemory[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationAmazonS3BufferList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationAmazonS3Buffer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationAmazonS3BufferOutputReference;
}
export interface ObservabilityPipelineConfigDestinationAmazonS3 {
    /**
    * S3 bucket name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#bucket ObservabilityPipeline#bucket}
    */
    readonly bucket: string;
    /**
    * Prefix for object keys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_prefix ObservabilityPipeline#key_prefix}
    */
    readonly keyPrefix: string;
    /**
    * AWS region of the S3 bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#region ObservabilityPipeline#region}
    */
    readonly region: string;
    /**
    * S3 storage class. Valid values are `STANDARD`, `REDUCED_REDUNDANCY`, `INTELLIGENT_TIERING`, `STANDARD_IA`, `EXPRESS_ONEZONE`, `ONEZONE_IA`, `GLACIER`, `GLACIER_IR`, `DEEP_ARCHIVE`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#storage_class ObservabilityPipeline#storage_class}
    */
    readonly storageClass: string;
    /**
    * auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#auth ObservabilityPipeline#auth}
    */
    readonly auth?: ObservabilityPipelineConfigDestinationAmazonS3Auth[] | cdktn.IResolvable;
    /**
    * buffer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#buffer ObservabilityPipeline#buffer}
    */
    readonly buffer?: ObservabilityPipelineConfigDestinationAmazonS3Buffer[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationAmazonS3ToTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonS3 | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationAmazonS3ToHclTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonS3 | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationAmazonS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationAmazonS3 | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationAmazonS3 | cdktn.IResolvable | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _keyPrefix?;
    get keyPrefix(): string;
    set keyPrefix(value: string);
    get keyPrefixInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _storageClass?;
    get storageClass(): string;
    set storageClass(value: string);
    get storageClassInput(): string | undefined;
    private _auth;
    get auth(): ObservabilityPipelineConfigDestinationAmazonS3AuthList;
    putAuth(value: ObservabilityPipelineConfigDestinationAmazonS3Auth[] | cdktn.IResolvable): void;
    resetAuth(): void;
    get authInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationAmazonS3Auth[] | undefined;
    private _buffer;
    get buffer(): ObservabilityPipelineConfigDestinationAmazonS3BufferList;
    putBuffer(value: ObservabilityPipelineConfigDestinationAmazonS3Buffer[] | cdktn.IResolvable): void;
    resetBuffer(): void;
    get bufferInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationAmazonS3Buffer[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationAmazonS3List extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationAmazonS3[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationAmazonS3OutputReference;
}
export interface ObservabilityPipelineConfigDestinationAmazonSecurityLakeAuth {
    /**
    * The Amazon Resource Name (ARN) of the role to assume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#assume_role ObservabilityPipeline#assume_role}
    */
    readonly assumeRole?: string;
    /**
    * A unique identifier for cross-account role assumption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#external_id ObservabilityPipeline#external_id}
    */
    readonly externalId?: string;
    /**
    * A session identifier used for logging and tracing the assumed role session.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#session_name ObservabilityPipeline#session_name}
    */
    readonly sessionName?: string;
}
export declare function observabilityPipelineConfigDestinationAmazonSecurityLakeAuthToTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonSecurityLakeAuth | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationAmazonSecurityLakeAuthToHclTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonSecurityLakeAuth | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationAmazonSecurityLakeAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationAmazonSecurityLakeAuth | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationAmazonSecurityLakeAuth | cdktn.IResolvable | undefined);
    private _assumeRole?;
    get assumeRole(): string;
    set assumeRole(value: string);
    resetAssumeRole(): void;
    get assumeRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _sessionName?;
    get sessionName(): string;
    set sessionName(value: string);
    resetSessionName(): void;
    get sessionNameInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationAmazonSecurityLakeAuthList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationAmazonSecurityLakeAuth[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationAmazonSecurityLakeAuthOutputReference;
}
export interface ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferDisk {
    /**
    * Maximum size of the disk buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationAmazonSecurityLakeBufferDiskToTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferDisk | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationAmazonSecurityLakeBufferDiskToHclTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferDisk | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferDisk | cdktn.IResolvable | undefined);
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferDiskList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferDiskOutputReference;
}
export interface ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferMemory {
    /**
    * Maximum events for the memory buffer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_events ObservabilityPipeline#max_events}
    */
    readonly maxEvents?: number;
    /**
    * Maximum size of the memory buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationAmazonSecurityLakeBufferMemoryToTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferMemory | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationAmazonSecurityLakeBufferMemoryToHclTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferMemory | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferMemoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferMemory | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferMemory | cdktn.IResolvable | undefined);
    private _maxEvents?;
    get maxEvents(): number;
    set maxEvents(value: number);
    resetMaxEvents(): void;
    get maxEventsInput(): number | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferMemoryList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferMemory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferMemoryOutputReference;
}
export interface ObservabilityPipelineConfigDestinationAmazonSecurityLakeBuffer {
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#disk ObservabilityPipeline#disk}
    */
    readonly disk?: ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferDisk[] | cdktn.IResolvable;
    /**
    * memory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#memory ObservabilityPipeline#memory}
    */
    readonly memory?: ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferMemory[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationAmazonSecurityLakeBufferToTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonSecurityLakeBuffer | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationAmazonSecurityLakeBufferToHclTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonSecurityLakeBuffer | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationAmazonSecurityLakeBuffer | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationAmazonSecurityLakeBuffer | cdktn.IResolvable | undefined);
    private _disk;
    get disk(): ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferDiskList;
    putDisk(value: ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferDisk[] | cdktn.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferDisk[] | undefined;
    private _memory;
    get memory(): ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferMemoryList;
    putMemory(value: ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferMemory[] | cdktn.IResolvable): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferMemory[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationAmazonSecurityLakeBuffer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferOutputReference;
}
export interface ObservabilityPipelineConfigDestinationAmazonSecurityLakeTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigDestinationAmazonSecurityLakeTlsToTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonSecurityLakeTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationAmazonSecurityLakeTlsToHclTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonSecurityLakeTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationAmazonSecurityLakeTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationAmazonSecurityLakeTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationAmazonSecurityLakeTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationAmazonSecurityLakeTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationAmazonSecurityLakeTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationAmazonSecurityLakeTlsOutputReference;
}
export interface ObservabilityPipelineConfigDestinationAmazonSecurityLake {
    /**
    * Name of the Amazon S3 bucket in Security Lake (3-63 characters).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#bucket ObservabilityPipeline#bucket}
    */
    readonly bucket: string;
    /**
    * Custom source name for the logs in Security Lake.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#custom_source_name ObservabilityPipeline#custom_source_name}
    */
    readonly customSourceName: string;
    /**
    * AWS region of the Security Lake bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#region ObservabilityPipeline#region}
    */
    readonly region: string;
    /**
    * auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#auth ObservabilityPipeline#auth}
    */
    readonly auth?: ObservabilityPipelineConfigDestinationAmazonSecurityLakeAuth[] | cdktn.IResolvable;
    /**
    * buffer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#buffer ObservabilityPipeline#buffer}
    */
    readonly buffer?: ObservabilityPipelineConfigDestinationAmazonSecurityLakeBuffer[] | cdktn.IResolvable;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigDestinationAmazonSecurityLakeTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationAmazonSecurityLakeToTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonSecurityLake | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationAmazonSecurityLakeToHclTerraform(struct?: ObservabilityPipelineConfigDestinationAmazonSecurityLake | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationAmazonSecurityLakeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationAmazonSecurityLake | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationAmazonSecurityLake | cdktn.IResolvable | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _customSourceName?;
    get customSourceName(): string;
    set customSourceName(value: string);
    get customSourceNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _auth;
    get auth(): ObservabilityPipelineConfigDestinationAmazonSecurityLakeAuthList;
    putAuth(value: ObservabilityPipelineConfigDestinationAmazonSecurityLakeAuth[] | cdktn.IResolvable): void;
    resetAuth(): void;
    get authInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationAmazonSecurityLakeAuth[] | undefined;
    private _buffer;
    get buffer(): ObservabilityPipelineConfigDestinationAmazonSecurityLakeBufferList;
    putBuffer(value: ObservabilityPipelineConfigDestinationAmazonSecurityLakeBuffer[] | cdktn.IResolvable): void;
    resetBuffer(): void;
    get bufferInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationAmazonSecurityLakeBuffer[] | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigDestinationAmazonSecurityLakeTlsList;
    putTls(value: ObservabilityPipelineConfigDestinationAmazonSecurityLakeTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationAmazonSecurityLakeTls[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationAmazonSecurityLakeList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationAmazonSecurityLake[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationAmazonSecurityLakeOutputReference;
}
export interface ObservabilityPipelineConfigDestinationAzureStorageBufferDisk {
    /**
    * Maximum size of the disk buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationAzureStorageBufferDiskToTerraform(struct?: ObservabilityPipelineConfigDestinationAzureStorageBufferDisk | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationAzureStorageBufferDiskToHclTerraform(struct?: ObservabilityPipelineConfigDestinationAzureStorageBufferDisk | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationAzureStorageBufferDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationAzureStorageBufferDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationAzureStorageBufferDisk | cdktn.IResolvable | undefined);
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationAzureStorageBufferDiskList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationAzureStorageBufferDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationAzureStorageBufferDiskOutputReference;
}
export interface ObservabilityPipelineConfigDestinationAzureStorageBufferMemory {
    /**
    * Maximum events for the memory buffer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_events ObservabilityPipeline#max_events}
    */
    readonly maxEvents?: number;
    /**
    * Maximum size of the memory buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationAzureStorageBufferMemoryToTerraform(struct?: ObservabilityPipelineConfigDestinationAzureStorageBufferMemory | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationAzureStorageBufferMemoryToHclTerraform(struct?: ObservabilityPipelineConfigDestinationAzureStorageBufferMemory | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationAzureStorageBufferMemoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationAzureStorageBufferMemory | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationAzureStorageBufferMemory | cdktn.IResolvable | undefined);
    private _maxEvents?;
    get maxEvents(): number;
    set maxEvents(value: number);
    resetMaxEvents(): void;
    get maxEventsInput(): number | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationAzureStorageBufferMemoryList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationAzureStorageBufferMemory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationAzureStorageBufferMemoryOutputReference;
}
export interface ObservabilityPipelineConfigDestinationAzureStorageBuffer {
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#disk ObservabilityPipeline#disk}
    */
    readonly disk?: ObservabilityPipelineConfigDestinationAzureStorageBufferDisk[] | cdktn.IResolvable;
    /**
    * memory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#memory ObservabilityPipeline#memory}
    */
    readonly memory?: ObservabilityPipelineConfigDestinationAzureStorageBufferMemory[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationAzureStorageBufferToTerraform(struct?: ObservabilityPipelineConfigDestinationAzureStorageBuffer | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationAzureStorageBufferToHclTerraform(struct?: ObservabilityPipelineConfigDestinationAzureStorageBuffer | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationAzureStorageBufferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationAzureStorageBuffer | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationAzureStorageBuffer | cdktn.IResolvable | undefined);
    private _disk;
    get disk(): ObservabilityPipelineConfigDestinationAzureStorageBufferDiskList;
    putDisk(value: ObservabilityPipelineConfigDestinationAzureStorageBufferDisk[] | cdktn.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationAzureStorageBufferDisk[] | undefined;
    private _memory;
    get memory(): ObservabilityPipelineConfigDestinationAzureStorageBufferMemoryList;
    putMemory(value: ObservabilityPipelineConfigDestinationAzureStorageBufferMemory[] | cdktn.IResolvable): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationAzureStorageBufferMemory[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationAzureStorageBufferList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationAzureStorageBuffer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationAzureStorageBufferOutputReference;
}
export interface ObservabilityPipelineConfigDestinationAzureStorage {
    /**
    * Optional prefix for blobs written to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#blob_prefix ObservabilityPipeline#blob_prefix}
    */
    readonly blobPrefix?: string;
    /**
    * The name of the Azure Blob Storage container to store logs in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#container_name ObservabilityPipeline#container_name}
    */
    readonly containerName: string;
    /**
    * buffer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#buffer ObservabilityPipeline#buffer}
    */
    readonly buffer?: ObservabilityPipelineConfigDestinationAzureStorageBuffer[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationAzureStorageToTerraform(struct?: ObservabilityPipelineConfigDestinationAzureStorage | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationAzureStorageToHclTerraform(struct?: ObservabilityPipelineConfigDestinationAzureStorage | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationAzureStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationAzureStorage | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationAzureStorage | cdktn.IResolvable | undefined);
    private _blobPrefix?;
    get blobPrefix(): string;
    set blobPrefix(value: string);
    resetBlobPrefix(): void;
    get blobPrefixInput(): string | undefined;
    private _containerName?;
    get containerName(): string;
    set containerName(value: string);
    get containerNameInput(): string | undefined;
    private _buffer;
    get buffer(): ObservabilityPipelineConfigDestinationAzureStorageBufferList;
    putBuffer(value: ObservabilityPipelineConfigDestinationAzureStorageBuffer[] | cdktn.IResolvable): void;
    resetBuffer(): void;
    get bufferInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationAzureStorageBuffer[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationAzureStorageList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationAzureStorage[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationAzureStorageOutputReference;
}
export interface ObservabilityPipelineConfigDestinationCloudPrem {
    /**
    * Name of the environment variable or secret that holds the endpoint URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#endpoint_url_key ObservabilityPipeline#endpoint_url_key}
    */
    readonly endpointUrlKey?: string;
}
export declare function observabilityPipelineConfigDestinationCloudPremToTerraform(struct?: ObservabilityPipelineConfigDestinationCloudPrem | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationCloudPremToHclTerraform(struct?: ObservabilityPipelineConfigDestinationCloudPrem | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationCloudPremOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationCloudPrem | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationCloudPrem | cdktn.IResolvable | undefined);
    private _endpointUrlKey?;
    get endpointUrlKey(): string;
    set endpointUrlKey(value: string);
    resetEndpointUrlKey(): void;
    get endpointUrlKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationCloudPremList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationCloudPrem[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationCloudPremOutputReference;
}
export interface ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferDisk {
    /**
    * Maximum size of the disk buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferDiskToTerraform(struct?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferDisk | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferDiskToHclTerraform(struct?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferDisk | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferDisk | cdktn.IResolvable | undefined);
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferDiskList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferDiskOutputReference;
}
export interface ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferMemory {
    /**
    * Maximum events for the memory buffer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_events ObservabilityPipeline#max_events}
    */
    readonly maxEvents?: number;
    /**
    * Maximum size of the memory buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferMemoryToTerraform(struct?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferMemory | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferMemoryToHclTerraform(struct?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferMemory | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferMemoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferMemory | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferMemory | cdktn.IResolvable | undefined);
    private _maxEvents?;
    get maxEvents(): number;
    set maxEvents(value: number);
    resetMaxEvents(): void;
    get maxEventsInput(): number | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferMemoryList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferMemory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferMemoryOutputReference;
}
export interface ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBuffer {
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#disk ObservabilityPipeline#disk}
    */
    readonly disk?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferDisk[] | cdktn.IResolvable;
    /**
    * memory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#memory ObservabilityPipeline#memory}
    */
    readonly memory?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferMemory[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferToTerraform(struct?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBuffer | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferToHclTerraform(struct?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBuffer | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBuffer | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBuffer | cdktn.IResolvable | undefined);
    private _disk;
    get disk(): ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferDiskList;
    putDisk(value: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferDisk[] | cdktn.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferDisk[] | undefined;
    private _memory;
    get memory(): ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferMemoryList;
    putMemory(value: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferMemory[] | cdktn.IResolvable): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferMemory[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBuffer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferOutputReference;
}
export interface ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemCompression {
    /**
    * Compression algorithm for log events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#algorithm ObservabilityPipeline#algorithm}
    */
    readonly algorithm: string;
    /**
    * Compression level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#level ObservabilityPipeline#level}
    */
    readonly level?: number;
}
export declare function observabilityPipelineConfigDestinationCrowdstrikeNextGenSiemCompressionToTerraform(struct?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemCompression | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationCrowdstrikeNextGenSiemCompressionToHclTerraform(struct?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemCompression | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemCompressionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemCompression | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemCompression | cdktn.IResolvable | undefined);
    private _algorithm?;
    get algorithm(): string;
    set algorithm(value: string);
    get algorithmInput(): string | undefined;
    private _level?;
    get level(): number;
    set level(value: number);
    resetLevel(): void;
    get levelInput(): number | undefined;
}
export declare class ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemCompressionList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemCompression[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemCompressionOutputReference;
}
export interface ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigDestinationCrowdstrikeNextGenSiemTlsToTerraform(struct?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationCrowdstrikeNextGenSiemTlsToHclTerraform(struct?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemTlsOutputReference;
}
export interface ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiem {
    /**
    * Encoding format for log events. Valid values are `json`, `raw_message`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#encoding ObservabilityPipeline#encoding}
    */
    readonly encoding: string;
    /**
    * Name of the environment variable or secret that holds the endpoint URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#endpoint_url_key ObservabilityPipeline#endpoint_url_key}
    */
    readonly endpointUrlKey?: string;
    /**
    * Name of the environment variable or secret that holds the authentication token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#token_key ObservabilityPipeline#token_key}
    */
    readonly tokenKey?: string;
    /**
    * buffer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#buffer ObservabilityPipeline#buffer}
    */
    readonly buffer?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBuffer[] | cdktn.IResolvable;
    /**
    * compression block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#compression ObservabilityPipeline#compression}
    */
    readonly compression?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemCompression[] | cdktn.IResolvable;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationCrowdstrikeNextGenSiemToTerraform(struct?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiem | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationCrowdstrikeNextGenSiemToHclTerraform(struct?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiem | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiem | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiem | cdktn.IResolvable | undefined);
    private _encoding?;
    get encoding(): string;
    set encoding(value: string);
    get encodingInput(): string | undefined;
    private _endpointUrlKey?;
    get endpointUrlKey(): string;
    set endpointUrlKey(value: string);
    resetEndpointUrlKey(): void;
    get endpointUrlKeyInput(): string | undefined;
    private _tokenKey?;
    get tokenKey(): string;
    set tokenKey(value: string);
    resetTokenKey(): void;
    get tokenKeyInput(): string | undefined;
    private _buffer;
    get buffer(): ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBufferList;
    putBuffer(value: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBuffer[] | cdktn.IResolvable): void;
    resetBuffer(): void;
    get bufferInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemBuffer[] | undefined;
    private _compression;
    get compression(): ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemCompressionList;
    putCompression(value: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemCompression[] | cdktn.IResolvable): void;
    resetCompression(): void;
    get compressionInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemCompression[] | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemTlsList;
    putTls(value: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemTls[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiem[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationCrowdstrikeNextGenSiemOutputReference;
}
export interface ObservabilityPipelineConfigDestinationDatadogLogsBufferDisk {
    /**
    * Maximum size of the disk buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationDatadogLogsBufferDiskToTerraform(struct?: ObservabilityPipelineConfigDestinationDatadogLogsBufferDisk | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationDatadogLogsBufferDiskToHclTerraform(struct?: ObservabilityPipelineConfigDestinationDatadogLogsBufferDisk | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationDatadogLogsBufferDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationDatadogLogsBufferDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationDatadogLogsBufferDisk | cdktn.IResolvable | undefined);
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationDatadogLogsBufferDiskList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationDatadogLogsBufferDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationDatadogLogsBufferDiskOutputReference;
}
export interface ObservabilityPipelineConfigDestinationDatadogLogsBufferMemory {
    /**
    * Maximum events for the memory buffer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_events ObservabilityPipeline#max_events}
    */
    readonly maxEvents?: number;
    /**
    * Maximum size of the memory buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationDatadogLogsBufferMemoryToTerraform(struct?: ObservabilityPipelineConfigDestinationDatadogLogsBufferMemory | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationDatadogLogsBufferMemoryToHclTerraform(struct?: ObservabilityPipelineConfigDestinationDatadogLogsBufferMemory | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationDatadogLogsBufferMemoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationDatadogLogsBufferMemory | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationDatadogLogsBufferMemory | cdktn.IResolvable | undefined);
    private _maxEvents?;
    get maxEvents(): number;
    set maxEvents(value: number);
    resetMaxEvents(): void;
    get maxEventsInput(): number | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationDatadogLogsBufferMemoryList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationDatadogLogsBufferMemory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationDatadogLogsBufferMemoryOutputReference;
}
export interface ObservabilityPipelineConfigDestinationDatadogLogsBuffer {
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#disk ObservabilityPipeline#disk}
    */
    readonly disk?: ObservabilityPipelineConfigDestinationDatadogLogsBufferDisk[] | cdktn.IResolvable;
    /**
    * memory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#memory ObservabilityPipeline#memory}
    */
    readonly memory?: ObservabilityPipelineConfigDestinationDatadogLogsBufferMemory[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationDatadogLogsBufferToTerraform(struct?: ObservabilityPipelineConfigDestinationDatadogLogsBuffer | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationDatadogLogsBufferToHclTerraform(struct?: ObservabilityPipelineConfigDestinationDatadogLogsBuffer | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationDatadogLogsBufferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationDatadogLogsBuffer | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationDatadogLogsBuffer | cdktn.IResolvable | undefined);
    private _disk;
    get disk(): ObservabilityPipelineConfigDestinationDatadogLogsBufferDiskList;
    putDisk(value: ObservabilityPipelineConfigDestinationDatadogLogsBufferDisk[] | cdktn.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationDatadogLogsBufferDisk[] | undefined;
    private _memory;
    get memory(): ObservabilityPipelineConfigDestinationDatadogLogsBufferMemoryList;
    putMemory(value: ObservabilityPipelineConfigDestinationDatadogLogsBufferMemory[] | cdktn.IResolvable): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationDatadogLogsBufferMemory[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationDatadogLogsBufferList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationDatadogLogsBuffer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationDatadogLogsBufferOutputReference;
}
export interface ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferDisk {
    /**
    * Maximum size of the disk buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationDatadogLogsRoutesBufferDiskToTerraform(struct?: ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferDisk | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationDatadogLogsRoutesBufferDiskToHclTerraform(struct?: ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferDisk | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferDisk | cdktn.IResolvable | undefined);
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferDiskList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferDiskOutputReference;
}
export interface ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferMemory {
    /**
    * Maximum events for the memory buffer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_events ObservabilityPipeline#max_events}
    */
    readonly maxEvents?: number;
    /**
    * Maximum size of the memory buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationDatadogLogsRoutesBufferMemoryToTerraform(struct?: ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferMemory | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationDatadogLogsRoutesBufferMemoryToHclTerraform(struct?: ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferMemory | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferMemoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferMemory | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferMemory | cdktn.IResolvable | undefined);
    private _maxEvents?;
    get maxEvents(): number;
    set maxEvents(value: number);
    resetMaxEvents(): void;
    get maxEventsInput(): number | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferMemoryList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferMemory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferMemoryOutputReference;
}
export interface ObservabilityPipelineConfigDestinationDatadogLogsRoutesBuffer {
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#disk ObservabilityPipeline#disk}
    */
    readonly disk?: ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferDisk[] | cdktn.IResolvable;
    /**
    * memory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#memory ObservabilityPipeline#memory}
    */
    readonly memory?: ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferMemory[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationDatadogLogsRoutesBufferToTerraform(struct?: ObservabilityPipelineConfigDestinationDatadogLogsRoutesBuffer | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationDatadogLogsRoutesBufferToHclTerraform(struct?: ObservabilityPipelineConfigDestinationDatadogLogsRoutesBuffer | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationDatadogLogsRoutesBuffer | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationDatadogLogsRoutesBuffer | cdktn.IResolvable | undefined);
    private _disk;
    get disk(): ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferDiskList;
    putDisk(value: ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferDisk[] | cdktn.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferDisk[] | undefined;
    private _memory;
    get memory(): ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferMemoryList;
    putMemory(value: ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferMemory[] | cdktn.IResolvable): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferMemory[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationDatadogLogsRoutesBuffer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferOutputReference;
}
export interface ObservabilityPipelineConfigDestinationDatadogLogsRoutes {
    /**
    * Name of the environment variable or secret that stores the Datadog API key used by this route.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#api_key_key ObservabilityPipeline#api_key_key}
    */
    readonly apiKeyKey: string;
    /**
    * A Datadog search query that determines which logs are forwarded using this route.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#include ObservabilityPipeline#include}
    */
    readonly include: string;
    /**
    * Unique identifier for this route within the destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#route_id ObservabilityPipeline#route_id}
    */
    readonly routeId: string;
    /**
    * Datadog site where matching logs are sent (for example, `us1`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#site ObservabilityPipeline#site}
    */
    readonly site: string;
    /**
    * buffer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#buffer ObservabilityPipeline#buffer}
    */
    readonly buffer?: ObservabilityPipelineConfigDestinationDatadogLogsRoutesBuffer[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationDatadogLogsRoutesToTerraform(struct?: ObservabilityPipelineConfigDestinationDatadogLogsRoutes | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationDatadogLogsRoutesToHclTerraform(struct?: ObservabilityPipelineConfigDestinationDatadogLogsRoutes | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationDatadogLogsRoutesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationDatadogLogsRoutes | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationDatadogLogsRoutes | cdktn.IResolvable | undefined);
    private _apiKeyKey?;
    get apiKeyKey(): string;
    set apiKeyKey(value: string);
    get apiKeyKeyInput(): string | undefined;
    private _include?;
    get include(): string;
    set include(value: string);
    get includeInput(): string | undefined;
    private _routeId?;
    get routeId(): string;
    set routeId(value: string);
    get routeIdInput(): string | undefined;
    private _site?;
    get site(): string;
    set site(value: string);
    get siteInput(): string | undefined;
    private _buffer;
    get buffer(): ObservabilityPipelineConfigDestinationDatadogLogsRoutesBufferList;
    putBuffer(value: ObservabilityPipelineConfigDestinationDatadogLogsRoutesBuffer[] | cdktn.IResolvable): void;
    resetBuffer(): void;
    get bufferInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationDatadogLogsRoutesBuffer[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationDatadogLogsRoutesList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationDatadogLogsRoutes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationDatadogLogsRoutesOutputReference;
}
export interface ObservabilityPipelineConfigDestinationDatadogLogs {
    /**
    * buffer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#buffer ObservabilityPipeline#buffer}
    */
    readonly buffer?: ObservabilityPipelineConfigDestinationDatadogLogsBuffer[] | cdktn.IResolvable;
    /**
    * routes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#routes ObservabilityPipeline#routes}
    */
    readonly routes?: ObservabilityPipelineConfigDestinationDatadogLogsRoutes[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationDatadogLogsToTerraform(struct?: ObservabilityPipelineConfigDestinationDatadogLogs | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationDatadogLogsToHclTerraform(struct?: ObservabilityPipelineConfigDestinationDatadogLogs | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationDatadogLogsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationDatadogLogs | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationDatadogLogs | cdktn.IResolvable | undefined);
    private _buffer;
    get buffer(): ObservabilityPipelineConfigDestinationDatadogLogsBufferList;
    putBuffer(value: ObservabilityPipelineConfigDestinationDatadogLogsBuffer[] | cdktn.IResolvable): void;
    resetBuffer(): void;
    get bufferInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationDatadogLogsBuffer[] | undefined;
    private _routes;
    get routes(): ObservabilityPipelineConfigDestinationDatadogLogsRoutesList;
    putRoutes(value: ObservabilityPipelineConfigDestinationDatadogLogsRoutes[] | cdktn.IResolvable): void;
    resetRoutes(): void;
    get routesInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationDatadogLogsRoutes[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationDatadogLogsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationDatadogLogs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationDatadogLogsOutputReference;
}
export interface ObservabilityPipelineConfigDestinationDatadogMetrics {
}
export declare function observabilityPipelineConfigDestinationDatadogMetricsToTerraform(struct?: ObservabilityPipelineConfigDestinationDatadogMetrics | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationDatadogMetricsToHclTerraform(struct?: ObservabilityPipelineConfigDestinationDatadogMetrics | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationDatadogMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationDatadogMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationDatadogMetrics | cdktn.IResolvable | undefined);
}
export declare class ObservabilityPipelineConfigDestinationDatadogMetricsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationDatadogMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationDatadogMetricsOutputReference;
}
export interface ObservabilityPipelineConfigDestinationElasticsearchAuth {
    /**
    * Name of the environment variable or secret that holds the Elasticsearch password (used when strategy is `basic`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#password_key ObservabilityPipeline#password_key}
    */
    readonly passwordKey?: string;
    /**
    * The authentication strategy. Use `basic` for username/password. Valid values are `basic`, `aws`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#strategy ObservabilityPipeline#strategy}
    */
    readonly strategy: string;
    /**
    * Name of the environment variable or secret that holds the Elasticsearch username (used when strategy is `basic`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#username_key ObservabilityPipeline#username_key}
    */
    readonly usernameKey?: string;
}
export declare function observabilityPipelineConfigDestinationElasticsearchAuthToTerraform(struct?: ObservabilityPipelineConfigDestinationElasticsearchAuth | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationElasticsearchAuthToHclTerraform(struct?: ObservabilityPipelineConfigDestinationElasticsearchAuth | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationElasticsearchAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationElasticsearchAuth | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationElasticsearchAuth | cdktn.IResolvable | undefined);
    private _passwordKey?;
    get passwordKey(): string;
    set passwordKey(value: string);
    resetPasswordKey(): void;
    get passwordKeyInput(): string | undefined;
    private _strategy?;
    get strategy(): string;
    set strategy(value: string);
    get strategyInput(): string | undefined;
    private _usernameKey?;
    get usernameKey(): string;
    set usernameKey(value: string);
    resetUsernameKey(): void;
    get usernameKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationElasticsearchAuthList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationElasticsearchAuth[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationElasticsearchAuthOutputReference;
}
export interface ObservabilityPipelineConfigDestinationElasticsearchBufferDisk {
    /**
    * Maximum size of the disk buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationElasticsearchBufferDiskToTerraform(struct?: ObservabilityPipelineConfigDestinationElasticsearchBufferDisk | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationElasticsearchBufferDiskToHclTerraform(struct?: ObservabilityPipelineConfigDestinationElasticsearchBufferDisk | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationElasticsearchBufferDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationElasticsearchBufferDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationElasticsearchBufferDisk | cdktn.IResolvable | undefined);
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationElasticsearchBufferDiskList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationElasticsearchBufferDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationElasticsearchBufferDiskOutputReference;
}
export interface ObservabilityPipelineConfigDestinationElasticsearchBufferMemory {
    /**
    * Maximum events for the memory buffer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_events ObservabilityPipeline#max_events}
    */
    readonly maxEvents?: number;
    /**
    * Maximum size of the memory buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationElasticsearchBufferMemoryToTerraform(struct?: ObservabilityPipelineConfigDestinationElasticsearchBufferMemory | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationElasticsearchBufferMemoryToHclTerraform(struct?: ObservabilityPipelineConfigDestinationElasticsearchBufferMemory | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationElasticsearchBufferMemoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationElasticsearchBufferMemory | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationElasticsearchBufferMemory | cdktn.IResolvable | undefined);
    private _maxEvents?;
    get maxEvents(): number;
    set maxEvents(value: number);
    resetMaxEvents(): void;
    get maxEventsInput(): number | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationElasticsearchBufferMemoryList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationElasticsearchBufferMemory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationElasticsearchBufferMemoryOutputReference;
}
export interface ObservabilityPipelineConfigDestinationElasticsearchBuffer {
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#disk ObservabilityPipeline#disk}
    */
    readonly disk?: ObservabilityPipelineConfigDestinationElasticsearchBufferDisk[] | cdktn.IResolvable;
    /**
    * memory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#memory ObservabilityPipeline#memory}
    */
    readonly memory?: ObservabilityPipelineConfigDestinationElasticsearchBufferMemory[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationElasticsearchBufferToTerraform(struct?: ObservabilityPipelineConfigDestinationElasticsearchBuffer | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationElasticsearchBufferToHclTerraform(struct?: ObservabilityPipelineConfigDestinationElasticsearchBuffer | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationElasticsearchBufferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationElasticsearchBuffer | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationElasticsearchBuffer | cdktn.IResolvable | undefined);
    private _disk;
    get disk(): ObservabilityPipelineConfigDestinationElasticsearchBufferDiskList;
    putDisk(value: ObservabilityPipelineConfigDestinationElasticsearchBufferDisk[] | cdktn.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationElasticsearchBufferDisk[] | undefined;
    private _memory;
    get memory(): ObservabilityPipelineConfigDestinationElasticsearchBufferMemoryList;
    putMemory(value: ObservabilityPipelineConfigDestinationElasticsearchBufferMemory[] | cdktn.IResolvable): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationElasticsearchBufferMemory[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationElasticsearchBufferList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationElasticsearchBuffer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationElasticsearchBufferOutputReference;
}
export interface ObservabilityPipelineConfigDestinationElasticsearchDataStream {
    /**
    * The data stream dataset for your logs. This groups logs by their source or application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#dataset ObservabilityPipeline#dataset}
    */
    readonly dataset?: string;
    /**
    * The data stream type for your logs. This determines how logs are categorized within the data stream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#dtype ObservabilityPipeline#dtype}
    */
    readonly dtype?: string;
    /**
    * The data stream namespace for your logs. This separates logs into different environments or domains.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#namespace ObservabilityPipeline#namespace}
    */
    readonly namespace?: string;
}
export declare function observabilityPipelineConfigDestinationElasticsearchDataStreamToTerraform(struct?: ObservabilityPipelineConfigDestinationElasticsearchDataStream | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationElasticsearchDataStreamToHclTerraform(struct?: ObservabilityPipelineConfigDestinationElasticsearchDataStream | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationElasticsearchDataStreamOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationElasticsearchDataStream | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationElasticsearchDataStream | cdktn.IResolvable | undefined);
    private _dataset?;
    get dataset(): string;
    set dataset(value: string);
    resetDataset(): void;
    get datasetInput(): string | undefined;
    private _dtype?;
    get dtype(): string;
    set dtype(value: string);
    resetDtype(): void;
    get dtypeInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationElasticsearchDataStreamList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationElasticsearchDataStream[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationElasticsearchDataStreamOutputReference;
}
export interface ObservabilityPipelineConfigDestinationElasticsearch {
    /**
    * The Elasticsearch API version to use. Set to `auto` to auto-detect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#api_version ObservabilityPipeline#api_version}
    */
    readonly apiVersion?: string;
    /**
    * The index or datastream to write logs to in Elasticsearch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#bulk_index ObservabilityPipeline#bulk_index}
    */
    readonly bulkIndex?: string;
    /**
    * Name of the environment variable or secret that holds the Elasticsearch endpoint URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#endpoint_url_key ObservabilityPipeline#endpoint_url_key}
    */
    readonly endpointUrlKey?: string;
    /**
    * auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#auth ObservabilityPipeline#auth}
    */
    readonly auth?: ObservabilityPipelineConfigDestinationElasticsearchAuth[] | cdktn.IResolvable;
    /**
    * buffer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#buffer ObservabilityPipeline#buffer}
    */
    readonly buffer?: ObservabilityPipelineConfigDestinationElasticsearchBuffer[] | cdktn.IResolvable;
    /**
    * data_stream block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#data_stream ObservabilityPipeline#data_stream}
    */
    readonly dataStream?: ObservabilityPipelineConfigDestinationElasticsearchDataStream[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationElasticsearchToTerraform(struct?: ObservabilityPipelineConfigDestinationElasticsearch | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationElasticsearchToHclTerraform(struct?: ObservabilityPipelineConfigDestinationElasticsearch | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationElasticsearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationElasticsearch | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationElasticsearch | cdktn.IResolvable | undefined);
    private _apiVersion?;
    get apiVersion(): string;
    set apiVersion(value: string);
    resetApiVersion(): void;
    get apiVersionInput(): string | undefined;
    private _bulkIndex?;
    get bulkIndex(): string;
    set bulkIndex(value: string);
    resetBulkIndex(): void;
    get bulkIndexInput(): string | undefined;
    private _endpointUrlKey?;
    get endpointUrlKey(): string;
    set endpointUrlKey(value: string);
    resetEndpointUrlKey(): void;
    get endpointUrlKeyInput(): string | undefined;
    private _auth;
    get auth(): ObservabilityPipelineConfigDestinationElasticsearchAuthList;
    putAuth(value: ObservabilityPipelineConfigDestinationElasticsearchAuth[] | cdktn.IResolvable): void;
    resetAuth(): void;
    get authInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationElasticsearchAuth[] | undefined;
    private _buffer;
    get buffer(): ObservabilityPipelineConfigDestinationElasticsearchBufferList;
    putBuffer(value: ObservabilityPipelineConfigDestinationElasticsearchBuffer[] | cdktn.IResolvable): void;
    resetBuffer(): void;
    get bufferInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationElasticsearchBuffer[] | undefined;
    private _dataStream;
    get dataStream(): ObservabilityPipelineConfigDestinationElasticsearchDataStreamList;
    putDataStream(value: ObservabilityPipelineConfigDestinationElasticsearchDataStream[] | cdktn.IResolvable): void;
    resetDataStream(): void;
    get dataStreamInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationElasticsearchDataStream[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationElasticsearchList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationElasticsearch[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationElasticsearchOutputReference;
}
export interface ObservabilityPipelineConfigDestinationGoogleCloudStorageAuth {
    /**
    * Path to the Google Cloud service account key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#credentials_file ObservabilityPipeline#credentials_file}
    */
    readonly credentialsFile: string;
}
export declare function observabilityPipelineConfigDestinationGoogleCloudStorageAuthToTerraform(struct?: ObservabilityPipelineConfigDestinationGoogleCloudStorageAuth | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationGoogleCloudStorageAuthToHclTerraform(struct?: ObservabilityPipelineConfigDestinationGoogleCloudStorageAuth | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationGoogleCloudStorageAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationGoogleCloudStorageAuth | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationGoogleCloudStorageAuth | cdktn.IResolvable | undefined);
    private _credentialsFile?;
    get credentialsFile(): string;
    set credentialsFile(value: string);
    get credentialsFileInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationGoogleCloudStorageAuthList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationGoogleCloudStorageAuth[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationGoogleCloudStorageAuthOutputReference;
}
export interface ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferDisk {
    /**
    * Maximum size of the disk buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationGoogleCloudStorageBufferDiskToTerraform(struct?: ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferDisk | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationGoogleCloudStorageBufferDiskToHclTerraform(struct?: ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferDisk | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferDisk | cdktn.IResolvable | undefined);
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferDiskList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferDiskOutputReference;
}
export interface ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferMemory {
    /**
    * Maximum events for the memory buffer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_events ObservabilityPipeline#max_events}
    */
    readonly maxEvents?: number;
    /**
    * Maximum size of the memory buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationGoogleCloudStorageBufferMemoryToTerraform(struct?: ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferMemory | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationGoogleCloudStorageBufferMemoryToHclTerraform(struct?: ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferMemory | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferMemoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferMemory | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferMemory | cdktn.IResolvable | undefined);
    private _maxEvents?;
    get maxEvents(): number;
    set maxEvents(value: number);
    resetMaxEvents(): void;
    get maxEventsInput(): number | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferMemoryList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferMemory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferMemoryOutputReference;
}
export interface ObservabilityPipelineConfigDestinationGoogleCloudStorageBuffer {
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#disk ObservabilityPipeline#disk}
    */
    readonly disk?: ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferDisk[] | cdktn.IResolvable;
    /**
    * memory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#memory ObservabilityPipeline#memory}
    */
    readonly memory?: ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferMemory[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationGoogleCloudStorageBufferToTerraform(struct?: ObservabilityPipelineConfigDestinationGoogleCloudStorageBuffer | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationGoogleCloudStorageBufferToHclTerraform(struct?: ObservabilityPipelineConfigDestinationGoogleCloudStorageBuffer | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationGoogleCloudStorageBuffer | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationGoogleCloudStorageBuffer | cdktn.IResolvable | undefined);
    private _disk;
    get disk(): ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferDiskList;
    putDisk(value: ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferDisk[] | cdktn.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferDisk[] | undefined;
    private _memory;
    get memory(): ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferMemoryList;
    putMemory(value: ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferMemory[] | cdktn.IResolvable): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferMemory[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationGoogleCloudStorageBuffer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferOutputReference;
}
export interface ObservabilityPipelineConfigDestinationGoogleCloudStorageMetadata {
    /**
    * The metadata key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#name ObservabilityPipeline#name}
    */
    readonly name: string;
    /**
    * The metadata value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#value ObservabilityPipeline#value}
    */
    readonly value: string;
}
export declare function observabilityPipelineConfigDestinationGoogleCloudStorageMetadataToTerraform(struct?: ObservabilityPipelineConfigDestinationGoogleCloudStorageMetadata | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationGoogleCloudStorageMetadataToHclTerraform(struct?: ObservabilityPipelineConfigDestinationGoogleCloudStorageMetadata | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationGoogleCloudStorageMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationGoogleCloudStorageMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationGoogleCloudStorageMetadata | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationGoogleCloudStorageMetadataList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationGoogleCloudStorageMetadata[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationGoogleCloudStorageMetadataOutputReference;
}
export interface ObservabilityPipelineConfigDestinationGoogleCloudStorage {
    /**
    * Access control list setting for objects written to the bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#acl ObservabilityPipeline#acl}
    */
    readonly acl?: string;
    /**
    * Name of the GCS bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#bucket ObservabilityPipeline#bucket}
    */
    readonly bucket: string;
    /**
    * Optional prefix for object keys within the GCS bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_prefix ObservabilityPipeline#key_prefix}
    */
    readonly keyPrefix?: string;
    /**
    * Storage class used for objects stored in GCS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#storage_class ObservabilityPipeline#storage_class}
    */
    readonly storageClass: string;
    /**
    * auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#auth ObservabilityPipeline#auth}
    */
    readonly auth?: ObservabilityPipelineConfigDestinationGoogleCloudStorageAuth[] | cdktn.IResolvable;
    /**
    * buffer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#buffer ObservabilityPipeline#buffer}
    */
    readonly buffer?: ObservabilityPipelineConfigDestinationGoogleCloudStorageBuffer[] | cdktn.IResolvable;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#metadata ObservabilityPipeline#metadata}
    */
    readonly metadata?: ObservabilityPipelineConfigDestinationGoogleCloudStorageMetadata[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationGoogleCloudStorageToTerraform(struct?: ObservabilityPipelineConfigDestinationGoogleCloudStorage | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationGoogleCloudStorageToHclTerraform(struct?: ObservabilityPipelineConfigDestinationGoogleCloudStorage | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationGoogleCloudStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationGoogleCloudStorage | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationGoogleCloudStorage | cdktn.IResolvable | undefined);
    private _acl?;
    get acl(): string;
    set acl(value: string);
    resetAcl(): void;
    get aclInput(): string | undefined;
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _keyPrefix?;
    get keyPrefix(): string;
    set keyPrefix(value: string);
    resetKeyPrefix(): void;
    get keyPrefixInput(): string | undefined;
    private _storageClass?;
    get storageClass(): string;
    set storageClass(value: string);
    get storageClassInput(): string | undefined;
    private _auth;
    get auth(): ObservabilityPipelineConfigDestinationGoogleCloudStorageAuthList;
    putAuth(value: ObservabilityPipelineConfigDestinationGoogleCloudStorageAuth[] | cdktn.IResolvable): void;
    resetAuth(): void;
    get authInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationGoogleCloudStorageAuth[] | undefined;
    private _buffer;
    get buffer(): ObservabilityPipelineConfigDestinationGoogleCloudStorageBufferList;
    putBuffer(value: ObservabilityPipelineConfigDestinationGoogleCloudStorageBuffer[] | cdktn.IResolvable): void;
    resetBuffer(): void;
    get bufferInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationGoogleCloudStorageBuffer[] | undefined;
    private _metadata;
    get metadata(): ObservabilityPipelineConfigDestinationGoogleCloudStorageMetadataList;
    putMetadata(value: ObservabilityPipelineConfigDestinationGoogleCloudStorageMetadata[] | cdktn.IResolvable): void;
    resetMetadata(): void;
    get metadataInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationGoogleCloudStorageMetadata[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationGoogleCloudStorageList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationGoogleCloudStorage[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationGoogleCloudStorageOutputReference;
}
export interface ObservabilityPipelineConfigDestinationGooglePubsubAuth {
    /**
    * Path to the Google Cloud service account key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#credentials_file ObservabilityPipeline#credentials_file}
    */
    readonly credentialsFile: string;
}
export declare function observabilityPipelineConfigDestinationGooglePubsubAuthToTerraform(struct?: ObservabilityPipelineConfigDestinationGooglePubsubAuth | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationGooglePubsubAuthToHclTerraform(struct?: ObservabilityPipelineConfigDestinationGooglePubsubAuth | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationGooglePubsubAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationGooglePubsubAuth | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationGooglePubsubAuth | cdktn.IResolvable | undefined);
    private _credentialsFile?;
    get credentialsFile(): string;
    set credentialsFile(value: string);
    get credentialsFileInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationGooglePubsubAuthList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationGooglePubsubAuth[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationGooglePubsubAuthOutputReference;
}
export interface ObservabilityPipelineConfigDestinationGooglePubsubBufferDisk {
    /**
    * Maximum size of the disk buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationGooglePubsubBufferDiskToTerraform(struct?: ObservabilityPipelineConfigDestinationGooglePubsubBufferDisk | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationGooglePubsubBufferDiskToHclTerraform(struct?: ObservabilityPipelineConfigDestinationGooglePubsubBufferDisk | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationGooglePubsubBufferDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationGooglePubsubBufferDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationGooglePubsubBufferDisk | cdktn.IResolvable | undefined);
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationGooglePubsubBufferDiskList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationGooglePubsubBufferDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationGooglePubsubBufferDiskOutputReference;
}
export interface ObservabilityPipelineConfigDestinationGooglePubsubBufferMemory {
    /**
    * Maximum events for the memory buffer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_events ObservabilityPipeline#max_events}
    */
    readonly maxEvents?: number;
    /**
    * Maximum size of the memory buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationGooglePubsubBufferMemoryToTerraform(struct?: ObservabilityPipelineConfigDestinationGooglePubsubBufferMemory | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationGooglePubsubBufferMemoryToHclTerraform(struct?: ObservabilityPipelineConfigDestinationGooglePubsubBufferMemory | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationGooglePubsubBufferMemoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationGooglePubsubBufferMemory | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationGooglePubsubBufferMemory | cdktn.IResolvable | undefined);
    private _maxEvents?;
    get maxEvents(): number;
    set maxEvents(value: number);
    resetMaxEvents(): void;
    get maxEventsInput(): number | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationGooglePubsubBufferMemoryList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationGooglePubsubBufferMemory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationGooglePubsubBufferMemoryOutputReference;
}
export interface ObservabilityPipelineConfigDestinationGooglePubsubBuffer {
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#disk ObservabilityPipeline#disk}
    */
    readonly disk?: ObservabilityPipelineConfigDestinationGooglePubsubBufferDisk[] | cdktn.IResolvable;
    /**
    * memory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#memory ObservabilityPipeline#memory}
    */
    readonly memory?: ObservabilityPipelineConfigDestinationGooglePubsubBufferMemory[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationGooglePubsubBufferToTerraform(struct?: ObservabilityPipelineConfigDestinationGooglePubsubBuffer | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationGooglePubsubBufferToHclTerraform(struct?: ObservabilityPipelineConfigDestinationGooglePubsubBuffer | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationGooglePubsubBufferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationGooglePubsubBuffer | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationGooglePubsubBuffer | cdktn.IResolvable | undefined);
    private _disk;
    get disk(): ObservabilityPipelineConfigDestinationGooglePubsubBufferDiskList;
    putDisk(value: ObservabilityPipelineConfigDestinationGooglePubsubBufferDisk[] | cdktn.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationGooglePubsubBufferDisk[] | undefined;
    private _memory;
    get memory(): ObservabilityPipelineConfigDestinationGooglePubsubBufferMemoryList;
    putMemory(value: ObservabilityPipelineConfigDestinationGooglePubsubBufferMemory[] | cdktn.IResolvable): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationGooglePubsubBufferMemory[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationGooglePubsubBufferList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationGooglePubsubBuffer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationGooglePubsubBufferOutputReference;
}
export interface ObservabilityPipelineConfigDestinationGooglePubsubTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigDestinationGooglePubsubTlsToTerraform(struct?: ObservabilityPipelineConfigDestinationGooglePubsubTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationGooglePubsubTlsToHclTerraform(struct?: ObservabilityPipelineConfigDestinationGooglePubsubTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationGooglePubsubTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationGooglePubsubTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationGooglePubsubTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationGooglePubsubTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationGooglePubsubTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationGooglePubsubTlsOutputReference;
}
export interface ObservabilityPipelineConfigDestinationGooglePubsub {
    /**
    * Encoding format for log events. Valid values: `json`, `raw_message`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#encoding ObservabilityPipeline#encoding}
    */
    readonly encoding: string;
    /**
    * Name of the environment variable or secret that holds the Google Cloud Pub/Sub endpoint URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#endpoint_url_key ObservabilityPipeline#endpoint_url_key}
    */
    readonly endpointUrlKey?: string;
    /**
    * The Google Cloud project ID that owns the Pub/Sub topic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#project ObservabilityPipeline#project}
    */
    readonly project: string;
    /**
    * The Pub/Sub topic name to publish logs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#topic ObservabilityPipeline#topic}
    */
    readonly topic: string;
    /**
    * auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#auth ObservabilityPipeline#auth}
    */
    readonly auth?: ObservabilityPipelineConfigDestinationGooglePubsubAuth[] | cdktn.IResolvable;
    /**
    * buffer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#buffer ObservabilityPipeline#buffer}
    */
    readonly buffer?: ObservabilityPipelineConfigDestinationGooglePubsubBuffer[] | cdktn.IResolvable;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigDestinationGooglePubsubTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationGooglePubsubToTerraform(struct?: ObservabilityPipelineConfigDestinationGooglePubsub | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationGooglePubsubToHclTerraform(struct?: ObservabilityPipelineConfigDestinationGooglePubsub | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationGooglePubsubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationGooglePubsub | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationGooglePubsub | cdktn.IResolvable | undefined);
    private _encoding?;
    get encoding(): string;
    set encoding(value: string);
    get encodingInput(): string | undefined;
    private _endpointUrlKey?;
    get endpointUrlKey(): string;
    set endpointUrlKey(value: string);
    resetEndpointUrlKey(): void;
    get endpointUrlKeyInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _topic?;
    get topic(): string;
    set topic(value: string);
    get topicInput(): string | undefined;
    private _auth;
    get auth(): ObservabilityPipelineConfigDestinationGooglePubsubAuthList;
    putAuth(value: ObservabilityPipelineConfigDestinationGooglePubsubAuth[] | cdktn.IResolvable): void;
    resetAuth(): void;
    get authInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationGooglePubsubAuth[] | undefined;
    private _buffer;
    get buffer(): ObservabilityPipelineConfigDestinationGooglePubsubBufferList;
    putBuffer(value: ObservabilityPipelineConfigDestinationGooglePubsubBuffer[] | cdktn.IResolvable): void;
    resetBuffer(): void;
    get bufferInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationGooglePubsubBuffer[] | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigDestinationGooglePubsubTlsList;
    putTls(value: ObservabilityPipelineConfigDestinationGooglePubsubTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationGooglePubsubTls[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationGooglePubsubList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationGooglePubsub[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationGooglePubsubOutputReference;
}
export interface ObservabilityPipelineConfigDestinationGoogleSecopsAuth {
    /**
    * Path to the Google Cloud service account key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#credentials_file ObservabilityPipeline#credentials_file}
    */
    readonly credentialsFile: string;
}
export declare function observabilityPipelineConfigDestinationGoogleSecopsAuthToTerraform(struct?: ObservabilityPipelineConfigDestinationGoogleSecopsAuth | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationGoogleSecopsAuthToHclTerraform(struct?: ObservabilityPipelineConfigDestinationGoogleSecopsAuth | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationGoogleSecopsAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationGoogleSecopsAuth | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationGoogleSecopsAuth | cdktn.IResolvable | undefined);
    private _credentialsFile?;
    get credentialsFile(): string;
    set credentialsFile(value: string);
    get credentialsFileInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationGoogleSecopsAuthList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationGoogleSecopsAuth[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationGoogleSecopsAuthOutputReference;
}
export interface ObservabilityPipelineConfigDestinationGoogleSecopsBufferDisk {
    /**
    * Maximum size of the disk buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationGoogleSecopsBufferDiskToTerraform(struct?: ObservabilityPipelineConfigDestinationGoogleSecopsBufferDisk | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationGoogleSecopsBufferDiskToHclTerraform(struct?: ObservabilityPipelineConfigDestinationGoogleSecopsBufferDisk | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationGoogleSecopsBufferDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationGoogleSecopsBufferDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationGoogleSecopsBufferDisk | cdktn.IResolvable | undefined);
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationGoogleSecopsBufferDiskList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationGoogleSecopsBufferDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationGoogleSecopsBufferDiskOutputReference;
}
export interface ObservabilityPipelineConfigDestinationGoogleSecopsBufferMemory {
    /**
    * Maximum events for the memory buffer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_events ObservabilityPipeline#max_events}
    */
    readonly maxEvents?: number;
    /**
    * Maximum size of the memory buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationGoogleSecopsBufferMemoryToTerraform(struct?: ObservabilityPipelineConfigDestinationGoogleSecopsBufferMemory | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationGoogleSecopsBufferMemoryToHclTerraform(struct?: ObservabilityPipelineConfigDestinationGoogleSecopsBufferMemory | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationGoogleSecopsBufferMemoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationGoogleSecopsBufferMemory | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationGoogleSecopsBufferMemory | cdktn.IResolvable | undefined);
    private _maxEvents?;
    get maxEvents(): number;
    set maxEvents(value: number);
    resetMaxEvents(): void;
    get maxEventsInput(): number | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationGoogleSecopsBufferMemoryList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationGoogleSecopsBufferMemory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationGoogleSecopsBufferMemoryOutputReference;
}
export interface ObservabilityPipelineConfigDestinationGoogleSecopsBuffer {
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#disk ObservabilityPipeline#disk}
    */
    readonly disk?: ObservabilityPipelineConfigDestinationGoogleSecopsBufferDisk[] | cdktn.IResolvable;
    /**
    * memory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#memory ObservabilityPipeline#memory}
    */
    readonly memory?: ObservabilityPipelineConfigDestinationGoogleSecopsBufferMemory[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationGoogleSecopsBufferToTerraform(struct?: ObservabilityPipelineConfigDestinationGoogleSecopsBuffer | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationGoogleSecopsBufferToHclTerraform(struct?: ObservabilityPipelineConfigDestinationGoogleSecopsBuffer | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationGoogleSecopsBufferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationGoogleSecopsBuffer | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationGoogleSecopsBuffer | cdktn.IResolvable | undefined);
    private _disk;
    get disk(): ObservabilityPipelineConfigDestinationGoogleSecopsBufferDiskList;
    putDisk(value: ObservabilityPipelineConfigDestinationGoogleSecopsBufferDisk[] | cdktn.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationGoogleSecopsBufferDisk[] | undefined;
    private _memory;
    get memory(): ObservabilityPipelineConfigDestinationGoogleSecopsBufferMemoryList;
    putMemory(value: ObservabilityPipelineConfigDestinationGoogleSecopsBufferMemory[] | cdktn.IResolvable): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationGoogleSecopsBufferMemory[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationGoogleSecopsBufferList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationGoogleSecopsBuffer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationGoogleSecopsBufferOutputReference;
}
export interface ObservabilityPipelineConfigDestinationGoogleSecops {
    /**
    * The Google SecOps customer ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#customer_id ObservabilityPipeline#customer_id}
    */
    readonly customerId: string;
    /**
    * The encoding format for the logs sent to Google SecOps. Valid values are `json`, `raw_message`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#encoding ObservabilityPipeline#encoding}
    */
    readonly encoding: string;
    /**
    * Name of the environment variable or secret that holds the Google Chronicle endpoint URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#endpoint_url_key ObservabilityPipeline#endpoint_url_key}
    */
    readonly endpointUrlKey?: string;
    /**
    * The log type metadata associated with the Google SecOps destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#log_type ObservabilityPipeline#log_type}
    */
    readonly logType: string;
    /**
    * auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#auth ObservabilityPipeline#auth}
    */
    readonly auth?: ObservabilityPipelineConfigDestinationGoogleSecopsAuth[] | cdktn.IResolvable;
    /**
    * buffer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#buffer ObservabilityPipeline#buffer}
    */
    readonly buffer?: ObservabilityPipelineConfigDestinationGoogleSecopsBuffer[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationGoogleSecopsToTerraform(struct?: ObservabilityPipelineConfigDestinationGoogleSecops | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationGoogleSecopsToHclTerraform(struct?: ObservabilityPipelineConfigDestinationGoogleSecops | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationGoogleSecopsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationGoogleSecops | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationGoogleSecops | cdktn.IResolvable | undefined);
    private _customerId?;
    get customerId(): string;
    set customerId(value: string);
    get customerIdInput(): string | undefined;
    private _encoding?;
    get encoding(): string;
    set encoding(value: string);
    get encodingInput(): string | undefined;
    private _endpointUrlKey?;
    get endpointUrlKey(): string;
    set endpointUrlKey(value: string);
    resetEndpointUrlKey(): void;
    get endpointUrlKeyInput(): string | undefined;
    private _logType?;
    get logType(): string;
    set logType(value: string);
    get logTypeInput(): string | undefined;
    private _auth;
    get auth(): ObservabilityPipelineConfigDestinationGoogleSecopsAuthList;
    putAuth(value: ObservabilityPipelineConfigDestinationGoogleSecopsAuth[] | cdktn.IResolvable): void;
    resetAuth(): void;
    get authInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationGoogleSecopsAuth[] | undefined;
    private _buffer;
    get buffer(): ObservabilityPipelineConfigDestinationGoogleSecopsBufferList;
    putBuffer(value: ObservabilityPipelineConfigDestinationGoogleSecopsBuffer[] | cdktn.IResolvable): void;
    resetBuffer(): void;
    get bufferInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationGoogleSecopsBuffer[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationGoogleSecopsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationGoogleSecops[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationGoogleSecopsOutputReference;
}
export interface ObservabilityPipelineConfigDestinationHttpClientCompression {
    /**
    * Compression algorithm. Valid values are `gzip`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#algorithm ObservabilityPipeline#algorithm}
    */
    readonly algorithm: string;
}
export declare function observabilityPipelineConfigDestinationHttpClientCompressionToTerraform(struct?: ObservabilityPipelineConfigDestinationHttpClientCompression | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationHttpClientCompressionToHclTerraform(struct?: ObservabilityPipelineConfigDestinationHttpClientCompression | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationHttpClientCompressionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationHttpClientCompression | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationHttpClientCompression | cdktn.IResolvable | undefined);
    private _algorithm?;
    get algorithm(): string;
    set algorithm(value: string);
    get algorithmInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationHttpClientCompressionList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationHttpClientCompression[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationHttpClientCompressionOutputReference;
}
export interface ObservabilityPipelineConfigDestinationHttpClientTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigDestinationHttpClientTlsToTerraform(struct?: ObservabilityPipelineConfigDestinationHttpClientTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationHttpClientTlsToHclTerraform(struct?: ObservabilityPipelineConfigDestinationHttpClientTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationHttpClientTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationHttpClientTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationHttpClientTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationHttpClientTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationHttpClientTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationHttpClientTlsOutputReference;
}
export interface ObservabilityPipelineConfigDestinationHttpClient {
    /**
    * HTTP authentication strategy. Valid values are `none`, `basic`, `bearer`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#auth_strategy ObservabilityPipeline#auth_strategy}
    */
    readonly authStrategy?: string;
    /**
    * Encoding format for events. Valid values are `json`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#encoding ObservabilityPipeline#encoding}
    */
    readonly encoding: string;
    /**
    * Name of the environment variable or secret that holds the password.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#password_key ObservabilityPipeline#password_key}
    */
    readonly passwordKey?: string;
    /**
    * Name of the environment variable or secret that holds the authentication token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#token_key ObservabilityPipeline#token_key}
    */
    readonly tokenKey?: string;
    /**
    * Name of the environment variable or secret that holds the request URI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#uri_key ObservabilityPipeline#uri_key}
    */
    readonly uriKey?: string;
    /**
    * Name of the environment variable or secret that holds the username.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#username_key ObservabilityPipeline#username_key}
    */
    readonly usernameKey?: string;
    /**
    * compression block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#compression ObservabilityPipeline#compression}
    */
    readonly compression?: ObservabilityPipelineConfigDestinationHttpClientCompression[] | cdktn.IResolvable;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigDestinationHttpClientTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationHttpClientToTerraform(struct?: ObservabilityPipelineConfigDestinationHttpClient | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationHttpClientToHclTerraform(struct?: ObservabilityPipelineConfigDestinationHttpClient | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationHttpClientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationHttpClient | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationHttpClient | cdktn.IResolvable | undefined);
    private _authStrategy?;
    get authStrategy(): string;
    set authStrategy(value: string);
    resetAuthStrategy(): void;
    get authStrategyInput(): string | undefined;
    private _encoding?;
    get encoding(): string;
    set encoding(value: string);
    get encodingInput(): string | undefined;
    private _passwordKey?;
    get passwordKey(): string;
    set passwordKey(value: string);
    resetPasswordKey(): void;
    get passwordKeyInput(): string | undefined;
    private _tokenKey?;
    get tokenKey(): string;
    set tokenKey(value: string);
    resetTokenKey(): void;
    get tokenKeyInput(): string | undefined;
    private _uriKey?;
    get uriKey(): string;
    set uriKey(value: string);
    resetUriKey(): void;
    get uriKeyInput(): string | undefined;
    private _usernameKey?;
    get usernameKey(): string;
    set usernameKey(value: string);
    resetUsernameKey(): void;
    get usernameKeyInput(): string | undefined;
    private _compression;
    get compression(): ObservabilityPipelineConfigDestinationHttpClientCompressionList;
    putCompression(value: ObservabilityPipelineConfigDestinationHttpClientCompression[] | cdktn.IResolvable): void;
    resetCompression(): void;
    get compressionInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationHttpClientCompression[] | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigDestinationHttpClientTlsList;
    putTls(value: ObservabilityPipelineConfigDestinationHttpClientTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationHttpClientTls[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationHttpClientList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationHttpClient[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationHttpClientOutputReference;
}
export interface ObservabilityPipelineConfigDestinationKafkaLibrdkafkaOption {
    /**
    * The name of the librdkafka configuration option.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#name ObservabilityPipeline#name}
    */
    readonly name: string;
    /**
    * The value of the librdkafka configuration option.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#value ObservabilityPipeline#value}
    */
    readonly value: string;
}
export declare function observabilityPipelineConfigDestinationKafkaLibrdkafkaOptionToTerraform(struct?: ObservabilityPipelineConfigDestinationKafkaLibrdkafkaOption | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationKafkaLibrdkafkaOptionToHclTerraform(struct?: ObservabilityPipelineConfigDestinationKafkaLibrdkafkaOption | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationKafkaLibrdkafkaOptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationKafkaLibrdkafkaOption | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationKafkaLibrdkafkaOption | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationKafkaLibrdkafkaOptionList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationKafkaLibrdkafkaOption[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationKafkaLibrdkafkaOptionOutputReference;
}
export interface ObservabilityPipelineConfigDestinationKafkaSasl {
    /**
    * SASL authentication mechanism. Valid values are `PLAIN`, `SCRAM-SHA-256`, `SCRAM-SHA-512`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#mechanism ObservabilityPipeline#mechanism}
    */
    readonly mechanism: string;
    /**
    * Name of the environment variable or secret that holds the SASL password.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#password_key ObservabilityPipeline#password_key}
    */
    readonly passwordKey?: string;
    /**
    * Name of the environment variable or secret that holds the SASL username.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#username_key ObservabilityPipeline#username_key}
    */
    readonly usernameKey?: string;
}
export declare function observabilityPipelineConfigDestinationKafkaSaslToTerraform(struct?: ObservabilityPipelineConfigDestinationKafkaSasl | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationKafkaSaslToHclTerraform(struct?: ObservabilityPipelineConfigDestinationKafkaSasl | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationKafkaSaslOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationKafkaSasl | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationKafkaSasl | cdktn.IResolvable | undefined);
    private _mechanism?;
    get mechanism(): string;
    set mechanism(value: string);
    get mechanismInput(): string | undefined;
    private _passwordKey?;
    get passwordKey(): string;
    set passwordKey(value: string);
    resetPasswordKey(): void;
    get passwordKeyInput(): string | undefined;
    private _usernameKey?;
    get usernameKey(): string;
    set usernameKey(value: string);
    resetUsernameKey(): void;
    get usernameKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationKafkaSaslList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationKafkaSasl[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationKafkaSaslOutputReference;
}
export interface ObservabilityPipelineConfigDestinationKafkaTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigDestinationKafkaTlsToTerraform(struct?: ObservabilityPipelineConfigDestinationKafkaTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationKafkaTlsToHclTerraform(struct?: ObservabilityPipelineConfigDestinationKafkaTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationKafkaTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationKafkaTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationKafkaTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationKafkaTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationKafkaTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationKafkaTlsOutputReference;
}
export interface ObservabilityPipelineConfigDestinationKafka {
    /**
    * Name of the environment variable or secret that holds the Kafka bootstrap servers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#bootstrap_servers_key ObservabilityPipeline#bootstrap_servers_key}
    */
    readonly bootstrapServersKey?: string;
    /**
    * Compression codec for Kafka messages. Valid values are `none`, `gzip`, `snappy`, `lz4`, `zstd`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#compression ObservabilityPipeline#compression}
    */
    readonly compression?: string;
    /**
    * Encoding format for log events. Valid values are `json`, `raw_message`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#encoding ObservabilityPipeline#encoding}
    */
    readonly encoding: string;
    /**
    * The field name to use for Kafka message headers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#headers_key ObservabilityPipeline#headers_key}
    */
    readonly headersKey?: string;
    /**
    * The field name to use as the Kafka message key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_field ObservabilityPipeline#key_field}
    */
    readonly keyField?: string;
    /**
    * Maximum time in milliseconds to wait for message delivery confirmation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#message_timeout_ms ObservabilityPipeline#message_timeout_ms}
    */
    readonly messageTimeoutMs?: number;
    /**
    * Duration in seconds for the rate limit window.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#rate_limit_duration_secs ObservabilityPipeline#rate_limit_duration_secs}
    */
    readonly rateLimitDurationSecs?: number;
    /**
    * Maximum number of messages allowed per rate limit duration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#rate_limit_num ObservabilityPipeline#rate_limit_num}
    */
    readonly rateLimitNum?: number;
    /**
    * Socket timeout in milliseconds for network requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#socket_timeout_ms ObservabilityPipeline#socket_timeout_ms}
    */
    readonly socketTimeoutMs?: number;
    /**
    * The Kafka topic name to publish logs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#topic ObservabilityPipeline#topic}
    */
    readonly topic: string;
    /**
    * librdkafka_option block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#librdkafka_option ObservabilityPipeline#librdkafka_option}
    */
    readonly librdkafkaOption?: ObservabilityPipelineConfigDestinationKafkaLibrdkafkaOption[] | cdktn.IResolvable;
    /**
    * sasl block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#sasl ObservabilityPipeline#sasl}
    */
    readonly sasl?: ObservabilityPipelineConfigDestinationKafkaSasl[] | cdktn.IResolvable;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigDestinationKafkaTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationKafkaToTerraform(struct?: ObservabilityPipelineConfigDestinationKafka | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationKafkaToHclTerraform(struct?: ObservabilityPipelineConfigDestinationKafka | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationKafkaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationKafka | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationKafka | cdktn.IResolvable | undefined);
    private _bootstrapServersKey?;
    get bootstrapServersKey(): string;
    set bootstrapServersKey(value: string);
    resetBootstrapServersKey(): void;
    get bootstrapServersKeyInput(): string | undefined;
    private _compression?;
    get compression(): string;
    set compression(value: string);
    resetCompression(): void;
    get compressionInput(): string | undefined;
    private _encoding?;
    get encoding(): string;
    set encoding(value: string);
    get encodingInput(): string | undefined;
    private _headersKey?;
    get headersKey(): string;
    set headersKey(value: string);
    resetHeadersKey(): void;
    get headersKeyInput(): string | undefined;
    private _keyField?;
    get keyField(): string;
    set keyField(value: string);
    resetKeyField(): void;
    get keyFieldInput(): string | undefined;
    private _messageTimeoutMs?;
    get messageTimeoutMs(): number;
    set messageTimeoutMs(value: number);
    resetMessageTimeoutMs(): void;
    get messageTimeoutMsInput(): number | undefined;
    private _rateLimitDurationSecs?;
    get rateLimitDurationSecs(): number;
    set rateLimitDurationSecs(value: number);
    resetRateLimitDurationSecs(): void;
    get rateLimitDurationSecsInput(): number | undefined;
    private _rateLimitNum?;
    get rateLimitNum(): number;
    set rateLimitNum(value: number);
    resetRateLimitNum(): void;
    get rateLimitNumInput(): number | undefined;
    private _socketTimeoutMs?;
    get socketTimeoutMs(): number;
    set socketTimeoutMs(value: number);
    resetSocketTimeoutMs(): void;
    get socketTimeoutMsInput(): number | undefined;
    private _topic?;
    get topic(): string;
    set topic(value: string);
    get topicInput(): string | undefined;
    private _librdkafkaOption;
    get librdkafkaOption(): ObservabilityPipelineConfigDestinationKafkaLibrdkafkaOptionList;
    putLibrdkafkaOption(value: ObservabilityPipelineConfigDestinationKafkaLibrdkafkaOption[] | cdktn.IResolvable): void;
    resetLibrdkafkaOption(): void;
    get librdkafkaOptionInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationKafkaLibrdkafkaOption[] | undefined;
    private _sasl;
    get sasl(): ObservabilityPipelineConfigDestinationKafkaSaslList;
    putSasl(value: ObservabilityPipelineConfigDestinationKafkaSasl[] | cdktn.IResolvable): void;
    resetSasl(): void;
    get saslInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationKafkaSasl[] | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigDestinationKafkaTlsList;
    putTls(value: ObservabilityPipelineConfigDestinationKafkaTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationKafkaTls[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationKafkaList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationKafka[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationKafkaOutputReference;
}
export interface ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferDisk {
    /**
    * Maximum size of the disk buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationMicrosoftSentinelBufferDiskToTerraform(struct?: ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferDisk | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationMicrosoftSentinelBufferDiskToHclTerraform(struct?: ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferDisk | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferDisk | cdktn.IResolvable | undefined);
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferDiskList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferDiskOutputReference;
}
export interface ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferMemory {
    /**
    * Maximum events for the memory buffer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_events ObservabilityPipeline#max_events}
    */
    readonly maxEvents?: number;
    /**
    * Maximum size of the memory buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationMicrosoftSentinelBufferMemoryToTerraform(struct?: ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferMemory | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationMicrosoftSentinelBufferMemoryToHclTerraform(struct?: ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferMemory | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferMemoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferMemory | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferMemory | cdktn.IResolvable | undefined);
    private _maxEvents?;
    get maxEvents(): number;
    set maxEvents(value: number);
    resetMaxEvents(): void;
    get maxEventsInput(): number | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferMemoryList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferMemory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferMemoryOutputReference;
}
export interface ObservabilityPipelineConfigDestinationMicrosoftSentinelBuffer {
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#disk ObservabilityPipeline#disk}
    */
    readonly disk?: ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferDisk[] | cdktn.IResolvable;
    /**
    * memory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#memory ObservabilityPipeline#memory}
    */
    readonly memory?: ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferMemory[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationMicrosoftSentinelBufferToTerraform(struct?: ObservabilityPipelineConfigDestinationMicrosoftSentinelBuffer | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationMicrosoftSentinelBufferToHclTerraform(struct?: ObservabilityPipelineConfigDestinationMicrosoftSentinelBuffer | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationMicrosoftSentinelBuffer | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationMicrosoftSentinelBuffer | cdktn.IResolvable | undefined);
    private _disk;
    get disk(): ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferDiskList;
    putDisk(value: ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferDisk[] | cdktn.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferDisk[] | undefined;
    private _memory;
    get memory(): ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferMemoryList;
    putMemory(value: ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferMemory[] | cdktn.IResolvable): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferMemory[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationMicrosoftSentinelBuffer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferOutputReference;
}
export interface ObservabilityPipelineConfigDestinationMicrosoftSentinel {
    /**
    * Azure AD client ID used for authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#client_id ObservabilityPipeline#client_id}
    */
    readonly clientId: string;
    /**
    * Name of the environment variable or secret that holds the Azure AD client secret.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#client_secret_key ObservabilityPipeline#client_secret_key}
    */
    readonly clientSecretKey?: string;
    /**
    * Name of the environment variable or secret that holds the Data Collection Endpoint (DCE) URI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#dce_uri_key ObservabilityPipeline#dce_uri_key}
    */
    readonly dceUriKey?: string;
    /**
    * The immutable ID of the Data Collection Rule (DCR).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#dcr_immutable_id ObservabilityPipeline#dcr_immutable_id}
    */
    readonly dcrImmutableId: string;
    /**
    * The name of the Log Analytics table where logs will be sent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#table ObservabilityPipeline#table}
    */
    readonly table: string;
    /**
    * Azure AD tenant ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tenant_id ObservabilityPipeline#tenant_id}
    */
    readonly tenantId: string;
    /**
    * buffer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#buffer ObservabilityPipeline#buffer}
    */
    readonly buffer?: ObservabilityPipelineConfigDestinationMicrosoftSentinelBuffer[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationMicrosoftSentinelToTerraform(struct?: ObservabilityPipelineConfigDestinationMicrosoftSentinel | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationMicrosoftSentinelToHclTerraform(struct?: ObservabilityPipelineConfigDestinationMicrosoftSentinel | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationMicrosoftSentinelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationMicrosoftSentinel | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationMicrosoftSentinel | cdktn.IResolvable | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    private _clientSecretKey?;
    get clientSecretKey(): string;
    set clientSecretKey(value: string);
    resetClientSecretKey(): void;
    get clientSecretKeyInput(): string | undefined;
    private _dceUriKey?;
    get dceUriKey(): string;
    set dceUriKey(value: string);
    resetDceUriKey(): void;
    get dceUriKeyInput(): string | undefined;
    private _dcrImmutableId?;
    get dcrImmutableId(): string;
    set dcrImmutableId(value: string);
    get dcrImmutableIdInput(): string | undefined;
    private _table?;
    get table(): string;
    set table(value: string);
    get tableInput(): string | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    get tenantIdInput(): string | undefined;
    private _buffer;
    get buffer(): ObservabilityPipelineConfigDestinationMicrosoftSentinelBufferList;
    putBuffer(value: ObservabilityPipelineConfigDestinationMicrosoftSentinelBuffer[] | cdktn.IResolvable): void;
    resetBuffer(): void;
    get bufferInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationMicrosoftSentinelBuffer[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationMicrosoftSentinelList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationMicrosoftSentinel[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationMicrosoftSentinelOutputReference;
}
export interface ObservabilityPipelineConfigDestinationNewRelicBufferDisk {
    /**
    * Maximum size of the disk buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationNewRelicBufferDiskToTerraform(struct?: ObservabilityPipelineConfigDestinationNewRelicBufferDisk | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationNewRelicBufferDiskToHclTerraform(struct?: ObservabilityPipelineConfigDestinationNewRelicBufferDisk | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationNewRelicBufferDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationNewRelicBufferDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationNewRelicBufferDisk | cdktn.IResolvable | undefined);
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationNewRelicBufferDiskList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationNewRelicBufferDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationNewRelicBufferDiskOutputReference;
}
export interface ObservabilityPipelineConfigDestinationNewRelicBufferMemory {
    /**
    * Maximum events for the memory buffer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_events ObservabilityPipeline#max_events}
    */
    readonly maxEvents?: number;
    /**
    * Maximum size of the memory buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationNewRelicBufferMemoryToTerraform(struct?: ObservabilityPipelineConfigDestinationNewRelicBufferMemory | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationNewRelicBufferMemoryToHclTerraform(struct?: ObservabilityPipelineConfigDestinationNewRelicBufferMemory | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationNewRelicBufferMemoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationNewRelicBufferMemory | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationNewRelicBufferMemory | cdktn.IResolvable | undefined);
    private _maxEvents?;
    get maxEvents(): number;
    set maxEvents(value: number);
    resetMaxEvents(): void;
    get maxEventsInput(): number | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationNewRelicBufferMemoryList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationNewRelicBufferMemory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationNewRelicBufferMemoryOutputReference;
}
export interface ObservabilityPipelineConfigDestinationNewRelicBuffer {
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#disk ObservabilityPipeline#disk}
    */
    readonly disk?: ObservabilityPipelineConfigDestinationNewRelicBufferDisk[] | cdktn.IResolvable;
    /**
    * memory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#memory ObservabilityPipeline#memory}
    */
    readonly memory?: ObservabilityPipelineConfigDestinationNewRelicBufferMemory[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationNewRelicBufferToTerraform(struct?: ObservabilityPipelineConfigDestinationNewRelicBuffer | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationNewRelicBufferToHclTerraform(struct?: ObservabilityPipelineConfigDestinationNewRelicBuffer | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationNewRelicBufferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationNewRelicBuffer | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationNewRelicBuffer | cdktn.IResolvable | undefined);
    private _disk;
    get disk(): ObservabilityPipelineConfigDestinationNewRelicBufferDiskList;
    putDisk(value: ObservabilityPipelineConfigDestinationNewRelicBufferDisk[] | cdktn.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationNewRelicBufferDisk[] | undefined;
    private _memory;
    get memory(): ObservabilityPipelineConfigDestinationNewRelicBufferMemoryList;
    putMemory(value: ObservabilityPipelineConfigDestinationNewRelicBufferMemory[] | cdktn.IResolvable): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationNewRelicBufferMemory[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationNewRelicBufferList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationNewRelicBuffer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationNewRelicBufferOutputReference;
}
export interface ObservabilityPipelineConfigDestinationNewRelic {
    /**
    * Name of the environment variable or secret that holds the New Relic account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#account_id_key ObservabilityPipeline#account_id_key}
    */
    readonly accountIdKey?: string;
    /**
    * Name of the environment variable or secret that holds the New Relic license key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#license_key_key ObservabilityPipeline#license_key_key}
    */
    readonly licenseKeyKey?: string;
    /**
    * The New Relic region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#region ObservabilityPipeline#region}
    */
    readonly region: string;
    /**
    * buffer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#buffer ObservabilityPipeline#buffer}
    */
    readonly buffer?: ObservabilityPipelineConfigDestinationNewRelicBuffer[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationNewRelicToTerraform(struct?: ObservabilityPipelineConfigDestinationNewRelic | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationNewRelicToHclTerraform(struct?: ObservabilityPipelineConfigDestinationNewRelic | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationNewRelicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationNewRelic | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationNewRelic | cdktn.IResolvable | undefined);
    private _accountIdKey?;
    get accountIdKey(): string;
    set accountIdKey(value: string);
    resetAccountIdKey(): void;
    get accountIdKeyInput(): string | undefined;
    private _licenseKeyKey?;
    get licenseKeyKey(): string;
    set licenseKeyKey(value: string);
    resetLicenseKeyKey(): void;
    get licenseKeyKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _buffer;
    get buffer(): ObservabilityPipelineConfigDestinationNewRelicBufferList;
    putBuffer(value: ObservabilityPipelineConfigDestinationNewRelicBuffer[] | cdktn.IResolvable): void;
    resetBuffer(): void;
    get bufferInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationNewRelicBuffer[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationNewRelicList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationNewRelic[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationNewRelicOutputReference;
}
export interface ObservabilityPipelineConfigDestinationOpensearchBufferDisk {
    /**
    * Maximum size of the disk buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationOpensearchBufferDiskToTerraform(struct?: ObservabilityPipelineConfigDestinationOpensearchBufferDisk | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationOpensearchBufferDiskToHclTerraform(struct?: ObservabilityPipelineConfigDestinationOpensearchBufferDisk | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationOpensearchBufferDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationOpensearchBufferDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationOpensearchBufferDisk | cdktn.IResolvable | undefined);
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationOpensearchBufferDiskList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationOpensearchBufferDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationOpensearchBufferDiskOutputReference;
}
export interface ObservabilityPipelineConfigDestinationOpensearchBufferMemory {
    /**
    * Maximum events for the memory buffer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_events ObservabilityPipeline#max_events}
    */
    readonly maxEvents?: number;
    /**
    * Maximum size of the memory buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationOpensearchBufferMemoryToTerraform(struct?: ObservabilityPipelineConfigDestinationOpensearchBufferMemory | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationOpensearchBufferMemoryToHclTerraform(struct?: ObservabilityPipelineConfigDestinationOpensearchBufferMemory | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationOpensearchBufferMemoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationOpensearchBufferMemory | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationOpensearchBufferMemory | cdktn.IResolvable | undefined);
    private _maxEvents?;
    get maxEvents(): number;
    set maxEvents(value: number);
    resetMaxEvents(): void;
    get maxEventsInput(): number | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationOpensearchBufferMemoryList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationOpensearchBufferMemory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationOpensearchBufferMemoryOutputReference;
}
export interface ObservabilityPipelineConfigDestinationOpensearchBuffer {
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#disk ObservabilityPipeline#disk}
    */
    readonly disk?: ObservabilityPipelineConfigDestinationOpensearchBufferDisk[] | cdktn.IResolvable;
    /**
    * memory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#memory ObservabilityPipeline#memory}
    */
    readonly memory?: ObservabilityPipelineConfigDestinationOpensearchBufferMemory[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationOpensearchBufferToTerraform(struct?: ObservabilityPipelineConfigDestinationOpensearchBuffer | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationOpensearchBufferToHclTerraform(struct?: ObservabilityPipelineConfigDestinationOpensearchBuffer | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationOpensearchBufferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationOpensearchBuffer | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationOpensearchBuffer | cdktn.IResolvable | undefined);
    private _disk;
    get disk(): ObservabilityPipelineConfigDestinationOpensearchBufferDiskList;
    putDisk(value: ObservabilityPipelineConfigDestinationOpensearchBufferDisk[] | cdktn.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationOpensearchBufferDisk[] | undefined;
    private _memory;
    get memory(): ObservabilityPipelineConfigDestinationOpensearchBufferMemoryList;
    putMemory(value: ObservabilityPipelineConfigDestinationOpensearchBufferMemory[] | cdktn.IResolvable): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationOpensearchBufferMemory[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationOpensearchBufferList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationOpensearchBuffer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationOpensearchBufferOutputReference;
}
export interface ObservabilityPipelineConfigDestinationOpensearchDataStream {
    /**
    * The data stream dataset for your logs. This groups logs by their source or application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#dataset ObservabilityPipeline#dataset}
    */
    readonly dataset?: string;
    /**
    * The data stream type for your logs. This determines how logs are categorized within the data stream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#dtype ObservabilityPipeline#dtype}
    */
    readonly dtype?: string;
    /**
    * The data stream namespace for your logs. This separates logs into different environments or domains.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#namespace ObservabilityPipeline#namespace}
    */
    readonly namespace?: string;
}
export declare function observabilityPipelineConfigDestinationOpensearchDataStreamToTerraform(struct?: ObservabilityPipelineConfigDestinationOpensearchDataStream | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationOpensearchDataStreamToHclTerraform(struct?: ObservabilityPipelineConfigDestinationOpensearchDataStream | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationOpensearchDataStreamOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationOpensearchDataStream | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationOpensearchDataStream | cdktn.IResolvable | undefined);
    private _dataset?;
    get dataset(): string;
    set dataset(value: string);
    resetDataset(): void;
    get datasetInput(): string | undefined;
    private _dtype?;
    get dtype(): string;
    set dtype(value: string);
    resetDtype(): void;
    get dtypeInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationOpensearchDataStreamList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationOpensearchDataStream[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationOpensearchDataStreamOutputReference;
}
export interface ObservabilityPipelineConfigDestinationOpensearch {
    /**
    * The index or datastream to write logs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#bulk_index ObservabilityPipeline#bulk_index}
    */
    readonly bulkIndex?: string;
    /**
    * buffer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#buffer ObservabilityPipeline#buffer}
    */
    readonly buffer?: ObservabilityPipelineConfigDestinationOpensearchBuffer[] | cdktn.IResolvable;
    /**
    * data_stream block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#data_stream ObservabilityPipeline#data_stream}
    */
    readonly dataStream?: ObservabilityPipelineConfigDestinationOpensearchDataStream[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationOpensearchToTerraform(struct?: ObservabilityPipelineConfigDestinationOpensearch | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationOpensearchToHclTerraform(struct?: ObservabilityPipelineConfigDestinationOpensearch | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationOpensearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationOpensearch | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationOpensearch | cdktn.IResolvable | undefined);
    private _bulkIndex?;
    get bulkIndex(): string;
    set bulkIndex(value: string);
    resetBulkIndex(): void;
    get bulkIndexInput(): string | undefined;
    private _buffer;
    get buffer(): ObservabilityPipelineConfigDestinationOpensearchBufferList;
    putBuffer(value: ObservabilityPipelineConfigDestinationOpensearchBuffer[] | cdktn.IResolvable): void;
    resetBuffer(): void;
    get bufferInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationOpensearchBuffer[] | undefined;
    private _dataStream;
    get dataStream(): ObservabilityPipelineConfigDestinationOpensearchDataStreamList;
    putDataStream(value: ObservabilityPipelineConfigDestinationOpensearchDataStream[] | cdktn.IResolvable): void;
    resetDataStream(): void;
    get dataStreamInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationOpensearchDataStream[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationOpensearchList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationOpensearch[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationOpensearchOutputReference;
}
export interface ObservabilityPipelineConfigDestinationRsyslogBufferDisk {
    /**
    * Maximum size of the disk buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationRsyslogBufferDiskToTerraform(struct?: ObservabilityPipelineConfigDestinationRsyslogBufferDisk | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationRsyslogBufferDiskToHclTerraform(struct?: ObservabilityPipelineConfigDestinationRsyslogBufferDisk | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationRsyslogBufferDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationRsyslogBufferDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationRsyslogBufferDisk | cdktn.IResolvable | undefined);
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationRsyslogBufferDiskList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationRsyslogBufferDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationRsyslogBufferDiskOutputReference;
}
export interface ObservabilityPipelineConfigDestinationRsyslogBufferMemory {
    /**
    * Maximum events for the memory buffer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_events ObservabilityPipeline#max_events}
    */
    readonly maxEvents?: number;
    /**
    * Maximum size of the memory buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationRsyslogBufferMemoryToTerraform(struct?: ObservabilityPipelineConfigDestinationRsyslogBufferMemory | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationRsyslogBufferMemoryToHclTerraform(struct?: ObservabilityPipelineConfigDestinationRsyslogBufferMemory | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationRsyslogBufferMemoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationRsyslogBufferMemory | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationRsyslogBufferMemory | cdktn.IResolvable | undefined);
    private _maxEvents?;
    get maxEvents(): number;
    set maxEvents(value: number);
    resetMaxEvents(): void;
    get maxEventsInput(): number | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationRsyslogBufferMemoryList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationRsyslogBufferMemory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationRsyslogBufferMemoryOutputReference;
}
export interface ObservabilityPipelineConfigDestinationRsyslogBuffer {
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#disk ObservabilityPipeline#disk}
    */
    readonly disk?: ObservabilityPipelineConfigDestinationRsyslogBufferDisk[] | cdktn.IResolvable;
    /**
    * memory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#memory ObservabilityPipeline#memory}
    */
    readonly memory?: ObservabilityPipelineConfigDestinationRsyslogBufferMemory[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationRsyslogBufferToTerraform(struct?: ObservabilityPipelineConfigDestinationRsyslogBuffer | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationRsyslogBufferToHclTerraform(struct?: ObservabilityPipelineConfigDestinationRsyslogBuffer | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationRsyslogBufferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationRsyslogBuffer | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationRsyslogBuffer | cdktn.IResolvable | undefined);
    private _disk;
    get disk(): ObservabilityPipelineConfigDestinationRsyslogBufferDiskList;
    putDisk(value: ObservabilityPipelineConfigDestinationRsyslogBufferDisk[] | cdktn.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationRsyslogBufferDisk[] | undefined;
    private _memory;
    get memory(): ObservabilityPipelineConfigDestinationRsyslogBufferMemoryList;
    putMemory(value: ObservabilityPipelineConfigDestinationRsyslogBufferMemory[] | cdktn.IResolvable): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationRsyslogBufferMemory[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationRsyslogBufferList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationRsyslogBuffer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationRsyslogBufferOutputReference;
}
export interface ObservabilityPipelineConfigDestinationRsyslogTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigDestinationRsyslogTlsToTerraform(struct?: ObservabilityPipelineConfigDestinationRsyslogTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationRsyslogTlsToHclTerraform(struct?: ObservabilityPipelineConfigDestinationRsyslogTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationRsyslogTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationRsyslogTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationRsyslogTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationRsyslogTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationRsyslogTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationRsyslogTlsOutputReference;
}
export interface ObservabilityPipelineConfigDestinationRsyslog {
    /**
    * Name of the environment variable or secret that holds the rsyslog endpoint URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#endpoint_url_key ObservabilityPipeline#endpoint_url_key}
    */
    readonly endpointUrlKey?: string;
    /**
    * Optional socket keepalive duration in milliseconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#keepalive ObservabilityPipeline#keepalive}
    */
    readonly keepalive?: number;
    /**
    * buffer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#buffer ObservabilityPipeline#buffer}
    */
    readonly buffer?: ObservabilityPipelineConfigDestinationRsyslogBuffer[] | cdktn.IResolvable;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigDestinationRsyslogTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationRsyslogToTerraform(struct?: ObservabilityPipelineConfigDestinationRsyslog | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationRsyslogToHclTerraform(struct?: ObservabilityPipelineConfigDestinationRsyslog | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationRsyslogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationRsyslog | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationRsyslog | cdktn.IResolvable | undefined);
    private _endpointUrlKey?;
    get endpointUrlKey(): string;
    set endpointUrlKey(value: string);
    resetEndpointUrlKey(): void;
    get endpointUrlKeyInput(): string | undefined;
    private _keepalive?;
    get keepalive(): number;
    set keepalive(value: number);
    resetKeepalive(): void;
    get keepaliveInput(): number | undefined;
    private _buffer;
    get buffer(): ObservabilityPipelineConfigDestinationRsyslogBufferList;
    putBuffer(value: ObservabilityPipelineConfigDestinationRsyslogBuffer[] | cdktn.IResolvable): void;
    resetBuffer(): void;
    get bufferInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationRsyslogBuffer[] | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigDestinationRsyslogTlsList;
    putTls(value: ObservabilityPipelineConfigDestinationRsyslogTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationRsyslogTls[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationRsyslogList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationRsyslog[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationRsyslogOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSentinelOneBufferDisk {
    /**
    * Maximum size of the disk buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationSentinelOneBufferDiskToTerraform(struct?: ObservabilityPipelineConfigDestinationSentinelOneBufferDisk | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSentinelOneBufferDiskToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSentinelOneBufferDisk | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSentinelOneBufferDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSentinelOneBufferDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSentinelOneBufferDisk | cdktn.IResolvable | undefined);
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSentinelOneBufferDiskList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSentinelOneBufferDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSentinelOneBufferDiskOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSentinelOneBufferMemory {
    /**
    * Maximum events for the memory buffer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_events ObservabilityPipeline#max_events}
    */
    readonly maxEvents?: number;
    /**
    * Maximum size of the memory buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationSentinelOneBufferMemoryToTerraform(struct?: ObservabilityPipelineConfigDestinationSentinelOneBufferMemory | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSentinelOneBufferMemoryToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSentinelOneBufferMemory | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSentinelOneBufferMemoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSentinelOneBufferMemory | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSentinelOneBufferMemory | cdktn.IResolvable | undefined);
    private _maxEvents?;
    get maxEvents(): number;
    set maxEvents(value: number);
    resetMaxEvents(): void;
    get maxEventsInput(): number | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSentinelOneBufferMemoryList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSentinelOneBufferMemory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSentinelOneBufferMemoryOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSentinelOneBuffer {
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#disk ObservabilityPipeline#disk}
    */
    readonly disk?: ObservabilityPipelineConfigDestinationSentinelOneBufferDisk[] | cdktn.IResolvable;
    /**
    * memory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#memory ObservabilityPipeline#memory}
    */
    readonly memory?: ObservabilityPipelineConfigDestinationSentinelOneBufferMemory[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationSentinelOneBufferToTerraform(struct?: ObservabilityPipelineConfigDestinationSentinelOneBuffer | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSentinelOneBufferToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSentinelOneBuffer | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSentinelOneBufferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSentinelOneBuffer | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSentinelOneBuffer | cdktn.IResolvable | undefined);
    private _disk;
    get disk(): ObservabilityPipelineConfigDestinationSentinelOneBufferDiskList;
    putDisk(value: ObservabilityPipelineConfigDestinationSentinelOneBufferDisk[] | cdktn.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSentinelOneBufferDisk[] | undefined;
    private _memory;
    get memory(): ObservabilityPipelineConfigDestinationSentinelOneBufferMemoryList;
    putMemory(value: ObservabilityPipelineConfigDestinationSentinelOneBufferMemory[] | cdktn.IResolvable): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSentinelOneBufferMemory[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSentinelOneBufferList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSentinelOneBuffer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSentinelOneBufferOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSentinelOne {
    /**
    * The SentinelOne region to send logs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#region ObservabilityPipeline#region}
    */
    readonly region: string;
    /**
    * Name of the environment variable or secret that holds the SentinelOne API token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#token_key ObservabilityPipeline#token_key}
    */
    readonly tokenKey?: string;
    /**
    * buffer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#buffer ObservabilityPipeline#buffer}
    */
    readonly buffer?: ObservabilityPipelineConfigDestinationSentinelOneBuffer[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationSentinelOneToTerraform(struct?: ObservabilityPipelineConfigDestinationSentinelOne | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSentinelOneToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSentinelOne | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSentinelOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSentinelOne | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSentinelOne | cdktn.IResolvable | undefined);
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _tokenKey?;
    get tokenKey(): string;
    set tokenKey(value: string);
    resetTokenKey(): void;
    get tokenKeyInput(): string | undefined;
    private _buffer;
    get buffer(): ObservabilityPipelineConfigDestinationSentinelOneBufferList;
    putBuffer(value: ObservabilityPipelineConfigDestinationSentinelOneBuffer[] | cdktn.IResolvable): void;
    resetBuffer(): void;
    get bufferInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSentinelOneBuffer[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSentinelOneList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSentinelOne[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSentinelOneOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSocketBufferDisk {
    /**
    * Maximum size of the disk buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationSocketBufferDiskToTerraform(struct?: ObservabilityPipelineConfigDestinationSocketBufferDisk | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSocketBufferDiskToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSocketBufferDisk | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSocketBufferDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSocketBufferDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSocketBufferDisk | cdktn.IResolvable | undefined);
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSocketBufferDiskList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSocketBufferDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSocketBufferDiskOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSocketBufferMemory {
    /**
    * Maximum events for the memory buffer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_events ObservabilityPipeline#max_events}
    */
    readonly maxEvents?: number;
    /**
    * Maximum size of the memory buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationSocketBufferMemoryToTerraform(struct?: ObservabilityPipelineConfigDestinationSocketBufferMemory | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSocketBufferMemoryToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSocketBufferMemory | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSocketBufferMemoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSocketBufferMemory | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSocketBufferMemory | cdktn.IResolvable | undefined);
    private _maxEvents?;
    get maxEvents(): number;
    set maxEvents(value: number);
    resetMaxEvents(): void;
    get maxEventsInput(): number | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSocketBufferMemoryList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSocketBufferMemory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSocketBufferMemoryOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSocketBuffer {
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#disk ObservabilityPipeline#disk}
    */
    readonly disk?: ObservabilityPipelineConfigDestinationSocketBufferDisk[] | cdktn.IResolvable;
    /**
    * memory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#memory ObservabilityPipeline#memory}
    */
    readonly memory?: ObservabilityPipelineConfigDestinationSocketBufferMemory[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationSocketBufferToTerraform(struct?: ObservabilityPipelineConfigDestinationSocketBuffer | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSocketBufferToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSocketBuffer | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSocketBufferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSocketBuffer | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSocketBuffer | cdktn.IResolvable | undefined);
    private _disk;
    get disk(): ObservabilityPipelineConfigDestinationSocketBufferDiskList;
    putDisk(value: ObservabilityPipelineConfigDestinationSocketBufferDisk[] | cdktn.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSocketBufferDisk[] | undefined;
    private _memory;
    get memory(): ObservabilityPipelineConfigDestinationSocketBufferMemoryList;
    putMemory(value: ObservabilityPipelineConfigDestinationSocketBufferMemory[] | cdktn.IResolvable): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSocketBufferMemory[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSocketBufferList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSocketBuffer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSocketBufferOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSocketFramingCharacterDelimited {
    /**
    * A single ASCII character used as a delimiter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#delimiter ObservabilityPipeline#delimiter}
    */
    readonly delimiter: string;
}
export declare function observabilityPipelineConfigDestinationSocketFramingCharacterDelimitedToTerraform(struct?: ObservabilityPipelineConfigDestinationSocketFramingCharacterDelimited | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSocketFramingCharacterDelimitedToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSocketFramingCharacterDelimited | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSocketFramingCharacterDelimitedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSocketFramingCharacterDelimited | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSocketFramingCharacterDelimited | cdktn.IResolvable | undefined);
    private _delimiter?;
    get delimiter(): string;
    set delimiter(value: string);
    get delimiterInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSocketFramingCharacterDelimitedList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSocketFramingCharacterDelimited[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSocketFramingCharacterDelimitedOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSocketFraming {
    /**
    * The framing method. Valid values are `newline_delimited`, `bytes`, `character_delimited`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#method ObservabilityPipeline#method}
    */
    readonly method: string;
    /**
    * character_delimited block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#character_delimited ObservabilityPipeline#character_delimited}
    */
    readonly characterDelimited?: ObservabilityPipelineConfigDestinationSocketFramingCharacterDelimited[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationSocketFramingToTerraform(struct?: ObservabilityPipelineConfigDestinationSocketFraming | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSocketFramingToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSocketFraming | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSocketFramingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSocketFraming | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSocketFraming | cdktn.IResolvable | undefined);
    private _method?;
    get method(): string;
    set method(value: string);
    get methodInput(): string | undefined;
    private _characterDelimited;
    get characterDelimited(): ObservabilityPipelineConfigDestinationSocketFramingCharacterDelimitedList;
    putCharacterDelimited(value: ObservabilityPipelineConfigDestinationSocketFramingCharacterDelimited[] | cdktn.IResolvable): void;
    resetCharacterDelimited(): void;
    get characterDelimitedInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSocketFramingCharacterDelimited[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSocketFramingList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSocketFraming[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSocketFramingOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSocketTls {
    /**
    * Path to the Certificate Authority (CA) file used to validate the server's TLS certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#ca_file ObservabilityPipeline#ca_file}
    */
    readonly caFile?: string;
    /**
    * Path to the TLS client certificate file used to authenticate the pipeline component with upstream or downstream services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#crt_file ObservabilityPipeline#crt_file}
    */
    readonly crtFile: string;
    /**
    * Path to the private key file associated with the TLS client certificate. Used for mutual TLS authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_file ObservabilityPipeline#key_file}
    */
    readonly keyFile?: string;
    /**
    * Name of the environment variable or secret that holds the passphrase for the private key file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#key_pass_key ObservabilityPipeline#key_pass_key}
    */
    readonly keyPassKey?: string;
}
export declare function observabilityPipelineConfigDestinationSocketTlsToTerraform(struct?: ObservabilityPipelineConfigDestinationSocketTls | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSocketTlsToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSocketTls | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSocketTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSocketTls | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSocketTls | cdktn.IResolvable | undefined);
    private _caFile?;
    get caFile(): string;
    set caFile(value: string);
    resetCaFile(): void;
    get caFileInput(): string | undefined;
    private _crtFile?;
    get crtFile(): string;
    set crtFile(value: string);
    get crtFileInput(): string | undefined;
    private _keyFile?;
    get keyFile(): string;
    set keyFile(value: string);
    resetKeyFile(): void;
    get keyFileInput(): string | undefined;
    private _keyPassKey?;
    get keyPassKey(): string;
    set keyPassKey(value: string);
    resetKeyPassKey(): void;
    get keyPassKeyInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSocketTlsList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSocketTls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSocketTlsOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSocket {
    /**
    * Name of the environment variable or secret that holds the socket address (host:port).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#address_key ObservabilityPipeline#address_key}
    */
    readonly addressKey?: string;
    /**
    * Encoding format for log events. Valid values are `json`, `raw_message`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#encoding ObservabilityPipeline#encoding}
    */
    readonly encoding: string;
    /**
    * The protocol used to send logs. Valid values are `tcp`, `udp`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#mode ObservabilityPipeline#mode}
    */
    readonly mode: string;
    /**
    * buffer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#buffer ObservabilityPipeline#buffer}
    */
    readonly buffer?: ObservabilityPipelineConfigDestinationSocketBuffer[] | cdktn.IResolvable;
    /**
    * framing block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#framing ObservabilityPipeline#framing}
    */
    readonly framing?: ObservabilityPipelineConfigDestinationSocketFraming[] | cdktn.IResolvable;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#tls ObservabilityPipeline#tls}
    */
    readonly tls?: ObservabilityPipelineConfigDestinationSocketTls[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationSocketToTerraform(struct?: ObservabilityPipelineConfigDestinationSocket | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSocketToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSocket | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSocket | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSocket | cdktn.IResolvable | undefined);
    private _addressKey?;
    get addressKey(): string;
    set addressKey(value: string);
    resetAddressKey(): void;
    get addressKeyInput(): string | undefined;
    private _encoding?;
    get encoding(): string;
    set encoding(value: string);
    get encodingInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _buffer;
    get buffer(): ObservabilityPipelineConfigDestinationSocketBufferList;
    putBuffer(value: ObservabilityPipelineConfigDestinationSocketBuffer[] | cdktn.IResolvable): void;
    resetBuffer(): void;
    get bufferInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSocketBuffer[] | undefined;
    private _framing;
    get framing(): ObservabilityPipelineConfigDestinationSocketFramingList;
    putFraming(value: ObservabilityPipelineConfigDestinationSocketFraming[] | cdktn.IResolvable): void;
    resetFraming(): void;
    get framingInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSocketFraming[] | undefined;
    private _tls;
    get tls(): ObservabilityPipelineConfigDestinationSocketTlsList;
    putTls(value: ObservabilityPipelineConfigDestinationSocketTls[] | cdktn.IResolvable): void;
    resetTls(): void;
    get tlsInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSocketTls[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSocketList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSocket[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSocketOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSplunkHecBufferDisk {
    /**
    * Maximum size of the disk buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationSplunkHecBufferDiskToTerraform(struct?: ObservabilityPipelineConfigDestinationSplunkHecBufferDisk | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSplunkHecBufferDiskToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSplunkHecBufferDisk | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSplunkHecBufferDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSplunkHecBufferDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSplunkHecBufferDisk | cdktn.IResolvable | undefined);
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSplunkHecBufferDiskList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSplunkHecBufferDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSplunkHecBufferDiskOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSplunkHecBufferMemory {
    /**
    * Maximum events for the memory buffer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_events ObservabilityPipeline#max_events}
    */
    readonly maxEvents?: number;
    /**
    * Maximum size of the memory buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationSplunkHecBufferMemoryToTerraform(struct?: ObservabilityPipelineConfigDestinationSplunkHecBufferMemory | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSplunkHecBufferMemoryToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSplunkHecBufferMemory | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSplunkHecBufferMemoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSplunkHecBufferMemory | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSplunkHecBufferMemory | cdktn.IResolvable | undefined);
    private _maxEvents?;
    get maxEvents(): number;
    set maxEvents(value: number);
    resetMaxEvents(): void;
    get maxEventsInput(): number | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSplunkHecBufferMemoryList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSplunkHecBufferMemory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSplunkHecBufferMemoryOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSplunkHecBuffer {
    /**
    * disk block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#disk ObservabilityPipeline#disk}
    */
    readonly disk?: ObservabilityPipelineConfigDestinationSplunkHecBufferDisk[] | cdktn.IResolvable;
    /**
    * memory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#memory ObservabilityPipeline#memory}
    */
    readonly memory?: ObservabilityPipelineConfigDestinationSplunkHecBufferMemory[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationSplunkHecBufferToTerraform(struct?: ObservabilityPipelineConfigDestinationSplunkHecBuffer | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSplunkHecBufferToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSplunkHecBuffer | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSplunkHecBufferOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSplunkHecBuffer | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSplunkHecBuffer | cdktn.IResolvable | undefined);
    private _disk;
    get disk(): ObservabilityPipelineConfigDestinationSplunkHecBufferDiskList;
    putDisk(value: ObservabilityPipelineConfigDestinationSplunkHecBufferDisk[] | cdktn.IResolvable): void;
    resetDisk(): void;
    get diskInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSplunkHecBufferDisk[] | undefined;
    private _memory;
    get memory(): ObservabilityPipelineConfigDestinationSplunkHecBufferMemoryList;
    putMemory(value: ObservabilityPipelineConfigDestinationSplunkHecBufferMemory[] | cdktn.IResolvable): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSplunkHecBufferMemory[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSplunkHecBufferList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSplunkHecBuffer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSplunkHecBufferOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSplunkHec {
    /**
    * If `true`, Splunk tries to extract timestamps from incoming log events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#auto_extract_timestamp ObservabilityPipeline#auto_extract_timestamp}
    */
    readonly autoExtractTimestamp?: boolean | cdktn.IResolvable;
    /**
    * Encoding format for log events. Valid values: `json`, `raw_message`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#encoding ObservabilityPipeline#encoding}
    */
    readonly encoding: string;
    /**
    * Name of the environment variable or secret that holds the Splunk HEC endpoint URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#endpoint_url_key ObservabilityPipeline#endpoint_url_key}
    */
    readonly endpointUrlKey?: string;
    /**
    * Optional name of the Splunk index where logs are written.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#index ObservabilityPipeline#index}
    */
    readonly index?: string;
    /**
    * The Splunk sourcetype to assign to log events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#sourcetype ObservabilityPipeline#sourcetype}
    */
    readonly sourcetype?: string;
    /**
    * Name of the environment variable or secret that holds the Splunk HEC token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#token_key ObservabilityPipeline#token_key}
    */
    readonly tokenKey?: string;
    /**
    * buffer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#buffer ObservabilityPipeline#buffer}
    */
    readonly buffer?: ObservabilityPipelineConfigDestinationSplunkHecBuffer[] | cdktn.IResolvable;
}
export declare function observabilityPipelineConfigDestinationSplunkHecToTerraform(struct?: ObservabilityPipelineConfigDestinationSplunkHec | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSplunkHecToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSplunkHec | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSplunkHecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSplunkHec | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSplunkHec | cdktn.IResolvable | undefined);
    private _autoExtractTimestamp?;
    get autoExtractTimestamp(): boolean | cdktn.IResolvable;
    set autoExtractTimestamp(value: boolean | cdktn.IResolvable);
    resetAutoExtractTimestamp(): void;
    get autoExtractTimestampInput(): boolean | cdktn.IResolvable | undefined;
    private _encoding?;
    get encoding(): string;
    set encoding(value: string);
    get encodingInput(): string | undefined;
    private _endpointUrlKey?;
    get endpointUrlKey(): string;
    set endpointUrlKey(value: string);
    resetEndpointUrlKey(): void;
    get endpointUrlKeyInput(): string | undefined;
    private _index?;
    get index(): string;
    set index(value: string);
    resetIndex(): void;
    get indexInput(): string | undefined;
    private _sourcetype?;
    get sourcetype(): string;
    set sourcetype(value: string);
    resetSourcetype(): void;
    get sourcetypeInput(): string | undefined;
    private _tokenKey?;
    get tokenKey(): string;
    set tokenKey(value: string);
    resetTokenKey(): void;
    get tokenKeyInput(): string | undefined;
    private _buffer;
    get buffer(): ObservabilityPipelineConfigDestinationSplunkHecBufferList;
    putBuffer(value: ObservabilityPipelineConfigDestinationSplunkHecBuffer[] | cdktn.IResolvable): void;
    resetBuffer(): void;
    get bufferInput(): cdktn.IResolvable | ObservabilityPipelineConfigDestinationSplunkHecBuffer[] | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSplunkHecList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSplunkHec[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSplunkHecOutputReference;
}
export interface ObservabilityPipelineConfigDestinationSumoLogicBufferDisk {
    /**
    * Maximum size of the disk buffer (in bytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#max_size ObservabilityPipeline#max_size}
    */
    readonly maxSize?: number;
    /**
    * Behavior when the buffer is full. Valid values are `block` or `drop_newest`. Defaults to `"block"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#when_full ObservabilityPipeline#when_full}
    */
    readonly whenFull?: string;
}
export declare function observabilityPipelineConfigDestinationSumoLogicBufferDiskToTerraform(struct?: ObservabilityPipelineConfigDestinationSumoLogicBufferDisk | cdktn.IResolvable): any;
export declare function observabilityPipelineConfigDestinationSumoLogicBufferDiskToHclTerraform(struct?: ObservabilityPipelineConfigDestinationSumoLogicBufferDisk | cdktn.IResolvable): any;
export declare class ObservabilityPipelineConfigDestinationSumoLogicBufferDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityPipelineConfigDestinationSumoLogicBufferDisk | cdktn.IResolvable | undefined;
    set internalValue(value: ObservabilityPipelineConfigDestinationSumoLogicBufferDisk | cdktn.IResolvable | undefined);
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    resetMaxSize(): void;
    get maxSizeInput(): number | undefined;
    private _whenFull?;
    get whenFull(): string;
    set whenFull(value: string);
    resetWhenFull(): void;
    get whenFullInput(): string | undefined;
}
export declare class ObservabilityPipelineConfigDestinationSumoLogicBufferDiskList extends cdktn.ComplexList {
    internalValue?: ObservabilityPipelineConfigDestinationSumoLogicBufferDisk[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityPipelineConfigDestinationSumoLogicBufferDiskOutputReference;
}
