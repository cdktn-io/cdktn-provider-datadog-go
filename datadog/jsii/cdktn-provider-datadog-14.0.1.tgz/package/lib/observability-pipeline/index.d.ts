/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { ObservabilityPipelineConfigA, ObservabilityPipelineConfigAList } from './index-structs';
export * from './index-structs';
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ObservabilityPipelineConfig extends cdktn.TerraformMetaArguments {
    /**
    * The pipeline name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#name ObservabilityPipeline#name}
    */
    readonly name: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#config ObservabilityPipeline#config}
    */
    readonly config?: ObservabilityPipelineConfigA[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline datadog_observability_pipeline}
*/
export declare class ObservabilityPipeline extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_observability_pipeline";
    /**
    * Generates CDKTN code for importing a ObservabilityPipeline resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ObservabilityPipeline to import
    * @param importFromId The id of the existing ObservabilityPipeline that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ObservabilityPipeline to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/observability_pipeline datadog_observability_pipeline} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ObservabilityPipelineConfig
    */
    constructor(scope: Construct, id: string, config: ObservabilityPipelineConfig);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _config;
    get config(): ObservabilityPipelineConfigAList;
    putConfig(value: ObservabilityPipelineConfigA[] | cdktn.IResolvable): void;
    resetConfig(): void;
    get configInput(): cdktn.IResolvable | ObservabilityPipelineConfigA[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
