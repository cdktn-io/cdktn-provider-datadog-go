/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ChildOrganizationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/child_organization#id ChildOrganization#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name for Child Organization after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/child_organization#name ChildOrganization#name}
    */
    readonly name: string;
}
export interface ChildOrganizationApiKey {
}
export declare function childOrganizationApiKeyToTerraform(struct?: ChildOrganizationApiKey): any;
export declare function childOrganizationApiKeyToHclTerraform(struct?: ChildOrganizationApiKey): any;
export declare class ChildOrganizationApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChildOrganizationApiKey | undefined;
    set internalValue(value: ChildOrganizationApiKey | undefined);
    get key(): string;
    get name(): string;
}
export declare class ChildOrganizationApiKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChildOrganizationApiKeyOutputReference;
}
export interface ChildOrganizationApplicationKey {
}
export declare function childOrganizationApplicationKeyToTerraform(struct?: ChildOrganizationApplicationKey): any;
export declare function childOrganizationApplicationKeyToHclTerraform(struct?: ChildOrganizationApplicationKey): any;
export declare class ChildOrganizationApplicationKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChildOrganizationApplicationKey | undefined;
    set internalValue(value: ChildOrganizationApplicationKey | undefined);
    get hash(): string;
    get name(): string;
    get owner(): string;
}
export declare class ChildOrganizationApplicationKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChildOrganizationApplicationKeyOutputReference;
}
export interface ChildOrganizationSettingsSaml {
}
export declare function childOrganizationSettingsSamlToTerraform(struct?: ChildOrganizationSettingsSaml): any;
export declare function childOrganizationSettingsSamlToHclTerraform(struct?: ChildOrganizationSettingsSaml): any;
export declare class ChildOrganizationSettingsSamlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChildOrganizationSettingsSaml | undefined;
    set internalValue(value: ChildOrganizationSettingsSaml | undefined);
    get enabled(): cdktn.IResolvable;
}
export declare class ChildOrganizationSettingsSamlList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChildOrganizationSettingsSamlOutputReference;
}
export interface ChildOrganizationSettingsSamlAutocreateUsersDomains {
}
export declare function childOrganizationSettingsSamlAutocreateUsersDomainsToTerraform(struct?: ChildOrganizationSettingsSamlAutocreateUsersDomains): any;
export declare function childOrganizationSettingsSamlAutocreateUsersDomainsToHclTerraform(struct?: ChildOrganizationSettingsSamlAutocreateUsersDomains): any;
export declare class ChildOrganizationSettingsSamlAutocreateUsersDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChildOrganizationSettingsSamlAutocreateUsersDomains | undefined;
    set internalValue(value: ChildOrganizationSettingsSamlAutocreateUsersDomains | undefined);
    get domains(): string[];
    get enabled(): cdktn.IResolvable;
}
export declare class ChildOrganizationSettingsSamlAutocreateUsersDomainsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChildOrganizationSettingsSamlAutocreateUsersDomainsOutputReference;
}
export interface ChildOrganizationSettingsSamlIdpInitiatedLogin {
}
export declare function childOrganizationSettingsSamlIdpInitiatedLoginToTerraform(struct?: ChildOrganizationSettingsSamlIdpInitiatedLogin): any;
export declare function childOrganizationSettingsSamlIdpInitiatedLoginToHclTerraform(struct?: ChildOrganizationSettingsSamlIdpInitiatedLogin): any;
export declare class ChildOrganizationSettingsSamlIdpInitiatedLoginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChildOrganizationSettingsSamlIdpInitiatedLogin | undefined;
    set internalValue(value: ChildOrganizationSettingsSamlIdpInitiatedLogin | undefined);
    get enabled(): cdktn.IResolvable;
}
export declare class ChildOrganizationSettingsSamlIdpInitiatedLoginList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChildOrganizationSettingsSamlIdpInitiatedLoginOutputReference;
}
export interface ChildOrganizationSettingsSamlStrictMode {
}
export declare function childOrganizationSettingsSamlStrictModeToTerraform(struct?: ChildOrganizationSettingsSamlStrictMode): any;
export declare function childOrganizationSettingsSamlStrictModeToHclTerraform(struct?: ChildOrganizationSettingsSamlStrictMode): any;
export declare class ChildOrganizationSettingsSamlStrictModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChildOrganizationSettingsSamlStrictMode | undefined;
    set internalValue(value: ChildOrganizationSettingsSamlStrictMode | undefined);
    get enabled(): cdktn.IResolvable;
}
export declare class ChildOrganizationSettingsSamlStrictModeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChildOrganizationSettingsSamlStrictModeOutputReference;
}
export interface ChildOrganizationSettings {
}
export declare function childOrganizationSettingsToTerraform(struct?: ChildOrganizationSettings): any;
export declare function childOrganizationSettingsToHclTerraform(struct?: ChildOrganizationSettings): any;
export declare class ChildOrganizationSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChildOrganizationSettings | undefined;
    set internalValue(value: ChildOrganizationSettings | undefined);
    get privateWidgetShare(): cdktn.IResolvable;
    private _saml;
    get saml(): ChildOrganizationSettingsSamlList;
    get samlAutocreateAccessRole(): string;
    private _samlAutocreateUsersDomains;
    get samlAutocreateUsersDomains(): ChildOrganizationSettingsSamlAutocreateUsersDomainsList;
    get samlCanBeEnabled(): cdktn.IResolvable;
    get samlIdpEndpoint(): string;
    private _samlIdpInitiatedLogin;
    get samlIdpInitiatedLogin(): ChildOrganizationSettingsSamlIdpInitiatedLoginList;
    get samlIdpMetadataUploaded(): cdktn.IResolvable;
    get samlLoginUrl(): string;
    private _samlStrictMode;
    get samlStrictMode(): ChildOrganizationSettingsSamlStrictModeList;
}
export declare class ChildOrganizationSettingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChildOrganizationSettingsOutputReference;
}
export interface ChildOrganizationUser {
}
export declare function childOrganizationUserToTerraform(struct?: ChildOrganizationUser): any;
export declare function childOrganizationUserToHclTerraform(struct?: ChildOrganizationUser): any;
export declare class ChildOrganizationUserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ChildOrganizationUser | undefined;
    set internalValue(value: ChildOrganizationUser | undefined);
    get accessRole(): string;
    get email(): string;
    get name(): string;
}
export declare class ChildOrganizationUserList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ChildOrganizationUserOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/child_organization datadog_child_organization}
*/
export declare class ChildOrganization extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_child_organization";
    /**
    * Generates CDKTN code for importing a ChildOrganization resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ChildOrganization to import
    * @param importFromId The id of the existing ChildOrganization that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/child_organization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ChildOrganization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/child_organization datadog_child_organization} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ChildOrganizationConfig
    */
    constructor(scope: Construct, id: string, config: ChildOrganizationConfig);
    private _apiKey;
    get apiKey(): ChildOrganizationApiKeyList;
    private _applicationKey;
    get applicationKey(): ChildOrganizationApplicationKeyList;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get publicId(): string;
    private _settings;
    get settings(): ChildOrganizationSettingsList;
    private _user;
    get user(): ChildOrganizationUserList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
