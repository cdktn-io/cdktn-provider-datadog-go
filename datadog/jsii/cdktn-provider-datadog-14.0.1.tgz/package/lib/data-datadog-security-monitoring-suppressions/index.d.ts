/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogSecurityMonitoringSuppressionsConfig extends cdktn.TerraformMetaArguments {
}
export interface DataDatadogSecurityMonitoringSuppressionsSuppressions {
}
export declare function dataDatadogSecurityMonitoringSuppressionsSuppressionsToTerraform(struct?: DataDatadogSecurityMonitoringSuppressionsSuppressions): any;
export declare function dataDatadogSecurityMonitoringSuppressionsSuppressionsToHclTerraform(struct?: DataDatadogSecurityMonitoringSuppressionsSuppressions): any;
export declare class DataDatadogSecurityMonitoringSuppressionsSuppressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogSecurityMonitoringSuppressionsSuppressions | undefined;
    set internalValue(value: DataDatadogSecurityMonitoringSuppressionsSuppressions | undefined);
    get dataExclusionQuery(): string;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get expirationDate(): string;
    get id(): string;
    get name(): string;
    get ruleQuery(): string;
    get startDate(): string;
    get suppressionQuery(): string;
    get tags(): string[];
}
export declare class DataDatadogSecurityMonitoringSuppressionsSuppressionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogSecurityMonitoringSuppressionsSuppressionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/security_monitoring_suppressions datadog_security_monitoring_suppressions}
*/
export declare class DataDatadogSecurityMonitoringSuppressions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_security_monitoring_suppressions";
    /**
    * Generates CDKTN code for importing a DataDatadogSecurityMonitoringSuppressions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogSecurityMonitoringSuppressions to import
    * @param importFromId The id of the existing DataDatadogSecurityMonitoringSuppressions that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/security_monitoring_suppressions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogSecurityMonitoringSuppressions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/security_monitoring_suppressions datadog_security_monitoring_suppressions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogSecurityMonitoringSuppressionsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogSecurityMonitoringSuppressionsConfig);
    get id(): string;
    get suppressionIds(): string[];
    private _suppressions;
    get suppressions(): DataDatadogSecurityMonitoringSuppressionsSuppressionsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
