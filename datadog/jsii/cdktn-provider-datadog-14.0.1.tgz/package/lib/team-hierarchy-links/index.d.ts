/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TeamHierarchyLinksConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the parent team the team hierarchy link is associated with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_hierarchy_links#parent_team_id TeamHierarchyLinks#parent_team_id}
    */
    readonly parentTeamId: string;
    /**
    * ID of the sub team the team hierarchy link is associated with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_hierarchy_links#sub_team_id TeamHierarchyLinks#sub_team_id}
    */
    readonly subTeamId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_hierarchy_links datadog_team_hierarchy_links}
*/
export declare class TeamHierarchyLinks extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_team_hierarchy_links";
    /**
    * Generates CDKTN code for importing a TeamHierarchyLinks resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TeamHierarchyLinks to import
    * @param importFromId The id of the existing TeamHierarchyLinks that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_hierarchy_links#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TeamHierarchyLinks to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/team_hierarchy_links datadog_team_hierarchy_links} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TeamHierarchyLinksConfig
    */
    constructor(scope: Construct, id: string, config: TeamHierarchyLinksConfig);
    get createdAt(): string;
    get id(): string;
    private _parentTeamId?;
    get parentTeamId(): string;
    set parentTeamId(value: string);
    get parentTeamIdInput(): string | undefined;
    get provisionedBy(): string;
    private _subTeamId?;
    get subTeamId(): string;
    set subTeamId(value: string);
    get subTeamIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
