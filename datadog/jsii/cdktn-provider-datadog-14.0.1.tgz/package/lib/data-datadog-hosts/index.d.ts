/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogHostsConfig extends cdktn.TerraformMetaArguments {
    /**
    * String to filter search results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/hosts#filter DataDatadogHosts#filter}
    */
    readonly filter?: string;
    /**
    * Number of seconds since UNIX epoch from which you want to search your hosts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/hosts#from DataDatadogHosts#from}
    */
    readonly from?: number;
    /**
    * Include information on the muted status of hosts and when the mute expires.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/hosts#include_muted_hosts_data DataDatadogHosts#include_muted_hosts_data}
    */
    readonly includeMutedHostsData?: boolean | cdktn.IResolvable;
    /**
    * Direction of sort. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/hosts#sort_dir DataDatadogHosts#sort_dir}
    */
    readonly sortDir?: string;
    /**
    * Sort hosts by this field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/hosts#sort_field DataDatadogHosts#sort_field}
    */
    readonly sortField?: string;
}
export interface DataDatadogHostsHostListMeta {
}
export declare function dataDatadogHostsHostListMetaToTerraform(struct?: DataDatadogHostsHostListMeta): any;
export declare function dataDatadogHostsHostListMetaToHclTerraform(struct?: DataDatadogHostsHostListMeta): any;
export declare class DataDatadogHostsHostListMetaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogHostsHostListMeta | undefined;
    set internalValue(value: DataDatadogHostsHostListMeta | undefined);
    get agentVersion(): string;
    get cpuCores(): number;
    get gohai(): string;
    get machine(): string;
    get platform(): string;
    get processor(): string;
    get pythonVersion(): string;
    get socketFqdn(): string;
    get socketHostname(): string;
}
export interface DataDatadogHostsHostListMetrics {
}
export declare function dataDatadogHostsHostListMetricsToTerraform(struct?: DataDatadogHostsHostListMetrics): any;
export declare function dataDatadogHostsHostListMetricsToHclTerraform(struct?: DataDatadogHostsHostListMetrics): any;
export declare class DataDatadogHostsHostListMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatadogHostsHostListMetrics | undefined;
    set internalValue(value: DataDatadogHostsHostListMetrics | undefined);
    get cpu(): number;
    get iowait(): number;
    get load(): number;
}
export interface DataDatadogHostsHostListStruct {
}
export declare function dataDatadogHostsHostListStructToTerraform(struct?: DataDatadogHostsHostListStruct): any;
export declare function dataDatadogHostsHostListStructToHclTerraform(struct?: DataDatadogHostsHostListStruct): any;
export declare class DataDatadogHostsHostListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogHostsHostListStruct | undefined;
    set internalValue(value: DataDatadogHostsHostListStruct | undefined);
    get aliases(): string[];
    get apps(): string[];
    get awsName(): string;
    get hostName(): string;
    get id(): number;
    get isMuted(): cdktn.IResolvable;
    get lastReportedTime(): number;
    private _meta;
    get meta(): DataDatadogHostsHostListMetaOutputReference;
    private _metrics;
    get metrics(): DataDatadogHostsHostListMetricsOutputReference;
    get muteTimeout(): number;
    get name(): string;
    get sources(): string[];
    private _tagsBySource;
    get tagsBySource(): cdktn.StringListMap;
    get up(): cdktn.IResolvable;
}
export declare class DataDatadogHostsHostListStructList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogHostsHostListStructOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/hosts datadog_hosts}
*/
export declare class DataDatadogHosts extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_hosts";
    /**
    * Generates CDKTN code for importing a DataDatadogHosts resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogHosts to import
    * @param importFromId The id of the existing DataDatadogHosts that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/hosts#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogHosts to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/hosts datadog_hosts} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogHostsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogHostsConfig);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _from?;
    get from(): number;
    set from(value: number);
    resetFrom(): void;
    get fromInput(): number | undefined;
    private _hostList;
    get hostList(): DataDatadogHostsHostListStructList;
    get id(): string;
    private _includeMutedHostsData?;
    get includeMutedHostsData(): boolean | cdktn.IResolvable;
    set includeMutedHostsData(value: boolean | cdktn.IResolvable);
    resetIncludeMutedHostsData(): void;
    get includeMutedHostsDataInput(): boolean | cdktn.IResolvable | undefined;
    private _sortDir?;
    get sortDir(): string;
    set sortDir(value: string);
    resetSortDir(): void;
    get sortDirInput(): string | undefined;
    private _sortField?;
    get sortField(): string;
    set sortField(value: string);
    resetSortField(): void;
    get sortFieldInput(): string | undefined;
    get totalMatching(): number;
    get totalReturned(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
