/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogGcpUcConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Datadog cloud account ID for the GCP Usage Cost configuration you want to retrieve information about.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/gcp_uc_config#cloud_account_id DataDatadogGcpUcConfig#cloud_account_id}
    */
    readonly cloudAccountId: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/gcp_uc_config datadog_gcp_uc_config}
*/
export declare class DataDatadogGcpUcConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_gcp_uc_config";
    /**
    * Generates CDKTN code for importing a DataDatadogGcpUcConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogGcpUcConfig to import
    * @param importFromId The id of the existing DataDatadogGcpUcConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/gcp_uc_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogGcpUcConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/gcp_uc_config datadog_gcp_uc_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogGcpUcConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogGcpUcConfigConfig);
    get accountId(): string;
    get bucketName(): string;
    private _cloudAccountId?;
    get cloudAccountId(): number;
    set cloudAccountId(value: number);
    get cloudAccountIdInput(): number | undefined;
    get createdAt(): string;
    get dataset(): string;
    get errorMessages(): string[];
    get exportPrefix(): string;
    get exportProjectName(): string;
    get id(): string;
    get months(): number;
    get serviceAccount(): string;
    get status(): string;
    get statusUpdatedAt(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
