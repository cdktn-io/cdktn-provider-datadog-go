/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WebhookConfig extends cdktn.TerraformMetaArguments {
    /**
    * The headers attached to the webhook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/webhook#custom_headers Webhook#custom_headers}
    */
    readonly customHeaders?: string;
    /**
    * Encoding type. Valid values are `json`, `form`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/webhook#encode_as Webhook#encode_as}
    */
    readonly encodeAs?: string;
    /**
    * The name of the webhook. It corresponds with `<WEBHOOK_NAME>`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/webhook#name Webhook#name}
    */
    readonly name: string;
    /**
    * The payload of the webhook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/webhook#payload Webhook#payload}
    */
    readonly payload?: string;
    /**
    * The URL of the webhook.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/webhook#url Webhook#url}
    */
    readonly url: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/webhook datadog_webhook}
*/
export declare class Webhook extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_webhook";
    /**
    * Generates CDKTN code for importing a Webhook resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Webhook to import
    * @param importFromId The id of the existing Webhook that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/webhook#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Webhook to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/webhook datadog_webhook} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WebhookConfig
    */
    constructor(scope: Construct, id: string, config: WebhookConfig);
    private _customHeaders?;
    get customHeaders(): string;
    set customHeaders(value: string);
    resetCustomHeaders(): void;
    get customHeadersInput(): string | undefined;
    private _encodeAs?;
    get encodeAs(): string;
    set encodeAs(value: string);
    resetEncodeAs(): void;
    get encodeAsInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _payload?;
    get payload(): string;
    set payload(value: string);
    resetPayload(): void;
    get payloadInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
