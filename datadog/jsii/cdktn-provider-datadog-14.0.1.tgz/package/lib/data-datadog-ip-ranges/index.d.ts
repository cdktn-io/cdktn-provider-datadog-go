/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogIpRangesConfig extends cdktn.TerraformMetaArguments {
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/ip_ranges datadog_ip_ranges}
*/
export declare class DataDatadogIpRanges extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_ip_ranges";
    /**
    * Generates CDKTN code for importing a DataDatadogIpRanges resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogIpRanges to import
    * @param importFromId The id of the existing DataDatadogIpRanges that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/ip_ranges#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogIpRanges to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/ip_ranges datadog_ip_ranges} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogIpRangesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogIpRangesConfig);
    get agentsIpv4(): string[];
    get agentsIpv6(): string[];
    get apiIpv4(): string[];
    get apiIpv6(): string[];
    get apmIpv4(): string[];
    get apmIpv6(): string[];
    get globalIpv4(): string[];
    get globalIpv6(): string[];
    get id(): string;
    get logsIpv4(): string[];
    get logsIpv6(): string[];
    get orchestratorIpv4(): string[];
    get orchestratorIpv6(): string[];
    get processIpv4(): string[];
    get processIpv6(): string[];
    get syntheticsIpv4(): string[];
    private _syntheticsIpv4ByLocation;
    get syntheticsIpv4ByLocation(): cdktn.StringMap;
    get syntheticsIpv6(): string[];
    private _syntheticsIpv6ByLocation;
    get syntheticsIpv6ByLocation(): cdktn.StringMap;
    get webhooksIpv4(): string[];
    get webhooksIpv6(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
