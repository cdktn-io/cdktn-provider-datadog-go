/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogDatastoreItemConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique identifier of the datastore containing the item.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/datastore_item#datastore_id DataDatadogDatastoreItem#datastore_id}
    */
    readonly datastoreId: string;
    /**
    * The primary key value that identifies the item to retrieve.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/datastore_item#item_key DataDatadogDatastoreItem#item_key}
    */
    readonly itemKey: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/datastore_item datadog_datastore_item}
*/
export declare class DataDatadogDatastoreItem extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_datastore_item";
    /**
    * Generates CDKTN code for importing a DataDatadogDatastoreItem resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogDatastoreItem to import
    * @param importFromId The id of the existing DataDatadogDatastoreItem that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/datastore_item#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogDatastoreItem to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/datastore_item datadog_datastore_item} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogDatastoreItemConfig
    */
    constructor(scope: Construct, id: string, config: DataDatadogDatastoreItemConfig);
    get createdAt(): string;
    private _datastoreId?;
    get datastoreId(): string;
    set datastoreId(value: string);
    get datastoreIdInput(): string | undefined;
    get id(): string;
    private _itemKey?;
    get itemKey(): string;
    set itemKey(value: string);
    get itemKeyInput(): string | undefined;
    get modifiedAt(): string;
    get orgId(): number;
    get signature(): string;
    get storeId(): string;
    private _value;
    get value(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
