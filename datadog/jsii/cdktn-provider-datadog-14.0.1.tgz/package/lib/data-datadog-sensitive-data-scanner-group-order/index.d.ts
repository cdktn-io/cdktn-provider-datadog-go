/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogSensitiveDataScannerGroupOrderConfig extends cdktn.TerraformMetaArguments {
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/sensitive_data_scanner_group_order datadog_sensitive_data_scanner_group_order}
*/
export declare class DataDatadogSensitiveDataScannerGroupOrder extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_sensitive_data_scanner_group_order";
    /**
    * Generates CDKTN code for importing a DataDatadogSensitiveDataScannerGroupOrder resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogSensitiveDataScannerGroupOrder to import
    * @param importFromId The id of the existing DataDatadogSensitiveDataScannerGroupOrder that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/sensitive_data_scanner_group_order#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogSensitiveDataScannerGroupOrder to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/sensitive_data_scanner_group_order datadog_sensitive_data_scanner_group_order} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogSensitiveDataScannerGroupOrderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogSensitiveDataScannerGroupOrderConfig);
    get groupIds(): string[];
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
