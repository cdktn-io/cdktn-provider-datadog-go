/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CsmThreatsPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * A description for the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_policy#description CsmThreatsPolicy#description}
    */
    readonly description?: string;
    /**
    * Indicates whether the policy is enabled. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_policy#enabled CsmThreatsPolicy#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Host tags that define where the policy is deployed. Inner values are ANDed, outer arrays are ORed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_policy#host_tags_lists CsmThreatsPolicy#host_tags_lists}
    */
    readonly hostTagsLists?: string[][] | cdktn.IResolvable;
    /**
    * The name of the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_policy#name CsmThreatsPolicy#name}
    */
    readonly name: string;
    /**
    * Host tags that define where the policy is deployed. Deprecated, use host_tags_lists instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_policy#tags CsmThreatsPolicy#tags}
    */
    readonly tags?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_policy datadog_csm_threats_policy}
*/
export declare class CsmThreatsPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_csm_threats_policy";
    /**
    * Generates CDKTN code for importing a CsmThreatsPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CsmThreatsPolicy to import
    * @param importFromId The id of the existing CsmThreatsPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CsmThreatsPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/csm_threats_policy datadog_csm_threats_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CsmThreatsPolicyConfig
    */
    constructor(scope: Construct, id: string, config: CsmThreatsPolicyConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _hostTagsLists?;
    get hostTagsLists(): string[][] | cdktn.IResolvable;
    set hostTagsLists(value: string[][] | cdktn.IResolvable);
    resetHostTagsLists(): void;
    get hostTagsListsInput(): cdktn.IResolvable | string[][] | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
