/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IntegrationMsTeamsWorkflowsWebhookHandleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Your Microsoft Workflows webhook handle name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_ms_teams_workflows_webhook_handle#name IntegrationMsTeamsWorkflowsWebhookHandle#name}
    */
    readonly name: string;
    /**
    * Your Microsoft Workflows webhook URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_ms_teams_workflows_webhook_handle#url IntegrationMsTeamsWorkflowsWebhookHandle#url}
    */
    readonly url: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_ms_teams_workflows_webhook_handle datadog_integration_ms_teams_workflows_webhook_handle}
*/
export declare class IntegrationMsTeamsWorkflowsWebhookHandle extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_integration_ms_teams_workflows_webhook_handle";
    /**
    * Generates CDKTN code for importing a IntegrationMsTeamsWorkflowsWebhookHandle resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IntegrationMsTeamsWorkflowsWebhookHandle to import
    * @param importFromId The id of the existing IntegrationMsTeamsWorkflowsWebhookHandle that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_ms_teams_workflows_webhook_handle#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IntegrationMsTeamsWorkflowsWebhookHandle to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/integration_ms_teams_workflows_webhook_handle datadog_integration_ms_teams_workflows_webhook_handle} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IntegrationMsTeamsWorkflowsWebhookHandleConfig
    */
    constructor(scope: Construct, id: string, config: IntegrationMsTeamsWorkflowsWebhookHandleConfig);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
