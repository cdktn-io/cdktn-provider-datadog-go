/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AgentlessScanningAwsScanOptionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The AWS account ID for which agentless scanning is configured. Must be a valid AWS account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/agentless_scanning_aws_scan_options#aws_account_id AgentlessScanningAwsScanOptions#aws_account_id}
    */
    readonly awsAccountId: string;
    /**
    * Indicates if scanning of Lambda functions is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/agentless_scanning_aws_scan_options#lambda AgentlessScanningAwsScanOptions#lambda}
    */
    readonly lambda: boolean | cdktn.IResolvable;
    /**
    * Indicates if scanning for sensitive data is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/agentless_scanning_aws_scan_options#sensitive_data AgentlessScanningAwsScanOptions#sensitive_data}
    */
    readonly sensitiveData: boolean | cdktn.IResolvable;
    /**
    * Indicates if scanning for vulnerabilities in containers is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/agentless_scanning_aws_scan_options#vuln_containers_os AgentlessScanningAwsScanOptions#vuln_containers_os}
    */
    readonly vulnContainersOs: boolean | cdktn.IResolvable;
    /**
    * Indicates if scanning for vulnerabilities in hosts is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/agentless_scanning_aws_scan_options#vuln_host_os AgentlessScanningAwsScanOptions#vuln_host_os}
    */
    readonly vulnHostOs: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/agentless_scanning_aws_scan_options datadog_agentless_scanning_aws_scan_options}
*/
export declare class AgentlessScanningAwsScanOptions extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_agentless_scanning_aws_scan_options";
    /**
    * Generates CDKTN code for importing a AgentlessScanningAwsScanOptions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AgentlessScanningAwsScanOptions to import
    * @param importFromId The id of the existing AgentlessScanningAwsScanOptions that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/agentless_scanning_aws_scan_options#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AgentlessScanningAwsScanOptions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/agentless_scanning_aws_scan_options datadog_agentless_scanning_aws_scan_options} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AgentlessScanningAwsScanOptionsConfig
    */
    constructor(scope: Construct, id: string, config: AgentlessScanningAwsScanOptionsConfig);
    private _awsAccountId?;
    get awsAccountId(): string;
    set awsAccountId(value: string);
    get awsAccountIdInput(): string | undefined;
    get id(): string;
    private _lambda?;
    get lambda(): boolean | cdktn.IResolvable;
    set lambda(value: boolean | cdktn.IResolvable);
    get lambdaInput(): boolean | cdktn.IResolvable | undefined;
    private _sensitiveData?;
    get sensitiveData(): boolean | cdktn.IResolvable;
    set sensitiveData(value: boolean | cdktn.IResolvable);
    get sensitiveDataInput(): boolean | cdktn.IResolvable | undefined;
    private _vulnContainersOs?;
    get vulnContainersOs(): boolean | cdktn.IResolvable;
    set vulnContainersOs(value: boolean | cdktn.IResolvable);
    get vulnContainersOsInput(): boolean | cdktn.IResolvable | undefined;
    private _vulnHostOs?;
    get vulnHostOs(): boolean | cdktn.IResolvable;
    set vulnHostOs(value: boolean | cdktn.IResolvable);
    get vulnHostOsInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
