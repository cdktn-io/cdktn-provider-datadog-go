/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
export interface DashboardTemplateVariable {
    /**
    * The list of values that the template variable drop-down is be limited to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#available_values Dashboard#available_values}
    */
    readonly availableValues?: string[];
    /**
    * The default value for the template variable on dashboard load. Cannot be used in conjunction with `defaults`. **Deprecated.** Use `defaults` instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#default Dashboard#default}
    */
    readonly default?: string;
    /**
    * One or many default values for template variables on load. If more than one default is specified, they will be unioned together with `OR`. Cannot be used in conjunction with `default`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#defaults Dashboard#defaults}
    */
    readonly defaults?: string[];
    /**
    * The name of the variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#name Dashboard#name}
    */
    readonly name: string;
    /**
    * The tag prefix associated with the variable. Only tags with this prefix appear in the variable dropdown.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#prefix Dashboard#prefix}
    */
    readonly prefix?: string;
}
export declare function dashboardTemplateVariableToTerraform(struct?: DashboardTemplateVariable | cdktn.IResolvable): any;
export declare function dashboardTemplateVariableToHclTerraform(struct?: DashboardTemplateVariable | cdktn.IResolvable): any;
export declare class DashboardTemplateVariableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardTemplateVariable | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardTemplateVariable | cdktn.IResolvable | undefined);
    private _availableValues?;
    get availableValues(): string[];
    set availableValues(value: string[]);
    resetAvailableValues(): void;
    get availableValuesInput(): string[] | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _defaults?;
    get defaults(): string[];
    set defaults(value: string[]);
    resetDefaults(): void;
    get defaultsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
}
export declare class DashboardTemplateVariableList extends cdktn.ComplexList {
    internalValue?: DashboardTemplateVariable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardTemplateVariableOutputReference;
}
export interface DashboardTemplateVariablePresetTemplateVariable {
    /**
    * The name of the template variable
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#name Dashboard#name}
    */
    readonly name?: string;
    /**
    * The value that should be assumed by the template variable in this preset. Cannot be used in conjunction with `values`. **Deprecated.** Use `values` instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#value Dashboard#value}
    */
    readonly value?: string;
    /**
    * One or many template variable values within the saved view, which will be unioned together using `OR` if more than one is specified. Cannot be used in conjunction with `value`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#values Dashboard#values}
    */
    readonly values?: string[];
}
export declare function dashboardTemplateVariablePresetTemplateVariableToTerraform(struct?: DashboardTemplateVariablePresetTemplateVariable | cdktn.IResolvable): any;
export declare function dashboardTemplateVariablePresetTemplateVariableToHclTerraform(struct?: DashboardTemplateVariablePresetTemplateVariable | cdktn.IResolvable): any;
export declare class DashboardTemplateVariablePresetTemplateVariableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardTemplateVariablePresetTemplateVariable | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardTemplateVariablePresetTemplateVariable | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class DashboardTemplateVariablePresetTemplateVariableList extends cdktn.ComplexList {
    internalValue?: DashboardTemplateVariablePresetTemplateVariable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardTemplateVariablePresetTemplateVariableOutputReference;
}
export interface DashboardTemplateVariablePreset {
    /**
    * The name of the preset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#name Dashboard#name}
    */
    readonly name?: string;
    /**
    * template_variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#template_variable Dashboard#template_variable}
    */
    readonly templateVariable?: DashboardTemplateVariablePresetTemplateVariable[] | cdktn.IResolvable;
}
export declare function dashboardTemplateVariablePresetToTerraform(struct?: DashboardTemplateVariablePreset | cdktn.IResolvable): any;
export declare function dashboardTemplateVariablePresetToHclTerraform(struct?: DashboardTemplateVariablePreset | cdktn.IResolvable): any;
export declare class DashboardTemplateVariablePresetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardTemplateVariablePreset | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardTemplateVariablePreset | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _templateVariable;
    get templateVariable(): DashboardTemplateVariablePresetTemplateVariableList;
    putTemplateVariable(value: DashboardTemplateVariablePresetTemplateVariable[] | cdktn.IResolvable): void;
    resetTemplateVariable(): void;
    get templateVariableInput(): cdktn.IResolvable | DashboardTemplateVariablePresetTemplateVariable[] | undefined;
}
export declare class DashboardTemplateVariablePresetList extends cdktn.ComplexList {
    internalValue?: DashboardTemplateVariablePreset[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardTemplateVariablePresetOutputReference;
}
export interface DashboardWidgetAlertGraphDefinition {
    /**
    * The ID of the monitor used by the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#alert_id Dashboard#alert_id}
    */
    readonly alertId: string;
    /**
    * Hide any portion of the widget's timeframe that is incomplete due to cost data not being available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#hide_incomplete_cost_data Dashboard#hide_incomplete_cost_data}
    */
    readonly hideIncompleteCostData?: boolean | cdktn.IResolvable;
    /**
    * The timeframe to use when displaying the widget. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#live_span Dashboard#live_span}
    */
    readonly liveSpan?: string;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title Dashboard#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title_align Dashboard#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title_size Dashboard#title_size}
    */
    readonly titleSize?: string;
    /**
    * Type of visualization to use when displaying the widget. Valid values are `timeseries`, `toplist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#viz_type Dashboard#viz_type}
    */
    readonly vizType: string;
}
export declare function dashboardWidgetAlertGraphDefinitionToTerraform(struct?: DashboardWidgetAlertGraphDefinitionOutputReference | DashboardWidgetAlertGraphDefinition): any;
export declare function dashboardWidgetAlertGraphDefinitionToHclTerraform(struct?: DashboardWidgetAlertGraphDefinitionOutputReference | DashboardWidgetAlertGraphDefinition): any;
export declare class DashboardWidgetAlertGraphDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetAlertGraphDefinition | undefined;
    set internalValue(value: DashboardWidgetAlertGraphDefinition | undefined);
    private _alertId?;
    get alertId(): string;
    set alertId(value: string);
    get alertIdInput(): string | undefined;
    private _hideIncompleteCostData?;
    get hideIncompleteCostData(): boolean | cdktn.IResolvable;
    set hideIncompleteCostData(value: boolean | cdktn.IResolvable);
    resetHideIncompleteCostData(): void;
    get hideIncompleteCostDataInput(): boolean | cdktn.IResolvable | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _vizType?;
    get vizType(): string;
    set vizType(value: string);
    get vizTypeInput(): string | undefined;
}
export interface DashboardWidgetAlertValueDefinition {
    /**
    * The ID of the monitor used by the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#alert_id Dashboard#alert_id}
    */
    readonly alertId: string;
    /**
    * The precision to use when displaying the value. Use `*` for maximum precision.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#precision Dashboard#precision}
    */
    readonly precision?: number;
    /**
    * The alignment of the text in the widget. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#text_align Dashboard#text_align}
    */
    readonly textAlign?: string;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title Dashboard#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title_align Dashboard#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title_size Dashboard#title_size}
    */
    readonly titleSize?: string;
    /**
    * The unit for the value displayed in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#unit Dashboard#unit}
    */
    readonly unit?: string;
}
export declare function dashboardWidgetAlertValueDefinitionToTerraform(struct?: DashboardWidgetAlertValueDefinitionOutputReference | DashboardWidgetAlertValueDefinition): any;
export declare function dashboardWidgetAlertValueDefinitionToHclTerraform(struct?: DashboardWidgetAlertValueDefinitionOutputReference | DashboardWidgetAlertValueDefinition): any;
export declare class DashboardWidgetAlertValueDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetAlertValueDefinition | undefined;
    set internalValue(value: DashboardWidgetAlertValueDefinition | undefined);
    private _alertId?;
    get alertId(): string;
    set alertId(value: string);
    get alertIdInput(): string | undefined;
    private _precision?;
    get precision(): number;
    set precision(value: number);
    resetPrecision(): void;
    get precisionInput(): number | undefined;
    private _textAlign?;
    get textAlign(): string;
    set textAlign(value: string);
    resetTextAlign(): void;
    get textAlignInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export interface DashboardWidgetChangeDefinitionCustomLink {
    /**
    * The flag for toggling context menu link visibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#is_hidden Dashboard#is_hidden}
    */
    readonly isHidden?: boolean | cdktn.IResolvable;
    /**
    * The label for the custom link URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#label Dashboard#label}
    */
    readonly label?: string;
    /**
    * The URL of the custom link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#link Dashboard#link}
    */
    readonly link?: string;
    /**
    * The label ID that refers to a context menu link item. When `override_label` is provided, the client request omits the label field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#override_label Dashboard#override_label}
    */
    readonly overrideLabel?: string;
}
export declare function dashboardWidgetChangeDefinitionCustomLinkToTerraform(struct?: DashboardWidgetChangeDefinitionCustomLink | cdktn.IResolvable): any;
export declare function dashboardWidgetChangeDefinitionCustomLinkToHclTerraform(struct?: DashboardWidgetChangeDefinitionCustomLink | cdktn.IResolvable): any;
export declare class DashboardWidgetChangeDefinitionCustomLinkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetChangeDefinitionCustomLink | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionCustomLink | cdktn.IResolvable | undefined);
    private _isHidden?;
    get isHidden(): boolean | cdktn.IResolvable;
    set isHidden(value: boolean | cdktn.IResolvable);
    resetIsHidden(): void;
    get isHiddenInput(): boolean | cdktn.IResolvable | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _link?;
    get link(): string;
    set link(value: string);
    resetLink(): void;
    get linkInput(): string | undefined;
    private _overrideLabel?;
    get overrideLabel(): string;
    set overrideLabel(value: string);
    resetOverrideLabel(): void;
    get overrideLabelInput(): string | undefined;
}
export declare class DashboardWidgetChangeDefinitionCustomLinkList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetChangeDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetChangeDefinitionCustomLinkOutputReference;
}
export interface DashboardWidgetChangeDefinitionRequestApmQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: number;
}
export declare function dashboardWidgetChangeDefinitionRequestApmQueryComputeQueryToTerraform(struct?: DashboardWidgetChangeDefinitionRequestApmQueryComputeQueryOutputReference | DashboardWidgetChangeDefinitionRequestApmQueryComputeQuery): any;
export declare function dashboardWidgetChangeDefinitionRequestApmQueryComputeQueryToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestApmQueryComputeQueryOutputReference | DashboardWidgetChangeDefinitionRequestApmQueryComputeQuery): any;
export declare class DashboardWidgetChangeDefinitionRequestApmQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestApmQueryComputeQuery | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestApmQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestApmQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#order Dashboard#order}
    */
    readonly order: string;
}
export declare function dashboardWidgetChangeDefinitionRequestApmQueryGroupBySortQueryToTerraform(struct?: DashboardWidgetChangeDefinitionRequestApmQueryGroupBySortQueryOutputReference | DashboardWidgetChangeDefinitionRequestApmQueryGroupBySortQuery): any;
export declare function dashboardWidgetChangeDefinitionRequestApmQueryGroupBySortQueryToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestApmQueryGroupBySortQueryOutputReference | DashboardWidgetChangeDefinitionRequestApmQueryGroupBySortQuery): any;
export declare class DashboardWidgetChangeDefinitionRequestApmQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestApmQueryGroupBySortQuery | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestApmQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestApmQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#limit Dashboard#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#sort_query Dashboard#sort_query}
    */
    readonly sortQuery?: DashboardWidgetChangeDefinitionRequestApmQueryGroupBySortQuery;
}
export declare function dashboardWidgetChangeDefinitionRequestApmQueryGroupByToTerraform(struct?: DashboardWidgetChangeDefinitionRequestApmQueryGroupBy | cdktn.IResolvable): any;
export declare function dashboardWidgetChangeDefinitionRequestApmQueryGroupByToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestApmQueryGroupBy | cdktn.IResolvable): any;
export declare class DashboardWidgetChangeDefinitionRequestApmQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetChangeDefinitionRequestApmQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestApmQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): DashboardWidgetChangeDefinitionRequestApmQueryGroupBySortQueryOutputReference;
    putSortQuery(value: DashboardWidgetChangeDefinitionRequestApmQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): DashboardWidgetChangeDefinitionRequestApmQueryGroupBySortQuery | undefined;
}
export declare class DashboardWidgetChangeDefinitionRequestApmQueryGroupByList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetChangeDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetChangeDefinitionRequestApmQueryGroupByOutputReference;
}
export interface DashboardWidgetChangeDefinitionRequestApmQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: number;
}
export declare function dashboardWidgetChangeDefinitionRequestApmQueryMultiComputeToTerraform(struct?: DashboardWidgetChangeDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable): any;
export declare function dashboardWidgetChangeDefinitionRequestApmQueryMultiComputeToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable): any;
export declare class DashboardWidgetChangeDefinitionRequestApmQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetChangeDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class DashboardWidgetChangeDefinitionRequestApmQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetChangeDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetChangeDefinitionRequestApmQueryMultiComputeOutputReference;
}
export interface DashboardWidgetChangeDefinitionRequestApmQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#index Dashboard#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#search_query Dashboard#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#compute_query Dashboard#compute_query}
    */
    readonly computeQuery?: DashboardWidgetChangeDefinitionRequestApmQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#group_by Dashboard#group_by}
    */
    readonly groupBy?: DashboardWidgetChangeDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#multi_compute Dashboard#multi_compute}
    */
    readonly multiCompute?: DashboardWidgetChangeDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function dashboardWidgetChangeDefinitionRequestApmQueryToTerraform(struct?: DashboardWidgetChangeDefinitionRequestApmQueryOutputReference | DashboardWidgetChangeDefinitionRequestApmQuery): any;
export declare function dashboardWidgetChangeDefinitionRequestApmQueryToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestApmQueryOutputReference | DashboardWidgetChangeDefinitionRequestApmQuery): any;
export declare class DashboardWidgetChangeDefinitionRequestApmQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestApmQuery | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestApmQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): DashboardWidgetChangeDefinitionRequestApmQueryComputeQueryOutputReference;
    putComputeQuery(value: DashboardWidgetChangeDefinitionRequestApmQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): DashboardWidgetChangeDefinitionRequestApmQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): DashboardWidgetChangeDefinitionRequestApmQueryGroupByList;
    putGroupBy(value: DashboardWidgetChangeDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | DashboardWidgetChangeDefinitionRequestApmQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): DashboardWidgetChangeDefinitionRequestApmQueryMultiComputeList;
    putMultiCompute(value: DashboardWidgetChangeDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | DashboardWidgetChangeDefinitionRequestApmQueryMultiCompute[] | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestFormulaConditionalFormats {
    /**
    * The comparator to use. Valid values are `=`, `>`, `>=`, `<`, `<=`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#comparator Dashboard#comparator}
    */
    readonly comparator: string;
    /**
    * The color palette to apply to the background, same values available as palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#custom_bg_color Dashboard#custom_bg_color}
    */
    readonly customBgColor?: string;
    /**
    * The color palette to apply to the foreground, same values available as palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#custom_fg_color Dashboard#custom_fg_color}
    */
    readonly customFgColor?: string;
    /**
    * Setting this to True hides values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#hide_value Dashboard#hide_value}
    */
    readonly hideValue?: boolean | cdktn.IResolvable;
    /**
    * Displays an image as the background.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#image_url Dashboard#image_url}
    */
    readonly imageUrl?: string;
    /**
    * The metric from the request to correlate with this conditional format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#metric Dashboard#metric}
    */
    readonly metric?: string;
    /**
    * The color palette to apply. Valid values are `blue`, `custom_bg`, `custom_image`, `custom_text`, `gray_on_white`, `grey`, `green`, `orange`, `red`, `red_on_white`, `white_on_gray`, `white_on_green`, `green_on_white`, `white_on_red`, `white_on_yellow`, `yellow_on_white`, `black_on_light_yellow`, `black_on_light_green`, `black_on_light_red`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#palette Dashboard#palette}
    */
    readonly palette: string;
    /**
    * Defines the displayed timeframe.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#timeframe Dashboard#timeframe}
    */
    readonly timeframe?: string;
    /**
    * A value for the comparator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#value Dashboard#value}
    */
    readonly value: number;
}
export declare function dashboardWidgetChangeDefinitionRequestFormulaConditionalFormatsToTerraform(struct?: DashboardWidgetChangeDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable): any;
export declare function dashboardWidgetChangeDefinitionRequestFormulaConditionalFormatsToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable): any;
export declare class DashboardWidgetChangeDefinitionRequestFormulaConditionalFormatsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetChangeDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable | undefined);
    private _comparator?;
    get comparator(): string;
    set comparator(value: string);
    get comparatorInput(): string | undefined;
    private _customBgColor?;
    get customBgColor(): string;
    set customBgColor(value: string);
    resetCustomBgColor(): void;
    get customBgColorInput(): string | undefined;
    private _customFgColor?;
    get customFgColor(): string;
    set customFgColor(value: string);
    resetCustomFgColor(): void;
    get customFgColorInput(): string | undefined;
    private _hideValue?;
    get hideValue(): boolean | cdktn.IResolvable;
    set hideValue(value: boolean | cdktn.IResolvable);
    resetHideValue(): void;
    get hideValueInput(): boolean | cdktn.IResolvable | undefined;
    private _imageUrl?;
    get imageUrl(): string;
    set imageUrl(value: string);
    resetImageUrl(): void;
    get imageUrlInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _palette?;
    get palette(): string;
    set palette(value: string);
    get paletteInput(): string | undefined;
    private _timeframe?;
    get timeframe(): string;
    set timeframe(value: string);
    resetTimeframe(): void;
    get timeframeInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DashboardWidgetChangeDefinitionRequestFormulaConditionalFormatsList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetChangeDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetChangeDefinitionRequestFormulaConditionalFormatsOutputReference;
}
export interface DashboardWidgetChangeDefinitionRequestFormulaLimit {
    /**
    * The number of results to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#count Dashboard#count}
    */
    readonly count?: number;
    /**
    * The direction of the sort. Valid values are `asc`, `desc`. Defaults to `"desc"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#order Dashboard#order}
    */
    readonly order?: string;
}
export declare function dashboardWidgetChangeDefinitionRequestFormulaLimitToTerraform(struct?: DashboardWidgetChangeDefinitionRequestFormulaLimitOutputReference | DashboardWidgetChangeDefinitionRequestFormulaLimit): any;
export declare function dashboardWidgetChangeDefinitionRequestFormulaLimitToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestFormulaLimitOutputReference | DashboardWidgetChangeDefinitionRequestFormulaLimit): any;
export declare class DashboardWidgetChangeDefinitionRequestFormulaLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestFormulaLimit | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestFormulaLimit | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    resetCount(): void;
    get countInput(): number | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonical {
    /**
    * per unit name. If you want to represent megabytes/s, you set 'unit_name' = 'megabyte' and 'per_unit_name = 'second'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#per_unit_name Dashboard#per_unit_name}
    */
    readonly perUnitName?: string;
    /**
    * Unit name. It should be in singular form ('megabyte' and not 'megabytes')
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#unit_name Dashboard#unit_name}
    */
    readonly unitName: string;
}
export declare function dashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonicalToTerraform(struct?: DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference | DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonical): any;
export declare function dashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonicalToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference | DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonical): any;
export declare class DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonical | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonical | undefined);
    private _perUnitName?;
    get perUnitName(): string;
    set perUnitName(value: string);
    resetPerUnitName(): void;
    get perUnitNameInput(): string | undefined;
    private _unitName?;
    get unitName(): string;
    set unitName(value: string);
    get unitNameInput(): string | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustom {
    /**
    * Unit label
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#label Dashboard#label}
    */
    readonly label: string;
}
export declare function dashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustomToTerraform(struct?: DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustomOutputReference | DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustom): any;
export declare function dashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustomToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustomOutputReference | DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustom): any;
export declare class DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustom | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustom | undefined);
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnit {
    /**
    * canonical block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#canonical Dashboard#canonical}
    */
    readonly canonical?: DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonical;
    /**
    * custom block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#custom Dashboard#custom}
    */
    readonly custom?: DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustom;
}
export declare function dashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitToTerraform(struct?: DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitOutputReference | DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnit): any;
export declare function dashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitOutputReference | DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnit): any;
export declare class DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnit | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnit | undefined);
    private _canonical;
    get canonical(): DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference;
    putCanonical(value: DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonical): void;
    resetCanonical(): void;
    get canonicalInput(): DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonical | undefined;
    private _custom;
    get custom(): DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustomOutputReference;
    putCustom(value: DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustom): void;
    resetCustom(): void;
    get customInput(): DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustom | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitScale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#unit_name Dashboard#unit_name}
    */
    readonly unitName: string;
}
export declare function dashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitScaleToTerraform(struct?: DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitScaleOutputReference | DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitScale): any;
export declare function dashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitScaleToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitScaleOutputReference | DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitScale): any;
export declare class DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitScaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitScale | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitScale | undefined);
    private _unitName?;
    get unitName(): string;
    set unitName(value: string);
    get unitNameInput(): string | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestFormulaNumberFormat {
    /**
    * unit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#unit Dashboard#unit}
    */
    readonly unit: DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnit;
    /**
    * unit_scale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#unit_scale Dashboard#unit_scale}
    */
    readonly unitScale?: DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitScale;
}
export declare function dashboardWidgetChangeDefinitionRequestFormulaNumberFormatToTerraform(struct?: DashboardWidgetChangeDefinitionRequestFormulaNumberFormatOutputReference | DashboardWidgetChangeDefinitionRequestFormulaNumberFormat): any;
export declare function dashboardWidgetChangeDefinitionRequestFormulaNumberFormatToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestFormulaNumberFormatOutputReference | DashboardWidgetChangeDefinitionRequestFormulaNumberFormat): any;
export declare class DashboardWidgetChangeDefinitionRequestFormulaNumberFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestFormulaNumberFormat | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestFormulaNumberFormat | undefined);
    private _unit;
    get unit(): DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitOutputReference;
    putUnit(value: DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnit): void;
    get unitInput(): DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnit | undefined;
    private _unitScale;
    get unitScale(): DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitScaleOutputReference;
    putUnitScale(value: DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitScale): void;
    resetUnitScale(): void;
    get unitScaleInput(): DashboardWidgetChangeDefinitionRequestFormulaNumberFormatUnitScale | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestFormulaStyle {
    /**
    * The color palette used to display the formula. A guide to the available color palettes can be found at https://docs.datadoghq.com/dashboards/guide/widget_colors.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#palette Dashboard#palette}
    */
    readonly palette?: string;
    /**
    * Index specifying which color to use within the palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#palette_index Dashboard#palette_index}
    */
    readonly paletteIndex?: number;
}
export declare function dashboardWidgetChangeDefinitionRequestFormulaStyleToTerraform(struct?: DashboardWidgetChangeDefinitionRequestFormulaStyleOutputReference | DashboardWidgetChangeDefinitionRequestFormulaStyle): any;
export declare function dashboardWidgetChangeDefinitionRequestFormulaStyleToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestFormulaStyleOutputReference | DashboardWidgetChangeDefinitionRequestFormulaStyle): any;
export declare class DashboardWidgetChangeDefinitionRequestFormulaStyleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestFormulaStyle | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestFormulaStyle | undefined);
    private _palette?;
    get palette(): string;
    set palette(value: string);
    resetPalette(): void;
    get paletteInput(): string | undefined;
    private _paletteIndex?;
    get paletteIndex(): number;
    set paletteIndex(value: number);
    resetPaletteIndex(): void;
    get paletteIndexInput(): number | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestFormula {
    /**
    * An expression alias.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#alias Dashboard#alias}
    */
    readonly alias?: string;
    /**
    * A list of display modes for each table cell. Valid values are `number`, `bar`, `trend`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#cell_display_mode Dashboard#cell_display_mode}
    */
    readonly cellDisplayMode?: string;
    /**
    * A string expression built from queries, formulas, and functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#formula_expression Dashboard#formula_expression}
    */
    readonly formulaExpression: string;
    /**
    * conditional_formats block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#conditional_formats Dashboard#conditional_formats}
    */
    readonly conditionalFormats?: DashboardWidgetChangeDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#limit Dashboard#limit}
    */
    readonly limit?: DashboardWidgetChangeDefinitionRequestFormulaLimit;
    /**
    * number_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#number_format Dashboard#number_format}
    */
    readonly numberFormat?: DashboardWidgetChangeDefinitionRequestFormulaNumberFormat;
    /**
    * style block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#style Dashboard#style}
    */
    readonly style?: DashboardWidgetChangeDefinitionRequestFormulaStyle;
}
export declare function dashboardWidgetChangeDefinitionRequestFormulaToTerraform(struct?: DashboardWidgetChangeDefinitionRequestFormula | cdktn.IResolvable): any;
export declare function dashboardWidgetChangeDefinitionRequestFormulaToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestFormula | cdktn.IResolvable): any;
export declare class DashboardWidgetChangeDefinitionRequestFormulaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetChangeDefinitionRequestFormula | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestFormula | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _cellDisplayMode?;
    get cellDisplayMode(): string;
    set cellDisplayMode(value: string);
    resetCellDisplayMode(): void;
    get cellDisplayModeInput(): string | undefined;
    private _formulaExpression?;
    get formulaExpression(): string;
    set formulaExpression(value: string);
    get formulaExpressionInput(): string | undefined;
    private _conditionalFormats;
    get conditionalFormats(): DashboardWidgetChangeDefinitionRequestFormulaConditionalFormatsList;
    putConditionalFormats(value: DashboardWidgetChangeDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable): void;
    resetConditionalFormats(): void;
    get conditionalFormatsInput(): cdktn.IResolvable | DashboardWidgetChangeDefinitionRequestFormulaConditionalFormats[] | undefined;
    private _limit;
    get limit(): DashboardWidgetChangeDefinitionRequestFormulaLimitOutputReference;
    putLimit(value: DashboardWidgetChangeDefinitionRequestFormulaLimit): void;
    resetLimit(): void;
    get limitInput(): DashboardWidgetChangeDefinitionRequestFormulaLimit | undefined;
    private _numberFormat;
    get numberFormat(): DashboardWidgetChangeDefinitionRequestFormulaNumberFormatOutputReference;
    putNumberFormat(value: DashboardWidgetChangeDefinitionRequestFormulaNumberFormat): void;
    resetNumberFormat(): void;
    get numberFormatInput(): DashboardWidgetChangeDefinitionRequestFormulaNumberFormat | undefined;
    private _style;
    get style(): DashboardWidgetChangeDefinitionRequestFormulaStyleOutputReference;
    putStyle(value: DashboardWidgetChangeDefinitionRequestFormulaStyle): void;
    resetStyle(): void;
    get styleInput(): DashboardWidgetChangeDefinitionRequestFormulaStyle | undefined;
}
export declare class DashboardWidgetChangeDefinitionRequestFormulaList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetChangeDefinitionRequestFormula[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetChangeDefinitionRequestFormulaOutputReference;
}
export interface DashboardWidgetChangeDefinitionRequestLogQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: number;
}
export declare function dashboardWidgetChangeDefinitionRequestLogQueryComputeQueryToTerraform(struct?: DashboardWidgetChangeDefinitionRequestLogQueryComputeQueryOutputReference | DashboardWidgetChangeDefinitionRequestLogQueryComputeQuery): any;
export declare function dashboardWidgetChangeDefinitionRequestLogQueryComputeQueryToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestLogQueryComputeQueryOutputReference | DashboardWidgetChangeDefinitionRequestLogQueryComputeQuery): any;
export declare class DashboardWidgetChangeDefinitionRequestLogQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestLogQueryComputeQuery | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestLogQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestLogQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#order Dashboard#order}
    */
    readonly order: string;
}
export declare function dashboardWidgetChangeDefinitionRequestLogQueryGroupBySortQueryToTerraform(struct?: DashboardWidgetChangeDefinitionRequestLogQueryGroupBySortQueryOutputReference | DashboardWidgetChangeDefinitionRequestLogQueryGroupBySortQuery): any;
export declare function dashboardWidgetChangeDefinitionRequestLogQueryGroupBySortQueryToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestLogQueryGroupBySortQueryOutputReference | DashboardWidgetChangeDefinitionRequestLogQueryGroupBySortQuery): any;
export declare class DashboardWidgetChangeDefinitionRequestLogQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestLogQueryGroupBySortQuery | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestLogQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestLogQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#limit Dashboard#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#sort_query Dashboard#sort_query}
    */
    readonly sortQuery?: DashboardWidgetChangeDefinitionRequestLogQueryGroupBySortQuery;
}
export declare function dashboardWidgetChangeDefinitionRequestLogQueryGroupByToTerraform(struct?: DashboardWidgetChangeDefinitionRequestLogQueryGroupBy | cdktn.IResolvable): any;
export declare function dashboardWidgetChangeDefinitionRequestLogQueryGroupByToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestLogQueryGroupBy | cdktn.IResolvable): any;
export declare class DashboardWidgetChangeDefinitionRequestLogQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetChangeDefinitionRequestLogQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestLogQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): DashboardWidgetChangeDefinitionRequestLogQueryGroupBySortQueryOutputReference;
    putSortQuery(value: DashboardWidgetChangeDefinitionRequestLogQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): DashboardWidgetChangeDefinitionRequestLogQueryGroupBySortQuery | undefined;
}
export declare class DashboardWidgetChangeDefinitionRequestLogQueryGroupByList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetChangeDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetChangeDefinitionRequestLogQueryGroupByOutputReference;
}
export interface DashboardWidgetChangeDefinitionRequestLogQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: number;
}
export declare function dashboardWidgetChangeDefinitionRequestLogQueryMultiComputeToTerraform(struct?: DashboardWidgetChangeDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable): any;
export declare function dashboardWidgetChangeDefinitionRequestLogQueryMultiComputeToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable): any;
export declare class DashboardWidgetChangeDefinitionRequestLogQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetChangeDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class DashboardWidgetChangeDefinitionRequestLogQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetChangeDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetChangeDefinitionRequestLogQueryMultiComputeOutputReference;
}
export interface DashboardWidgetChangeDefinitionRequestLogQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#index Dashboard#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#search_query Dashboard#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#compute_query Dashboard#compute_query}
    */
    readonly computeQuery?: DashboardWidgetChangeDefinitionRequestLogQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#group_by Dashboard#group_by}
    */
    readonly groupBy?: DashboardWidgetChangeDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#multi_compute Dashboard#multi_compute}
    */
    readonly multiCompute?: DashboardWidgetChangeDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function dashboardWidgetChangeDefinitionRequestLogQueryToTerraform(struct?: DashboardWidgetChangeDefinitionRequestLogQueryOutputReference | DashboardWidgetChangeDefinitionRequestLogQuery): any;
export declare function dashboardWidgetChangeDefinitionRequestLogQueryToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestLogQueryOutputReference | DashboardWidgetChangeDefinitionRequestLogQuery): any;
export declare class DashboardWidgetChangeDefinitionRequestLogQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestLogQuery | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestLogQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): DashboardWidgetChangeDefinitionRequestLogQueryComputeQueryOutputReference;
    putComputeQuery(value: DashboardWidgetChangeDefinitionRequestLogQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): DashboardWidgetChangeDefinitionRequestLogQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): DashboardWidgetChangeDefinitionRequestLogQueryGroupByList;
    putGroupBy(value: DashboardWidgetChangeDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | DashboardWidgetChangeDefinitionRequestLogQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): DashboardWidgetChangeDefinitionRequestLogQueryMultiComputeList;
    putMultiCompute(value: DashboardWidgetChangeDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | DashboardWidgetChangeDefinitionRequestLogQueryMultiCompute[] | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestProcessQuery {
    /**
    * A list of processes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#filter_by Dashboard#filter_by}
    */
    readonly filterBy?: string[];
    /**
    * The max number of items in the filter list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#limit Dashboard#limit}
    */
    readonly limit?: number;
    /**
    * Your chosen metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#metric Dashboard#metric}
    */
    readonly metric: string;
    /**
    * Your chosen search term.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#search_by Dashboard#search_by}
    */
    readonly searchBy?: string;
}
export declare function dashboardWidgetChangeDefinitionRequestProcessQueryToTerraform(struct?: DashboardWidgetChangeDefinitionRequestProcessQueryOutputReference | DashboardWidgetChangeDefinitionRequestProcessQuery): any;
export declare function dashboardWidgetChangeDefinitionRequestProcessQueryToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestProcessQueryOutputReference | DashboardWidgetChangeDefinitionRequestProcessQuery): any;
export declare class DashboardWidgetChangeDefinitionRequestProcessQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestProcessQuery | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestProcessQuery | undefined);
    private _filterBy?;
    get filterBy(): string[];
    set filterBy(value: string[]);
    resetFilterBy(): void;
    get filterByInput(): string[] | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _searchBy?;
    get searchBy(): string;
    set searchBy(value: string);
    resetSearchBy(): void;
    get searchByInput(): string | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestQueryApmDependencyStatsQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#cross_org_uuids Dashboard#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for APM Dependency Stats queries. Valid values are `apm_dependency_stats`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#data_source Dashboard#data_source}
    */
    readonly dataSource: string;
    /**
    * APM environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#env Dashboard#env}
    */
    readonly env: string;
    /**
    * Determines whether stats for upstream or downstream dependencies should be queried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#is_upstream Dashboard#is_upstream}
    */
    readonly isUpstream?: boolean | cdktn.IResolvable;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#name Dashboard#name}
    */
    readonly name: string;
    /**
    * Name of operation on service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#operation_name Dashboard#operation_name}
    */
    readonly operationName: string;
    /**
    * The name of the second primary tag used within APM; required when `primary_tag_value` is specified. See https://docs.datadoghq.com/tracing/guide/setting_primary_tags_to_scope/#add-a-second-primary-tag-in-datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#primary_tag_name Dashboard#primary_tag_name}
    */
    readonly primaryTagName?: string;
    /**
    * Filter APM data by the second primary tag. `primary_tag_name` must also be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#primary_tag_value Dashboard#primary_tag_value}
    */
    readonly primaryTagValue?: string;
    /**
    * APM resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#resource_name Dashboard#resource_name}
    */
    readonly resourceName: string;
    /**
    * APM service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#service Dashboard#service}
    */
    readonly service: string;
    /**
    * APM statistic. Valid values are `avg_duration`, `avg_root_duration`, `avg_spans_per_trace`, `error_rate`, `pct_exec_time`, `pct_of_traces`, `total_traces_count`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#stat Dashboard#stat}
    */
    readonly stat: string;
}
export declare function dashboardWidgetChangeDefinitionRequestQueryApmDependencyStatsQueryToTerraform(struct?: DashboardWidgetChangeDefinitionRequestQueryApmDependencyStatsQueryOutputReference | DashboardWidgetChangeDefinitionRequestQueryApmDependencyStatsQuery): any;
export declare function dashboardWidgetChangeDefinitionRequestQueryApmDependencyStatsQueryToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestQueryApmDependencyStatsQueryOutputReference | DashboardWidgetChangeDefinitionRequestQueryApmDependencyStatsQuery): any;
export declare class DashboardWidgetChangeDefinitionRequestQueryApmDependencyStatsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestQueryApmDependencyStatsQuery | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestQueryApmDependencyStatsQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    private _isUpstream?;
    get isUpstream(): boolean | cdktn.IResolvable;
    set isUpstream(value: boolean | cdktn.IResolvable);
    resetIsUpstream(): void;
    get isUpstreamInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    get operationNameInput(): string | undefined;
    private _primaryTagName?;
    get primaryTagName(): string;
    set primaryTagName(value: string);
    resetPrimaryTagName(): void;
    get primaryTagNameInput(): string | undefined;
    private _primaryTagValue?;
    get primaryTagValue(): string;
    set primaryTagValue(value: string);
    resetPrimaryTagValue(): void;
    get primaryTagValueInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    get resourceNameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    get statInput(): string | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestQueryApmResourceStatsQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#cross_org_uuids Dashboard#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for APM Resource Stats queries. Valid values are `apm_resource_stats`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#data_source Dashboard#data_source}
    */
    readonly dataSource: string;
    /**
    * APM environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#env Dashboard#env}
    */
    readonly env: string;
    /**
    * Array of fields to group results by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#group_by Dashboard#group_by}
    */
    readonly groupBy?: string[];
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#name Dashboard#name}
    */
    readonly name: string;
    /**
    * Name of operation on service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#operation_name Dashboard#operation_name}
    */
    readonly operationName?: string;
    /**
    * The name of the second primary tag used within APM; required when `primary_tag_value` is specified. See https://docs.datadoghq.com/tracing/guide/setting_primary_tags_to_scope/#add-a-second-primary-tag-in-datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#primary_tag_name Dashboard#primary_tag_name}
    */
    readonly primaryTagName?: string;
    /**
    * Filter APM data by the second primary tag. `primary_tag_name` must also be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#primary_tag_value Dashboard#primary_tag_value}
    */
    readonly primaryTagValue?: string;
    /**
    * APM resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#resource_name Dashboard#resource_name}
    */
    readonly resourceName?: string;
    /**
    * APM service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#service Dashboard#service}
    */
    readonly service: string;
    /**
    * APM statistic. Valid values are `errors`, `error_rate`, `hits`, `latency_avg`, `latency_distribution`, `latency_max`, `latency_p50`, `latency_p75`, `latency_p90`, `latency_p95`, `latency_p99`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#stat Dashboard#stat}
    */
    readonly stat: string;
}
export declare function dashboardWidgetChangeDefinitionRequestQueryApmResourceStatsQueryToTerraform(struct?: DashboardWidgetChangeDefinitionRequestQueryApmResourceStatsQueryOutputReference | DashboardWidgetChangeDefinitionRequestQueryApmResourceStatsQuery): any;
export declare function dashboardWidgetChangeDefinitionRequestQueryApmResourceStatsQueryToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestQueryApmResourceStatsQueryOutputReference | DashboardWidgetChangeDefinitionRequestQueryApmResourceStatsQuery): any;
export declare class DashboardWidgetChangeDefinitionRequestQueryApmResourceStatsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestQueryApmResourceStatsQuery | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestQueryApmResourceStatsQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    private _groupBy?;
    get groupBy(): string[];
    set groupBy(value: string[]);
    resetGroupBy(): void;
    get groupByInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    resetOperationName(): void;
    get operationNameInput(): string | undefined;
    private _primaryTagName?;
    get primaryTagName(): string;
    set primaryTagName(value: string);
    resetPrimaryTagName(): void;
    get primaryTagNameInput(): string | undefined;
    private _primaryTagValue?;
    get primaryTagValue(): string;
    set primaryTagValue(value: string);
    resetPrimaryTagValue(): void;
    get primaryTagValueInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    resetResourceName(): void;
    get resourceNameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    get statInput(): string | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestQueryCloudCostQuery {
    /**
    * The aggregation methods available for cloud cost queries. Valid values are `avg`, `last`, `max`, `min`, `sum`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregator Dashboard#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#cross_org_uuids Dashboard#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for cloud cost queries. Valid values are `cloud_cost`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#data_source Dashboard#data_source}
    */
    readonly dataSource: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#name Dashboard#name}
    */
    readonly name: string;
    /**
    * The cloud cost query definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#query Dashboard#query}
    */
    readonly query: string;
}
export declare function dashboardWidgetChangeDefinitionRequestQueryCloudCostQueryToTerraform(struct?: DashboardWidgetChangeDefinitionRequestQueryCloudCostQueryOutputReference | DashboardWidgetChangeDefinitionRequestQueryCloudCostQuery): any;
export declare function dashboardWidgetChangeDefinitionRequestQueryCloudCostQueryToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestQueryCloudCostQueryOutputReference | DashboardWidgetChangeDefinitionRequestQueryCloudCostQuery): any;
export declare class DashboardWidgetChangeDefinitionRequestQueryCloudCostQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestQueryCloudCostQuery | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestQueryCloudCostQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestQueryEventQueryCompute {
    /**
    * The aggregation methods for event platform queries. Valid values are `count`, `cardinality`, `median`, `pc75`, `pc90`, `pc95`, `pc98`, `pc99`, `sum`, `min`, `max`, `avg`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * A time interval in milliseconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: number;
    /**
    * The measurable attribute to compute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#metric Dashboard#metric}
    */
    readonly metric?: string;
}
export declare function dashboardWidgetChangeDefinitionRequestQueryEventQueryComputeToTerraform(struct?: DashboardWidgetChangeDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable): any;
export declare function dashboardWidgetChangeDefinitionRequestQueryEventQueryComputeToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable): any;
export declare class DashboardWidgetChangeDefinitionRequestQueryEventQueryComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetChangeDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
}
export declare class DashboardWidgetChangeDefinitionRequestQueryEventQueryComputeList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetChangeDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetChangeDefinitionRequestQueryEventQueryComputeOutputReference;
}
export interface DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBySort {
    /**
    * The aggregation methods for the event platform queries. Valid values are `count`, `cardinality`, `median`, `pc75`, `pc90`, `pc95`, `pc98`, `pc99`, `sum`, `min`, `max`, `avg`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The metric used for sorting group by results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#metric Dashboard#metric}
    */
    readonly metric?: string;
    /**
    * Direction of sort. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#order Dashboard#order}
    */
    readonly order?: string;
}
export declare function dashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBySortToTerraform(struct?: DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBySortOutputReference | DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBySort): any;
export declare function dashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBySortToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBySortOutputReference | DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBySort): any;
export declare class DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBySortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBySort | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBySort | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBy {
    /**
    * The event facet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet: string;
    /**
    * The number of groups to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#limit Dashboard#limit}
    */
    readonly limit?: number;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#sort Dashboard#sort}
    */
    readonly sort?: DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBySort;
}
export declare function dashboardWidgetChangeDefinitionRequestQueryEventQueryGroupByToTerraform(struct?: DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable): any;
export declare function dashboardWidgetChangeDefinitionRequestQueryEventQueryGroupByToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable): any;
export declare class DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sort;
    get sort(): DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBySortOutputReference;
    putSort(value: DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBySort): void;
    resetSort(): void;
    get sortInput(): DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBySort | undefined;
}
export declare class DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupByList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupByOutputReference;
}
export interface DashboardWidgetChangeDefinitionRequestQueryEventQuerySearch {
    /**
    * The events search string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#query Dashboard#query}
    */
    readonly query: string;
}
export declare function dashboardWidgetChangeDefinitionRequestQueryEventQuerySearchToTerraform(struct?: DashboardWidgetChangeDefinitionRequestQueryEventQuerySearchOutputReference | DashboardWidgetChangeDefinitionRequestQueryEventQuerySearch): any;
export declare function dashboardWidgetChangeDefinitionRequestQueryEventQuerySearchToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestQueryEventQuerySearchOutputReference | DashboardWidgetChangeDefinitionRequestQueryEventQuerySearch): any;
export declare class DashboardWidgetChangeDefinitionRequestQueryEventQuerySearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestQueryEventQuerySearch | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestQueryEventQuerySearch | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestQueryEventQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#cross_org_uuids Dashboard#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for event platform-based queries. Valid values are `logs`, `spans`, `network`, `rum`, `security_signals`, `profiles`, `audit`, `events`, `ci_tests`, `ci_pipelines`, `incident_analytics`, `product_analytics`, `on_call_events`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#data_source Dashboard#data_source}
    */
    readonly dataSource: string;
    /**
    * An array of index names to query in the stream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#indexes Dashboard#indexes}
    */
    readonly indexes?: string[];
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#name Dashboard#name}
    */
    readonly name: string;
    /**
    * Storage location (private beta).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#storage Dashboard#storage}
    */
    readonly storage?: string;
    /**
    * compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#compute Dashboard#compute}
    */
    readonly compute: DashboardWidgetChangeDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#group_by Dashboard#group_by}
    */
    readonly groupBy?: DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable;
    /**
    * search block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#search Dashboard#search}
    */
    readonly search?: DashboardWidgetChangeDefinitionRequestQueryEventQuerySearch;
}
export declare function dashboardWidgetChangeDefinitionRequestQueryEventQueryToTerraform(struct?: DashboardWidgetChangeDefinitionRequestQueryEventQueryOutputReference | DashboardWidgetChangeDefinitionRequestQueryEventQuery): any;
export declare function dashboardWidgetChangeDefinitionRequestQueryEventQueryToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestQueryEventQueryOutputReference | DashboardWidgetChangeDefinitionRequestQueryEventQuery): any;
export declare class DashboardWidgetChangeDefinitionRequestQueryEventQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestQueryEventQuery | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestQueryEventQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _indexes?;
    get indexes(): string[];
    set indexes(value: string[]);
    resetIndexes(): void;
    get indexesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _storage?;
    get storage(): string;
    set storage(value: string);
    resetStorage(): void;
    get storageInput(): string | undefined;
    private _compute;
    get compute(): DashboardWidgetChangeDefinitionRequestQueryEventQueryComputeList;
    putCompute(value: DashboardWidgetChangeDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable): void;
    get computeInput(): cdktn.IResolvable | DashboardWidgetChangeDefinitionRequestQueryEventQueryCompute[] | undefined;
    private _groupBy;
    get groupBy(): DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupByList;
    putGroupBy(value: DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | DashboardWidgetChangeDefinitionRequestQueryEventQueryGroupBy[] | undefined;
    private _search;
    get search(): DashboardWidgetChangeDefinitionRequestQueryEventQuerySearchOutputReference;
    putSearch(value: DashboardWidgetChangeDefinitionRequestQueryEventQuerySearch): void;
    resetSearch(): void;
    get searchInput(): DashboardWidgetChangeDefinitionRequestQueryEventQuerySearch | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestQueryMetricQuery {
    /**
    * The aggregation methods available for metrics queries. Valid values are `avg`, `min`, `max`, `sum`, `last`, `area`, `l2norm`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregator Dashboard#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#cross_org_uuids Dashboard#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for metrics queries. Defaults to `"metrics"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#data_source Dashboard#data_source}
    */
    readonly dataSource?: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#name Dashboard#name}
    */
    readonly name: string;
    /**
    * The metrics query definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#query Dashboard#query}
    */
    readonly query: string;
    /**
    * Semantic mode for metrics queries. This determines how metrics from different sources are combined or displayed. Valid values are `combined`, `native`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#semantic_mode Dashboard#semantic_mode}
    */
    readonly semanticMode?: string;
}
export declare function dashboardWidgetChangeDefinitionRequestQueryMetricQueryToTerraform(struct?: DashboardWidgetChangeDefinitionRequestQueryMetricQueryOutputReference | DashboardWidgetChangeDefinitionRequestQueryMetricQuery): any;
export declare function dashboardWidgetChangeDefinitionRequestQueryMetricQueryToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestQueryMetricQueryOutputReference | DashboardWidgetChangeDefinitionRequestQueryMetricQuery): any;
export declare class DashboardWidgetChangeDefinitionRequestQueryMetricQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestQueryMetricQuery | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestQueryMetricQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    resetDataSource(): void;
    get dataSourceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _semanticMode?;
    get semanticMode(): string;
    set semanticMode(value: string);
    resetSemanticMode(): void;
    get semanticModeInput(): string | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestQueryProcessQuery {
    /**
    * The aggregation methods available for metrics queries. Valid values are `avg`, `min`, `max`, `sum`, `last`, `area`, `l2norm`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregator Dashboard#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#cross_org_uuids Dashboard#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for process queries. Valid values are `process`, `container`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#data_source Dashboard#data_source}
    */
    readonly dataSource: string;
    /**
    * Whether to normalize the CPU percentages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#is_normalized_cpu Dashboard#is_normalized_cpu}
    */
    readonly isNormalizedCpu?: boolean | cdktn.IResolvable;
    /**
    * The number of hits to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#limit Dashboard#limit}
    */
    readonly limit?: number;
    /**
    * The process metric name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#metric Dashboard#metric}
    */
    readonly metric: string;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#name Dashboard#name}
    */
    readonly name: string;
    /**
    * The direction of the sort. Valid values are `asc`, `desc`. Defaults to `"desc"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#sort Dashboard#sort}
    */
    readonly sort?: string;
    /**
    * An array of tags to filter by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#tag_filters Dashboard#tag_filters}
    */
    readonly tagFilters?: string[];
    /**
    * The text to use as a filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#text_filter Dashboard#text_filter}
    */
    readonly textFilter?: string;
}
export declare function dashboardWidgetChangeDefinitionRequestQueryProcessQueryToTerraform(struct?: DashboardWidgetChangeDefinitionRequestQueryProcessQueryOutputReference | DashboardWidgetChangeDefinitionRequestQueryProcessQuery): any;
export declare function dashboardWidgetChangeDefinitionRequestQueryProcessQueryToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestQueryProcessQueryOutputReference | DashboardWidgetChangeDefinitionRequestQueryProcessQuery): any;
export declare class DashboardWidgetChangeDefinitionRequestQueryProcessQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestQueryProcessQuery | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestQueryProcessQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _isNormalizedCpu?;
    get isNormalizedCpu(): boolean | cdktn.IResolvable;
    set isNormalizedCpu(value: boolean | cdktn.IResolvable);
    resetIsNormalizedCpu(): void;
    get isNormalizedCpuInput(): boolean | cdktn.IResolvable | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _sort?;
    get sort(): string;
    set sort(value: string);
    resetSort(): void;
    get sortInput(): string | undefined;
    private _tagFilters?;
    get tagFilters(): string[];
    set tagFilters(value: string[]);
    resetTagFilters(): void;
    get tagFiltersInput(): string[] | undefined;
    private _textFilter?;
    get textFilter(): string;
    set textFilter(value: string);
    resetTextFilter(): void;
    get textFilterInput(): string | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestQuerySloQuery {
    /**
    * Additional filters applied to the SLO query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#additional_query_filters Dashboard#additional_query_filters}
    */
    readonly additionalQueryFilters?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#cross_org_uuids Dashboard#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for SLO queries. Valid values are `slo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#data_source Dashboard#data_source}
    */
    readonly dataSource: string;
    /**
    * Group mode to query measures. Valid values are `overall`, `components`. Defaults to `"overall"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#group_mode Dashboard#group_mode}
    */
    readonly groupMode?: string;
    /**
    * SLO measures queries. Valid values are `good_events`, `bad_events`, `good_minutes`, `bad_minutes`, `slo_status`, `error_budget_remaining`, `burn_rate`, `error_budget_burndown`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#measure Dashboard#measure}
    */
    readonly measure: string;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#name Dashboard#name}
    */
    readonly name?: string;
    /**
    * ID of an SLO to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#slo_id Dashboard#slo_id}
    */
    readonly sloId: string;
    /**
    * type of the SLO to query. Valid values are `metric`, `monitor`, `time_slice`. Defaults to `"metric"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#slo_query_type Dashboard#slo_query_type}
    */
    readonly sloQueryType?: string;
}
export declare function dashboardWidgetChangeDefinitionRequestQuerySloQueryToTerraform(struct?: DashboardWidgetChangeDefinitionRequestQuerySloQueryOutputReference | DashboardWidgetChangeDefinitionRequestQuerySloQuery): any;
export declare function dashboardWidgetChangeDefinitionRequestQuerySloQueryToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestQuerySloQueryOutputReference | DashboardWidgetChangeDefinitionRequestQuerySloQuery): any;
export declare class DashboardWidgetChangeDefinitionRequestQuerySloQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestQuerySloQuery | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestQuerySloQuery | undefined);
    private _additionalQueryFilters?;
    get additionalQueryFilters(): string;
    set additionalQueryFilters(value: string);
    resetAdditionalQueryFilters(): void;
    get additionalQueryFiltersInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _groupMode?;
    get groupMode(): string;
    set groupMode(value: string);
    resetGroupMode(): void;
    get groupModeInput(): string | undefined;
    private _measure?;
    get measure(): string;
    set measure(value: string);
    get measureInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sloId?;
    get sloId(): string;
    set sloId(value: string);
    get sloIdInput(): string | undefined;
    private _sloQueryType?;
    get sloQueryType(): string;
    set sloQueryType(value: string);
    resetSloQueryType(): void;
    get sloQueryTypeInput(): string | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestQuery {
    /**
    * apm_dependency_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#apm_dependency_stats_query Dashboard#apm_dependency_stats_query}
    */
    readonly apmDependencyStatsQuery?: DashboardWidgetChangeDefinitionRequestQueryApmDependencyStatsQuery;
    /**
    * apm_resource_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#apm_resource_stats_query Dashboard#apm_resource_stats_query}
    */
    readonly apmResourceStatsQuery?: DashboardWidgetChangeDefinitionRequestQueryApmResourceStatsQuery;
    /**
    * cloud_cost_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#cloud_cost_query Dashboard#cloud_cost_query}
    */
    readonly cloudCostQuery?: DashboardWidgetChangeDefinitionRequestQueryCloudCostQuery;
    /**
    * event_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#event_query Dashboard#event_query}
    */
    readonly eventQuery?: DashboardWidgetChangeDefinitionRequestQueryEventQuery;
    /**
    * metric_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#metric_query Dashboard#metric_query}
    */
    readonly metricQuery?: DashboardWidgetChangeDefinitionRequestQueryMetricQuery;
    /**
    * process_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#process_query Dashboard#process_query}
    */
    readonly processQuery?: DashboardWidgetChangeDefinitionRequestQueryProcessQuery;
    /**
    * slo_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#slo_query Dashboard#slo_query}
    */
    readonly sloQuery?: DashboardWidgetChangeDefinitionRequestQuerySloQuery;
}
export declare function dashboardWidgetChangeDefinitionRequestQueryToTerraform(struct?: DashboardWidgetChangeDefinitionRequestQuery | cdktn.IResolvable): any;
export declare function dashboardWidgetChangeDefinitionRequestQueryToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestQuery | cdktn.IResolvable): any;
export declare class DashboardWidgetChangeDefinitionRequestQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetChangeDefinitionRequestQuery | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestQuery | cdktn.IResolvable | undefined);
    private _apmDependencyStatsQuery;
    get apmDependencyStatsQuery(): DashboardWidgetChangeDefinitionRequestQueryApmDependencyStatsQueryOutputReference;
    putApmDependencyStatsQuery(value: DashboardWidgetChangeDefinitionRequestQueryApmDependencyStatsQuery): void;
    resetApmDependencyStatsQuery(): void;
    get apmDependencyStatsQueryInput(): DashboardWidgetChangeDefinitionRequestQueryApmDependencyStatsQuery | undefined;
    private _apmResourceStatsQuery;
    get apmResourceStatsQuery(): DashboardWidgetChangeDefinitionRequestQueryApmResourceStatsQueryOutputReference;
    putApmResourceStatsQuery(value: DashboardWidgetChangeDefinitionRequestQueryApmResourceStatsQuery): void;
    resetApmResourceStatsQuery(): void;
    get apmResourceStatsQueryInput(): DashboardWidgetChangeDefinitionRequestQueryApmResourceStatsQuery | undefined;
    private _cloudCostQuery;
    get cloudCostQuery(): DashboardWidgetChangeDefinitionRequestQueryCloudCostQueryOutputReference;
    putCloudCostQuery(value: DashboardWidgetChangeDefinitionRequestQueryCloudCostQuery): void;
    resetCloudCostQuery(): void;
    get cloudCostQueryInput(): DashboardWidgetChangeDefinitionRequestQueryCloudCostQuery | undefined;
    private _eventQuery;
    get eventQuery(): DashboardWidgetChangeDefinitionRequestQueryEventQueryOutputReference;
    putEventQuery(value: DashboardWidgetChangeDefinitionRequestQueryEventQuery): void;
    resetEventQuery(): void;
    get eventQueryInput(): DashboardWidgetChangeDefinitionRequestQueryEventQuery | undefined;
    private _metricQuery;
    get metricQuery(): DashboardWidgetChangeDefinitionRequestQueryMetricQueryOutputReference;
    putMetricQuery(value: DashboardWidgetChangeDefinitionRequestQueryMetricQuery): void;
    resetMetricQuery(): void;
    get metricQueryInput(): DashboardWidgetChangeDefinitionRequestQueryMetricQuery | undefined;
    private _processQuery;
    get processQuery(): DashboardWidgetChangeDefinitionRequestQueryProcessQueryOutputReference;
    putProcessQuery(value: DashboardWidgetChangeDefinitionRequestQueryProcessQuery): void;
    resetProcessQuery(): void;
    get processQueryInput(): DashboardWidgetChangeDefinitionRequestQueryProcessQuery | undefined;
    private _sloQuery;
    get sloQuery(): DashboardWidgetChangeDefinitionRequestQuerySloQueryOutputReference;
    putSloQuery(value: DashboardWidgetChangeDefinitionRequestQuerySloQuery): void;
    resetSloQuery(): void;
    get sloQueryInput(): DashboardWidgetChangeDefinitionRequestQuerySloQuery | undefined;
}
export declare class DashboardWidgetChangeDefinitionRequestQueryList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetChangeDefinitionRequestQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetChangeDefinitionRequestQueryOutputReference;
}
export interface DashboardWidgetChangeDefinitionRequestRumQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: number;
}
export declare function dashboardWidgetChangeDefinitionRequestRumQueryComputeQueryToTerraform(struct?: DashboardWidgetChangeDefinitionRequestRumQueryComputeQueryOutputReference | DashboardWidgetChangeDefinitionRequestRumQueryComputeQuery): any;
export declare function dashboardWidgetChangeDefinitionRequestRumQueryComputeQueryToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestRumQueryComputeQueryOutputReference | DashboardWidgetChangeDefinitionRequestRumQueryComputeQuery): any;
export declare class DashboardWidgetChangeDefinitionRequestRumQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestRumQueryComputeQuery | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestRumQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestRumQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#order Dashboard#order}
    */
    readonly order: string;
}
export declare function dashboardWidgetChangeDefinitionRequestRumQueryGroupBySortQueryToTerraform(struct?: DashboardWidgetChangeDefinitionRequestRumQueryGroupBySortQueryOutputReference | DashboardWidgetChangeDefinitionRequestRumQueryGroupBySortQuery): any;
export declare function dashboardWidgetChangeDefinitionRequestRumQueryGroupBySortQueryToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestRumQueryGroupBySortQueryOutputReference | DashboardWidgetChangeDefinitionRequestRumQueryGroupBySortQuery): any;
export declare class DashboardWidgetChangeDefinitionRequestRumQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestRumQueryGroupBySortQuery | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestRumQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestRumQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#limit Dashboard#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#sort_query Dashboard#sort_query}
    */
    readonly sortQuery?: DashboardWidgetChangeDefinitionRequestRumQueryGroupBySortQuery;
}
export declare function dashboardWidgetChangeDefinitionRequestRumQueryGroupByToTerraform(struct?: DashboardWidgetChangeDefinitionRequestRumQueryGroupBy | cdktn.IResolvable): any;
export declare function dashboardWidgetChangeDefinitionRequestRumQueryGroupByToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestRumQueryGroupBy | cdktn.IResolvable): any;
export declare class DashboardWidgetChangeDefinitionRequestRumQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetChangeDefinitionRequestRumQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestRumQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): DashboardWidgetChangeDefinitionRequestRumQueryGroupBySortQueryOutputReference;
    putSortQuery(value: DashboardWidgetChangeDefinitionRequestRumQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): DashboardWidgetChangeDefinitionRequestRumQueryGroupBySortQuery | undefined;
}
export declare class DashboardWidgetChangeDefinitionRequestRumQueryGroupByList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetChangeDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetChangeDefinitionRequestRumQueryGroupByOutputReference;
}
export interface DashboardWidgetChangeDefinitionRequestRumQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: number;
}
export declare function dashboardWidgetChangeDefinitionRequestRumQueryMultiComputeToTerraform(struct?: DashboardWidgetChangeDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable): any;
export declare function dashboardWidgetChangeDefinitionRequestRumQueryMultiComputeToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable): any;
export declare class DashboardWidgetChangeDefinitionRequestRumQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetChangeDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class DashboardWidgetChangeDefinitionRequestRumQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetChangeDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetChangeDefinitionRequestRumQueryMultiComputeOutputReference;
}
export interface DashboardWidgetChangeDefinitionRequestRumQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#index Dashboard#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#search_query Dashboard#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#compute_query Dashboard#compute_query}
    */
    readonly computeQuery?: DashboardWidgetChangeDefinitionRequestRumQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#group_by Dashboard#group_by}
    */
    readonly groupBy?: DashboardWidgetChangeDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#multi_compute Dashboard#multi_compute}
    */
    readonly multiCompute?: DashboardWidgetChangeDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function dashboardWidgetChangeDefinitionRequestRumQueryToTerraform(struct?: DashboardWidgetChangeDefinitionRequestRumQueryOutputReference | DashboardWidgetChangeDefinitionRequestRumQuery): any;
export declare function dashboardWidgetChangeDefinitionRequestRumQueryToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestRumQueryOutputReference | DashboardWidgetChangeDefinitionRequestRumQuery): any;
export declare class DashboardWidgetChangeDefinitionRequestRumQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestRumQuery | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestRumQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): DashboardWidgetChangeDefinitionRequestRumQueryComputeQueryOutputReference;
    putComputeQuery(value: DashboardWidgetChangeDefinitionRequestRumQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): DashboardWidgetChangeDefinitionRequestRumQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): DashboardWidgetChangeDefinitionRequestRumQueryGroupByList;
    putGroupBy(value: DashboardWidgetChangeDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | DashboardWidgetChangeDefinitionRequestRumQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): DashboardWidgetChangeDefinitionRequestRumQueryMultiComputeList;
    putMultiCompute(value: DashboardWidgetChangeDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | DashboardWidgetChangeDefinitionRequestRumQueryMultiCompute[] | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestSecurityQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: number;
}
export declare function dashboardWidgetChangeDefinitionRequestSecurityQueryComputeQueryToTerraform(struct?: DashboardWidgetChangeDefinitionRequestSecurityQueryComputeQueryOutputReference | DashboardWidgetChangeDefinitionRequestSecurityQueryComputeQuery): any;
export declare function dashboardWidgetChangeDefinitionRequestSecurityQueryComputeQueryToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestSecurityQueryComputeQueryOutputReference | DashboardWidgetChangeDefinitionRequestSecurityQueryComputeQuery): any;
export declare class DashboardWidgetChangeDefinitionRequestSecurityQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestSecurityQueryComputeQuery | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestSecurityQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestSecurityQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#order Dashboard#order}
    */
    readonly order: string;
}
export declare function dashboardWidgetChangeDefinitionRequestSecurityQueryGroupBySortQueryToTerraform(struct?: DashboardWidgetChangeDefinitionRequestSecurityQueryGroupBySortQueryOutputReference | DashboardWidgetChangeDefinitionRequestSecurityQueryGroupBySortQuery): any;
export declare function dashboardWidgetChangeDefinitionRequestSecurityQueryGroupBySortQueryToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestSecurityQueryGroupBySortQueryOutputReference | DashboardWidgetChangeDefinitionRequestSecurityQueryGroupBySortQuery): any;
export declare class DashboardWidgetChangeDefinitionRequestSecurityQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestSecurityQueryGroupBySortQuery | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestSecurityQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface DashboardWidgetChangeDefinitionRequestSecurityQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#limit Dashboard#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#sort_query Dashboard#sort_query}
    */
    readonly sortQuery?: DashboardWidgetChangeDefinitionRequestSecurityQueryGroupBySortQuery;
}
export declare function dashboardWidgetChangeDefinitionRequestSecurityQueryGroupByToTerraform(struct?: DashboardWidgetChangeDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare function dashboardWidgetChangeDefinitionRequestSecurityQueryGroupByToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare class DashboardWidgetChangeDefinitionRequestSecurityQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetChangeDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): DashboardWidgetChangeDefinitionRequestSecurityQueryGroupBySortQueryOutputReference;
    putSortQuery(value: DashboardWidgetChangeDefinitionRequestSecurityQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): DashboardWidgetChangeDefinitionRequestSecurityQueryGroupBySortQuery | undefined;
}
export declare class DashboardWidgetChangeDefinitionRequestSecurityQueryGroupByList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetChangeDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetChangeDefinitionRequestSecurityQueryGroupByOutputReference;
}
export interface DashboardWidgetChangeDefinitionRequestSecurityQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: number;
}
export declare function dashboardWidgetChangeDefinitionRequestSecurityQueryMultiComputeToTerraform(struct?: DashboardWidgetChangeDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare function dashboardWidgetChangeDefinitionRequestSecurityQueryMultiComputeToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare class DashboardWidgetChangeDefinitionRequestSecurityQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetChangeDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class DashboardWidgetChangeDefinitionRequestSecurityQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetChangeDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetChangeDefinitionRequestSecurityQueryMultiComputeOutputReference;
}
export interface DashboardWidgetChangeDefinitionRequestSecurityQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#index Dashboard#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#search_query Dashboard#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#compute_query Dashboard#compute_query}
    */
    readonly computeQuery?: DashboardWidgetChangeDefinitionRequestSecurityQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#group_by Dashboard#group_by}
    */
    readonly groupBy?: DashboardWidgetChangeDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#multi_compute Dashboard#multi_compute}
    */
    readonly multiCompute?: DashboardWidgetChangeDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function dashboardWidgetChangeDefinitionRequestSecurityQueryToTerraform(struct?: DashboardWidgetChangeDefinitionRequestSecurityQueryOutputReference | DashboardWidgetChangeDefinitionRequestSecurityQuery): any;
export declare function dashboardWidgetChangeDefinitionRequestSecurityQueryToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequestSecurityQueryOutputReference | DashboardWidgetChangeDefinitionRequestSecurityQuery): any;
export declare class DashboardWidgetChangeDefinitionRequestSecurityQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinitionRequestSecurityQuery | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequestSecurityQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): DashboardWidgetChangeDefinitionRequestSecurityQueryComputeQueryOutputReference;
    putComputeQuery(value: DashboardWidgetChangeDefinitionRequestSecurityQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): DashboardWidgetChangeDefinitionRequestSecurityQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): DashboardWidgetChangeDefinitionRequestSecurityQueryGroupByList;
    putGroupBy(value: DashboardWidgetChangeDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | DashboardWidgetChangeDefinitionRequestSecurityQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): DashboardWidgetChangeDefinitionRequestSecurityQueryMultiComputeList;
    putMultiCompute(value: DashboardWidgetChangeDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | DashboardWidgetChangeDefinitionRequestSecurityQueryMultiCompute[] | undefined;
}
export interface DashboardWidgetChangeDefinitionRequest {
    /**
    * Whether to show absolute or relative change. Valid values are `absolute`, `relative`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#change_type Dashboard#change_type}
    */
    readonly changeType?: string;
    /**
    * Choose from when to compare current data to. Valid values are `hour_before`, `day_before`, `week_before`, `month_before`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#compare_to Dashboard#compare_to}
    */
    readonly compareTo?: string;
    /**
    * A Boolean indicating whether an increase in the value is good (displayed in green) or not (displayed in red).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#increase_good Dashboard#increase_good}
    */
    readonly increaseGood?: boolean | cdktn.IResolvable;
    /**
    * What to order by. Valid values are `change`, `name`, `present`, `past`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#order_by Dashboard#order_by}
    */
    readonly orderBy?: string;
    /**
    * Widget sorting method. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#order_dir Dashboard#order_dir}
    */
    readonly orderDir?: string;
    /**
    * The metric query to use for this widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#q Dashboard#q}
    */
    readonly q?: string;
    /**
    * If set to `true`, displays the current value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#show_present Dashboard#show_present}
    */
    readonly showPresent?: boolean | cdktn.IResolvable;
    /**
    * apm_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#apm_query Dashboard#apm_query}
    */
    readonly apmQuery?: DashboardWidgetChangeDefinitionRequestApmQuery;
    /**
    * formula block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#formula Dashboard#formula}
    */
    readonly formula?: DashboardWidgetChangeDefinitionRequestFormula[] | cdktn.IResolvable;
    /**
    * log_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#log_query Dashboard#log_query}
    */
    readonly logQuery?: DashboardWidgetChangeDefinitionRequestLogQuery;
    /**
    * process_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#process_query Dashboard#process_query}
    */
    readonly processQuery?: DashboardWidgetChangeDefinitionRequestProcessQuery;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#query Dashboard#query}
    */
    readonly query?: DashboardWidgetChangeDefinitionRequestQuery[] | cdktn.IResolvable;
    /**
    * rum_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#rum_query Dashboard#rum_query}
    */
    readonly rumQuery?: DashboardWidgetChangeDefinitionRequestRumQuery;
    /**
    * security_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#security_query Dashboard#security_query}
    */
    readonly securityQuery?: DashboardWidgetChangeDefinitionRequestSecurityQuery;
}
export declare function dashboardWidgetChangeDefinitionRequestToTerraform(struct?: DashboardWidgetChangeDefinitionRequest | cdktn.IResolvable): any;
export declare function dashboardWidgetChangeDefinitionRequestToHclTerraform(struct?: DashboardWidgetChangeDefinitionRequest | cdktn.IResolvable): any;
export declare class DashboardWidgetChangeDefinitionRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetChangeDefinitionRequest | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetChangeDefinitionRequest | cdktn.IResolvable | undefined);
    private _changeType?;
    get changeType(): string;
    set changeType(value: string);
    resetChangeType(): void;
    get changeTypeInput(): string | undefined;
    private _compareTo?;
    get compareTo(): string;
    set compareTo(value: string);
    resetCompareTo(): void;
    get compareToInput(): string | undefined;
    private _increaseGood?;
    get increaseGood(): boolean | cdktn.IResolvable;
    set increaseGood(value: boolean | cdktn.IResolvable);
    resetIncreaseGood(): void;
    get increaseGoodInput(): boolean | cdktn.IResolvable | undefined;
    private _orderBy?;
    get orderBy(): string;
    set orderBy(value: string);
    resetOrderBy(): void;
    get orderByInput(): string | undefined;
    private _orderDir?;
    get orderDir(): string;
    set orderDir(value: string);
    resetOrderDir(): void;
    get orderDirInput(): string | undefined;
    private _q?;
    get q(): string;
    set q(value: string);
    resetQ(): void;
    get qInput(): string | undefined;
    private _showPresent?;
    get showPresent(): boolean | cdktn.IResolvable;
    set showPresent(value: boolean | cdktn.IResolvable);
    resetShowPresent(): void;
    get showPresentInput(): boolean | cdktn.IResolvable | undefined;
    private _apmQuery;
    get apmQuery(): DashboardWidgetChangeDefinitionRequestApmQueryOutputReference;
    putApmQuery(value: DashboardWidgetChangeDefinitionRequestApmQuery): void;
    resetApmQuery(): void;
    get apmQueryInput(): DashboardWidgetChangeDefinitionRequestApmQuery | undefined;
    private _formula;
    get formula(): DashboardWidgetChangeDefinitionRequestFormulaList;
    putFormula(value: DashboardWidgetChangeDefinitionRequestFormula[] | cdktn.IResolvable): void;
    resetFormula(): void;
    get formulaInput(): cdktn.IResolvable | DashboardWidgetChangeDefinitionRequestFormula[] | undefined;
    private _logQuery;
    get logQuery(): DashboardWidgetChangeDefinitionRequestLogQueryOutputReference;
    putLogQuery(value: DashboardWidgetChangeDefinitionRequestLogQuery): void;
    resetLogQuery(): void;
    get logQueryInput(): DashboardWidgetChangeDefinitionRequestLogQuery | undefined;
    private _processQuery;
    get processQuery(): DashboardWidgetChangeDefinitionRequestProcessQueryOutputReference;
    putProcessQuery(value: DashboardWidgetChangeDefinitionRequestProcessQuery): void;
    resetProcessQuery(): void;
    get processQueryInput(): DashboardWidgetChangeDefinitionRequestProcessQuery | undefined;
    private _query;
    get query(): DashboardWidgetChangeDefinitionRequestQueryList;
    putQuery(value: DashboardWidgetChangeDefinitionRequestQuery[] | cdktn.IResolvable): void;
    resetQuery(): void;
    get queryInput(): cdktn.IResolvable | DashboardWidgetChangeDefinitionRequestQuery[] | undefined;
    private _rumQuery;
    get rumQuery(): DashboardWidgetChangeDefinitionRequestRumQueryOutputReference;
    putRumQuery(value: DashboardWidgetChangeDefinitionRequestRumQuery): void;
    resetRumQuery(): void;
    get rumQueryInput(): DashboardWidgetChangeDefinitionRequestRumQuery | undefined;
    private _securityQuery;
    get securityQuery(): DashboardWidgetChangeDefinitionRequestSecurityQueryOutputReference;
    putSecurityQuery(value: DashboardWidgetChangeDefinitionRequestSecurityQuery): void;
    resetSecurityQuery(): void;
    get securityQueryInput(): DashboardWidgetChangeDefinitionRequestSecurityQuery | undefined;
}
export declare class DashboardWidgetChangeDefinitionRequestList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetChangeDefinitionRequest[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetChangeDefinitionRequestOutputReference;
}
export interface DashboardWidgetChangeDefinition {
    /**
    * Hide any portion of the widget's timeframe that is incomplete due to cost data not being available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#hide_incomplete_cost_data Dashboard#hide_incomplete_cost_data}
    */
    readonly hideIncompleteCostData?: boolean | cdktn.IResolvable;
    /**
    * The timeframe to use when displaying the widget. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#live_span Dashboard#live_span}
    */
    readonly liveSpan?: string;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title Dashboard#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title_align Dashboard#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title_size Dashboard#title_size}
    */
    readonly titleSize?: string;
    /**
    * custom_link block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#custom_link Dashboard#custom_link}
    */
    readonly customLink?: DashboardWidgetChangeDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#request Dashboard#request}
    */
    readonly request?: DashboardWidgetChangeDefinitionRequest[] | cdktn.IResolvable;
}
export declare function dashboardWidgetChangeDefinitionToTerraform(struct?: DashboardWidgetChangeDefinitionOutputReference | DashboardWidgetChangeDefinition): any;
export declare function dashboardWidgetChangeDefinitionToHclTerraform(struct?: DashboardWidgetChangeDefinitionOutputReference | DashboardWidgetChangeDefinition): any;
export declare class DashboardWidgetChangeDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetChangeDefinition | undefined;
    set internalValue(value: DashboardWidgetChangeDefinition | undefined);
    private _hideIncompleteCostData?;
    get hideIncompleteCostData(): boolean | cdktn.IResolvable;
    set hideIncompleteCostData(value: boolean | cdktn.IResolvable);
    resetHideIncompleteCostData(): void;
    get hideIncompleteCostDataInput(): boolean | cdktn.IResolvable | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _customLink;
    get customLink(): DashboardWidgetChangeDefinitionCustomLinkList;
    putCustomLink(value: DashboardWidgetChangeDefinitionCustomLink[] | cdktn.IResolvable): void;
    resetCustomLink(): void;
    get customLinkInput(): cdktn.IResolvable | DashboardWidgetChangeDefinitionCustomLink[] | undefined;
    private _request;
    get request(): DashboardWidgetChangeDefinitionRequestList;
    putRequest(value: DashboardWidgetChangeDefinitionRequest[] | cdktn.IResolvable): void;
    resetRequest(): void;
    get requestInput(): cdktn.IResolvable | DashboardWidgetChangeDefinitionRequest[] | undefined;
}
export interface DashboardWidgetCheckStatusDefinition {
    /**
    * The check to use in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#check Dashboard#check}
    */
    readonly check: string;
    /**
    * The check group to use in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#group Dashboard#group}
    */
    readonly group?: string;
    /**
    * When `grouping = "cluster"`, indicates a list of tags to use for grouping.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#group_by Dashboard#group_by}
    */
    readonly groupBy?: string[];
    /**
    * The kind of grouping to use. Valid values are `check`, `cluster`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#grouping Dashboard#grouping}
    */
    readonly grouping: string;
    /**
    * Hide any portion of the widget's timeframe that is incomplete due to cost data not being available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#hide_incomplete_cost_data Dashboard#hide_incomplete_cost_data}
    */
    readonly hideIncompleteCostData?: boolean | cdktn.IResolvable;
    /**
    * The timeframe to use when displaying the widget. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#live_span Dashboard#live_span}
    */
    readonly liveSpan?: string;
    /**
    * A list of tags to use in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#tags Dashboard#tags}
    */
    readonly tags?: string[];
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title Dashboard#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title_align Dashboard#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title_size Dashboard#title_size}
    */
    readonly titleSize?: string;
}
export declare function dashboardWidgetCheckStatusDefinitionToTerraform(struct?: DashboardWidgetCheckStatusDefinitionOutputReference | DashboardWidgetCheckStatusDefinition): any;
export declare function dashboardWidgetCheckStatusDefinitionToHclTerraform(struct?: DashboardWidgetCheckStatusDefinitionOutputReference | DashboardWidgetCheckStatusDefinition): any;
export declare class DashboardWidgetCheckStatusDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetCheckStatusDefinition | undefined;
    set internalValue(value: DashboardWidgetCheckStatusDefinition | undefined);
    private _check?;
    get check(): string;
    set check(value: string);
    get checkInput(): string | undefined;
    private _group?;
    get group(): string;
    set group(value: string);
    resetGroup(): void;
    get groupInput(): string | undefined;
    private _groupBy?;
    get groupBy(): string[];
    set groupBy(value: string[]);
    resetGroupBy(): void;
    get groupByInput(): string[] | undefined;
    private _grouping?;
    get grouping(): string;
    set grouping(value: string);
    get groupingInput(): string | undefined;
    private _hideIncompleteCostData?;
    get hideIncompleteCostData(): boolean | cdktn.IResolvable;
    set hideIncompleteCostData(value: boolean | cdktn.IResolvable);
    resetHideIncompleteCostData(): void;
    get hideIncompleteCostDataInput(): boolean | cdktn.IResolvable | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
}
export interface DashboardWidgetDistributionDefinitionRequestApmQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: number;
}
export declare function dashboardWidgetDistributionDefinitionRequestApmQueryComputeQueryToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestApmQueryComputeQueryOutputReference | DashboardWidgetDistributionDefinitionRequestApmQueryComputeQuery): any;
export declare function dashboardWidgetDistributionDefinitionRequestApmQueryComputeQueryToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestApmQueryComputeQueryOutputReference | DashboardWidgetDistributionDefinitionRequestApmQueryComputeQuery): any;
export declare class DashboardWidgetDistributionDefinitionRequestApmQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestApmQueryComputeQuery | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestApmQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface DashboardWidgetDistributionDefinitionRequestApmQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#order Dashboard#order}
    */
    readonly order: string;
}
export declare function dashboardWidgetDistributionDefinitionRequestApmQueryGroupBySortQueryToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestApmQueryGroupBySortQueryOutputReference | DashboardWidgetDistributionDefinitionRequestApmQueryGroupBySortQuery): any;
export declare function dashboardWidgetDistributionDefinitionRequestApmQueryGroupBySortQueryToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestApmQueryGroupBySortQueryOutputReference | DashboardWidgetDistributionDefinitionRequestApmQueryGroupBySortQuery): any;
export declare class DashboardWidgetDistributionDefinitionRequestApmQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestApmQueryGroupBySortQuery | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestApmQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface DashboardWidgetDistributionDefinitionRequestApmQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#limit Dashboard#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#sort_query Dashboard#sort_query}
    */
    readonly sortQuery?: DashboardWidgetDistributionDefinitionRequestApmQueryGroupBySortQuery;
}
export declare function dashboardWidgetDistributionDefinitionRequestApmQueryGroupByToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestApmQueryGroupBy | cdktn.IResolvable): any;
export declare function dashboardWidgetDistributionDefinitionRequestApmQueryGroupByToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestApmQueryGroupBy | cdktn.IResolvable): any;
export declare class DashboardWidgetDistributionDefinitionRequestApmQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestApmQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestApmQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): DashboardWidgetDistributionDefinitionRequestApmQueryGroupBySortQueryOutputReference;
    putSortQuery(value: DashboardWidgetDistributionDefinitionRequestApmQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): DashboardWidgetDistributionDefinitionRequestApmQueryGroupBySortQuery | undefined;
}
export declare class DashboardWidgetDistributionDefinitionRequestApmQueryGroupByList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetDistributionDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetDistributionDefinitionRequestApmQueryGroupByOutputReference;
}
export interface DashboardWidgetDistributionDefinitionRequestApmQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: number;
}
export declare function dashboardWidgetDistributionDefinitionRequestApmQueryMultiComputeToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable): any;
export declare function dashboardWidgetDistributionDefinitionRequestApmQueryMultiComputeToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable): any;
export declare class DashboardWidgetDistributionDefinitionRequestApmQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class DashboardWidgetDistributionDefinitionRequestApmQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetDistributionDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetDistributionDefinitionRequestApmQueryMultiComputeOutputReference;
}
export interface DashboardWidgetDistributionDefinitionRequestApmQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#index Dashboard#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#search_query Dashboard#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#compute_query Dashboard#compute_query}
    */
    readonly computeQuery?: DashboardWidgetDistributionDefinitionRequestApmQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#group_by Dashboard#group_by}
    */
    readonly groupBy?: DashboardWidgetDistributionDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#multi_compute Dashboard#multi_compute}
    */
    readonly multiCompute?: DashboardWidgetDistributionDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function dashboardWidgetDistributionDefinitionRequestApmQueryToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestApmQueryOutputReference | DashboardWidgetDistributionDefinitionRequestApmQuery): any;
export declare function dashboardWidgetDistributionDefinitionRequestApmQueryToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestApmQueryOutputReference | DashboardWidgetDistributionDefinitionRequestApmQuery): any;
export declare class DashboardWidgetDistributionDefinitionRequestApmQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestApmQuery | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestApmQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): DashboardWidgetDistributionDefinitionRequestApmQueryComputeQueryOutputReference;
    putComputeQuery(value: DashboardWidgetDistributionDefinitionRequestApmQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): DashboardWidgetDistributionDefinitionRequestApmQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): DashboardWidgetDistributionDefinitionRequestApmQueryGroupByList;
    putGroupBy(value: DashboardWidgetDistributionDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | DashboardWidgetDistributionDefinitionRequestApmQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): DashboardWidgetDistributionDefinitionRequestApmQueryMultiComputeList;
    putMultiCompute(value: DashboardWidgetDistributionDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | DashboardWidgetDistributionDefinitionRequestApmQueryMultiCompute[] | undefined;
}
export interface DashboardWidgetDistributionDefinitionRequestApmStatsQueryColumns {
    /**
    * A user-assigned alias for the column.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#alias Dashboard#alias}
    */
    readonly alias?: string;
    /**
    * A list of display modes for each table cell. Valid values are `number`, `bar`, `trend`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#cell_display_mode Dashboard#cell_display_mode}
    */
    readonly cellDisplayMode?: string;
    /**
    * The column name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#name Dashboard#name}
    */
    readonly name: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#order Dashboard#order}
    */
    readonly order?: string;
}
export declare function dashboardWidgetDistributionDefinitionRequestApmStatsQueryColumnsToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestApmStatsQueryColumns | cdktn.IResolvable): any;
export declare function dashboardWidgetDistributionDefinitionRequestApmStatsQueryColumnsToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestApmStatsQueryColumns | cdktn.IResolvable): any;
export declare class DashboardWidgetDistributionDefinitionRequestApmStatsQueryColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestApmStatsQueryColumns | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestApmStatsQueryColumns | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _cellDisplayMode?;
    get cellDisplayMode(): string;
    set cellDisplayMode(value: string);
    resetCellDisplayMode(): void;
    get cellDisplayModeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export declare class DashboardWidgetDistributionDefinitionRequestApmStatsQueryColumnsList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetDistributionDefinitionRequestApmStatsQueryColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetDistributionDefinitionRequestApmStatsQueryColumnsOutputReference;
}
export interface DashboardWidgetDistributionDefinitionRequestApmStatsQuery {
    /**
    * The environment name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#env Dashboard#env}
    */
    readonly env: string;
    /**
    * The operation name associated with the service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#name Dashboard#name}
    */
    readonly name: string;
    /**
    * The organization's host group name and value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#primary_tag Dashboard#primary_tag}
    */
    readonly primaryTag: string;
    /**
    * The resource name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#resource Dashboard#resource}
    */
    readonly resource?: string;
    /**
    * The level of detail for the request. Valid values are `service`, `resource`, `span`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#row_type Dashboard#row_type}
    */
    readonly rowType: string;
    /**
    * The service name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#service Dashboard#service}
    */
    readonly service: string;
    /**
    * columns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#columns Dashboard#columns}
    */
    readonly columns?: DashboardWidgetDistributionDefinitionRequestApmStatsQueryColumns[] | cdktn.IResolvable;
}
export declare function dashboardWidgetDistributionDefinitionRequestApmStatsQueryToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestApmStatsQueryOutputReference | DashboardWidgetDistributionDefinitionRequestApmStatsQuery): any;
export declare function dashboardWidgetDistributionDefinitionRequestApmStatsQueryToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestApmStatsQueryOutputReference | DashboardWidgetDistributionDefinitionRequestApmStatsQuery): any;
export declare class DashboardWidgetDistributionDefinitionRequestApmStatsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestApmStatsQuery | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestApmStatsQuery | undefined);
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _primaryTag?;
    get primaryTag(): string;
    set primaryTag(value: string);
    get primaryTagInput(): string | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    resetResource(): void;
    get resourceInput(): string | undefined;
    private _rowType?;
    get rowType(): string;
    set rowType(value: string);
    get rowTypeInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _columns;
    get columns(): DashboardWidgetDistributionDefinitionRequestApmStatsQueryColumnsList;
    putColumns(value: DashboardWidgetDistributionDefinitionRequestApmStatsQueryColumns[] | cdktn.IResolvable): void;
    resetColumns(): void;
    get columnsInput(): cdktn.IResolvable | DashboardWidgetDistributionDefinitionRequestApmStatsQueryColumns[] | undefined;
}
export interface DashboardWidgetDistributionDefinitionRequestLogQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: number;
}
export declare function dashboardWidgetDistributionDefinitionRequestLogQueryComputeQueryToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestLogQueryComputeQueryOutputReference | DashboardWidgetDistributionDefinitionRequestLogQueryComputeQuery): any;
export declare function dashboardWidgetDistributionDefinitionRequestLogQueryComputeQueryToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestLogQueryComputeQueryOutputReference | DashboardWidgetDistributionDefinitionRequestLogQueryComputeQuery): any;
export declare class DashboardWidgetDistributionDefinitionRequestLogQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestLogQueryComputeQuery | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestLogQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface DashboardWidgetDistributionDefinitionRequestLogQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#order Dashboard#order}
    */
    readonly order: string;
}
export declare function dashboardWidgetDistributionDefinitionRequestLogQueryGroupBySortQueryToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestLogQueryGroupBySortQueryOutputReference | DashboardWidgetDistributionDefinitionRequestLogQueryGroupBySortQuery): any;
export declare function dashboardWidgetDistributionDefinitionRequestLogQueryGroupBySortQueryToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestLogQueryGroupBySortQueryOutputReference | DashboardWidgetDistributionDefinitionRequestLogQueryGroupBySortQuery): any;
export declare class DashboardWidgetDistributionDefinitionRequestLogQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestLogQueryGroupBySortQuery | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestLogQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface DashboardWidgetDistributionDefinitionRequestLogQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#limit Dashboard#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#sort_query Dashboard#sort_query}
    */
    readonly sortQuery?: DashboardWidgetDistributionDefinitionRequestLogQueryGroupBySortQuery;
}
export declare function dashboardWidgetDistributionDefinitionRequestLogQueryGroupByToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestLogQueryGroupBy | cdktn.IResolvable): any;
export declare function dashboardWidgetDistributionDefinitionRequestLogQueryGroupByToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestLogQueryGroupBy | cdktn.IResolvable): any;
export declare class DashboardWidgetDistributionDefinitionRequestLogQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestLogQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestLogQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): DashboardWidgetDistributionDefinitionRequestLogQueryGroupBySortQueryOutputReference;
    putSortQuery(value: DashboardWidgetDistributionDefinitionRequestLogQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): DashboardWidgetDistributionDefinitionRequestLogQueryGroupBySortQuery | undefined;
}
export declare class DashboardWidgetDistributionDefinitionRequestLogQueryGroupByList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetDistributionDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetDistributionDefinitionRequestLogQueryGroupByOutputReference;
}
export interface DashboardWidgetDistributionDefinitionRequestLogQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: number;
}
export declare function dashboardWidgetDistributionDefinitionRequestLogQueryMultiComputeToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable): any;
export declare function dashboardWidgetDistributionDefinitionRequestLogQueryMultiComputeToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable): any;
export declare class DashboardWidgetDistributionDefinitionRequestLogQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class DashboardWidgetDistributionDefinitionRequestLogQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetDistributionDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetDistributionDefinitionRequestLogQueryMultiComputeOutputReference;
}
export interface DashboardWidgetDistributionDefinitionRequestLogQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#index Dashboard#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#search_query Dashboard#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#compute_query Dashboard#compute_query}
    */
    readonly computeQuery?: DashboardWidgetDistributionDefinitionRequestLogQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#group_by Dashboard#group_by}
    */
    readonly groupBy?: DashboardWidgetDistributionDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#multi_compute Dashboard#multi_compute}
    */
    readonly multiCompute?: DashboardWidgetDistributionDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function dashboardWidgetDistributionDefinitionRequestLogQueryToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestLogQueryOutputReference | DashboardWidgetDistributionDefinitionRequestLogQuery): any;
export declare function dashboardWidgetDistributionDefinitionRequestLogQueryToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestLogQueryOutputReference | DashboardWidgetDistributionDefinitionRequestLogQuery): any;
export declare class DashboardWidgetDistributionDefinitionRequestLogQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestLogQuery | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestLogQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): DashboardWidgetDistributionDefinitionRequestLogQueryComputeQueryOutputReference;
    putComputeQuery(value: DashboardWidgetDistributionDefinitionRequestLogQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): DashboardWidgetDistributionDefinitionRequestLogQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): DashboardWidgetDistributionDefinitionRequestLogQueryGroupByList;
    putGroupBy(value: DashboardWidgetDistributionDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | DashboardWidgetDistributionDefinitionRequestLogQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): DashboardWidgetDistributionDefinitionRequestLogQueryMultiComputeList;
    putMultiCompute(value: DashboardWidgetDistributionDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | DashboardWidgetDistributionDefinitionRequestLogQueryMultiCompute[] | undefined;
}
export interface DashboardWidgetDistributionDefinitionRequestProcessQuery {
    /**
    * A list of processes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#filter_by Dashboard#filter_by}
    */
    readonly filterBy?: string[];
    /**
    * The max number of items in the filter list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#limit Dashboard#limit}
    */
    readonly limit?: number;
    /**
    * Your chosen metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#metric Dashboard#metric}
    */
    readonly metric: string;
    /**
    * Your chosen search term.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#search_by Dashboard#search_by}
    */
    readonly searchBy?: string;
}
export declare function dashboardWidgetDistributionDefinitionRequestProcessQueryToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestProcessQueryOutputReference | DashboardWidgetDistributionDefinitionRequestProcessQuery): any;
export declare function dashboardWidgetDistributionDefinitionRequestProcessQueryToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestProcessQueryOutputReference | DashboardWidgetDistributionDefinitionRequestProcessQuery): any;
export declare class DashboardWidgetDistributionDefinitionRequestProcessQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestProcessQuery | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestProcessQuery | undefined);
    private _filterBy?;
    get filterBy(): string[];
    set filterBy(value: string[]);
    resetFilterBy(): void;
    get filterByInput(): string[] | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _searchBy?;
    get searchBy(): string;
    set searchBy(value: string);
    resetSearchBy(): void;
    get searchByInput(): string | undefined;
}
export interface DashboardWidgetDistributionDefinitionRequestRumQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: number;
}
export declare function dashboardWidgetDistributionDefinitionRequestRumQueryComputeQueryToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestRumQueryComputeQueryOutputReference | DashboardWidgetDistributionDefinitionRequestRumQueryComputeQuery): any;
export declare function dashboardWidgetDistributionDefinitionRequestRumQueryComputeQueryToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestRumQueryComputeQueryOutputReference | DashboardWidgetDistributionDefinitionRequestRumQueryComputeQuery): any;
export declare class DashboardWidgetDistributionDefinitionRequestRumQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestRumQueryComputeQuery | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestRumQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface DashboardWidgetDistributionDefinitionRequestRumQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#order Dashboard#order}
    */
    readonly order: string;
}
export declare function dashboardWidgetDistributionDefinitionRequestRumQueryGroupBySortQueryToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestRumQueryGroupBySortQueryOutputReference | DashboardWidgetDistributionDefinitionRequestRumQueryGroupBySortQuery): any;
export declare function dashboardWidgetDistributionDefinitionRequestRumQueryGroupBySortQueryToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestRumQueryGroupBySortQueryOutputReference | DashboardWidgetDistributionDefinitionRequestRumQueryGroupBySortQuery): any;
export declare class DashboardWidgetDistributionDefinitionRequestRumQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestRumQueryGroupBySortQuery | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestRumQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface DashboardWidgetDistributionDefinitionRequestRumQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#limit Dashboard#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#sort_query Dashboard#sort_query}
    */
    readonly sortQuery?: DashboardWidgetDistributionDefinitionRequestRumQueryGroupBySortQuery;
}
export declare function dashboardWidgetDistributionDefinitionRequestRumQueryGroupByToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestRumQueryGroupBy | cdktn.IResolvable): any;
export declare function dashboardWidgetDistributionDefinitionRequestRumQueryGroupByToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestRumQueryGroupBy | cdktn.IResolvable): any;
export declare class DashboardWidgetDistributionDefinitionRequestRumQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestRumQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestRumQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): DashboardWidgetDistributionDefinitionRequestRumQueryGroupBySortQueryOutputReference;
    putSortQuery(value: DashboardWidgetDistributionDefinitionRequestRumQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): DashboardWidgetDistributionDefinitionRequestRumQueryGroupBySortQuery | undefined;
}
export declare class DashboardWidgetDistributionDefinitionRequestRumQueryGroupByList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetDistributionDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetDistributionDefinitionRequestRumQueryGroupByOutputReference;
}
export interface DashboardWidgetDistributionDefinitionRequestRumQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: number;
}
export declare function dashboardWidgetDistributionDefinitionRequestRumQueryMultiComputeToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable): any;
export declare function dashboardWidgetDistributionDefinitionRequestRumQueryMultiComputeToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable): any;
export declare class DashboardWidgetDistributionDefinitionRequestRumQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class DashboardWidgetDistributionDefinitionRequestRumQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetDistributionDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetDistributionDefinitionRequestRumQueryMultiComputeOutputReference;
}
export interface DashboardWidgetDistributionDefinitionRequestRumQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#index Dashboard#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#search_query Dashboard#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#compute_query Dashboard#compute_query}
    */
    readonly computeQuery?: DashboardWidgetDistributionDefinitionRequestRumQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#group_by Dashboard#group_by}
    */
    readonly groupBy?: DashboardWidgetDistributionDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#multi_compute Dashboard#multi_compute}
    */
    readonly multiCompute?: DashboardWidgetDistributionDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function dashboardWidgetDistributionDefinitionRequestRumQueryToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestRumQueryOutputReference | DashboardWidgetDistributionDefinitionRequestRumQuery): any;
export declare function dashboardWidgetDistributionDefinitionRequestRumQueryToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestRumQueryOutputReference | DashboardWidgetDistributionDefinitionRequestRumQuery): any;
export declare class DashboardWidgetDistributionDefinitionRequestRumQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestRumQuery | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestRumQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): DashboardWidgetDistributionDefinitionRequestRumQueryComputeQueryOutputReference;
    putComputeQuery(value: DashboardWidgetDistributionDefinitionRequestRumQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): DashboardWidgetDistributionDefinitionRequestRumQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): DashboardWidgetDistributionDefinitionRequestRumQueryGroupByList;
    putGroupBy(value: DashboardWidgetDistributionDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | DashboardWidgetDistributionDefinitionRequestRumQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): DashboardWidgetDistributionDefinitionRequestRumQueryMultiComputeList;
    putMultiCompute(value: DashboardWidgetDistributionDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | DashboardWidgetDistributionDefinitionRequestRumQueryMultiCompute[] | undefined;
}
export interface DashboardWidgetDistributionDefinitionRequestSecurityQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: number;
}
export declare function dashboardWidgetDistributionDefinitionRequestSecurityQueryComputeQueryToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestSecurityQueryComputeQueryOutputReference | DashboardWidgetDistributionDefinitionRequestSecurityQueryComputeQuery): any;
export declare function dashboardWidgetDistributionDefinitionRequestSecurityQueryComputeQueryToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestSecurityQueryComputeQueryOutputReference | DashboardWidgetDistributionDefinitionRequestSecurityQueryComputeQuery): any;
export declare class DashboardWidgetDistributionDefinitionRequestSecurityQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestSecurityQueryComputeQuery | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestSecurityQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#order Dashboard#order}
    */
    readonly order: string;
}
export declare function dashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQueryToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQueryOutputReference | DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQuery): any;
export declare function dashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQueryToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQueryOutputReference | DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQuery): any;
export declare class DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQuery | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#limit Dashboard#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#sort_query Dashboard#sort_query}
    */
    readonly sortQuery?: DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQuery;
}
export declare function dashboardWidgetDistributionDefinitionRequestSecurityQueryGroupByToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare function dashboardWidgetDistributionDefinitionRequestSecurityQueryGroupByToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare class DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQueryOutputReference;
    putSortQuery(value: DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQuery | undefined;
}
export declare class DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupByList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupByOutputReference;
}
export interface DashboardWidgetDistributionDefinitionRequestSecurityQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: number;
}
export declare function dashboardWidgetDistributionDefinitionRequestSecurityQueryMultiComputeToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare function dashboardWidgetDistributionDefinitionRequestSecurityQueryMultiComputeToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare class DashboardWidgetDistributionDefinitionRequestSecurityQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class DashboardWidgetDistributionDefinitionRequestSecurityQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetDistributionDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetDistributionDefinitionRequestSecurityQueryMultiComputeOutputReference;
}
export interface DashboardWidgetDistributionDefinitionRequestSecurityQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#index Dashboard#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#search_query Dashboard#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#compute_query Dashboard#compute_query}
    */
    readonly computeQuery?: DashboardWidgetDistributionDefinitionRequestSecurityQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#group_by Dashboard#group_by}
    */
    readonly groupBy?: DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#multi_compute Dashboard#multi_compute}
    */
    readonly multiCompute?: DashboardWidgetDistributionDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function dashboardWidgetDistributionDefinitionRequestSecurityQueryToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestSecurityQueryOutputReference | DashboardWidgetDistributionDefinitionRequestSecurityQuery): any;
export declare function dashboardWidgetDistributionDefinitionRequestSecurityQueryToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestSecurityQueryOutputReference | DashboardWidgetDistributionDefinitionRequestSecurityQuery): any;
export declare class DashboardWidgetDistributionDefinitionRequestSecurityQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestSecurityQuery | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestSecurityQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): DashboardWidgetDistributionDefinitionRequestSecurityQueryComputeQueryOutputReference;
    putComputeQuery(value: DashboardWidgetDistributionDefinitionRequestSecurityQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): DashboardWidgetDistributionDefinitionRequestSecurityQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupByList;
    putGroupBy(value: DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | DashboardWidgetDistributionDefinitionRequestSecurityQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): DashboardWidgetDistributionDefinitionRequestSecurityQueryMultiComputeList;
    putMultiCompute(value: DashboardWidgetDistributionDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | DashboardWidgetDistributionDefinitionRequestSecurityQueryMultiCompute[] | undefined;
}
export interface DashboardWidgetDistributionDefinitionRequestStyle {
    /**
    * A color palette to apply to the widget. The available options are available at: https://docs.datadoghq.com/dashboards/widgets/timeseries/#appearance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#palette Dashboard#palette}
    */
    readonly palette?: string;
}
export declare function dashboardWidgetDistributionDefinitionRequestStyleToTerraform(struct?: DashboardWidgetDistributionDefinitionRequestStyleOutputReference | DashboardWidgetDistributionDefinitionRequestStyle): any;
export declare function dashboardWidgetDistributionDefinitionRequestStyleToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequestStyleOutputReference | DashboardWidgetDistributionDefinitionRequestStyle): any;
export declare class DashboardWidgetDistributionDefinitionRequestStyleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetDistributionDefinitionRequestStyle | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequestStyle | undefined);
    private _palette?;
    get palette(): string;
    set palette(value: string);
    resetPalette(): void;
    get paletteInput(): string | undefined;
}
export interface DashboardWidgetDistributionDefinitionRequest {
    /**
    * The metric query to use for this widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#q Dashboard#q}
    */
    readonly q?: string;
    /**
    * apm_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#apm_query Dashboard#apm_query}
    */
    readonly apmQuery?: DashboardWidgetDistributionDefinitionRequestApmQuery;
    /**
    * apm_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#apm_stats_query Dashboard#apm_stats_query}
    */
    readonly apmStatsQuery?: DashboardWidgetDistributionDefinitionRequestApmStatsQuery;
    /**
    * log_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#log_query Dashboard#log_query}
    */
    readonly logQuery?: DashboardWidgetDistributionDefinitionRequestLogQuery;
    /**
    * process_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#process_query Dashboard#process_query}
    */
    readonly processQuery?: DashboardWidgetDistributionDefinitionRequestProcessQuery;
    /**
    * rum_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#rum_query Dashboard#rum_query}
    */
    readonly rumQuery?: DashboardWidgetDistributionDefinitionRequestRumQuery;
    /**
    * security_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#security_query Dashboard#security_query}
    */
    readonly securityQuery?: DashboardWidgetDistributionDefinitionRequestSecurityQuery;
    /**
    * style block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#style Dashboard#style}
    */
    readonly style?: DashboardWidgetDistributionDefinitionRequestStyle;
}
export declare function dashboardWidgetDistributionDefinitionRequestToTerraform(struct?: DashboardWidgetDistributionDefinitionRequest | cdktn.IResolvable): any;
export declare function dashboardWidgetDistributionDefinitionRequestToHclTerraform(struct?: DashboardWidgetDistributionDefinitionRequest | cdktn.IResolvable): any;
export declare class DashboardWidgetDistributionDefinitionRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetDistributionDefinitionRequest | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionRequest | cdktn.IResolvable | undefined);
    private _q?;
    get q(): string;
    set q(value: string);
    resetQ(): void;
    get qInput(): string | undefined;
    private _apmQuery;
    get apmQuery(): DashboardWidgetDistributionDefinitionRequestApmQueryOutputReference;
    putApmQuery(value: DashboardWidgetDistributionDefinitionRequestApmQuery): void;
    resetApmQuery(): void;
    get apmQueryInput(): DashboardWidgetDistributionDefinitionRequestApmQuery | undefined;
    private _apmStatsQuery;
    get apmStatsQuery(): DashboardWidgetDistributionDefinitionRequestApmStatsQueryOutputReference;
    putApmStatsQuery(value: DashboardWidgetDistributionDefinitionRequestApmStatsQuery): void;
    resetApmStatsQuery(): void;
    get apmStatsQueryInput(): DashboardWidgetDistributionDefinitionRequestApmStatsQuery | undefined;
    private _logQuery;
    get logQuery(): DashboardWidgetDistributionDefinitionRequestLogQueryOutputReference;
    putLogQuery(value: DashboardWidgetDistributionDefinitionRequestLogQuery): void;
    resetLogQuery(): void;
    get logQueryInput(): DashboardWidgetDistributionDefinitionRequestLogQuery | undefined;
    private _processQuery;
    get processQuery(): DashboardWidgetDistributionDefinitionRequestProcessQueryOutputReference;
    putProcessQuery(value: DashboardWidgetDistributionDefinitionRequestProcessQuery): void;
    resetProcessQuery(): void;
    get processQueryInput(): DashboardWidgetDistributionDefinitionRequestProcessQuery | undefined;
    private _rumQuery;
    get rumQuery(): DashboardWidgetDistributionDefinitionRequestRumQueryOutputReference;
    putRumQuery(value: DashboardWidgetDistributionDefinitionRequestRumQuery): void;
    resetRumQuery(): void;
    get rumQueryInput(): DashboardWidgetDistributionDefinitionRequestRumQuery | undefined;
    private _securityQuery;
    get securityQuery(): DashboardWidgetDistributionDefinitionRequestSecurityQueryOutputReference;
    putSecurityQuery(value: DashboardWidgetDistributionDefinitionRequestSecurityQuery): void;
    resetSecurityQuery(): void;
    get securityQueryInput(): DashboardWidgetDistributionDefinitionRequestSecurityQuery | undefined;
    private _style;
    get style(): DashboardWidgetDistributionDefinitionRequestStyleOutputReference;
    putStyle(value: DashboardWidgetDistributionDefinitionRequestStyle): void;
    resetStyle(): void;
    get styleInput(): DashboardWidgetDistributionDefinitionRequestStyle | undefined;
}
export declare class DashboardWidgetDistributionDefinitionRequestList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetDistributionDefinitionRequest[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetDistributionDefinitionRequestOutputReference;
}
export interface DashboardWidgetDistributionDefinitionXaxis {
    /**
    * Always include zero or fit the axis to the data range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#include_zero Dashboard#include_zero}
    */
    readonly includeZero?: boolean | cdktn.IResolvable;
    /**
    * Specify the maximum value to show on the Y-axis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#max Dashboard#max}
    */
    readonly max?: string;
    /**
    * Specify the minimum value to show on the Y-axis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#min Dashboard#min}
    */
    readonly min?: string;
    /**
    * Specify the scale type, options: `linear`, `log`, `pow`, `sqrt`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#scale Dashboard#scale}
    */
    readonly scale?: string;
}
export declare function dashboardWidgetDistributionDefinitionXaxisToTerraform(struct?: DashboardWidgetDistributionDefinitionXaxisOutputReference | DashboardWidgetDistributionDefinitionXaxis): any;
export declare function dashboardWidgetDistributionDefinitionXaxisToHclTerraform(struct?: DashboardWidgetDistributionDefinitionXaxisOutputReference | DashboardWidgetDistributionDefinitionXaxis): any;
export declare class DashboardWidgetDistributionDefinitionXaxisOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetDistributionDefinitionXaxis | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionXaxis | undefined);
    private _includeZero?;
    get includeZero(): boolean | cdktn.IResolvable;
    set includeZero(value: boolean | cdktn.IResolvable);
    resetIncludeZero(): void;
    get includeZeroInput(): boolean | cdktn.IResolvable | undefined;
    private _max?;
    get max(): string;
    set max(value: string);
    resetMax(): void;
    get maxInput(): string | undefined;
    private _min?;
    get min(): string;
    set min(value: string);
    resetMin(): void;
    get minInput(): string | undefined;
    private _scale?;
    get scale(): string;
    set scale(value: string);
    resetScale(): void;
    get scaleInput(): string | undefined;
}
export interface DashboardWidgetDistributionDefinitionYaxis {
    /**
    * Always include zero or fit the axis to the data range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#include_zero Dashboard#include_zero}
    */
    readonly includeZero?: boolean | cdktn.IResolvable;
    /**
    * The label of the axis to display on the graph.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#label Dashboard#label}
    */
    readonly label?: string;
    /**
    * Specify the maximum value to show on the Y-axis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#max Dashboard#max}
    */
    readonly max?: string;
    /**
    * Specify the minimum value to show on the Y-axis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#min Dashboard#min}
    */
    readonly min?: string;
    /**
    * Specify the scale type, options: `linear`, `log`, `pow`, `sqrt`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#scale Dashboard#scale}
    */
    readonly scale?: string;
}
export declare function dashboardWidgetDistributionDefinitionYaxisToTerraform(struct?: DashboardWidgetDistributionDefinitionYaxisOutputReference | DashboardWidgetDistributionDefinitionYaxis): any;
export declare function dashboardWidgetDistributionDefinitionYaxisToHclTerraform(struct?: DashboardWidgetDistributionDefinitionYaxisOutputReference | DashboardWidgetDistributionDefinitionYaxis): any;
export declare class DashboardWidgetDistributionDefinitionYaxisOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetDistributionDefinitionYaxis | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinitionYaxis | undefined);
    private _includeZero?;
    get includeZero(): boolean | cdktn.IResolvable;
    set includeZero(value: boolean | cdktn.IResolvable);
    resetIncludeZero(): void;
    get includeZeroInput(): boolean | cdktn.IResolvable | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _max?;
    get max(): string;
    set max(value: string);
    resetMax(): void;
    get maxInput(): string | undefined;
    private _min?;
    get min(): string;
    set min(value: string);
    resetMin(): void;
    get minInput(): string | undefined;
    private _scale?;
    get scale(): string;
    set scale(value: string);
    resetScale(): void;
    get scaleInput(): string | undefined;
}
export interface DashboardWidgetDistributionDefinition {
    /**
    * Hide any portion of the widget's timeframe that is incomplete due to cost data not being available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#hide_incomplete_cost_data Dashboard#hide_incomplete_cost_data}
    */
    readonly hideIncompleteCostData?: boolean | cdktn.IResolvable;
    /**
    * The size of the legend displayed in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#legend_size Dashboard#legend_size}
    */
    readonly legendSize?: string;
    /**
    * The timeframe to use when displaying the widget. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#live_span Dashboard#live_span}
    */
    readonly liveSpan?: string;
    /**
    * Whether or not to show the legend on this widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#show_legend Dashboard#show_legend}
    */
    readonly showLegend?: boolean | cdktn.IResolvable;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title Dashboard#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title_align Dashboard#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title_size Dashboard#title_size}
    */
    readonly titleSize?: string;
    /**
    * request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#request Dashboard#request}
    */
    readonly request?: DashboardWidgetDistributionDefinitionRequest[] | cdktn.IResolvable;
    /**
    * xaxis block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#xaxis Dashboard#xaxis}
    */
    readonly xaxis?: DashboardWidgetDistributionDefinitionXaxis;
    /**
    * yaxis block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#yaxis Dashboard#yaxis}
    */
    readonly yaxis?: DashboardWidgetDistributionDefinitionYaxis;
}
export declare function dashboardWidgetDistributionDefinitionToTerraform(struct?: DashboardWidgetDistributionDefinitionOutputReference | DashboardWidgetDistributionDefinition): any;
export declare function dashboardWidgetDistributionDefinitionToHclTerraform(struct?: DashboardWidgetDistributionDefinitionOutputReference | DashboardWidgetDistributionDefinition): any;
export declare class DashboardWidgetDistributionDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetDistributionDefinition | undefined;
    set internalValue(value: DashboardWidgetDistributionDefinition | undefined);
    private _hideIncompleteCostData?;
    get hideIncompleteCostData(): boolean | cdktn.IResolvable;
    set hideIncompleteCostData(value: boolean | cdktn.IResolvable);
    resetHideIncompleteCostData(): void;
    get hideIncompleteCostDataInput(): boolean | cdktn.IResolvable | undefined;
    private _legendSize?;
    get legendSize(): string;
    set legendSize(value: string);
    resetLegendSize(): void;
    get legendSizeInput(): string | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _showLegend?;
    get showLegend(): boolean | cdktn.IResolvable;
    set showLegend(value: boolean | cdktn.IResolvable);
    resetShowLegend(): void;
    get showLegendInput(): boolean | cdktn.IResolvable | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _request;
    get request(): DashboardWidgetDistributionDefinitionRequestList;
    putRequest(value: DashboardWidgetDistributionDefinitionRequest[] | cdktn.IResolvable): void;
    resetRequest(): void;
    get requestInput(): cdktn.IResolvable | DashboardWidgetDistributionDefinitionRequest[] | undefined;
    private _xaxis;
    get xaxis(): DashboardWidgetDistributionDefinitionXaxisOutputReference;
    putXaxis(value: DashboardWidgetDistributionDefinitionXaxis): void;
    resetXaxis(): void;
    get xaxisInput(): DashboardWidgetDistributionDefinitionXaxis | undefined;
    private _yaxis;
    get yaxis(): DashboardWidgetDistributionDefinitionYaxisOutputReference;
    putYaxis(value: DashboardWidgetDistributionDefinitionYaxis): void;
    resetYaxis(): void;
    get yaxisInput(): DashboardWidgetDistributionDefinitionYaxis | undefined;
}
export interface DashboardWidgetEventStreamDefinition {
    /**
    * The size to use to display an event. Valid values are `s`, `l`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#event_size Dashboard#event_size}
    */
    readonly eventSize?: string;
    /**
    * Hide any portion of the widget's timeframe that is incomplete due to cost data not being available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#hide_incomplete_cost_data Dashboard#hide_incomplete_cost_data}
    */
    readonly hideIncompleteCostData?: boolean | cdktn.IResolvable;
    /**
    * The timeframe to use when displaying the widget. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#live_span Dashboard#live_span}
    */
    readonly liveSpan?: string;
    /**
    * The query to use in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#query Dashboard#query}
    */
    readonly query: string;
    /**
    * The execution method for multi-value filters, options: `and` or `or`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#tags_execution Dashboard#tags_execution}
    */
    readonly tagsExecution?: string;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title Dashboard#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title_align Dashboard#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title_size Dashboard#title_size}
    */
    readonly titleSize?: string;
}
export declare function dashboardWidgetEventStreamDefinitionToTerraform(struct?: DashboardWidgetEventStreamDefinitionOutputReference | DashboardWidgetEventStreamDefinition): any;
export declare function dashboardWidgetEventStreamDefinitionToHclTerraform(struct?: DashboardWidgetEventStreamDefinitionOutputReference | DashboardWidgetEventStreamDefinition): any;
export declare class DashboardWidgetEventStreamDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetEventStreamDefinition | undefined;
    set internalValue(value: DashboardWidgetEventStreamDefinition | undefined);
    private _eventSize?;
    get eventSize(): string;
    set eventSize(value: string);
    resetEventSize(): void;
    get eventSizeInput(): string | undefined;
    private _hideIncompleteCostData?;
    get hideIncompleteCostData(): boolean | cdktn.IResolvable;
    set hideIncompleteCostData(value: boolean | cdktn.IResolvable);
    resetHideIncompleteCostData(): void;
    get hideIncompleteCostDataInput(): boolean | cdktn.IResolvable | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _tagsExecution?;
    get tagsExecution(): string;
    set tagsExecution(value: string);
    resetTagsExecution(): void;
    get tagsExecutionInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
}
export interface DashboardWidgetEventTimelineDefinition {
    /**
    * Hide any portion of the widget's timeframe that is incomplete due to cost data not being available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#hide_incomplete_cost_data Dashboard#hide_incomplete_cost_data}
    */
    readonly hideIncompleteCostData?: boolean | cdktn.IResolvable;
    /**
    * The timeframe to use when displaying the widget. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#live_span Dashboard#live_span}
    */
    readonly liveSpan?: string;
    /**
    * The query to use in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#query Dashboard#query}
    */
    readonly query: string;
    /**
    * The execution method for multi-value filters, options: `and` or `or`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#tags_execution Dashboard#tags_execution}
    */
    readonly tagsExecution?: string;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title Dashboard#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title_align Dashboard#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title_size Dashboard#title_size}
    */
    readonly titleSize?: string;
}
export declare function dashboardWidgetEventTimelineDefinitionToTerraform(struct?: DashboardWidgetEventTimelineDefinitionOutputReference | DashboardWidgetEventTimelineDefinition): any;
export declare function dashboardWidgetEventTimelineDefinitionToHclTerraform(struct?: DashboardWidgetEventTimelineDefinitionOutputReference | DashboardWidgetEventTimelineDefinition): any;
export declare class DashboardWidgetEventTimelineDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetEventTimelineDefinition | undefined;
    set internalValue(value: DashboardWidgetEventTimelineDefinition | undefined);
    private _hideIncompleteCostData?;
    get hideIncompleteCostData(): boolean | cdktn.IResolvable;
    set hideIncompleteCostData(value: boolean | cdktn.IResolvable);
    resetHideIncompleteCostData(): void;
    get hideIncompleteCostDataInput(): boolean | cdktn.IResolvable | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _tagsExecution?;
    get tagsExecution(): string;
    set tagsExecution(value: string);
    resetTagsExecution(): void;
    get tagsExecutionInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
}
export interface DashboardWidgetFreeTextDefinition {
    /**
    * The color of the text in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#color Dashboard#color}
    */
    readonly color?: string;
    /**
    * The size of the text in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#font_size Dashboard#font_size}
    */
    readonly fontSize?: string;
    /**
    * The text to display in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#text Dashboard#text}
    */
    readonly text: string;
    /**
    * The alignment of the text in the widget. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#text_align Dashboard#text_align}
    */
    readonly textAlign?: string;
}
export declare function dashboardWidgetFreeTextDefinitionToTerraform(struct?: DashboardWidgetFreeTextDefinitionOutputReference | DashboardWidgetFreeTextDefinition): any;
export declare function dashboardWidgetFreeTextDefinitionToHclTerraform(struct?: DashboardWidgetFreeTextDefinitionOutputReference | DashboardWidgetFreeTextDefinition): any;
export declare class DashboardWidgetFreeTextDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetFreeTextDefinition | undefined;
    set internalValue(value: DashboardWidgetFreeTextDefinition | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _fontSize?;
    get fontSize(): string;
    set fontSize(value: string);
    resetFontSize(): void;
    get fontSizeInput(): string | undefined;
    private _text?;
    get text(): string;
    set text(value: string);
    get textInput(): string | undefined;
    private _textAlign?;
    get textAlign(): string;
    set textAlign(value: string);
    resetTextAlign(): void;
    get textAlignInput(): string | undefined;
}
export interface DashboardWidgetGeomapDefinitionCustomLink {
    /**
    * The flag for toggling context menu link visibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#is_hidden Dashboard#is_hidden}
    */
    readonly isHidden?: boolean | cdktn.IResolvable;
    /**
    * The label for the custom link URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#label Dashboard#label}
    */
    readonly label?: string;
    /**
    * The URL of the custom link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#link Dashboard#link}
    */
    readonly link?: string;
    /**
    * The label ID that refers to a context menu link item. When `override_label` is provided, the client request omits the label field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#override_label Dashboard#override_label}
    */
    readonly overrideLabel?: string;
}
export declare function dashboardWidgetGeomapDefinitionCustomLinkToTerraform(struct?: DashboardWidgetGeomapDefinitionCustomLink | cdktn.IResolvable): any;
export declare function dashboardWidgetGeomapDefinitionCustomLinkToHclTerraform(struct?: DashboardWidgetGeomapDefinitionCustomLink | cdktn.IResolvable): any;
export declare class DashboardWidgetGeomapDefinitionCustomLinkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetGeomapDefinitionCustomLink | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionCustomLink | cdktn.IResolvable | undefined);
    private _isHidden?;
    get isHidden(): boolean | cdktn.IResolvable;
    set isHidden(value: boolean | cdktn.IResolvable);
    resetIsHidden(): void;
    get isHiddenInput(): boolean | cdktn.IResolvable | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _link?;
    get link(): string;
    set link(value: string);
    resetLink(): void;
    get linkInput(): string | undefined;
    private _overrideLabel?;
    get overrideLabel(): string;
    set overrideLabel(value: string);
    resetOverrideLabel(): void;
    get overrideLabelInput(): string | undefined;
}
export declare class DashboardWidgetGeomapDefinitionCustomLinkList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetGeomapDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetGeomapDefinitionCustomLinkOutputReference;
}
export interface DashboardWidgetGeomapDefinitionRequestFormulaConditionalFormats {
    /**
    * The comparator to use. Valid values are `=`, `>`, `>=`, `<`, `<=`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#comparator Dashboard#comparator}
    */
    readonly comparator: string;
    /**
    * The color palette to apply to the background, same values available as palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#custom_bg_color Dashboard#custom_bg_color}
    */
    readonly customBgColor?: string;
    /**
    * The color palette to apply to the foreground, same values available as palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#custom_fg_color Dashboard#custom_fg_color}
    */
    readonly customFgColor?: string;
    /**
    * Setting this to True hides values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#hide_value Dashboard#hide_value}
    */
    readonly hideValue?: boolean | cdktn.IResolvable;
    /**
    * Displays an image as the background.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#image_url Dashboard#image_url}
    */
    readonly imageUrl?: string;
    /**
    * The metric from the request to correlate with this conditional format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#metric Dashboard#metric}
    */
    readonly metric?: string;
    /**
    * The color palette to apply. Valid values are `blue`, `custom_bg`, `custom_image`, `custom_text`, `gray_on_white`, `grey`, `green`, `orange`, `red`, `red_on_white`, `white_on_gray`, `white_on_green`, `green_on_white`, `white_on_red`, `white_on_yellow`, `yellow_on_white`, `black_on_light_yellow`, `black_on_light_green`, `black_on_light_red`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#palette Dashboard#palette}
    */
    readonly palette: string;
    /**
    * Defines the displayed timeframe.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#timeframe Dashboard#timeframe}
    */
    readonly timeframe?: string;
    /**
    * A value for the comparator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#value Dashboard#value}
    */
    readonly value: number;
}
export declare function dashboardWidgetGeomapDefinitionRequestFormulaConditionalFormatsToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable): any;
export declare function dashboardWidgetGeomapDefinitionRequestFormulaConditionalFormatsToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable): any;
export declare class DashboardWidgetGeomapDefinitionRequestFormulaConditionalFormatsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable | undefined);
    private _comparator?;
    get comparator(): string;
    set comparator(value: string);
    get comparatorInput(): string | undefined;
    private _customBgColor?;
    get customBgColor(): string;
    set customBgColor(value: string);
    resetCustomBgColor(): void;
    get customBgColorInput(): string | undefined;
    private _customFgColor?;
    get customFgColor(): string;
    set customFgColor(value: string);
    resetCustomFgColor(): void;
    get customFgColorInput(): string | undefined;
    private _hideValue?;
    get hideValue(): boolean | cdktn.IResolvable;
    set hideValue(value: boolean | cdktn.IResolvable);
    resetHideValue(): void;
    get hideValueInput(): boolean | cdktn.IResolvable | undefined;
    private _imageUrl?;
    get imageUrl(): string;
    set imageUrl(value: string);
    resetImageUrl(): void;
    get imageUrlInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _palette?;
    get palette(): string;
    set palette(value: string);
    get paletteInput(): string | undefined;
    private _timeframe?;
    get timeframe(): string;
    set timeframe(value: string);
    resetTimeframe(): void;
    get timeframeInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DashboardWidgetGeomapDefinitionRequestFormulaConditionalFormatsList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetGeomapDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetGeomapDefinitionRequestFormulaConditionalFormatsOutputReference;
}
export interface DashboardWidgetGeomapDefinitionRequestFormulaLimit {
    /**
    * The number of results to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#count Dashboard#count}
    */
    readonly count?: number;
    /**
    * The direction of the sort. Valid values are `asc`, `desc`. Defaults to `"desc"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#order Dashboard#order}
    */
    readonly order?: string;
}
export declare function dashboardWidgetGeomapDefinitionRequestFormulaLimitToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestFormulaLimitOutputReference | DashboardWidgetGeomapDefinitionRequestFormulaLimit): any;
export declare function dashboardWidgetGeomapDefinitionRequestFormulaLimitToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestFormulaLimitOutputReference | DashboardWidgetGeomapDefinitionRequestFormulaLimit): any;
export declare class DashboardWidgetGeomapDefinitionRequestFormulaLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestFormulaLimit | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestFormulaLimit | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    resetCount(): void;
    get countInput(): number | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export interface DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonical {
    /**
    * per unit name. If you want to represent megabytes/s, you set 'unit_name' = 'megabyte' and 'per_unit_name = 'second'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#per_unit_name Dashboard#per_unit_name}
    */
    readonly perUnitName?: string;
    /**
    * Unit name. It should be in singular form ('megabyte' and not 'megabytes')
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#unit_name Dashboard#unit_name}
    */
    readonly unitName: string;
}
export declare function dashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonicalToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference | DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonical): any;
export declare function dashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonicalToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference | DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonical): any;
export declare class DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonical | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonical | undefined);
    private _perUnitName?;
    get perUnitName(): string;
    set perUnitName(value: string);
    resetPerUnitName(): void;
    get perUnitNameInput(): string | undefined;
    private _unitName?;
    get unitName(): string;
    set unitName(value: string);
    get unitNameInput(): string | undefined;
}
export interface DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustom {
    /**
    * Unit label
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#label Dashboard#label}
    */
    readonly label: string;
}
export declare function dashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustomToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustomOutputReference | DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustom): any;
export declare function dashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustomToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustomOutputReference | DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustom): any;
export declare class DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustom | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustom | undefined);
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
}
export interface DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnit {
    /**
    * canonical block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#canonical Dashboard#canonical}
    */
    readonly canonical?: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonical;
    /**
    * custom block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#custom Dashboard#custom}
    */
    readonly custom?: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustom;
}
export declare function dashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitOutputReference | DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnit): any;
export declare function dashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitOutputReference | DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnit): any;
export declare class DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnit | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnit | undefined);
    private _canonical;
    get canonical(): DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference;
    putCanonical(value: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonical): void;
    resetCanonical(): void;
    get canonicalInput(): DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonical | undefined;
    private _custom;
    get custom(): DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustomOutputReference;
    putCustom(value: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustom): void;
    resetCustom(): void;
    get customInput(): DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustom | undefined;
}
export interface DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#unit_name Dashboard#unit_name}
    */
    readonly unitName: string;
}
export declare function dashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScaleToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScaleOutputReference | DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScale): any;
export declare function dashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScaleToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScaleOutputReference | DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScale): any;
export declare class DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScale | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScale | undefined);
    private _unitName?;
    get unitName(): string;
    set unitName(value: string);
    get unitNameInput(): string | undefined;
}
export interface DashboardWidgetGeomapDefinitionRequestFormulaNumberFormat {
    /**
    * unit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#unit Dashboard#unit}
    */
    readonly unit: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnit;
    /**
    * unit_scale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#unit_scale Dashboard#unit_scale}
    */
    readonly unitScale?: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScale;
}
export declare function dashboardWidgetGeomapDefinitionRequestFormulaNumberFormatToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatOutputReference | DashboardWidgetGeomapDefinitionRequestFormulaNumberFormat): any;
export declare function dashboardWidgetGeomapDefinitionRequestFormulaNumberFormatToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatOutputReference | DashboardWidgetGeomapDefinitionRequestFormulaNumberFormat): any;
export declare class DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestFormulaNumberFormat | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormat | undefined);
    private _unit;
    get unit(): DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitOutputReference;
    putUnit(value: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnit): void;
    get unitInput(): DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnit | undefined;
    private _unitScale;
    get unitScale(): DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScaleOutputReference;
    putUnitScale(value: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScale): void;
    resetUnitScale(): void;
    get unitScaleInput(): DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScale | undefined;
}
export interface DashboardWidgetGeomapDefinitionRequestFormulaStyle {
    /**
    * The color palette used to display the formula. A guide to the available color palettes can be found at https://docs.datadoghq.com/dashboards/guide/widget_colors.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#palette Dashboard#palette}
    */
    readonly palette?: string;
    /**
    * Index specifying which color to use within the palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#palette_index Dashboard#palette_index}
    */
    readonly paletteIndex?: number;
}
export declare function dashboardWidgetGeomapDefinitionRequestFormulaStyleToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestFormulaStyleOutputReference | DashboardWidgetGeomapDefinitionRequestFormulaStyle): any;
export declare function dashboardWidgetGeomapDefinitionRequestFormulaStyleToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestFormulaStyleOutputReference | DashboardWidgetGeomapDefinitionRequestFormulaStyle): any;
export declare class DashboardWidgetGeomapDefinitionRequestFormulaStyleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestFormulaStyle | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestFormulaStyle | undefined);
    private _palette?;
    get palette(): string;
    set palette(value: string);
    resetPalette(): void;
    get paletteInput(): string | undefined;
    private _paletteIndex?;
    get paletteIndex(): number;
    set paletteIndex(value: number);
    resetPaletteIndex(): void;
    get paletteIndexInput(): number | undefined;
}
export interface DashboardWidgetGeomapDefinitionRequestFormula {
    /**
    * An expression alias.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#alias Dashboard#alias}
    */
    readonly alias?: string;
    /**
    * A list of display modes for each table cell. Valid values are `number`, `bar`, `trend`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#cell_display_mode Dashboard#cell_display_mode}
    */
    readonly cellDisplayMode?: string;
    /**
    * A string expression built from queries, formulas, and functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#formula_expression Dashboard#formula_expression}
    */
    readonly formulaExpression: string;
    /**
    * conditional_formats block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#conditional_formats Dashboard#conditional_formats}
    */
    readonly conditionalFormats?: DashboardWidgetGeomapDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#limit Dashboard#limit}
    */
    readonly limit?: DashboardWidgetGeomapDefinitionRequestFormulaLimit;
    /**
    * number_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#number_format Dashboard#number_format}
    */
    readonly numberFormat?: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormat;
    /**
    * style block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#style Dashboard#style}
    */
    readonly style?: DashboardWidgetGeomapDefinitionRequestFormulaStyle;
}
export declare function dashboardWidgetGeomapDefinitionRequestFormulaToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestFormula | cdktn.IResolvable): any;
export declare function dashboardWidgetGeomapDefinitionRequestFormulaToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestFormula | cdktn.IResolvable): any;
export declare class DashboardWidgetGeomapDefinitionRequestFormulaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestFormula | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestFormula | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _cellDisplayMode?;
    get cellDisplayMode(): string;
    set cellDisplayMode(value: string);
    resetCellDisplayMode(): void;
    get cellDisplayModeInput(): string | undefined;
    private _formulaExpression?;
    get formulaExpression(): string;
    set formulaExpression(value: string);
    get formulaExpressionInput(): string | undefined;
    private _conditionalFormats;
    get conditionalFormats(): DashboardWidgetGeomapDefinitionRequestFormulaConditionalFormatsList;
    putConditionalFormats(value: DashboardWidgetGeomapDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable): void;
    resetConditionalFormats(): void;
    get conditionalFormatsInput(): cdktn.IResolvable | DashboardWidgetGeomapDefinitionRequestFormulaConditionalFormats[] | undefined;
    private _limit;
    get limit(): DashboardWidgetGeomapDefinitionRequestFormulaLimitOutputReference;
    putLimit(value: DashboardWidgetGeomapDefinitionRequestFormulaLimit): void;
    resetLimit(): void;
    get limitInput(): DashboardWidgetGeomapDefinitionRequestFormulaLimit | undefined;
    private _numberFormat;
    get numberFormat(): DashboardWidgetGeomapDefinitionRequestFormulaNumberFormatOutputReference;
    putNumberFormat(value: DashboardWidgetGeomapDefinitionRequestFormulaNumberFormat): void;
    resetNumberFormat(): void;
    get numberFormatInput(): DashboardWidgetGeomapDefinitionRequestFormulaNumberFormat | undefined;
    private _style;
    get style(): DashboardWidgetGeomapDefinitionRequestFormulaStyleOutputReference;
    putStyle(value: DashboardWidgetGeomapDefinitionRequestFormulaStyle): void;
    resetStyle(): void;
    get styleInput(): DashboardWidgetGeomapDefinitionRequestFormulaStyle | undefined;
}
export declare class DashboardWidgetGeomapDefinitionRequestFormulaList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetGeomapDefinitionRequestFormula[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetGeomapDefinitionRequestFormulaOutputReference;
}
export interface DashboardWidgetGeomapDefinitionRequestLogQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: number;
}
export declare function dashboardWidgetGeomapDefinitionRequestLogQueryComputeQueryToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestLogQueryComputeQueryOutputReference | DashboardWidgetGeomapDefinitionRequestLogQueryComputeQuery): any;
export declare function dashboardWidgetGeomapDefinitionRequestLogQueryComputeQueryToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestLogQueryComputeQueryOutputReference | DashboardWidgetGeomapDefinitionRequestLogQueryComputeQuery): any;
export declare class DashboardWidgetGeomapDefinitionRequestLogQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestLogQueryComputeQuery | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestLogQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface DashboardWidgetGeomapDefinitionRequestLogQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#order Dashboard#order}
    */
    readonly order: string;
}
export declare function dashboardWidgetGeomapDefinitionRequestLogQueryGroupBySortQueryToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestLogQueryGroupBySortQueryOutputReference | DashboardWidgetGeomapDefinitionRequestLogQueryGroupBySortQuery): any;
export declare function dashboardWidgetGeomapDefinitionRequestLogQueryGroupBySortQueryToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestLogQueryGroupBySortQueryOutputReference | DashboardWidgetGeomapDefinitionRequestLogQueryGroupBySortQuery): any;
export declare class DashboardWidgetGeomapDefinitionRequestLogQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestLogQueryGroupBySortQuery | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestLogQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface DashboardWidgetGeomapDefinitionRequestLogQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#limit Dashboard#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#sort_query Dashboard#sort_query}
    */
    readonly sortQuery?: DashboardWidgetGeomapDefinitionRequestLogQueryGroupBySortQuery;
}
export declare function dashboardWidgetGeomapDefinitionRequestLogQueryGroupByToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestLogQueryGroupBy | cdktn.IResolvable): any;
export declare function dashboardWidgetGeomapDefinitionRequestLogQueryGroupByToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestLogQueryGroupBy | cdktn.IResolvable): any;
export declare class DashboardWidgetGeomapDefinitionRequestLogQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestLogQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestLogQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): DashboardWidgetGeomapDefinitionRequestLogQueryGroupBySortQueryOutputReference;
    putSortQuery(value: DashboardWidgetGeomapDefinitionRequestLogQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): DashboardWidgetGeomapDefinitionRequestLogQueryGroupBySortQuery | undefined;
}
export declare class DashboardWidgetGeomapDefinitionRequestLogQueryGroupByList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetGeomapDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetGeomapDefinitionRequestLogQueryGroupByOutputReference;
}
export interface DashboardWidgetGeomapDefinitionRequestLogQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: number;
}
export declare function dashboardWidgetGeomapDefinitionRequestLogQueryMultiComputeToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable): any;
export declare function dashboardWidgetGeomapDefinitionRequestLogQueryMultiComputeToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable): any;
export declare class DashboardWidgetGeomapDefinitionRequestLogQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class DashboardWidgetGeomapDefinitionRequestLogQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetGeomapDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetGeomapDefinitionRequestLogQueryMultiComputeOutputReference;
}
export interface DashboardWidgetGeomapDefinitionRequestLogQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#index Dashboard#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#search_query Dashboard#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#compute_query Dashboard#compute_query}
    */
    readonly computeQuery?: DashboardWidgetGeomapDefinitionRequestLogQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#group_by Dashboard#group_by}
    */
    readonly groupBy?: DashboardWidgetGeomapDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#multi_compute Dashboard#multi_compute}
    */
    readonly multiCompute?: DashboardWidgetGeomapDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function dashboardWidgetGeomapDefinitionRequestLogQueryToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestLogQueryOutputReference | DashboardWidgetGeomapDefinitionRequestLogQuery): any;
export declare function dashboardWidgetGeomapDefinitionRequestLogQueryToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestLogQueryOutputReference | DashboardWidgetGeomapDefinitionRequestLogQuery): any;
export declare class DashboardWidgetGeomapDefinitionRequestLogQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestLogQuery | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestLogQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): DashboardWidgetGeomapDefinitionRequestLogQueryComputeQueryOutputReference;
    putComputeQuery(value: DashboardWidgetGeomapDefinitionRequestLogQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): DashboardWidgetGeomapDefinitionRequestLogQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): DashboardWidgetGeomapDefinitionRequestLogQueryGroupByList;
    putGroupBy(value: DashboardWidgetGeomapDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | DashboardWidgetGeomapDefinitionRequestLogQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): DashboardWidgetGeomapDefinitionRequestLogQueryMultiComputeList;
    putMultiCompute(value: DashboardWidgetGeomapDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | DashboardWidgetGeomapDefinitionRequestLogQueryMultiCompute[] | undefined;
}
export interface DashboardWidgetGeomapDefinitionRequestQueryApmDependencyStatsQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#cross_org_uuids Dashboard#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for APM Dependency Stats queries. Valid values are `apm_dependency_stats`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#data_source Dashboard#data_source}
    */
    readonly dataSource: string;
    /**
    * APM environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#env Dashboard#env}
    */
    readonly env: string;
    /**
    * Determines whether stats for upstream or downstream dependencies should be queried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#is_upstream Dashboard#is_upstream}
    */
    readonly isUpstream?: boolean | cdktn.IResolvable;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#name Dashboard#name}
    */
    readonly name: string;
    /**
    * Name of operation on service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#operation_name Dashboard#operation_name}
    */
    readonly operationName: string;
    /**
    * The name of the second primary tag used within APM; required when `primary_tag_value` is specified. See https://docs.datadoghq.com/tracing/guide/setting_primary_tags_to_scope/#add-a-second-primary-tag-in-datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#primary_tag_name Dashboard#primary_tag_name}
    */
    readonly primaryTagName?: string;
    /**
    * Filter APM data by the second primary tag. `primary_tag_name` must also be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#primary_tag_value Dashboard#primary_tag_value}
    */
    readonly primaryTagValue?: string;
    /**
    * APM resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#resource_name Dashboard#resource_name}
    */
    readonly resourceName: string;
    /**
    * APM service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#service Dashboard#service}
    */
    readonly service: string;
    /**
    * APM statistic. Valid values are `avg_duration`, `avg_root_duration`, `avg_spans_per_trace`, `error_rate`, `pct_exec_time`, `pct_of_traces`, `total_traces_count`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#stat Dashboard#stat}
    */
    readonly stat: string;
}
export declare function dashboardWidgetGeomapDefinitionRequestQueryApmDependencyStatsQueryToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQueryApmDependencyStatsQueryOutputReference | DashboardWidgetGeomapDefinitionRequestQueryApmDependencyStatsQuery): any;
export declare function dashboardWidgetGeomapDefinitionRequestQueryApmDependencyStatsQueryToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQueryApmDependencyStatsQueryOutputReference | DashboardWidgetGeomapDefinitionRequestQueryApmDependencyStatsQuery): any;
export declare class DashboardWidgetGeomapDefinitionRequestQueryApmDependencyStatsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestQueryApmDependencyStatsQuery | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestQueryApmDependencyStatsQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    private _isUpstream?;
    get isUpstream(): boolean | cdktn.IResolvable;
    set isUpstream(value: boolean | cdktn.IResolvable);
    resetIsUpstream(): void;
    get isUpstreamInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    get operationNameInput(): string | undefined;
    private _primaryTagName?;
    get primaryTagName(): string;
    set primaryTagName(value: string);
    resetPrimaryTagName(): void;
    get primaryTagNameInput(): string | undefined;
    private _primaryTagValue?;
    get primaryTagValue(): string;
    set primaryTagValue(value: string);
    resetPrimaryTagValue(): void;
    get primaryTagValueInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    get resourceNameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    get statInput(): string | undefined;
}
export interface DashboardWidgetGeomapDefinitionRequestQueryApmResourceStatsQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#cross_org_uuids Dashboard#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for APM Resource Stats queries. Valid values are `apm_resource_stats`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#data_source Dashboard#data_source}
    */
    readonly dataSource: string;
    /**
    * APM environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#env Dashboard#env}
    */
    readonly env: string;
    /**
    * Array of fields to group results by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#group_by Dashboard#group_by}
    */
    readonly groupBy?: string[];
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#name Dashboard#name}
    */
    readonly name: string;
    /**
    * Name of operation on service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#operation_name Dashboard#operation_name}
    */
    readonly operationName?: string;
    /**
    * The name of the second primary tag used within APM; required when `primary_tag_value` is specified. See https://docs.datadoghq.com/tracing/guide/setting_primary_tags_to_scope/#add-a-second-primary-tag-in-datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#primary_tag_name Dashboard#primary_tag_name}
    */
    readonly primaryTagName?: string;
    /**
    * Filter APM data by the second primary tag. `primary_tag_name` must also be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#primary_tag_value Dashboard#primary_tag_value}
    */
    readonly primaryTagValue?: string;
    /**
    * APM resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#resource_name Dashboard#resource_name}
    */
    readonly resourceName?: string;
    /**
    * APM service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#service Dashboard#service}
    */
    readonly service: string;
    /**
    * APM statistic. Valid values are `errors`, `error_rate`, `hits`, `latency_avg`, `latency_distribution`, `latency_max`, `latency_p50`, `latency_p75`, `latency_p90`, `latency_p95`, `latency_p99`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#stat Dashboard#stat}
    */
    readonly stat: string;
}
export declare function dashboardWidgetGeomapDefinitionRequestQueryApmResourceStatsQueryToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQueryApmResourceStatsQueryOutputReference | DashboardWidgetGeomapDefinitionRequestQueryApmResourceStatsQuery): any;
export declare function dashboardWidgetGeomapDefinitionRequestQueryApmResourceStatsQueryToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQueryApmResourceStatsQueryOutputReference | DashboardWidgetGeomapDefinitionRequestQueryApmResourceStatsQuery): any;
export declare class DashboardWidgetGeomapDefinitionRequestQueryApmResourceStatsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestQueryApmResourceStatsQuery | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestQueryApmResourceStatsQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    private _groupBy?;
    get groupBy(): string[];
    set groupBy(value: string[]);
    resetGroupBy(): void;
    get groupByInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    resetOperationName(): void;
    get operationNameInput(): string | undefined;
    private _primaryTagName?;
    get primaryTagName(): string;
    set primaryTagName(value: string);
    resetPrimaryTagName(): void;
    get primaryTagNameInput(): string | undefined;
    private _primaryTagValue?;
    get primaryTagValue(): string;
    set primaryTagValue(value: string);
    resetPrimaryTagValue(): void;
    get primaryTagValueInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    resetResourceName(): void;
    get resourceNameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    get statInput(): string | undefined;
}
export interface DashboardWidgetGeomapDefinitionRequestQueryCloudCostQuery {
    /**
    * The aggregation methods available for cloud cost queries. Valid values are `avg`, `last`, `max`, `min`, `sum`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregator Dashboard#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#cross_org_uuids Dashboard#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for cloud cost queries. Valid values are `cloud_cost`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#data_source Dashboard#data_source}
    */
    readonly dataSource: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#name Dashboard#name}
    */
    readonly name: string;
    /**
    * The cloud cost query definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#query Dashboard#query}
    */
    readonly query: string;
}
export declare function dashboardWidgetGeomapDefinitionRequestQueryCloudCostQueryToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQueryCloudCostQueryOutputReference | DashboardWidgetGeomapDefinitionRequestQueryCloudCostQuery): any;
export declare function dashboardWidgetGeomapDefinitionRequestQueryCloudCostQueryToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQueryCloudCostQueryOutputReference | DashboardWidgetGeomapDefinitionRequestQueryCloudCostQuery): any;
export declare class DashboardWidgetGeomapDefinitionRequestQueryCloudCostQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestQueryCloudCostQuery | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestQueryCloudCostQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface DashboardWidgetGeomapDefinitionRequestQueryEventQueryCompute {
    /**
    * The aggregation methods for event platform queries. Valid values are `count`, `cardinality`, `median`, `pc75`, `pc90`, `pc95`, `pc98`, `pc99`, `sum`, `min`, `max`, `avg`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * A time interval in milliseconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: number;
    /**
    * The measurable attribute to compute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#metric Dashboard#metric}
    */
    readonly metric?: string;
}
export declare function dashboardWidgetGeomapDefinitionRequestQueryEventQueryComputeToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable): any;
export declare function dashboardWidgetGeomapDefinitionRequestQueryEventQueryComputeToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable): any;
export declare class DashboardWidgetGeomapDefinitionRequestQueryEventQueryComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
}
export declare class DashboardWidgetGeomapDefinitionRequestQueryEventQueryComputeList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetGeomapDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetGeomapDefinitionRequestQueryEventQueryComputeOutputReference;
}
export interface DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBySort {
    /**
    * The aggregation methods for the event platform queries. Valid values are `count`, `cardinality`, `median`, `pc75`, `pc90`, `pc95`, `pc98`, `pc99`, `sum`, `min`, `max`, `avg`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The metric used for sorting group by results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#metric Dashboard#metric}
    */
    readonly metric?: string;
    /**
    * Direction of sort. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#order Dashboard#order}
    */
    readonly order?: string;
}
export declare function dashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBySortToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBySortOutputReference | DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBySort): any;
export declare function dashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBySortToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBySortOutputReference | DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBySort): any;
export declare class DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBySortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBySort | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBySort | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export interface DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBy {
    /**
    * The event facet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet: string;
    /**
    * The number of groups to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#limit Dashboard#limit}
    */
    readonly limit?: number;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#sort Dashboard#sort}
    */
    readonly sort?: DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBySort;
}
export declare function dashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupByToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable): any;
export declare function dashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupByToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable): any;
export declare class DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sort;
    get sort(): DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBySortOutputReference;
    putSort(value: DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBySort): void;
    resetSort(): void;
    get sortInput(): DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBySort | undefined;
}
export declare class DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupByList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupByOutputReference;
}
export interface DashboardWidgetGeomapDefinitionRequestQueryEventQuerySearch {
    /**
    * The events search string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#query Dashboard#query}
    */
    readonly query: string;
}
export declare function dashboardWidgetGeomapDefinitionRequestQueryEventQuerySearchToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQueryEventQuerySearchOutputReference | DashboardWidgetGeomapDefinitionRequestQueryEventQuerySearch): any;
export declare function dashboardWidgetGeomapDefinitionRequestQueryEventQuerySearchToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQueryEventQuerySearchOutputReference | DashboardWidgetGeomapDefinitionRequestQueryEventQuerySearch): any;
export declare class DashboardWidgetGeomapDefinitionRequestQueryEventQuerySearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestQueryEventQuerySearch | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestQueryEventQuerySearch | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface DashboardWidgetGeomapDefinitionRequestQueryEventQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#cross_org_uuids Dashboard#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for event platform-based queries. Valid values are `logs`, `spans`, `network`, `rum`, `security_signals`, `profiles`, `audit`, `events`, `ci_tests`, `ci_pipelines`, `incident_analytics`, `product_analytics`, `on_call_events`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#data_source Dashboard#data_source}
    */
    readonly dataSource: string;
    /**
    * An array of index names to query in the stream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#indexes Dashboard#indexes}
    */
    readonly indexes?: string[];
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#name Dashboard#name}
    */
    readonly name: string;
    /**
    * Storage location (private beta).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#storage Dashboard#storage}
    */
    readonly storage?: string;
    /**
    * compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#compute Dashboard#compute}
    */
    readonly compute: DashboardWidgetGeomapDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#group_by Dashboard#group_by}
    */
    readonly groupBy?: DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable;
    /**
    * search block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#search Dashboard#search}
    */
    readonly search?: DashboardWidgetGeomapDefinitionRequestQueryEventQuerySearch;
}
export declare function dashboardWidgetGeomapDefinitionRequestQueryEventQueryToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQueryEventQueryOutputReference | DashboardWidgetGeomapDefinitionRequestQueryEventQuery): any;
export declare function dashboardWidgetGeomapDefinitionRequestQueryEventQueryToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQueryEventQueryOutputReference | DashboardWidgetGeomapDefinitionRequestQueryEventQuery): any;
export declare class DashboardWidgetGeomapDefinitionRequestQueryEventQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestQueryEventQuery | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestQueryEventQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _indexes?;
    get indexes(): string[];
    set indexes(value: string[]);
    resetIndexes(): void;
    get indexesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _storage?;
    get storage(): string;
    set storage(value: string);
    resetStorage(): void;
    get storageInput(): string | undefined;
    private _compute;
    get compute(): DashboardWidgetGeomapDefinitionRequestQueryEventQueryComputeList;
    putCompute(value: DashboardWidgetGeomapDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable): void;
    get computeInput(): cdktn.IResolvable | DashboardWidgetGeomapDefinitionRequestQueryEventQueryCompute[] | undefined;
    private _groupBy;
    get groupBy(): DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupByList;
    putGroupBy(value: DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | DashboardWidgetGeomapDefinitionRequestQueryEventQueryGroupBy[] | undefined;
    private _search;
    get search(): DashboardWidgetGeomapDefinitionRequestQueryEventQuerySearchOutputReference;
    putSearch(value: DashboardWidgetGeomapDefinitionRequestQueryEventQuerySearch): void;
    resetSearch(): void;
    get searchInput(): DashboardWidgetGeomapDefinitionRequestQueryEventQuerySearch | undefined;
}
export interface DashboardWidgetGeomapDefinitionRequestQueryMetricQuery {
    /**
    * The aggregation methods available for metrics queries. Valid values are `avg`, `min`, `max`, `sum`, `last`, `area`, `l2norm`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregator Dashboard#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#cross_org_uuids Dashboard#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for metrics queries. Defaults to `"metrics"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#data_source Dashboard#data_source}
    */
    readonly dataSource?: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#name Dashboard#name}
    */
    readonly name: string;
    /**
    * The metrics query definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#query Dashboard#query}
    */
    readonly query: string;
    /**
    * Semantic mode for metrics queries. This determines how metrics from different sources are combined or displayed. Valid values are `combined`, `native`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#semantic_mode Dashboard#semantic_mode}
    */
    readonly semanticMode?: string;
}
export declare function dashboardWidgetGeomapDefinitionRequestQueryMetricQueryToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQueryMetricQueryOutputReference | DashboardWidgetGeomapDefinitionRequestQueryMetricQuery): any;
export declare function dashboardWidgetGeomapDefinitionRequestQueryMetricQueryToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQueryMetricQueryOutputReference | DashboardWidgetGeomapDefinitionRequestQueryMetricQuery): any;
export declare class DashboardWidgetGeomapDefinitionRequestQueryMetricQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestQueryMetricQuery | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestQueryMetricQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    resetDataSource(): void;
    get dataSourceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _semanticMode?;
    get semanticMode(): string;
    set semanticMode(value: string);
    resetSemanticMode(): void;
    get semanticModeInput(): string | undefined;
}
export interface DashboardWidgetGeomapDefinitionRequestQueryProcessQuery {
    /**
    * The aggregation methods available for metrics queries. Valid values are `avg`, `min`, `max`, `sum`, `last`, `area`, `l2norm`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregator Dashboard#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#cross_org_uuids Dashboard#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for process queries. Valid values are `process`, `container`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#data_source Dashboard#data_source}
    */
    readonly dataSource: string;
    /**
    * Whether to normalize the CPU percentages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#is_normalized_cpu Dashboard#is_normalized_cpu}
    */
    readonly isNormalizedCpu?: boolean | cdktn.IResolvable;
    /**
    * The number of hits to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#limit Dashboard#limit}
    */
    readonly limit?: number;
    /**
    * The process metric name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#metric Dashboard#metric}
    */
    readonly metric: string;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#name Dashboard#name}
    */
    readonly name: string;
    /**
    * The direction of the sort. Valid values are `asc`, `desc`. Defaults to `"desc"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#sort Dashboard#sort}
    */
    readonly sort?: string;
    /**
    * An array of tags to filter by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#tag_filters Dashboard#tag_filters}
    */
    readonly tagFilters?: string[];
    /**
    * The text to use as a filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#text_filter Dashboard#text_filter}
    */
    readonly textFilter?: string;
}
export declare function dashboardWidgetGeomapDefinitionRequestQueryProcessQueryToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQueryProcessQueryOutputReference | DashboardWidgetGeomapDefinitionRequestQueryProcessQuery): any;
export declare function dashboardWidgetGeomapDefinitionRequestQueryProcessQueryToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQueryProcessQueryOutputReference | DashboardWidgetGeomapDefinitionRequestQueryProcessQuery): any;
export declare class DashboardWidgetGeomapDefinitionRequestQueryProcessQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestQueryProcessQuery | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestQueryProcessQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _isNormalizedCpu?;
    get isNormalizedCpu(): boolean | cdktn.IResolvable;
    set isNormalizedCpu(value: boolean | cdktn.IResolvable);
    resetIsNormalizedCpu(): void;
    get isNormalizedCpuInput(): boolean | cdktn.IResolvable | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _sort?;
    get sort(): string;
    set sort(value: string);
    resetSort(): void;
    get sortInput(): string | undefined;
    private _tagFilters?;
    get tagFilters(): string[];
    set tagFilters(value: string[]);
    resetTagFilters(): void;
    get tagFiltersInput(): string[] | undefined;
    private _textFilter?;
    get textFilter(): string;
    set textFilter(value: string);
    resetTextFilter(): void;
    get textFilterInput(): string | undefined;
}
export interface DashboardWidgetGeomapDefinitionRequestQuerySloQuery {
    /**
    * Additional filters applied to the SLO query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#additional_query_filters Dashboard#additional_query_filters}
    */
    readonly additionalQueryFilters?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#cross_org_uuids Dashboard#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for SLO queries. Valid values are `slo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#data_source Dashboard#data_source}
    */
    readonly dataSource: string;
    /**
    * Group mode to query measures. Valid values are `overall`, `components`. Defaults to `"overall"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#group_mode Dashboard#group_mode}
    */
    readonly groupMode?: string;
    /**
    * SLO measures queries. Valid values are `good_events`, `bad_events`, `good_minutes`, `bad_minutes`, `slo_status`, `error_budget_remaining`, `burn_rate`, `error_budget_burndown`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#measure Dashboard#measure}
    */
    readonly measure: string;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#name Dashboard#name}
    */
    readonly name?: string;
    /**
    * ID of an SLO to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#slo_id Dashboard#slo_id}
    */
    readonly sloId: string;
    /**
    * type of the SLO to query. Valid values are `metric`, `monitor`, `time_slice`. Defaults to `"metric"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#slo_query_type Dashboard#slo_query_type}
    */
    readonly sloQueryType?: string;
}
export declare function dashboardWidgetGeomapDefinitionRequestQuerySloQueryToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQuerySloQueryOutputReference | DashboardWidgetGeomapDefinitionRequestQuerySloQuery): any;
export declare function dashboardWidgetGeomapDefinitionRequestQuerySloQueryToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQuerySloQueryOutputReference | DashboardWidgetGeomapDefinitionRequestQuerySloQuery): any;
export declare class DashboardWidgetGeomapDefinitionRequestQuerySloQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestQuerySloQuery | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestQuerySloQuery | undefined);
    private _additionalQueryFilters?;
    get additionalQueryFilters(): string;
    set additionalQueryFilters(value: string);
    resetAdditionalQueryFilters(): void;
    get additionalQueryFiltersInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _groupMode?;
    get groupMode(): string;
    set groupMode(value: string);
    resetGroupMode(): void;
    get groupModeInput(): string | undefined;
    private _measure?;
    get measure(): string;
    set measure(value: string);
    get measureInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sloId?;
    get sloId(): string;
    set sloId(value: string);
    get sloIdInput(): string | undefined;
    private _sloQueryType?;
    get sloQueryType(): string;
    set sloQueryType(value: string);
    resetSloQueryType(): void;
    get sloQueryTypeInput(): string | undefined;
}
export interface DashboardWidgetGeomapDefinitionRequestQuery {
    /**
    * apm_dependency_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#apm_dependency_stats_query Dashboard#apm_dependency_stats_query}
    */
    readonly apmDependencyStatsQuery?: DashboardWidgetGeomapDefinitionRequestQueryApmDependencyStatsQuery;
    /**
    * apm_resource_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#apm_resource_stats_query Dashboard#apm_resource_stats_query}
    */
    readonly apmResourceStatsQuery?: DashboardWidgetGeomapDefinitionRequestQueryApmResourceStatsQuery;
    /**
    * cloud_cost_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#cloud_cost_query Dashboard#cloud_cost_query}
    */
    readonly cloudCostQuery?: DashboardWidgetGeomapDefinitionRequestQueryCloudCostQuery;
    /**
    * event_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#event_query Dashboard#event_query}
    */
    readonly eventQuery?: DashboardWidgetGeomapDefinitionRequestQueryEventQuery;
    /**
    * metric_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#metric_query Dashboard#metric_query}
    */
    readonly metricQuery?: DashboardWidgetGeomapDefinitionRequestQueryMetricQuery;
    /**
    * process_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#process_query Dashboard#process_query}
    */
    readonly processQuery?: DashboardWidgetGeomapDefinitionRequestQueryProcessQuery;
    /**
    * slo_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#slo_query Dashboard#slo_query}
    */
    readonly sloQuery?: DashboardWidgetGeomapDefinitionRequestQuerySloQuery;
}
export declare function dashboardWidgetGeomapDefinitionRequestQueryToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQuery | cdktn.IResolvable): any;
export declare function dashboardWidgetGeomapDefinitionRequestQueryToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestQuery | cdktn.IResolvable): any;
export declare class DashboardWidgetGeomapDefinitionRequestQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestQuery | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestQuery | cdktn.IResolvable | undefined);
    private _apmDependencyStatsQuery;
    get apmDependencyStatsQuery(): DashboardWidgetGeomapDefinitionRequestQueryApmDependencyStatsQueryOutputReference;
    putApmDependencyStatsQuery(value: DashboardWidgetGeomapDefinitionRequestQueryApmDependencyStatsQuery): void;
    resetApmDependencyStatsQuery(): void;
    get apmDependencyStatsQueryInput(): DashboardWidgetGeomapDefinitionRequestQueryApmDependencyStatsQuery | undefined;
    private _apmResourceStatsQuery;
    get apmResourceStatsQuery(): DashboardWidgetGeomapDefinitionRequestQueryApmResourceStatsQueryOutputReference;
    putApmResourceStatsQuery(value: DashboardWidgetGeomapDefinitionRequestQueryApmResourceStatsQuery): void;
    resetApmResourceStatsQuery(): void;
    get apmResourceStatsQueryInput(): DashboardWidgetGeomapDefinitionRequestQueryApmResourceStatsQuery | undefined;
    private _cloudCostQuery;
    get cloudCostQuery(): DashboardWidgetGeomapDefinitionRequestQueryCloudCostQueryOutputReference;
    putCloudCostQuery(value: DashboardWidgetGeomapDefinitionRequestQueryCloudCostQuery): void;
    resetCloudCostQuery(): void;
    get cloudCostQueryInput(): DashboardWidgetGeomapDefinitionRequestQueryCloudCostQuery | undefined;
    private _eventQuery;
    get eventQuery(): DashboardWidgetGeomapDefinitionRequestQueryEventQueryOutputReference;
    putEventQuery(value: DashboardWidgetGeomapDefinitionRequestQueryEventQuery): void;
    resetEventQuery(): void;
    get eventQueryInput(): DashboardWidgetGeomapDefinitionRequestQueryEventQuery | undefined;
    private _metricQuery;
    get metricQuery(): DashboardWidgetGeomapDefinitionRequestQueryMetricQueryOutputReference;
    putMetricQuery(value: DashboardWidgetGeomapDefinitionRequestQueryMetricQuery): void;
    resetMetricQuery(): void;
    get metricQueryInput(): DashboardWidgetGeomapDefinitionRequestQueryMetricQuery | undefined;
    private _processQuery;
    get processQuery(): DashboardWidgetGeomapDefinitionRequestQueryProcessQueryOutputReference;
    putProcessQuery(value: DashboardWidgetGeomapDefinitionRequestQueryProcessQuery): void;
    resetProcessQuery(): void;
    get processQueryInput(): DashboardWidgetGeomapDefinitionRequestQueryProcessQuery | undefined;
    private _sloQuery;
    get sloQuery(): DashboardWidgetGeomapDefinitionRequestQuerySloQueryOutputReference;
    putSloQuery(value: DashboardWidgetGeomapDefinitionRequestQuerySloQuery): void;
    resetSloQuery(): void;
    get sloQueryInput(): DashboardWidgetGeomapDefinitionRequestQuerySloQuery | undefined;
}
export declare class DashboardWidgetGeomapDefinitionRequestQueryList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetGeomapDefinitionRequestQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetGeomapDefinitionRequestQueryOutputReference;
}
export interface DashboardWidgetGeomapDefinitionRequestRumQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: number;
}
export declare function dashboardWidgetGeomapDefinitionRequestRumQueryComputeQueryToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestRumQueryComputeQueryOutputReference | DashboardWidgetGeomapDefinitionRequestRumQueryComputeQuery): any;
export declare function dashboardWidgetGeomapDefinitionRequestRumQueryComputeQueryToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestRumQueryComputeQueryOutputReference | DashboardWidgetGeomapDefinitionRequestRumQueryComputeQuery): any;
export declare class DashboardWidgetGeomapDefinitionRequestRumQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestRumQueryComputeQuery | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestRumQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface DashboardWidgetGeomapDefinitionRequestRumQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#order Dashboard#order}
    */
    readonly order: string;
}
export declare function dashboardWidgetGeomapDefinitionRequestRumQueryGroupBySortQueryToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestRumQueryGroupBySortQueryOutputReference | DashboardWidgetGeomapDefinitionRequestRumQueryGroupBySortQuery): any;
export declare function dashboardWidgetGeomapDefinitionRequestRumQueryGroupBySortQueryToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestRumQueryGroupBySortQueryOutputReference | DashboardWidgetGeomapDefinitionRequestRumQueryGroupBySortQuery): any;
export declare class DashboardWidgetGeomapDefinitionRequestRumQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestRumQueryGroupBySortQuery | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestRumQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface DashboardWidgetGeomapDefinitionRequestRumQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#limit Dashboard#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#sort_query Dashboard#sort_query}
    */
    readonly sortQuery?: DashboardWidgetGeomapDefinitionRequestRumQueryGroupBySortQuery;
}
export declare function dashboardWidgetGeomapDefinitionRequestRumQueryGroupByToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestRumQueryGroupBy | cdktn.IResolvable): any;
export declare function dashboardWidgetGeomapDefinitionRequestRumQueryGroupByToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestRumQueryGroupBy | cdktn.IResolvable): any;
export declare class DashboardWidgetGeomapDefinitionRequestRumQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestRumQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestRumQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): DashboardWidgetGeomapDefinitionRequestRumQueryGroupBySortQueryOutputReference;
    putSortQuery(value: DashboardWidgetGeomapDefinitionRequestRumQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): DashboardWidgetGeomapDefinitionRequestRumQueryGroupBySortQuery | undefined;
}
export declare class DashboardWidgetGeomapDefinitionRequestRumQueryGroupByList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetGeomapDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetGeomapDefinitionRequestRumQueryGroupByOutputReference;
}
export interface DashboardWidgetGeomapDefinitionRequestRumQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#aggregation Dashboard#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#facet Dashboard#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#interval Dashboard#interval}
    */
    readonly interval?: number;
}
export declare function dashboardWidgetGeomapDefinitionRequestRumQueryMultiComputeToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable): any;
export declare function dashboardWidgetGeomapDefinitionRequestRumQueryMultiComputeToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable): any;
export declare class DashboardWidgetGeomapDefinitionRequestRumQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class DashboardWidgetGeomapDefinitionRequestRumQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetGeomapDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetGeomapDefinitionRequestRumQueryMultiComputeOutputReference;
}
export interface DashboardWidgetGeomapDefinitionRequestRumQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#index Dashboard#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#search_query Dashboard#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#compute_query Dashboard#compute_query}
    */
    readonly computeQuery?: DashboardWidgetGeomapDefinitionRequestRumQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#group_by Dashboard#group_by}
    */
    readonly groupBy?: DashboardWidgetGeomapDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#multi_compute Dashboard#multi_compute}
    */
    readonly multiCompute?: DashboardWidgetGeomapDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function dashboardWidgetGeomapDefinitionRequestRumQueryToTerraform(struct?: DashboardWidgetGeomapDefinitionRequestRumQueryOutputReference | DashboardWidgetGeomapDefinitionRequestRumQuery): any;
export declare function dashboardWidgetGeomapDefinitionRequestRumQueryToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequestRumQueryOutputReference | DashboardWidgetGeomapDefinitionRequestRumQuery): any;
export declare class DashboardWidgetGeomapDefinitionRequestRumQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionRequestRumQuery | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequestRumQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): DashboardWidgetGeomapDefinitionRequestRumQueryComputeQueryOutputReference;
    putComputeQuery(value: DashboardWidgetGeomapDefinitionRequestRumQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): DashboardWidgetGeomapDefinitionRequestRumQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): DashboardWidgetGeomapDefinitionRequestRumQueryGroupByList;
    putGroupBy(value: DashboardWidgetGeomapDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | DashboardWidgetGeomapDefinitionRequestRumQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): DashboardWidgetGeomapDefinitionRequestRumQueryMultiComputeList;
    putMultiCompute(value: DashboardWidgetGeomapDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | DashboardWidgetGeomapDefinitionRequestRumQueryMultiCompute[] | undefined;
}
export interface DashboardWidgetGeomapDefinitionRequest {
    /**
    * The metric query to use for this widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#q Dashboard#q}
    */
    readonly q?: string;
    /**
    * formula block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#formula Dashboard#formula}
    */
    readonly formula?: DashboardWidgetGeomapDefinitionRequestFormula[] | cdktn.IResolvable;
    /**
    * log_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#log_query Dashboard#log_query}
    */
    readonly logQuery?: DashboardWidgetGeomapDefinitionRequestLogQuery;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#query Dashboard#query}
    */
    readonly query?: DashboardWidgetGeomapDefinitionRequestQuery[] | cdktn.IResolvable;
    /**
    * rum_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#rum_query Dashboard#rum_query}
    */
    readonly rumQuery?: DashboardWidgetGeomapDefinitionRequestRumQuery;
}
export declare function dashboardWidgetGeomapDefinitionRequestToTerraform(struct?: DashboardWidgetGeomapDefinitionRequest | cdktn.IResolvable): any;
export declare function dashboardWidgetGeomapDefinitionRequestToHclTerraform(struct?: DashboardWidgetGeomapDefinitionRequest | cdktn.IResolvable): any;
export declare class DashboardWidgetGeomapDefinitionRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DashboardWidgetGeomapDefinitionRequest | cdktn.IResolvable | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionRequest | cdktn.IResolvable | undefined);
    private _q?;
    get q(): string;
    set q(value: string);
    resetQ(): void;
    get qInput(): string | undefined;
    private _formula;
    get formula(): DashboardWidgetGeomapDefinitionRequestFormulaList;
    putFormula(value: DashboardWidgetGeomapDefinitionRequestFormula[] | cdktn.IResolvable): void;
    resetFormula(): void;
    get formulaInput(): cdktn.IResolvable | DashboardWidgetGeomapDefinitionRequestFormula[] | undefined;
    private _logQuery;
    get logQuery(): DashboardWidgetGeomapDefinitionRequestLogQueryOutputReference;
    putLogQuery(value: DashboardWidgetGeomapDefinitionRequestLogQuery): void;
    resetLogQuery(): void;
    get logQueryInput(): DashboardWidgetGeomapDefinitionRequestLogQuery | undefined;
    private _query;
    get query(): DashboardWidgetGeomapDefinitionRequestQueryList;
    putQuery(value: DashboardWidgetGeomapDefinitionRequestQuery[] | cdktn.IResolvable): void;
    resetQuery(): void;
    get queryInput(): cdktn.IResolvable | DashboardWidgetGeomapDefinitionRequestQuery[] | undefined;
    private _rumQuery;
    get rumQuery(): DashboardWidgetGeomapDefinitionRequestRumQueryOutputReference;
    putRumQuery(value: DashboardWidgetGeomapDefinitionRequestRumQuery): void;
    resetRumQuery(): void;
    get rumQueryInput(): DashboardWidgetGeomapDefinitionRequestRumQuery | undefined;
}
export declare class DashboardWidgetGeomapDefinitionRequestList extends cdktn.ComplexList {
    internalValue?: DashboardWidgetGeomapDefinitionRequest[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DashboardWidgetGeomapDefinitionRequestOutputReference;
}
export interface DashboardWidgetGeomapDefinitionStyle {
    /**
    * The color palette to apply to the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#palette Dashboard#palette}
    */
    readonly palette: string;
    /**
    * A Boolean indicating whether to flip the palette tones.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#palette_flip Dashboard#palette_flip}
    */
    readonly paletteFlip: boolean | cdktn.IResolvable;
}
export declare function dashboardWidgetGeomapDefinitionStyleToTerraform(struct?: DashboardWidgetGeomapDefinitionStyleOutputReference | DashboardWidgetGeomapDefinitionStyle): any;
export declare function dashboardWidgetGeomapDefinitionStyleToHclTerraform(struct?: DashboardWidgetGeomapDefinitionStyleOutputReference | DashboardWidgetGeomapDefinitionStyle): any;
export declare class DashboardWidgetGeomapDefinitionStyleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionStyle | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionStyle | undefined);
    private _palette?;
    get palette(): string;
    set palette(value: string);
    get paletteInput(): string | undefined;
    private _paletteFlip?;
    get paletteFlip(): boolean | cdktn.IResolvable;
    set paletteFlip(value: boolean | cdktn.IResolvable);
    get paletteFlipInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DashboardWidgetGeomapDefinitionView {
    /**
    * The two-letter ISO code of a country to focus the map on (or `WORLD`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#focus Dashboard#focus}
    */
    readonly focus: string;
}
export declare function dashboardWidgetGeomapDefinitionViewToTerraform(struct?: DashboardWidgetGeomapDefinitionViewOutputReference | DashboardWidgetGeomapDefinitionView): any;
export declare function dashboardWidgetGeomapDefinitionViewToHclTerraform(struct?: DashboardWidgetGeomapDefinitionViewOutputReference | DashboardWidgetGeomapDefinitionView): any;
export declare class DashboardWidgetGeomapDefinitionViewOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinitionView | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinitionView | undefined);
    private _focus?;
    get focus(): string;
    set focus(value: string);
    get focusInput(): string | undefined;
}
export interface DashboardWidgetGeomapDefinition {
    /**
    * Hide any portion of the widget's timeframe that is incomplete due to cost data not being available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#hide_incomplete_cost_data Dashboard#hide_incomplete_cost_data}
    */
    readonly hideIncompleteCostData?: boolean | cdktn.IResolvable;
    /**
    * The timeframe to use when displaying the widget. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#live_span Dashboard#live_span}
    */
    readonly liveSpan?: string;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title Dashboard#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title_align Dashboard#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title_size Dashboard#title_size}
    */
    readonly titleSize?: string;
    /**
    * custom_link block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#custom_link Dashboard#custom_link}
    */
    readonly customLink?: DashboardWidgetGeomapDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#request Dashboard#request}
    */
    readonly request?: DashboardWidgetGeomapDefinitionRequest[] | cdktn.IResolvable;
    /**
    * style block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#style Dashboard#style}
    */
    readonly style?: DashboardWidgetGeomapDefinitionStyle;
    /**
    * view block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#view Dashboard#view}
    */
    readonly view: DashboardWidgetGeomapDefinitionView;
}
export declare function dashboardWidgetGeomapDefinitionToTerraform(struct?: DashboardWidgetGeomapDefinitionOutputReference | DashboardWidgetGeomapDefinition): any;
export declare function dashboardWidgetGeomapDefinitionToHclTerraform(struct?: DashboardWidgetGeomapDefinitionOutputReference | DashboardWidgetGeomapDefinition): any;
export declare class DashboardWidgetGeomapDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGeomapDefinition | undefined;
    set internalValue(value: DashboardWidgetGeomapDefinition | undefined);
    private _hideIncompleteCostData?;
    get hideIncompleteCostData(): boolean | cdktn.IResolvable;
    set hideIncompleteCostData(value: boolean | cdktn.IResolvable);
    resetHideIncompleteCostData(): void;
    get hideIncompleteCostDataInput(): boolean | cdktn.IResolvable | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _customLink;
    get customLink(): DashboardWidgetGeomapDefinitionCustomLinkList;
    putCustomLink(value: DashboardWidgetGeomapDefinitionCustomLink[] | cdktn.IResolvable): void;
    resetCustomLink(): void;
    get customLinkInput(): cdktn.IResolvable | DashboardWidgetGeomapDefinitionCustomLink[] | undefined;
    private _request;
    get request(): DashboardWidgetGeomapDefinitionRequestList;
    putRequest(value: DashboardWidgetGeomapDefinitionRequest[] | cdktn.IResolvable): void;
    resetRequest(): void;
    get requestInput(): cdktn.IResolvable | DashboardWidgetGeomapDefinitionRequest[] | undefined;
    private _style;
    get style(): DashboardWidgetGeomapDefinitionStyleOutputReference;
    putStyle(value: DashboardWidgetGeomapDefinitionStyle): void;
    resetStyle(): void;
    get styleInput(): DashboardWidgetGeomapDefinitionStyle | undefined;
    private _view;
    get view(): DashboardWidgetGeomapDefinitionViewOutputReference;
    putView(value: DashboardWidgetGeomapDefinitionView): void;
    get viewInput(): DashboardWidgetGeomapDefinitionView | undefined;
}
export interface DashboardWidgetGroupDefinitionWidgetAlertGraphDefinition {
    /**
    * The ID of the monitor used by the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#alert_id Dashboard#alert_id}
    */
    readonly alertId: string;
    /**
    * Hide any portion of the widget's timeframe that is incomplete due to cost data not being available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#hide_incomplete_cost_data Dashboard#hide_incomplete_cost_data}
    */
    readonly hideIncompleteCostData?: boolean | cdktn.IResolvable;
    /**
    * The timeframe to use when displaying the widget. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#live_span Dashboard#live_span}
    */
    readonly liveSpan?: string;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title Dashboard#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title_align Dashboard#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title_size Dashboard#title_size}
    */
    readonly titleSize?: string;
    /**
    * Type of visualization to use when displaying the widget. Valid values are `timeseries`, `toplist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#viz_type Dashboard#viz_type}
    */
    readonly vizType: string;
}
export declare function dashboardWidgetGroupDefinitionWidgetAlertGraphDefinitionToTerraform(struct?: DashboardWidgetGroupDefinitionWidgetAlertGraphDefinitionOutputReference | DashboardWidgetGroupDefinitionWidgetAlertGraphDefinition): any;
export declare function dashboardWidgetGroupDefinitionWidgetAlertGraphDefinitionToHclTerraform(struct?: DashboardWidgetGroupDefinitionWidgetAlertGraphDefinitionOutputReference | DashboardWidgetGroupDefinitionWidgetAlertGraphDefinition): any;
export declare class DashboardWidgetGroupDefinitionWidgetAlertGraphDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGroupDefinitionWidgetAlertGraphDefinition | undefined;
    set internalValue(value: DashboardWidgetGroupDefinitionWidgetAlertGraphDefinition | undefined);
    private _alertId?;
    get alertId(): string;
    set alertId(value: string);
    get alertIdInput(): string | undefined;
    private _hideIncompleteCostData?;
    get hideIncompleteCostData(): boolean | cdktn.IResolvable;
    set hideIncompleteCostData(value: boolean | cdktn.IResolvable);
    resetHideIncompleteCostData(): void;
    get hideIncompleteCostDataInput(): boolean | cdktn.IResolvable | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _vizType?;
    get vizType(): string;
    set vizType(value: string);
    get vizTypeInput(): string | undefined;
}
export interface DashboardWidgetGroupDefinitionWidgetAlertValueDefinition {
    /**
    * The ID of the monitor used by the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#alert_id Dashboard#alert_id}
    */
    readonly alertId: string;
    /**
    * The precision to use when displaying the value. Use `*` for maximum precision.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#precision Dashboard#precision}
    */
    readonly precision?: number;
    /**
    * The alignment of the text in the widget. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#text_align Dashboard#text_align}
    */
    readonly textAlign?: string;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title Dashboard#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title_align Dashboard#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#title_size Dashboard#title_size}
    */
    readonly titleSize?: string;
    /**
    * The unit for the value displayed in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/dashboard#unit Dashboard#unit}
    */
    readonly unit?: string;
}
export declare function dashboardWidgetGroupDefinitionWidgetAlertValueDefinitionToTerraform(struct?: DashboardWidgetGroupDefinitionWidgetAlertValueDefinitionOutputReference | DashboardWidgetGroupDefinitionWidgetAlertValueDefinition): any;
export declare function dashboardWidgetGroupDefinitionWidgetAlertValueDefinitionToHclTerraform(struct?: DashboardWidgetGroupDefinitionWidgetAlertValueDefinitionOutputReference | DashboardWidgetGroupDefinitionWidgetAlertValueDefinition): any;
export declare class DashboardWidgetGroupDefinitionWidgetAlertValueDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardWidgetGroupDefinitionWidgetAlertValueDefinition | undefined;
    set internalValue(value: DashboardWidgetGroupDefinitionWidgetAlertValueDefinition | undefined);
    private _alertId?;
    get alertId(): string;
    set alertId(value: string);
    get alertIdInput(): string | undefined;
    private _precision?;
    get precision(): number;
    set precision(value: number);
    resetPrecision(): void;
    get precisionInput(): number | undefined;
    private _textAlign?;
    get textAlign(): string;
    set textAlign(value: string);
    resetTextAlign(): void;
    get textAlignInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
