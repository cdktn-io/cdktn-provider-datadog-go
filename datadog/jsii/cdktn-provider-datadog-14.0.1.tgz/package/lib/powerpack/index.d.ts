/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { PowerpackLayout, PowerpackLayoutOutputReference, PowerpackTemplateVariables, PowerpackTemplateVariablesList, PowerpackWidget, PowerpackWidgetList } from './index-structs';
export * from './index-structs';
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PowerpackConfig extends cdktn.TerraformMetaArguments {
    /**
    * The description of the powerpack.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#description Powerpack#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#id Powerpack#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The timeframe to use when displaying the powerpack. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#live_span Powerpack#live_span}
    */
    readonly liveSpan?: string;
    /**
    * The name for the powerpack.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name?: string;
    /**
    * Whether or not title should be displayed in the powerpack.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#show_title Powerpack#show_title}
    */
    readonly showTitle?: boolean | cdktn.IResolvable;
    /**
    * List of tags to identify this powerpack.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#tags Powerpack#tags}
    */
    readonly tags?: string[];
    /**
    * layout block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#layout Powerpack#layout}
    */
    readonly layout?: PowerpackLayout;
    /**
    * template_variables block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#template_variables Powerpack#template_variables}
    */
    readonly templateVariables?: PowerpackTemplateVariables[] | cdktn.IResolvable;
    /**
    * widget block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#widget Powerpack#widget}
    */
    readonly widget?: PowerpackWidget[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack datadog_powerpack}
*/
export declare class Powerpack extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_powerpack";
    /**
    * Generates CDKTN code for importing a Powerpack resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Powerpack to import
    * @param importFromId The id of the existing Powerpack that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Powerpack to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack datadog_powerpack} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PowerpackConfig = {}
    */
    constructor(scope: Construct, id: string, config?: PowerpackConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _showTitle?;
    get showTitle(): boolean | cdktn.IResolvable;
    set showTitle(value: boolean | cdktn.IResolvable);
    resetShowTitle(): void;
    get showTitleInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _layout;
    get layout(): PowerpackLayoutOutputReference;
    putLayout(value: PowerpackLayout): void;
    resetLayout(): void;
    get layoutInput(): PowerpackLayout | undefined;
    private _templateVariables;
    get templateVariables(): PowerpackTemplateVariablesList;
    putTemplateVariables(value: PowerpackTemplateVariables[] | cdktn.IResolvable): void;
    resetTemplateVariables(): void;
    get templateVariablesInput(): cdktn.IResolvable | PowerpackTemplateVariables[] | undefined;
    private _widget;
    get widget(): PowerpackWidgetList;
    putWidget(value: PowerpackWidget[] | cdktn.IResolvable): void;
    resetWidget(): void;
    get widgetInput(): cdktn.IResolvable | PowerpackWidget[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
