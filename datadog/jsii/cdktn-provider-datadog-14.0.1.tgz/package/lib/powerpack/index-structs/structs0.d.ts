/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
export interface PowerpackLayout {
    /**
    * The height of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#height Powerpack#height}
    */
    readonly height?: number;
    /**
    * The width of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#width Powerpack#width}
    */
    readonly width?: number;
    /**
    * The position of the widget on the x (horizontal) axis. Should be greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#x Powerpack#x}
    */
    readonly x?: number;
    /**
    * The position of the widget on the y (vertical) axis. Should be greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#y Powerpack#y}
    */
    readonly y?: number;
}
export declare function powerpackLayoutToTerraform(struct?: PowerpackLayoutOutputReference | PowerpackLayout): any;
export declare function powerpackLayoutToHclTerraform(struct?: PowerpackLayoutOutputReference | PowerpackLayout): any;
export declare class PowerpackLayoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackLayout | undefined;
    set internalValue(value: PowerpackLayout | undefined);
    private _height?;
    get height(): number;
    set height(value: number);
    resetHeight(): void;
    get heightInput(): number | undefined;
    private _width?;
    get width(): number;
    set width(value: number);
    resetWidth(): void;
    get widthInput(): number | undefined;
    private _x?;
    get x(): number;
    set x(value: number);
    resetX(): void;
    get xInput(): number | undefined;
    private _y?;
    get y(): number;
    set y(value: number);
    resetY(): void;
    get yInput(): number | undefined;
}
export interface PowerpackTemplateVariables {
    /**
    * One or many default values for powerpack template variables on load. If more than one default is specified, they will be unioned together with `OR`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#defaults Powerpack#defaults}
    */
    readonly defaults?: string[];
    /**
    * The name of the powerpack template variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
}
export declare function powerpackTemplateVariablesToTerraform(struct?: PowerpackTemplateVariables | cdktn.IResolvable): any;
export declare function powerpackTemplateVariablesToHclTerraform(struct?: PowerpackTemplateVariables | cdktn.IResolvable): any;
export declare class PowerpackTemplateVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackTemplateVariables | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackTemplateVariables | cdktn.IResolvable | undefined);
    private _defaults?;
    get defaults(): string[];
    set defaults(value: string[]);
    resetDefaults(): void;
    get defaultsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class PowerpackTemplateVariablesList extends cdktn.ComplexList {
    internalValue?: PowerpackTemplateVariables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackTemplateVariablesOutputReference;
}
export interface PowerpackWidgetAlertGraphDefinition {
    /**
    * The ID of the monitor used by the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#alert_id Powerpack#alert_id}
    */
    readonly alertId: string;
    /**
    * Hide any portion of the widget's timeframe that is incomplete due to cost data not being available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_incomplete_cost_data Powerpack#hide_incomplete_cost_data}
    */
    readonly hideIncompleteCostData?: boolean | cdktn.IResolvable;
    /**
    * The timeframe to use when displaying the widget. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#live_span Powerpack#live_span}
    */
    readonly liveSpan?: string;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title Powerpack#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_align Powerpack#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_size Powerpack#title_size}
    */
    readonly titleSize?: string;
    /**
    * Type of visualization to use when displaying the widget. Valid values are `timeseries`, `toplist`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#viz_type Powerpack#viz_type}
    */
    readonly vizType: string;
}
export declare function powerpackWidgetAlertGraphDefinitionToTerraform(struct?: PowerpackWidgetAlertGraphDefinitionOutputReference | PowerpackWidgetAlertGraphDefinition): any;
export declare function powerpackWidgetAlertGraphDefinitionToHclTerraform(struct?: PowerpackWidgetAlertGraphDefinitionOutputReference | PowerpackWidgetAlertGraphDefinition): any;
export declare class PowerpackWidgetAlertGraphDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetAlertGraphDefinition | undefined;
    set internalValue(value: PowerpackWidgetAlertGraphDefinition | undefined);
    private _alertId?;
    get alertId(): string;
    set alertId(value: string);
    get alertIdInput(): string | undefined;
    private _hideIncompleteCostData?;
    get hideIncompleteCostData(): boolean | cdktn.IResolvable;
    set hideIncompleteCostData(value: boolean | cdktn.IResolvable);
    resetHideIncompleteCostData(): void;
    get hideIncompleteCostDataInput(): boolean | cdktn.IResolvable | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _vizType?;
    get vizType(): string;
    set vizType(value: string);
    get vizTypeInput(): string | undefined;
}
export interface PowerpackWidgetAlertValueDefinition {
    /**
    * The ID of the monitor used by the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#alert_id Powerpack#alert_id}
    */
    readonly alertId: string;
    /**
    * The precision to use when displaying the value. Use `*` for maximum precision.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#precision Powerpack#precision}
    */
    readonly precision?: number;
    /**
    * The alignment of the text in the widget. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#text_align Powerpack#text_align}
    */
    readonly textAlign?: string;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title Powerpack#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_align Powerpack#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_size Powerpack#title_size}
    */
    readonly titleSize?: string;
    /**
    * The unit for the value displayed in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit Powerpack#unit}
    */
    readonly unit?: string;
}
export declare function powerpackWidgetAlertValueDefinitionToTerraform(struct?: PowerpackWidgetAlertValueDefinitionOutputReference | PowerpackWidgetAlertValueDefinition): any;
export declare function powerpackWidgetAlertValueDefinitionToHclTerraform(struct?: PowerpackWidgetAlertValueDefinitionOutputReference | PowerpackWidgetAlertValueDefinition): any;
export declare class PowerpackWidgetAlertValueDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetAlertValueDefinition | undefined;
    set internalValue(value: PowerpackWidgetAlertValueDefinition | undefined);
    private _alertId?;
    get alertId(): string;
    set alertId(value: string);
    get alertIdInput(): string | undefined;
    private _precision?;
    get precision(): number;
    set precision(value: number);
    resetPrecision(): void;
    get precisionInput(): number | undefined;
    private _textAlign?;
    get textAlign(): string;
    set textAlign(value: string);
    resetTextAlign(): void;
    get textAlignInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export interface PowerpackWidgetChangeDefinitionCustomLink {
    /**
    * The flag for toggling context menu link visibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_hidden Powerpack#is_hidden}
    */
    readonly isHidden?: boolean | cdktn.IResolvable;
    /**
    * The label for the custom link URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label?: string;
    /**
    * The URL of the custom link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#link Powerpack#link}
    */
    readonly link?: string;
    /**
    * The label ID that refers to a context menu link item. When `override_label` is provided, the client request omits the label field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#override_label Powerpack#override_label}
    */
    readonly overrideLabel?: string;
}
export declare function powerpackWidgetChangeDefinitionCustomLinkToTerraform(struct?: PowerpackWidgetChangeDefinitionCustomLink | cdktn.IResolvable): any;
export declare function powerpackWidgetChangeDefinitionCustomLinkToHclTerraform(struct?: PowerpackWidgetChangeDefinitionCustomLink | cdktn.IResolvable): any;
export declare class PowerpackWidgetChangeDefinitionCustomLinkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetChangeDefinitionCustomLink | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionCustomLink | cdktn.IResolvable | undefined);
    private _isHidden?;
    get isHidden(): boolean | cdktn.IResolvable;
    set isHidden(value: boolean | cdktn.IResolvable);
    resetIsHidden(): void;
    get isHiddenInput(): boolean | cdktn.IResolvable | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _link?;
    get link(): string;
    set link(value: string);
    resetLink(): void;
    get linkInput(): string | undefined;
    private _overrideLabel?;
    get overrideLabel(): string;
    set overrideLabel(value: string);
    resetOverrideLabel(): void;
    get overrideLabelInput(): string | undefined;
}
export declare class PowerpackWidgetChangeDefinitionCustomLinkList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetChangeDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetChangeDefinitionCustomLinkOutputReference;
}
export interface PowerpackWidgetChangeDefinitionRequestApmQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetChangeDefinitionRequestApmQueryComputeQueryToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestApmQueryComputeQueryOutputReference | PowerpackWidgetChangeDefinitionRequestApmQueryComputeQuery): any;
export declare function powerpackWidgetChangeDefinitionRequestApmQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestApmQueryComputeQueryOutputReference | PowerpackWidgetChangeDefinitionRequestApmQueryComputeQuery): any;
export declare class PowerpackWidgetChangeDefinitionRequestApmQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestApmQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestApmQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestApmQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetChangeDefinitionRequestApmQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestApmQueryGroupBySortQueryOutputReference | PowerpackWidgetChangeDefinitionRequestApmQueryGroupBySortQuery): any;
export declare function powerpackWidgetChangeDefinitionRequestApmQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestApmQueryGroupBySortQueryOutputReference | PowerpackWidgetChangeDefinitionRequestApmQueryGroupBySortQuery): any;
export declare class PowerpackWidgetChangeDefinitionRequestApmQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestApmQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestApmQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestApmQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetChangeDefinitionRequestApmQueryGroupBySortQuery;
}
export declare function powerpackWidgetChangeDefinitionRequestApmQueryGroupByToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestApmQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetChangeDefinitionRequestApmQueryGroupByToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestApmQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetChangeDefinitionRequestApmQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestApmQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestApmQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetChangeDefinitionRequestApmQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetChangeDefinitionRequestApmQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetChangeDefinitionRequestApmQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetChangeDefinitionRequestApmQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetChangeDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetChangeDefinitionRequestApmQueryGroupByOutputReference;
}
export interface PowerpackWidgetChangeDefinitionRequestApmQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetChangeDefinitionRequestApmQueryMultiComputeToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetChangeDefinitionRequestApmQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetChangeDefinitionRequestApmQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetChangeDefinitionRequestApmQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetChangeDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetChangeDefinitionRequestApmQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetChangeDefinitionRequestApmQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetChangeDefinitionRequestApmQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetChangeDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetChangeDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetChangeDefinitionRequestApmQueryToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestApmQueryOutputReference | PowerpackWidgetChangeDefinitionRequestApmQuery): any;
export declare function powerpackWidgetChangeDefinitionRequestApmQueryToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestApmQueryOutputReference | PowerpackWidgetChangeDefinitionRequestApmQuery): any;
export declare class PowerpackWidgetChangeDefinitionRequestApmQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestApmQuery | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestApmQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetChangeDefinitionRequestApmQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetChangeDefinitionRequestApmQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetChangeDefinitionRequestApmQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetChangeDefinitionRequestApmQueryGroupByList;
    putGroupBy(value: PowerpackWidgetChangeDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetChangeDefinitionRequestApmQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetChangeDefinitionRequestApmQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetChangeDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetChangeDefinitionRequestApmQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestFormulaConditionalFormats {
    /**
    * The comparator to use. Valid values are `=`, `>`, `>=`, `<`, `<=`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#comparator Powerpack#comparator}
    */
    readonly comparator: string;
    /**
    * The color palette to apply to the background, same values available as palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_bg_color Powerpack#custom_bg_color}
    */
    readonly customBgColor?: string;
    /**
    * The color palette to apply to the foreground, same values available as palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_fg_color Powerpack#custom_fg_color}
    */
    readonly customFgColor?: string;
    /**
    * Setting this to True hides values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_value Powerpack#hide_value}
    */
    readonly hideValue?: boolean | cdktn.IResolvable;
    /**
    * Displays an image as the background.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#image_url Powerpack#image_url}
    */
    readonly imageUrl?: string;
    /**
    * The metric from the request to correlate with this conditional format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
    /**
    * The color palette to apply. Valid values are `blue`, `custom_bg`, `custom_image`, `custom_text`, `gray_on_white`, `grey`, `green`, `orange`, `red`, `red_on_white`, `white_on_gray`, `white_on_green`, `green_on_white`, `white_on_red`, `white_on_yellow`, `yellow_on_white`, `black_on_light_yellow`, `black_on_light_green`, `black_on_light_red`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette Powerpack#palette}
    */
    readonly palette: string;
    /**
    * Defines the displayed timeframe.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#timeframe Powerpack#timeframe}
    */
    readonly timeframe?: string;
    /**
    * A value for the comparator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#value Powerpack#value}
    */
    readonly value: number;
}
export declare function powerpackWidgetChangeDefinitionRequestFormulaConditionalFormatsToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable): any;
export declare function powerpackWidgetChangeDefinitionRequestFormulaConditionalFormatsToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable): any;
export declare class PowerpackWidgetChangeDefinitionRequestFormulaConditionalFormatsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable | undefined);
    private _comparator?;
    get comparator(): string;
    set comparator(value: string);
    get comparatorInput(): string | undefined;
    private _customBgColor?;
    get customBgColor(): string;
    set customBgColor(value: string);
    resetCustomBgColor(): void;
    get customBgColorInput(): string | undefined;
    private _customFgColor?;
    get customFgColor(): string;
    set customFgColor(value: string);
    resetCustomFgColor(): void;
    get customFgColorInput(): string | undefined;
    private _hideValue?;
    get hideValue(): boolean | cdktn.IResolvable;
    set hideValue(value: boolean | cdktn.IResolvable);
    resetHideValue(): void;
    get hideValueInput(): boolean | cdktn.IResolvable | undefined;
    private _imageUrl?;
    get imageUrl(): string;
    set imageUrl(value: string);
    resetImageUrl(): void;
    get imageUrlInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _palette?;
    get palette(): string;
    set palette(value: string);
    get paletteInput(): string | undefined;
    private _timeframe?;
    get timeframe(): string;
    set timeframe(value: string);
    resetTimeframe(): void;
    get timeframeInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class PowerpackWidgetChangeDefinitionRequestFormulaConditionalFormatsList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetChangeDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetChangeDefinitionRequestFormulaConditionalFormatsOutputReference;
}
export interface PowerpackWidgetChangeDefinitionRequestFormulaLimit {
    /**
    * The number of results to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#count Powerpack#count}
    */
    readonly count?: number;
    /**
    * The direction of the sort. Valid values are `asc`, `desc`. Defaults to `"desc"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order?: string;
}
export declare function powerpackWidgetChangeDefinitionRequestFormulaLimitToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestFormulaLimitOutputReference | PowerpackWidgetChangeDefinitionRequestFormulaLimit): any;
export declare function powerpackWidgetChangeDefinitionRequestFormulaLimitToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestFormulaLimitOutputReference | PowerpackWidgetChangeDefinitionRequestFormulaLimit): any;
export declare class PowerpackWidgetChangeDefinitionRequestFormulaLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestFormulaLimit | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestFormulaLimit | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    resetCount(): void;
    get countInput(): number | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonical {
    /**
    * per unit name. If you want to represent megabytes/s, you set 'unit_name' = 'megabyte' and 'per_unit_name = 'second'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#per_unit_name Powerpack#per_unit_name}
    */
    readonly perUnitName?: string;
    /**
    * Unit name. It should be in singular form ('megabyte' and not 'megabytes')
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit_name Powerpack#unit_name}
    */
    readonly unitName: string;
}
export declare function powerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonicalToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference | PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonical): any;
export declare function powerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonicalToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference | PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonical): any;
export declare class PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonical | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonical | undefined);
    private _perUnitName?;
    get perUnitName(): string;
    set perUnitName(value: string);
    resetPerUnitName(): void;
    get perUnitNameInput(): string | undefined;
    private _unitName?;
    get unitName(): string;
    set unitName(value: string);
    get unitNameInput(): string | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustom {
    /**
    * Unit label
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label: string;
}
export declare function powerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustomToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustomOutputReference | PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustom): any;
export declare function powerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustomToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustomOutputReference | PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustom): any;
export declare class PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustom | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustom | undefined);
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnit {
    /**
    * canonical block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#canonical Powerpack#canonical}
    */
    readonly canonical?: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonical;
    /**
    * custom block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom Powerpack#custom}
    */
    readonly custom?: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustom;
}
export declare function powerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitOutputReference | PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnit): any;
export declare function powerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitOutputReference | PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnit): any;
export declare class PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnit | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnit | undefined);
    private _canonical;
    get canonical(): PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference;
    putCanonical(value: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonical): void;
    resetCanonical(): void;
    get canonicalInput(): PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCanonical | undefined;
    private _custom;
    get custom(): PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustomOutputReference;
    putCustom(value: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustom): void;
    resetCustom(): void;
    get customInput(): PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitCustom | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitScale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit_name Powerpack#unit_name}
    */
    readonly unitName: string;
}
export declare function powerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitScaleToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitScaleOutputReference | PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitScale): any;
export declare function powerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitScaleToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitScaleOutputReference | PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitScale): any;
export declare class PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitScaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitScale | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitScale | undefined);
    private _unitName?;
    get unitName(): string;
    set unitName(value: string);
    get unitNameInput(): string | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestFormulaNumberFormat {
    /**
    * unit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit Powerpack#unit}
    */
    readonly unit: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnit;
    /**
    * unit_scale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit_scale Powerpack#unit_scale}
    */
    readonly unitScale?: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitScale;
}
export declare function powerpackWidgetChangeDefinitionRequestFormulaNumberFormatToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatOutputReference | PowerpackWidgetChangeDefinitionRequestFormulaNumberFormat): any;
export declare function powerpackWidgetChangeDefinitionRequestFormulaNumberFormatToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatOutputReference | PowerpackWidgetChangeDefinitionRequestFormulaNumberFormat): any;
export declare class PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestFormulaNumberFormat | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormat | undefined);
    private _unit;
    get unit(): PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitOutputReference;
    putUnit(value: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnit): void;
    get unitInput(): PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnit | undefined;
    private _unitScale;
    get unitScale(): PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitScaleOutputReference;
    putUnitScale(value: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitScale): void;
    resetUnitScale(): void;
    get unitScaleInput(): PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatUnitScale | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestFormulaStyle {
    /**
    * The color palette used to display the formula. A guide to the available color palettes can be found at https://docs.datadoghq.com/dashboards/guide/widget_colors.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette Powerpack#palette}
    */
    readonly palette?: string;
    /**
    * Index specifying which color to use within the palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette_index Powerpack#palette_index}
    */
    readonly paletteIndex?: number;
}
export declare function powerpackWidgetChangeDefinitionRequestFormulaStyleToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestFormulaStyleOutputReference | PowerpackWidgetChangeDefinitionRequestFormulaStyle): any;
export declare function powerpackWidgetChangeDefinitionRequestFormulaStyleToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestFormulaStyleOutputReference | PowerpackWidgetChangeDefinitionRequestFormulaStyle): any;
export declare class PowerpackWidgetChangeDefinitionRequestFormulaStyleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestFormulaStyle | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestFormulaStyle | undefined);
    private _palette?;
    get palette(): string;
    set palette(value: string);
    resetPalette(): void;
    get paletteInput(): string | undefined;
    private _paletteIndex?;
    get paletteIndex(): number;
    set paletteIndex(value: number);
    resetPaletteIndex(): void;
    get paletteIndexInput(): number | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestFormula {
    /**
    * An expression alias.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#alias Powerpack#alias}
    */
    readonly alias?: string;
    /**
    * A list of display modes for each table cell. Valid values are `number`, `bar`, `trend`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cell_display_mode Powerpack#cell_display_mode}
    */
    readonly cellDisplayMode?: string;
    /**
    * A string expression built from queries, formulas, and functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#formula_expression Powerpack#formula_expression}
    */
    readonly formulaExpression: string;
    /**
    * conditional_formats block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#conditional_formats Powerpack#conditional_formats}
    */
    readonly conditionalFormats?: PowerpackWidgetChangeDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: PowerpackWidgetChangeDefinitionRequestFormulaLimit;
    /**
    * number_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#number_format Powerpack#number_format}
    */
    readonly numberFormat?: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormat;
    /**
    * style block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#style Powerpack#style}
    */
    readonly style?: PowerpackWidgetChangeDefinitionRequestFormulaStyle;
}
export declare function powerpackWidgetChangeDefinitionRequestFormulaToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestFormula | cdktn.IResolvable): any;
export declare function powerpackWidgetChangeDefinitionRequestFormulaToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestFormula | cdktn.IResolvable): any;
export declare class PowerpackWidgetChangeDefinitionRequestFormulaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestFormula | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestFormula | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _cellDisplayMode?;
    get cellDisplayMode(): string;
    set cellDisplayMode(value: string);
    resetCellDisplayMode(): void;
    get cellDisplayModeInput(): string | undefined;
    private _formulaExpression?;
    get formulaExpression(): string;
    set formulaExpression(value: string);
    get formulaExpressionInput(): string | undefined;
    private _conditionalFormats;
    get conditionalFormats(): PowerpackWidgetChangeDefinitionRequestFormulaConditionalFormatsList;
    putConditionalFormats(value: PowerpackWidgetChangeDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable): void;
    resetConditionalFormats(): void;
    get conditionalFormatsInput(): cdktn.IResolvable | PowerpackWidgetChangeDefinitionRequestFormulaConditionalFormats[] | undefined;
    private _limit;
    get limit(): PowerpackWidgetChangeDefinitionRequestFormulaLimitOutputReference;
    putLimit(value: PowerpackWidgetChangeDefinitionRequestFormulaLimit): void;
    resetLimit(): void;
    get limitInput(): PowerpackWidgetChangeDefinitionRequestFormulaLimit | undefined;
    private _numberFormat;
    get numberFormat(): PowerpackWidgetChangeDefinitionRequestFormulaNumberFormatOutputReference;
    putNumberFormat(value: PowerpackWidgetChangeDefinitionRequestFormulaNumberFormat): void;
    resetNumberFormat(): void;
    get numberFormatInput(): PowerpackWidgetChangeDefinitionRequestFormulaNumberFormat | undefined;
    private _style;
    get style(): PowerpackWidgetChangeDefinitionRequestFormulaStyleOutputReference;
    putStyle(value: PowerpackWidgetChangeDefinitionRequestFormulaStyle): void;
    resetStyle(): void;
    get styleInput(): PowerpackWidgetChangeDefinitionRequestFormulaStyle | undefined;
}
export declare class PowerpackWidgetChangeDefinitionRequestFormulaList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetChangeDefinitionRequestFormula[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetChangeDefinitionRequestFormulaOutputReference;
}
export interface PowerpackWidgetChangeDefinitionRequestLogQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetChangeDefinitionRequestLogQueryComputeQueryToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestLogQueryComputeQueryOutputReference | PowerpackWidgetChangeDefinitionRequestLogQueryComputeQuery): any;
export declare function powerpackWidgetChangeDefinitionRequestLogQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestLogQueryComputeQueryOutputReference | PowerpackWidgetChangeDefinitionRequestLogQueryComputeQuery): any;
export declare class PowerpackWidgetChangeDefinitionRequestLogQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestLogQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestLogQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestLogQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetChangeDefinitionRequestLogQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestLogQueryGroupBySortQueryOutputReference | PowerpackWidgetChangeDefinitionRequestLogQueryGroupBySortQuery): any;
export declare function powerpackWidgetChangeDefinitionRequestLogQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestLogQueryGroupBySortQueryOutputReference | PowerpackWidgetChangeDefinitionRequestLogQueryGroupBySortQuery): any;
export declare class PowerpackWidgetChangeDefinitionRequestLogQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestLogQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestLogQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestLogQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetChangeDefinitionRequestLogQueryGroupBySortQuery;
}
export declare function powerpackWidgetChangeDefinitionRequestLogQueryGroupByToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestLogQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetChangeDefinitionRequestLogQueryGroupByToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestLogQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetChangeDefinitionRequestLogQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestLogQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestLogQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetChangeDefinitionRequestLogQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetChangeDefinitionRequestLogQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetChangeDefinitionRequestLogQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetChangeDefinitionRequestLogQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetChangeDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetChangeDefinitionRequestLogQueryGroupByOutputReference;
}
export interface PowerpackWidgetChangeDefinitionRequestLogQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetChangeDefinitionRequestLogQueryMultiComputeToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetChangeDefinitionRequestLogQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetChangeDefinitionRequestLogQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetChangeDefinitionRequestLogQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetChangeDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetChangeDefinitionRequestLogQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetChangeDefinitionRequestLogQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetChangeDefinitionRequestLogQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetChangeDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetChangeDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetChangeDefinitionRequestLogQueryToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestLogQueryOutputReference | PowerpackWidgetChangeDefinitionRequestLogQuery): any;
export declare function powerpackWidgetChangeDefinitionRequestLogQueryToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestLogQueryOutputReference | PowerpackWidgetChangeDefinitionRequestLogQuery): any;
export declare class PowerpackWidgetChangeDefinitionRequestLogQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestLogQuery | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestLogQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetChangeDefinitionRequestLogQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetChangeDefinitionRequestLogQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetChangeDefinitionRequestLogQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetChangeDefinitionRequestLogQueryGroupByList;
    putGroupBy(value: PowerpackWidgetChangeDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetChangeDefinitionRequestLogQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetChangeDefinitionRequestLogQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetChangeDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetChangeDefinitionRequestLogQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestProcessQuery {
    /**
    * A list of processes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#filter_by Powerpack#filter_by}
    */
    readonly filterBy?: string[];
    /**
    * The max number of items in the filter list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * Your chosen metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric: string;
    /**
    * Your chosen search term.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_by Powerpack#search_by}
    */
    readonly searchBy?: string;
}
export declare function powerpackWidgetChangeDefinitionRequestProcessQueryToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestProcessQueryOutputReference | PowerpackWidgetChangeDefinitionRequestProcessQuery): any;
export declare function powerpackWidgetChangeDefinitionRequestProcessQueryToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestProcessQueryOutputReference | PowerpackWidgetChangeDefinitionRequestProcessQuery): any;
export declare class PowerpackWidgetChangeDefinitionRequestProcessQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestProcessQuery | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestProcessQuery | undefined);
    private _filterBy?;
    get filterBy(): string[];
    set filterBy(value: string[]);
    resetFilterBy(): void;
    get filterByInput(): string[] | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _searchBy?;
    get searchBy(): string;
    set searchBy(value: string);
    resetSearchBy(): void;
    get searchByInput(): string | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestQueryApmDependencyStatsQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for APM Dependency Stats queries. Valid values are `apm_dependency_stats`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * APM environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#env Powerpack#env}
    */
    readonly env: string;
    /**
    * Determines whether stats for upstream or downstream dependencies should be queried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_upstream Powerpack#is_upstream}
    */
    readonly isUpstream?: boolean | cdktn.IResolvable;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Name of operation on service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#operation_name Powerpack#operation_name}
    */
    readonly operationName: string;
    /**
    * The name of the second primary tag used within APM; required when `primary_tag_value` is specified. See https://docs.datadoghq.com/tracing/guide/setting_primary_tags_to_scope/#add-a-second-primary-tag-in-datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_name Powerpack#primary_tag_name}
    */
    readonly primaryTagName?: string;
    /**
    * Filter APM data by the second primary tag. `primary_tag_name` must also be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_value Powerpack#primary_tag_value}
    */
    readonly primaryTagValue?: string;
    /**
    * APM resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#resource_name Powerpack#resource_name}
    */
    readonly resourceName: string;
    /**
    * APM service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#service Powerpack#service}
    */
    readonly service: string;
    /**
    * APM statistic. Valid values are `avg_duration`, `avg_root_duration`, `avg_spans_per_trace`, `error_rate`, `pct_exec_time`, `pct_of_traces`, `total_traces_count`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#stat Powerpack#stat}
    */
    readonly stat: string;
}
export declare function powerpackWidgetChangeDefinitionRequestQueryApmDependencyStatsQueryToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQueryApmDependencyStatsQueryOutputReference | PowerpackWidgetChangeDefinitionRequestQueryApmDependencyStatsQuery): any;
export declare function powerpackWidgetChangeDefinitionRequestQueryApmDependencyStatsQueryToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQueryApmDependencyStatsQueryOutputReference | PowerpackWidgetChangeDefinitionRequestQueryApmDependencyStatsQuery): any;
export declare class PowerpackWidgetChangeDefinitionRequestQueryApmDependencyStatsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestQueryApmDependencyStatsQuery | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestQueryApmDependencyStatsQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    private _isUpstream?;
    get isUpstream(): boolean | cdktn.IResolvable;
    set isUpstream(value: boolean | cdktn.IResolvable);
    resetIsUpstream(): void;
    get isUpstreamInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    get operationNameInput(): string | undefined;
    private _primaryTagName?;
    get primaryTagName(): string;
    set primaryTagName(value: string);
    resetPrimaryTagName(): void;
    get primaryTagNameInput(): string | undefined;
    private _primaryTagValue?;
    get primaryTagValue(): string;
    set primaryTagValue(value: string);
    resetPrimaryTagValue(): void;
    get primaryTagValueInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    get resourceNameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    get statInput(): string | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestQueryApmResourceStatsQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for APM Resource Stats queries. Valid values are `apm_resource_stats`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * APM environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#env Powerpack#env}
    */
    readonly env: string;
    /**
    * Array of fields to group results by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: string[];
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Name of operation on service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#operation_name Powerpack#operation_name}
    */
    readonly operationName?: string;
    /**
    * The name of the second primary tag used within APM; required when `primary_tag_value` is specified. See https://docs.datadoghq.com/tracing/guide/setting_primary_tags_to_scope/#add-a-second-primary-tag-in-datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_name Powerpack#primary_tag_name}
    */
    readonly primaryTagName?: string;
    /**
    * Filter APM data by the second primary tag. `primary_tag_name` must also be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_value Powerpack#primary_tag_value}
    */
    readonly primaryTagValue?: string;
    /**
    * APM resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#resource_name Powerpack#resource_name}
    */
    readonly resourceName?: string;
    /**
    * APM service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#service Powerpack#service}
    */
    readonly service: string;
    /**
    * APM statistic. Valid values are `errors`, `error_rate`, `hits`, `latency_avg`, `latency_distribution`, `latency_max`, `latency_p50`, `latency_p75`, `latency_p90`, `latency_p95`, `latency_p99`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#stat Powerpack#stat}
    */
    readonly stat: string;
}
export declare function powerpackWidgetChangeDefinitionRequestQueryApmResourceStatsQueryToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQueryApmResourceStatsQueryOutputReference | PowerpackWidgetChangeDefinitionRequestQueryApmResourceStatsQuery): any;
export declare function powerpackWidgetChangeDefinitionRequestQueryApmResourceStatsQueryToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQueryApmResourceStatsQueryOutputReference | PowerpackWidgetChangeDefinitionRequestQueryApmResourceStatsQuery): any;
export declare class PowerpackWidgetChangeDefinitionRequestQueryApmResourceStatsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestQueryApmResourceStatsQuery | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestQueryApmResourceStatsQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    private _groupBy?;
    get groupBy(): string[];
    set groupBy(value: string[]);
    resetGroupBy(): void;
    get groupByInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    resetOperationName(): void;
    get operationNameInput(): string | undefined;
    private _primaryTagName?;
    get primaryTagName(): string;
    set primaryTagName(value: string);
    resetPrimaryTagName(): void;
    get primaryTagNameInput(): string | undefined;
    private _primaryTagValue?;
    get primaryTagValue(): string;
    set primaryTagValue(value: string);
    resetPrimaryTagValue(): void;
    get primaryTagValueInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    resetResourceName(): void;
    get resourceNameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    get statInput(): string | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestQueryCloudCostQuery {
    /**
    * The aggregation methods available for cloud cost queries. Valid values are `avg`, `last`, `max`, `min`, `sum`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for cloud cost queries. Valid values are `cloud_cost`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The cloud cost query definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
}
export declare function powerpackWidgetChangeDefinitionRequestQueryCloudCostQueryToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQueryCloudCostQueryOutputReference | PowerpackWidgetChangeDefinitionRequestQueryCloudCostQuery): any;
export declare function powerpackWidgetChangeDefinitionRequestQueryCloudCostQueryToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQueryCloudCostQueryOutputReference | PowerpackWidgetChangeDefinitionRequestQueryCloudCostQuery): any;
export declare class PowerpackWidgetChangeDefinitionRequestQueryCloudCostQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestQueryCloudCostQuery | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestQueryCloudCostQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestQueryEventQueryCompute {
    /**
    * The aggregation methods for event platform queries. Valid values are `count`, `cardinality`, `median`, `pc75`, `pc90`, `pc95`, `pc98`, `pc99`, `sum`, `min`, `max`, `avg`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * A time interval in milliseconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
    /**
    * The measurable attribute to compute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
}
export declare function powerpackWidgetChangeDefinitionRequestQueryEventQueryComputeToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetChangeDefinitionRequestQueryEventQueryComputeToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetChangeDefinitionRequestQueryEventQueryComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
}
export declare class PowerpackWidgetChangeDefinitionRequestQueryEventQueryComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetChangeDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetChangeDefinitionRequestQueryEventQueryComputeOutputReference;
}
export interface PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBySort {
    /**
    * The aggregation methods for the event platform queries. Valid values are `count`, `cardinality`, `median`, `pc75`, `pc90`, `pc95`, `pc98`, `pc99`, `sum`, `min`, `max`, `avg`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The metric used for sorting group by results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
    /**
    * Direction of sort. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order?: string;
}
export declare function powerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBySortToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBySortOutputReference | PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBySort): any;
export declare function powerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBySortToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBySortOutputReference | PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBySort): any;
export declare class PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBySortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBySort | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBySort | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBy {
    /**
    * The event facet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet: string;
    /**
    * The number of groups to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort Powerpack#sort}
    */
    readonly sort?: PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBySort;
}
export declare function powerpackWidgetChangeDefinitionRequestQueryEventQueryGroupByToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetChangeDefinitionRequestQueryEventQueryGroupByToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sort;
    get sort(): PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBySortOutputReference;
    putSort(value: PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBySort): void;
    resetSort(): void;
    get sortInput(): PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBySort | undefined;
}
export declare class PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupByOutputReference;
}
export interface PowerpackWidgetChangeDefinitionRequestQueryEventQuerySearch {
    /**
    * The events search string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
}
export declare function powerpackWidgetChangeDefinitionRequestQueryEventQuerySearchToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQueryEventQuerySearchOutputReference | PowerpackWidgetChangeDefinitionRequestQueryEventQuerySearch): any;
export declare function powerpackWidgetChangeDefinitionRequestQueryEventQuerySearchToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQueryEventQuerySearchOutputReference | PowerpackWidgetChangeDefinitionRequestQueryEventQuerySearch): any;
export declare class PowerpackWidgetChangeDefinitionRequestQueryEventQuerySearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestQueryEventQuerySearch | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestQueryEventQuerySearch | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestQueryEventQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for event platform-based queries. Valid values are `logs`, `spans`, `network`, `rum`, `security_signals`, `profiles`, `audit`, `events`, `ci_tests`, `ci_pipelines`, `incident_analytics`, `product_analytics`, `on_call_events`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * An array of index names to query in the stream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#indexes Powerpack#indexes}
    */
    readonly indexes?: string[];
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Storage location (private beta).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#storage Powerpack#storage}
    */
    readonly storage?: string;
    /**
    * compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute Powerpack#compute}
    */
    readonly compute: PowerpackWidgetChangeDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable;
    /**
    * search block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search Powerpack#search}
    */
    readonly search?: PowerpackWidgetChangeDefinitionRequestQueryEventQuerySearch;
}
export declare function powerpackWidgetChangeDefinitionRequestQueryEventQueryToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQueryEventQueryOutputReference | PowerpackWidgetChangeDefinitionRequestQueryEventQuery): any;
export declare function powerpackWidgetChangeDefinitionRequestQueryEventQueryToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQueryEventQueryOutputReference | PowerpackWidgetChangeDefinitionRequestQueryEventQuery): any;
export declare class PowerpackWidgetChangeDefinitionRequestQueryEventQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestQueryEventQuery | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestQueryEventQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _indexes?;
    get indexes(): string[];
    set indexes(value: string[]);
    resetIndexes(): void;
    get indexesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _storage?;
    get storage(): string;
    set storage(value: string);
    resetStorage(): void;
    get storageInput(): string | undefined;
    private _compute;
    get compute(): PowerpackWidgetChangeDefinitionRequestQueryEventQueryComputeList;
    putCompute(value: PowerpackWidgetChangeDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable): void;
    get computeInput(): cdktn.IResolvable | PowerpackWidgetChangeDefinitionRequestQueryEventQueryCompute[] | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupByList;
    putGroupBy(value: PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetChangeDefinitionRequestQueryEventQueryGroupBy[] | undefined;
    private _search;
    get search(): PowerpackWidgetChangeDefinitionRequestQueryEventQuerySearchOutputReference;
    putSearch(value: PowerpackWidgetChangeDefinitionRequestQueryEventQuerySearch): void;
    resetSearch(): void;
    get searchInput(): PowerpackWidgetChangeDefinitionRequestQueryEventQuerySearch | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestQueryMetricQuery {
    /**
    * The aggregation methods available for metrics queries. Valid values are `avg`, `min`, `max`, `sum`, `last`, `area`, `l2norm`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for metrics queries. Defaults to `"metrics"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource?: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The metrics query definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
    /**
    * Semantic mode for metrics queries. This determines how metrics from different sources are combined or displayed. Valid values are `combined`, `native`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#semantic_mode Powerpack#semantic_mode}
    */
    readonly semanticMode?: string;
}
export declare function powerpackWidgetChangeDefinitionRequestQueryMetricQueryToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQueryMetricQueryOutputReference | PowerpackWidgetChangeDefinitionRequestQueryMetricQuery): any;
export declare function powerpackWidgetChangeDefinitionRequestQueryMetricQueryToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQueryMetricQueryOutputReference | PowerpackWidgetChangeDefinitionRequestQueryMetricQuery): any;
export declare class PowerpackWidgetChangeDefinitionRequestQueryMetricQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestQueryMetricQuery | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestQueryMetricQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    resetDataSource(): void;
    get dataSourceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _semanticMode?;
    get semanticMode(): string;
    set semanticMode(value: string);
    resetSemanticMode(): void;
    get semanticModeInput(): string | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestQueryProcessQuery {
    /**
    * The aggregation methods available for metrics queries. Valid values are `avg`, `min`, `max`, `sum`, `last`, `area`, `l2norm`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for process queries. Valid values are `process`, `container`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * Whether to normalize the CPU percentages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_normalized_cpu Powerpack#is_normalized_cpu}
    */
    readonly isNormalizedCpu?: boolean | cdktn.IResolvable;
    /**
    * The number of hits to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * The process metric name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric: string;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The direction of the sort. Valid values are `asc`, `desc`. Defaults to `"desc"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort Powerpack#sort}
    */
    readonly sort?: string;
    /**
    * An array of tags to filter by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#tag_filters Powerpack#tag_filters}
    */
    readonly tagFilters?: string[];
    /**
    * The text to use as a filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#text_filter Powerpack#text_filter}
    */
    readonly textFilter?: string;
}
export declare function powerpackWidgetChangeDefinitionRequestQueryProcessQueryToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQueryProcessQueryOutputReference | PowerpackWidgetChangeDefinitionRequestQueryProcessQuery): any;
export declare function powerpackWidgetChangeDefinitionRequestQueryProcessQueryToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQueryProcessQueryOutputReference | PowerpackWidgetChangeDefinitionRequestQueryProcessQuery): any;
export declare class PowerpackWidgetChangeDefinitionRequestQueryProcessQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestQueryProcessQuery | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestQueryProcessQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _isNormalizedCpu?;
    get isNormalizedCpu(): boolean | cdktn.IResolvable;
    set isNormalizedCpu(value: boolean | cdktn.IResolvable);
    resetIsNormalizedCpu(): void;
    get isNormalizedCpuInput(): boolean | cdktn.IResolvable | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _sort?;
    get sort(): string;
    set sort(value: string);
    resetSort(): void;
    get sortInput(): string | undefined;
    private _tagFilters?;
    get tagFilters(): string[];
    set tagFilters(value: string[]);
    resetTagFilters(): void;
    get tagFiltersInput(): string[] | undefined;
    private _textFilter?;
    get textFilter(): string;
    set textFilter(value: string);
    resetTextFilter(): void;
    get textFilterInput(): string | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestQuerySloQuery {
    /**
    * Additional filters applied to the SLO query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#additional_query_filters Powerpack#additional_query_filters}
    */
    readonly additionalQueryFilters?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for SLO queries. Valid values are `slo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * Group mode to query measures. Valid values are `overall`, `components`. Defaults to `"overall"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_mode Powerpack#group_mode}
    */
    readonly groupMode?: string;
    /**
    * SLO measures queries. Valid values are `good_events`, `bad_events`, `good_minutes`, `bad_minutes`, `slo_status`, `error_budget_remaining`, `burn_rate`, `error_budget_burndown`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#measure Powerpack#measure}
    */
    readonly measure: string;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name?: string;
    /**
    * ID of an SLO to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_id Powerpack#slo_id}
    */
    readonly sloId: string;
    /**
    * type of the SLO to query. Valid values are `metric`, `monitor`, `time_slice`. Defaults to `"metric"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_query_type Powerpack#slo_query_type}
    */
    readonly sloQueryType?: string;
}
export declare function powerpackWidgetChangeDefinitionRequestQuerySloQueryToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQuerySloQueryOutputReference | PowerpackWidgetChangeDefinitionRequestQuerySloQuery): any;
export declare function powerpackWidgetChangeDefinitionRequestQuerySloQueryToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQuerySloQueryOutputReference | PowerpackWidgetChangeDefinitionRequestQuerySloQuery): any;
export declare class PowerpackWidgetChangeDefinitionRequestQuerySloQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestQuerySloQuery | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestQuerySloQuery | undefined);
    private _additionalQueryFilters?;
    get additionalQueryFilters(): string;
    set additionalQueryFilters(value: string);
    resetAdditionalQueryFilters(): void;
    get additionalQueryFiltersInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _groupMode?;
    get groupMode(): string;
    set groupMode(value: string);
    resetGroupMode(): void;
    get groupModeInput(): string | undefined;
    private _measure?;
    get measure(): string;
    set measure(value: string);
    get measureInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sloId?;
    get sloId(): string;
    set sloId(value: string);
    get sloIdInput(): string | undefined;
    private _sloQueryType?;
    get sloQueryType(): string;
    set sloQueryType(value: string);
    resetSloQueryType(): void;
    get sloQueryTypeInput(): string | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestQuery {
    /**
    * apm_dependency_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_dependency_stats_query Powerpack#apm_dependency_stats_query}
    */
    readonly apmDependencyStatsQuery?: PowerpackWidgetChangeDefinitionRequestQueryApmDependencyStatsQuery;
    /**
    * apm_resource_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_resource_stats_query Powerpack#apm_resource_stats_query}
    */
    readonly apmResourceStatsQuery?: PowerpackWidgetChangeDefinitionRequestQueryApmResourceStatsQuery;
    /**
    * cloud_cost_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cloud_cost_query Powerpack#cloud_cost_query}
    */
    readonly cloudCostQuery?: PowerpackWidgetChangeDefinitionRequestQueryCloudCostQuery;
    /**
    * event_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#event_query Powerpack#event_query}
    */
    readonly eventQuery?: PowerpackWidgetChangeDefinitionRequestQueryEventQuery;
    /**
    * metric_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric_query Powerpack#metric_query}
    */
    readonly metricQuery?: PowerpackWidgetChangeDefinitionRequestQueryMetricQuery;
    /**
    * process_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#process_query Powerpack#process_query}
    */
    readonly processQuery?: PowerpackWidgetChangeDefinitionRequestQueryProcessQuery;
    /**
    * slo_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_query Powerpack#slo_query}
    */
    readonly sloQuery?: PowerpackWidgetChangeDefinitionRequestQuerySloQuery;
}
export declare function powerpackWidgetChangeDefinitionRequestQueryToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQuery | cdktn.IResolvable): any;
export declare function powerpackWidgetChangeDefinitionRequestQueryToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestQuery | cdktn.IResolvable): any;
export declare class PowerpackWidgetChangeDefinitionRequestQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestQuery | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestQuery | cdktn.IResolvable | undefined);
    private _apmDependencyStatsQuery;
    get apmDependencyStatsQuery(): PowerpackWidgetChangeDefinitionRequestQueryApmDependencyStatsQueryOutputReference;
    putApmDependencyStatsQuery(value: PowerpackWidgetChangeDefinitionRequestQueryApmDependencyStatsQuery): void;
    resetApmDependencyStatsQuery(): void;
    get apmDependencyStatsQueryInput(): PowerpackWidgetChangeDefinitionRequestQueryApmDependencyStatsQuery | undefined;
    private _apmResourceStatsQuery;
    get apmResourceStatsQuery(): PowerpackWidgetChangeDefinitionRequestQueryApmResourceStatsQueryOutputReference;
    putApmResourceStatsQuery(value: PowerpackWidgetChangeDefinitionRequestQueryApmResourceStatsQuery): void;
    resetApmResourceStatsQuery(): void;
    get apmResourceStatsQueryInput(): PowerpackWidgetChangeDefinitionRequestQueryApmResourceStatsQuery | undefined;
    private _cloudCostQuery;
    get cloudCostQuery(): PowerpackWidgetChangeDefinitionRequestQueryCloudCostQueryOutputReference;
    putCloudCostQuery(value: PowerpackWidgetChangeDefinitionRequestQueryCloudCostQuery): void;
    resetCloudCostQuery(): void;
    get cloudCostQueryInput(): PowerpackWidgetChangeDefinitionRequestQueryCloudCostQuery | undefined;
    private _eventQuery;
    get eventQuery(): PowerpackWidgetChangeDefinitionRequestQueryEventQueryOutputReference;
    putEventQuery(value: PowerpackWidgetChangeDefinitionRequestQueryEventQuery): void;
    resetEventQuery(): void;
    get eventQueryInput(): PowerpackWidgetChangeDefinitionRequestQueryEventQuery | undefined;
    private _metricQuery;
    get metricQuery(): PowerpackWidgetChangeDefinitionRequestQueryMetricQueryOutputReference;
    putMetricQuery(value: PowerpackWidgetChangeDefinitionRequestQueryMetricQuery): void;
    resetMetricQuery(): void;
    get metricQueryInput(): PowerpackWidgetChangeDefinitionRequestQueryMetricQuery | undefined;
    private _processQuery;
    get processQuery(): PowerpackWidgetChangeDefinitionRequestQueryProcessQueryOutputReference;
    putProcessQuery(value: PowerpackWidgetChangeDefinitionRequestQueryProcessQuery): void;
    resetProcessQuery(): void;
    get processQueryInput(): PowerpackWidgetChangeDefinitionRequestQueryProcessQuery | undefined;
    private _sloQuery;
    get sloQuery(): PowerpackWidgetChangeDefinitionRequestQuerySloQueryOutputReference;
    putSloQuery(value: PowerpackWidgetChangeDefinitionRequestQuerySloQuery): void;
    resetSloQuery(): void;
    get sloQueryInput(): PowerpackWidgetChangeDefinitionRequestQuerySloQuery | undefined;
}
export declare class PowerpackWidgetChangeDefinitionRequestQueryList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetChangeDefinitionRequestQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetChangeDefinitionRequestQueryOutputReference;
}
export interface PowerpackWidgetChangeDefinitionRequestRumQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetChangeDefinitionRequestRumQueryComputeQueryToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestRumQueryComputeQueryOutputReference | PowerpackWidgetChangeDefinitionRequestRumQueryComputeQuery): any;
export declare function powerpackWidgetChangeDefinitionRequestRumQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestRumQueryComputeQueryOutputReference | PowerpackWidgetChangeDefinitionRequestRumQueryComputeQuery): any;
export declare class PowerpackWidgetChangeDefinitionRequestRumQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestRumQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestRumQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestRumQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetChangeDefinitionRequestRumQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestRumQueryGroupBySortQueryOutputReference | PowerpackWidgetChangeDefinitionRequestRumQueryGroupBySortQuery): any;
export declare function powerpackWidgetChangeDefinitionRequestRumQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestRumQueryGroupBySortQueryOutputReference | PowerpackWidgetChangeDefinitionRequestRumQueryGroupBySortQuery): any;
export declare class PowerpackWidgetChangeDefinitionRequestRumQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestRumQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestRumQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestRumQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetChangeDefinitionRequestRumQueryGroupBySortQuery;
}
export declare function powerpackWidgetChangeDefinitionRequestRumQueryGroupByToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestRumQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetChangeDefinitionRequestRumQueryGroupByToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestRumQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetChangeDefinitionRequestRumQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestRumQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestRumQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetChangeDefinitionRequestRumQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetChangeDefinitionRequestRumQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetChangeDefinitionRequestRumQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetChangeDefinitionRequestRumQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetChangeDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetChangeDefinitionRequestRumQueryGroupByOutputReference;
}
export interface PowerpackWidgetChangeDefinitionRequestRumQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetChangeDefinitionRequestRumQueryMultiComputeToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetChangeDefinitionRequestRumQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetChangeDefinitionRequestRumQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetChangeDefinitionRequestRumQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetChangeDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetChangeDefinitionRequestRumQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetChangeDefinitionRequestRumQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetChangeDefinitionRequestRumQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetChangeDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetChangeDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetChangeDefinitionRequestRumQueryToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestRumQueryOutputReference | PowerpackWidgetChangeDefinitionRequestRumQuery): any;
export declare function powerpackWidgetChangeDefinitionRequestRumQueryToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestRumQueryOutputReference | PowerpackWidgetChangeDefinitionRequestRumQuery): any;
export declare class PowerpackWidgetChangeDefinitionRequestRumQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestRumQuery | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestRumQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetChangeDefinitionRequestRumQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetChangeDefinitionRequestRumQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetChangeDefinitionRequestRumQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetChangeDefinitionRequestRumQueryGroupByList;
    putGroupBy(value: PowerpackWidgetChangeDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetChangeDefinitionRequestRumQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetChangeDefinitionRequestRumQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetChangeDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetChangeDefinitionRequestRumQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestSecurityQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetChangeDefinitionRequestSecurityQueryComputeQueryToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestSecurityQueryComputeQueryOutputReference | PowerpackWidgetChangeDefinitionRequestSecurityQueryComputeQuery): any;
export declare function powerpackWidgetChangeDefinitionRequestSecurityQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestSecurityQueryComputeQueryOutputReference | PowerpackWidgetChangeDefinitionRequestSecurityQueryComputeQuery): any;
export declare class PowerpackWidgetChangeDefinitionRequestSecurityQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestSecurityQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestSecurityQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetChangeDefinitionRequestSecurityQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupBySortQueryOutputReference | PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupBySortQuery): any;
export declare function powerpackWidgetChangeDefinitionRequestSecurityQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupBySortQueryOutputReference | PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupBySortQuery): any;
export declare class PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupBySortQuery;
}
export declare function powerpackWidgetChangeDefinitionRequestSecurityQueryGroupByToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetChangeDefinitionRequestSecurityQueryGroupByToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupByOutputReference;
}
export interface PowerpackWidgetChangeDefinitionRequestSecurityQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetChangeDefinitionRequestSecurityQueryMultiComputeToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetChangeDefinitionRequestSecurityQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetChangeDefinitionRequestSecurityQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetChangeDefinitionRequestSecurityQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetChangeDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetChangeDefinitionRequestSecurityQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetChangeDefinitionRequestSecurityQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetChangeDefinitionRequestSecurityQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetChangeDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetChangeDefinitionRequestSecurityQueryToTerraform(struct?: PowerpackWidgetChangeDefinitionRequestSecurityQueryOutputReference | PowerpackWidgetChangeDefinitionRequestSecurityQuery): any;
export declare function powerpackWidgetChangeDefinitionRequestSecurityQueryToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequestSecurityQueryOutputReference | PowerpackWidgetChangeDefinitionRequestSecurityQuery): any;
export declare class PowerpackWidgetChangeDefinitionRequestSecurityQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinitionRequestSecurityQuery | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequestSecurityQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetChangeDefinitionRequestSecurityQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetChangeDefinitionRequestSecurityQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetChangeDefinitionRequestSecurityQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupByList;
    putGroupBy(value: PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetChangeDefinitionRequestSecurityQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetChangeDefinitionRequestSecurityQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetChangeDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetChangeDefinitionRequestSecurityQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetChangeDefinitionRequest {
    /**
    * Whether to show absolute or relative change. Valid values are `absolute`, `relative`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#change_type Powerpack#change_type}
    */
    readonly changeType?: string;
    /**
    * Choose from when to compare current data to. Valid values are `hour_before`, `day_before`, `week_before`, `month_before`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compare_to Powerpack#compare_to}
    */
    readonly compareTo?: string;
    /**
    * A Boolean indicating whether an increase in the value is good (displayed in green) or not (displayed in red).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#increase_good Powerpack#increase_good}
    */
    readonly increaseGood?: boolean | cdktn.IResolvable;
    /**
    * What to order by. Valid values are `change`, `name`, `present`, `past`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order_by Powerpack#order_by}
    */
    readonly orderBy?: string;
    /**
    * Widget sorting method. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order_dir Powerpack#order_dir}
    */
    readonly orderDir?: string;
    /**
    * The metric query to use for this widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#q Powerpack#q}
    */
    readonly q?: string;
    /**
    * If set to `true`, displays the current value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#show_present Powerpack#show_present}
    */
    readonly showPresent?: boolean | cdktn.IResolvable;
    /**
    * apm_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_query Powerpack#apm_query}
    */
    readonly apmQuery?: PowerpackWidgetChangeDefinitionRequestApmQuery;
    /**
    * formula block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#formula Powerpack#formula}
    */
    readonly formula?: PowerpackWidgetChangeDefinitionRequestFormula[] | cdktn.IResolvable;
    /**
    * log_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#log_query Powerpack#log_query}
    */
    readonly logQuery?: PowerpackWidgetChangeDefinitionRequestLogQuery;
    /**
    * process_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#process_query Powerpack#process_query}
    */
    readonly processQuery?: PowerpackWidgetChangeDefinitionRequestProcessQuery;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query?: PowerpackWidgetChangeDefinitionRequestQuery[] | cdktn.IResolvable;
    /**
    * rum_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#rum_query Powerpack#rum_query}
    */
    readonly rumQuery?: PowerpackWidgetChangeDefinitionRequestRumQuery;
    /**
    * security_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#security_query Powerpack#security_query}
    */
    readonly securityQuery?: PowerpackWidgetChangeDefinitionRequestSecurityQuery;
}
export declare function powerpackWidgetChangeDefinitionRequestToTerraform(struct?: PowerpackWidgetChangeDefinitionRequest | cdktn.IResolvable): any;
export declare function powerpackWidgetChangeDefinitionRequestToHclTerraform(struct?: PowerpackWidgetChangeDefinitionRequest | cdktn.IResolvable): any;
export declare class PowerpackWidgetChangeDefinitionRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetChangeDefinitionRequest | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinitionRequest | cdktn.IResolvable | undefined);
    private _changeType?;
    get changeType(): string;
    set changeType(value: string);
    resetChangeType(): void;
    get changeTypeInput(): string | undefined;
    private _compareTo?;
    get compareTo(): string;
    set compareTo(value: string);
    resetCompareTo(): void;
    get compareToInput(): string | undefined;
    private _increaseGood?;
    get increaseGood(): boolean | cdktn.IResolvable;
    set increaseGood(value: boolean | cdktn.IResolvable);
    resetIncreaseGood(): void;
    get increaseGoodInput(): boolean | cdktn.IResolvable | undefined;
    private _orderBy?;
    get orderBy(): string;
    set orderBy(value: string);
    resetOrderBy(): void;
    get orderByInput(): string | undefined;
    private _orderDir?;
    get orderDir(): string;
    set orderDir(value: string);
    resetOrderDir(): void;
    get orderDirInput(): string | undefined;
    private _q?;
    get q(): string;
    set q(value: string);
    resetQ(): void;
    get qInput(): string | undefined;
    private _showPresent?;
    get showPresent(): boolean | cdktn.IResolvable;
    set showPresent(value: boolean | cdktn.IResolvable);
    resetShowPresent(): void;
    get showPresentInput(): boolean | cdktn.IResolvable | undefined;
    private _apmQuery;
    get apmQuery(): PowerpackWidgetChangeDefinitionRequestApmQueryOutputReference;
    putApmQuery(value: PowerpackWidgetChangeDefinitionRequestApmQuery): void;
    resetApmQuery(): void;
    get apmQueryInput(): PowerpackWidgetChangeDefinitionRequestApmQuery | undefined;
    private _formula;
    get formula(): PowerpackWidgetChangeDefinitionRequestFormulaList;
    putFormula(value: PowerpackWidgetChangeDefinitionRequestFormula[] | cdktn.IResolvable): void;
    resetFormula(): void;
    get formulaInput(): cdktn.IResolvable | PowerpackWidgetChangeDefinitionRequestFormula[] | undefined;
    private _logQuery;
    get logQuery(): PowerpackWidgetChangeDefinitionRequestLogQueryOutputReference;
    putLogQuery(value: PowerpackWidgetChangeDefinitionRequestLogQuery): void;
    resetLogQuery(): void;
    get logQueryInput(): PowerpackWidgetChangeDefinitionRequestLogQuery | undefined;
    private _processQuery;
    get processQuery(): PowerpackWidgetChangeDefinitionRequestProcessQueryOutputReference;
    putProcessQuery(value: PowerpackWidgetChangeDefinitionRequestProcessQuery): void;
    resetProcessQuery(): void;
    get processQueryInput(): PowerpackWidgetChangeDefinitionRequestProcessQuery | undefined;
    private _query;
    get query(): PowerpackWidgetChangeDefinitionRequestQueryList;
    putQuery(value: PowerpackWidgetChangeDefinitionRequestQuery[] | cdktn.IResolvable): void;
    resetQuery(): void;
    get queryInput(): cdktn.IResolvable | PowerpackWidgetChangeDefinitionRequestQuery[] | undefined;
    private _rumQuery;
    get rumQuery(): PowerpackWidgetChangeDefinitionRequestRumQueryOutputReference;
    putRumQuery(value: PowerpackWidgetChangeDefinitionRequestRumQuery): void;
    resetRumQuery(): void;
    get rumQueryInput(): PowerpackWidgetChangeDefinitionRequestRumQuery | undefined;
    private _securityQuery;
    get securityQuery(): PowerpackWidgetChangeDefinitionRequestSecurityQueryOutputReference;
    putSecurityQuery(value: PowerpackWidgetChangeDefinitionRequestSecurityQuery): void;
    resetSecurityQuery(): void;
    get securityQueryInput(): PowerpackWidgetChangeDefinitionRequestSecurityQuery | undefined;
}
export declare class PowerpackWidgetChangeDefinitionRequestList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetChangeDefinitionRequest[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetChangeDefinitionRequestOutputReference;
}
export interface PowerpackWidgetChangeDefinition {
    /**
    * Hide any portion of the widget's timeframe that is incomplete due to cost data not being available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_incomplete_cost_data Powerpack#hide_incomplete_cost_data}
    */
    readonly hideIncompleteCostData?: boolean | cdktn.IResolvable;
    /**
    * The timeframe to use when displaying the widget. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#live_span Powerpack#live_span}
    */
    readonly liveSpan?: string;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title Powerpack#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_align Powerpack#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_size Powerpack#title_size}
    */
    readonly titleSize?: string;
    /**
    * custom_link block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_link Powerpack#custom_link}
    */
    readonly customLink?: PowerpackWidgetChangeDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#request Powerpack#request}
    */
    readonly request?: PowerpackWidgetChangeDefinitionRequest[] | cdktn.IResolvable;
}
export declare function powerpackWidgetChangeDefinitionToTerraform(struct?: PowerpackWidgetChangeDefinitionOutputReference | PowerpackWidgetChangeDefinition): any;
export declare function powerpackWidgetChangeDefinitionToHclTerraform(struct?: PowerpackWidgetChangeDefinitionOutputReference | PowerpackWidgetChangeDefinition): any;
export declare class PowerpackWidgetChangeDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetChangeDefinition | undefined;
    set internalValue(value: PowerpackWidgetChangeDefinition | undefined);
    private _hideIncompleteCostData?;
    get hideIncompleteCostData(): boolean | cdktn.IResolvable;
    set hideIncompleteCostData(value: boolean | cdktn.IResolvable);
    resetHideIncompleteCostData(): void;
    get hideIncompleteCostDataInput(): boolean | cdktn.IResolvable | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _customLink;
    get customLink(): PowerpackWidgetChangeDefinitionCustomLinkList;
    putCustomLink(value: PowerpackWidgetChangeDefinitionCustomLink[] | cdktn.IResolvable): void;
    resetCustomLink(): void;
    get customLinkInput(): cdktn.IResolvable | PowerpackWidgetChangeDefinitionCustomLink[] | undefined;
    private _request;
    get request(): PowerpackWidgetChangeDefinitionRequestList;
    putRequest(value: PowerpackWidgetChangeDefinitionRequest[] | cdktn.IResolvable): void;
    resetRequest(): void;
    get requestInput(): cdktn.IResolvable | PowerpackWidgetChangeDefinitionRequest[] | undefined;
}
export interface PowerpackWidgetCheckStatusDefinition {
    /**
    * The check to use in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#check Powerpack#check}
    */
    readonly check: string;
    /**
    * The check group to use in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group Powerpack#group}
    */
    readonly group?: string;
    /**
    * When `grouping = "cluster"`, indicates a list of tags to use for grouping.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: string[];
    /**
    * The kind of grouping to use. Valid values are `check`, `cluster`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#grouping Powerpack#grouping}
    */
    readonly grouping: string;
    /**
    * Hide any portion of the widget's timeframe that is incomplete due to cost data not being available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_incomplete_cost_data Powerpack#hide_incomplete_cost_data}
    */
    readonly hideIncompleteCostData?: boolean | cdktn.IResolvable;
    /**
    * The timeframe to use when displaying the widget. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#live_span Powerpack#live_span}
    */
    readonly liveSpan?: string;
    /**
    * A list of tags to use in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#tags Powerpack#tags}
    */
    readonly tags?: string[];
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title Powerpack#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_align Powerpack#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_size Powerpack#title_size}
    */
    readonly titleSize?: string;
}
export declare function powerpackWidgetCheckStatusDefinitionToTerraform(struct?: PowerpackWidgetCheckStatusDefinitionOutputReference | PowerpackWidgetCheckStatusDefinition): any;
export declare function powerpackWidgetCheckStatusDefinitionToHclTerraform(struct?: PowerpackWidgetCheckStatusDefinitionOutputReference | PowerpackWidgetCheckStatusDefinition): any;
export declare class PowerpackWidgetCheckStatusDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetCheckStatusDefinition | undefined;
    set internalValue(value: PowerpackWidgetCheckStatusDefinition | undefined);
    private _check?;
    get check(): string;
    set check(value: string);
    get checkInput(): string | undefined;
    private _group?;
    get group(): string;
    set group(value: string);
    resetGroup(): void;
    get groupInput(): string | undefined;
    private _groupBy?;
    get groupBy(): string[];
    set groupBy(value: string[]);
    resetGroupBy(): void;
    get groupByInput(): string[] | undefined;
    private _grouping?;
    get grouping(): string;
    set grouping(value: string);
    get groupingInput(): string | undefined;
    private _hideIncompleteCostData?;
    get hideIncompleteCostData(): boolean | cdktn.IResolvable;
    set hideIncompleteCostData(value: boolean | cdktn.IResolvable);
    resetHideIncompleteCostData(): void;
    get hideIncompleteCostDataInput(): boolean | cdktn.IResolvable | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
}
export interface PowerpackWidgetDistributionDefinitionRequestApmQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetDistributionDefinitionRequestApmQueryComputeQueryToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestApmQueryComputeQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestApmQueryComputeQuery): any;
export declare function powerpackWidgetDistributionDefinitionRequestApmQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestApmQueryComputeQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestApmQueryComputeQuery): any;
export declare class PowerpackWidgetDistributionDefinitionRequestApmQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestApmQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestApmQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetDistributionDefinitionRequestApmQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetDistributionDefinitionRequestApmQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestApmQueryGroupBySortQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestApmQueryGroupBySortQuery): any;
export declare function powerpackWidgetDistributionDefinitionRequestApmQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestApmQueryGroupBySortQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestApmQueryGroupBySortQuery): any;
export declare class PowerpackWidgetDistributionDefinitionRequestApmQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestApmQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestApmQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetDistributionDefinitionRequestApmQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetDistributionDefinitionRequestApmQueryGroupBySortQuery;
}
export declare function powerpackWidgetDistributionDefinitionRequestApmQueryGroupByToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestApmQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetDistributionDefinitionRequestApmQueryGroupByToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestApmQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetDistributionDefinitionRequestApmQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestApmQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestApmQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetDistributionDefinitionRequestApmQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetDistributionDefinitionRequestApmQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetDistributionDefinitionRequestApmQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetDistributionDefinitionRequestApmQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetDistributionDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetDistributionDefinitionRequestApmQueryGroupByOutputReference;
}
export interface PowerpackWidgetDistributionDefinitionRequestApmQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetDistributionDefinitionRequestApmQueryMultiComputeToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetDistributionDefinitionRequestApmQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetDistributionDefinitionRequestApmQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetDistributionDefinitionRequestApmQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetDistributionDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetDistributionDefinitionRequestApmQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetDistributionDefinitionRequestApmQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetDistributionDefinitionRequestApmQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetDistributionDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetDistributionDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetDistributionDefinitionRequestApmQueryToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestApmQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestApmQuery): any;
export declare function powerpackWidgetDistributionDefinitionRequestApmQueryToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestApmQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestApmQuery): any;
export declare class PowerpackWidgetDistributionDefinitionRequestApmQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestApmQuery | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestApmQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetDistributionDefinitionRequestApmQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetDistributionDefinitionRequestApmQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetDistributionDefinitionRequestApmQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetDistributionDefinitionRequestApmQueryGroupByList;
    putGroupBy(value: PowerpackWidgetDistributionDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetDistributionDefinitionRequestApmQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetDistributionDefinitionRequestApmQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetDistributionDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetDistributionDefinitionRequestApmQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetDistributionDefinitionRequestApmStatsQueryColumns {
    /**
    * A user-assigned alias for the column.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#alias Powerpack#alias}
    */
    readonly alias?: string;
    /**
    * A list of display modes for each table cell. Valid values are `number`, `bar`, `trend`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cell_display_mode Powerpack#cell_display_mode}
    */
    readonly cellDisplayMode?: string;
    /**
    * The column name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order?: string;
}
export declare function powerpackWidgetDistributionDefinitionRequestApmStatsQueryColumnsToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestApmStatsQueryColumns | cdktn.IResolvable): any;
export declare function powerpackWidgetDistributionDefinitionRequestApmStatsQueryColumnsToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestApmStatsQueryColumns | cdktn.IResolvable): any;
export declare class PowerpackWidgetDistributionDefinitionRequestApmStatsQueryColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestApmStatsQueryColumns | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestApmStatsQueryColumns | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _cellDisplayMode?;
    get cellDisplayMode(): string;
    set cellDisplayMode(value: string);
    resetCellDisplayMode(): void;
    get cellDisplayModeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export declare class PowerpackWidgetDistributionDefinitionRequestApmStatsQueryColumnsList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetDistributionDefinitionRequestApmStatsQueryColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetDistributionDefinitionRequestApmStatsQueryColumnsOutputReference;
}
export interface PowerpackWidgetDistributionDefinitionRequestApmStatsQuery {
    /**
    * The environment name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#env Powerpack#env}
    */
    readonly env: string;
    /**
    * The operation name associated with the service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The organization's host group name and value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag Powerpack#primary_tag}
    */
    readonly primaryTag: string;
    /**
    * The resource name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#resource Powerpack#resource}
    */
    readonly resource?: string;
    /**
    * The level of detail for the request. Valid values are `service`, `resource`, `span`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#row_type Powerpack#row_type}
    */
    readonly rowType: string;
    /**
    * The service name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#service Powerpack#service}
    */
    readonly service: string;
    /**
    * columns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#columns Powerpack#columns}
    */
    readonly columns?: PowerpackWidgetDistributionDefinitionRequestApmStatsQueryColumns[] | cdktn.IResolvable;
}
export declare function powerpackWidgetDistributionDefinitionRequestApmStatsQueryToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestApmStatsQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestApmStatsQuery): any;
export declare function powerpackWidgetDistributionDefinitionRequestApmStatsQueryToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestApmStatsQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestApmStatsQuery): any;
export declare class PowerpackWidgetDistributionDefinitionRequestApmStatsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestApmStatsQuery | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestApmStatsQuery | undefined);
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _primaryTag?;
    get primaryTag(): string;
    set primaryTag(value: string);
    get primaryTagInput(): string | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    resetResource(): void;
    get resourceInput(): string | undefined;
    private _rowType?;
    get rowType(): string;
    set rowType(value: string);
    get rowTypeInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _columns;
    get columns(): PowerpackWidgetDistributionDefinitionRequestApmStatsQueryColumnsList;
    putColumns(value: PowerpackWidgetDistributionDefinitionRequestApmStatsQueryColumns[] | cdktn.IResolvable): void;
    resetColumns(): void;
    get columnsInput(): cdktn.IResolvable | PowerpackWidgetDistributionDefinitionRequestApmStatsQueryColumns[] | undefined;
}
export interface PowerpackWidgetDistributionDefinitionRequestLogQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetDistributionDefinitionRequestLogQueryComputeQueryToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestLogQueryComputeQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestLogQueryComputeQuery): any;
export declare function powerpackWidgetDistributionDefinitionRequestLogQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestLogQueryComputeQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestLogQueryComputeQuery): any;
export declare class PowerpackWidgetDistributionDefinitionRequestLogQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestLogQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestLogQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetDistributionDefinitionRequestLogQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetDistributionDefinitionRequestLogQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestLogQueryGroupBySortQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestLogQueryGroupBySortQuery): any;
export declare function powerpackWidgetDistributionDefinitionRequestLogQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestLogQueryGroupBySortQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestLogQueryGroupBySortQuery): any;
export declare class PowerpackWidgetDistributionDefinitionRequestLogQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestLogQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestLogQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetDistributionDefinitionRequestLogQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetDistributionDefinitionRequestLogQueryGroupBySortQuery;
}
export declare function powerpackWidgetDistributionDefinitionRequestLogQueryGroupByToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestLogQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetDistributionDefinitionRequestLogQueryGroupByToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestLogQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetDistributionDefinitionRequestLogQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestLogQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestLogQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetDistributionDefinitionRequestLogQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetDistributionDefinitionRequestLogQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetDistributionDefinitionRequestLogQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetDistributionDefinitionRequestLogQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetDistributionDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetDistributionDefinitionRequestLogQueryGroupByOutputReference;
}
export interface PowerpackWidgetDistributionDefinitionRequestLogQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetDistributionDefinitionRequestLogQueryMultiComputeToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetDistributionDefinitionRequestLogQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetDistributionDefinitionRequestLogQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetDistributionDefinitionRequestLogQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetDistributionDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetDistributionDefinitionRequestLogQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetDistributionDefinitionRequestLogQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetDistributionDefinitionRequestLogQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetDistributionDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetDistributionDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetDistributionDefinitionRequestLogQueryToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestLogQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestLogQuery): any;
export declare function powerpackWidgetDistributionDefinitionRequestLogQueryToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestLogQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestLogQuery): any;
export declare class PowerpackWidgetDistributionDefinitionRequestLogQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestLogQuery | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestLogQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetDistributionDefinitionRequestLogQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetDistributionDefinitionRequestLogQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetDistributionDefinitionRequestLogQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetDistributionDefinitionRequestLogQueryGroupByList;
    putGroupBy(value: PowerpackWidgetDistributionDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetDistributionDefinitionRequestLogQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetDistributionDefinitionRequestLogQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetDistributionDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetDistributionDefinitionRequestLogQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetDistributionDefinitionRequestProcessQuery {
    /**
    * A list of processes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#filter_by Powerpack#filter_by}
    */
    readonly filterBy?: string[];
    /**
    * The max number of items in the filter list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * Your chosen metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric: string;
    /**
    * Your chosen search term.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_by Powerpack#search_by}
    */
    readonly searchBy?: string;
}
export declare function powerpackWidgetDistributionDefinitionRequestProcessQueryToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestProcessQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestProcessQuery): any;
export declare function powerpackWidgetDistributionDefinitionRequestProcessQueryToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestProcessQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestProcessQuery): any;
export declare class PowerpackWidgetDistributionDefinitionRequestProcessQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestProcessQuery | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestProcessQuery | undefined);
    private _filterBy?;
    get filterBy(): string[];
    set filterBy(value: string[]);
    resetFilterBy(): void;
    get filterByInput(): string[] | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _searchBy?;
    get searchBy(): string;
    set searchBy(value: string);
    resetSearchBy(): void;
    get searchByInput(): string | undefined;
}
export interface PowerpackWidgetDistributionDefinitionRequestRumQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetDistributionDefinitionRequestRumQueryComputeQueryToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestRumQueryComputeQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestRumQueryComputeQuery): any;
export declare function powerpackWidgetDistributionDefinitionRequestRumQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestRumQueryComputeQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestRumQueryComputeQuery): any;
export declare class PowerpackWidgetDistributionDefinitionRequestRumQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestRumQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestRumQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetDistributionDefinitionRequestRumQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetDistributionDefinitionRequestRumQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestRumQueryGroupBySortQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestRumQueryGroupBySortQuery): any;
export declare function powerpackWidgetDistributionDefinitionRequestRumQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestRumQueryGroupBySortQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestRumQueryGroupBySortQuery): any;
export declare class PowerpackWidgetDistributionDefinitionRequestRumQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestRumQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestRumQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetDistributionDefinitionRequestRumQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetDistributionDefinitionRequestRumQueryGroupBySortQuery;
}
export declare function powerpackWidgetDistributionDefinitionRequestRumQueryGroupByToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestRumQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetDistributionDefinitionRequestRumQueryGroupByToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestRumQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetDistributionDefinitionRequestRumQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestRumQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestRumQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetDistributionDefinitionRequestRumQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetDistributionDefinitionRequestRumQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetDistributionDefinitionRequestRumQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetDistributionDefinitionRequestRumQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetDistributionDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetDistributionDefinitionRequestRumQueryGroupByOutputReference;
}
export interface PowerpackWidgetDistributionDefinitionRequestRumQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetDistributionDefinitionRequestRumQueryMultiComputeToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetDistributionDefinitionRequestRumQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetDistributionDefinitionRequestRumQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetDistributionDefinitionRequestRumQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetDistributionDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetDistributionDefinitionRequestRumQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetDistributionDefinitionRequestRumQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetDistributionDefinitionRequestRumQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetDistributionDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetDistributionDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetDistributionDefinitionRequestRumQueryToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestRumQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestRumQuery): any;
export declare function powerpackWidgetDistributionDefinitionRequestRumQueryToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestRumQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestRumQuery): any;
export declare class PowerpackWidgetDistributionDefinitionRequestRumQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestRumQuery | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestRumQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetDistributionDefinitionRequestRumQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetDistributionDefinitionRequestRumQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetDistributionDefinitionRequestRumQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetDistributionDefinitionRequestRumQueryGroupByList;
    putGroupBy(value: PowerpackWidgetDistributionDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetDistributionDefinitionRequestRumQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetDistributionDefinitionRequestRumQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetDistributionDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetDistributionDefinitionRequestRumQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetDistributionDefinitionRequestSecurityQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetDistributionDefinitionRequestSecurityQueryComputeQueryToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestSecurityQueryComputeQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestSecurityQueryComputeQuery): any;
export declare function powerpackWidgetDistributionDefinitionRequestSecurityQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestSecurityQueryComputeQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestSecurityQueryComputeQuery): any;
export declare class PowerpackWidgetDistributionDefinitionRequestSecurityQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestSecurityQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestSecurityQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQuery): any;
export declare function powerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQuery): any;
export declare class PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQuery;
}
export declare function powerpackWidgetDistributionDefinitionRequestSecurityQueryGroupByToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetDistributionDefinitionRequestSecurityQueryGroupByToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupByOutputReference;
}
export interface PowerpackWidgetDistributionDefinitionRequestSecurityQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetDistributionDefinitionRequestSecurityQueryMultiComputeToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetDistributionDefinitionRequestSecurityQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetDistributionDefinitionRequestSecurityQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetDistributionDefinitionRequestSecurityQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetDistributionDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetDistributionDefinitionRequestSecurityQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetDistributionDefinitionRequestSecurityQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetDistributionDefinitionRequestSecurityQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetDistributionDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetDistributionDefinitionRequestSecurityQueryToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestSecurityQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestSecurityQuery): any;
export declare function powerpackWidgetDistributionDefinitionRequestSecurityQueryToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestSecurityQueryOutputReference | PowerpackWidgetDistributionDefinitionRequestSecurityQuery): any;
export declare class PowerpackWidgetDistributionDefinitionRequestSecurityQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestSecurityQuery | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestSecurityQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetDistributionDefinitionRequestSecurityQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetDistributionDefinitionRequestSecurityQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetDistributionDefinitionRequestSecurityQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupByList;
    putGroupBy(value: PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetDistributionDefinitionRequestSecurityQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetDistributionDefinitionRequestSecurityQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetDistributionDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetDistributionDefinitionRequestSecurityQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetDistributionDefinitionRequestStyle {
    /**
    * A color palette to apply to the widget. The available options are available at: https://docs.datadoghq.com/dashboards/widgets/timeseries/#appearance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette Powerpack#palette}
    */
    readonly palette?: string;
}
export declare function powerpackWidgetDistributionDefinitionRequestStyleToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestStyleOutputReference | PowerpackWidgetDistributionDefinitionRequestStyle): any;
export declare function powerpackWidgetDistributionDefinitionRequestStyleToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequestStyleOutputReference | PowerpackWidgetDistributionDefinitionRequestStyle): any;
export declare class PowerpackWidgetDistributionDefinitionRequestStyleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequestStyle | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequestStyle | undefined);
    private _palette?;
    get palette(): string;
    set palette(value: string);
    resetPalette(): void;
    get paletteInput(): string | undefined;
}
export interface PowerpackWidgetDistributionDefinitionRequest {
    /**
    * The metric query to use for this widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#q Powerpack#q}
    */
    readonly q?: string;
    /**
    * apm_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_query Powerpack#apm_query}
    */
    readonly apmQuery?: PowerpackWidgetDistributionDefinitionRequestApmQuery;
    /**
    * apm_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_stats_query Powerpack#apm_stats_query}
    */
    readonly apmStatsQuery?: PowerpackWidgetDistributionDefinitionRequestApmStatsQuery;
    /**
    * log_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#log_query Powerpack#log_query}
    */
    readonly logQuery?: PowerpackWidgetDistributionDefinitionRequestLogQuery;
    /**
    * process_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#process_query Powerpack#process_query}
    */
    readonly processQuery?: PowerpackWidgetDistributionDefinitionRequestProcessQuery;
    /**
    * rum_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#rum_query Powerpack#rum_query}
    */
    readonly rumQuery?: PowerpackWidgetDistributionDefinitionRequestRumQuery;
    /**
    * security_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#security_query Powerpack#security_query}
    */
    readonly securityQuery?: PowerpackWidgetDistributionDefinitionRequestSecurityQuery;
    /**
    * style block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#style Powerpack#style}
    */
    readonly style?: PowerpackWidgetDistributionDefinitionRequestStyle;
}
export declare function powerpackWidgetDistributionDefinitionRequestToTerraform(struct?: PowerpackWidgetDistributionDefinitionRequest | cdktn.IResolvable): any;
export declare function powerpackWidgetDistributionDefinitionRequestToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionRequest | cdktn.IResolvable): any;
export declare class PowerpackWidgetDistributionDefinitionRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetDistributionDefinitionRequest | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionRequest | cdktn.IResolvable | undefined);
    private _q?;
    get q(): string;
    set q(value: string);
    resetQ(): void;
    get qInput(): string | undefined;
    private _apmQuery;
    get apmQuery(): PowerpackWidgetDistributionDefinitionRequestApmQueryOutputReference;
    putApmQuery(value: PowerpackWidgetDistributionDefinitionRequestApmQuery): void;
    resetApmQuery(): void;
    get apmQueryInput(): PowerpackWidgetDistributionDefinitionRequestApmQuery | undefined;
    private _apmStatsQuery;
    get apmStatsQuery(): PowerpackWidgetDistributionDefinitionRequestApmStatsQueryOutputReference;
    putApmStatsQuery(value: PowerpackWidgetDistributionDefinitionRequestApmStatsQuery): void;
    resetApmStatsQuery(): void;
    get apmStatsQueryInput(): PowerpackWidgetDistributionDefinitionRequestApmStatsQuery | undefined;
    private _logQuery;
    get logQuery(): PowerpackWidgetDistributionDefinitionRequestLogQueryOutputReference;
    putLogQuery(value: PowerpackWidgetDistributionDefinitionRequestLogQuery): void;
    resetLogQuery(): void;
    get logQueryInput(): PowerpackWidgetDistributionDefinitionRequestLogQuery | undefined;
    private _processQuery;
    get processQuery(): PowerpackWidgetDistributionDefinitionRequestProcessQueryOutputReference;
    putProcessQuery(value: PowerpackWidgetDistributionDefinitionRequestProcessQuery): void;
    resetProcessQuery(): void;
    get processQueryInput(): PowerpackWidgetDistributionDefinitionRequestProcessQuery | undefined;
    private _rumQuery;
    get rumQuery(): PowerpackWidgetDistributionDefinitionRequestRumQueryOutputReference;
    putRumQuery(value: PowerpackWidgetDistributionDefinitionRequestRumQuery): void;
    resetRumQuery(): void;
    get rumQueryInput(): PowerpackWidgetDistributionDefinitionRequestRumQuery | undefined;
    private _securityQuery;
    get securityQuery(): PowerpackWidgetDistributionDefinitionRequestSecurityQueryOutputReference;
    putSecurityQuery(value: PowerpackWidgetDistributionDefinitionRequestSecurityQuery): void;
    resetSecurityQuery(): void;
    get securityQueryInput(): PowerpackWidgetDistributionDefinitionRequestSecurityQuery | undefined;
    private _style;
    get style(): PowerpackWidgetDistributionDefinitionRequestStyleOutputReference;
    putStyle(value: PowerpackWidgetDistributionDefinitionRequestStyle): void;
    resetStyle(): void;
    get styleInput(): PowerpackWidgetDistributionDefinitionRequestStyle | undefined;
}
export declare class PowerpackWidgetDistributionDefinitionRequestList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetDistributionDefinitionRequest[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetDistributionDefinitionRequestOutputReference;
}
export interface PowerpackWidgetDistributionDefinitionXaxis {
    /**
    * Always include zero or fit the axis to the data range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#include_zero Powerpack#include_zero}
    */
    readonly includeZero?: boolean | cdktn.IResolvable;
    /**
    * Specify the maximum value to show on the Y-axis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#max Powerpack#max}
    */
    readonly max?: string;
    /**
    * Specify the minimum value to show on the Y-axis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#min Powerpack#min}
    */
    readonly min?: string;
    /**
    * Specify the scale type, options: `linear`, `log`, `pow`, `sqrt`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#scale Powerpack#scale}
    */
    readonly scale?: string;
}
export declare function powerpackWidgetDistributionDefinitionXaxisToTerraform(struct?: PowerpackWidgetDistributionDefinitionXaxisOutputReference | PowerpackWidgetDistributionDefinitionXaxis): any;
export declare function powerpackWidgetDistributionDefinitionXaxisToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionXaxisOutputReference | PowerpackWidgetDistributionDefinitionXaxis): any;
export declare class PowerpackWidgetDistributionDefinitionXaxisOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetDistributionDefinitionXaxis | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionXaxis | undefined);
    private _includeZero?;
    get includeZero(): boolean | cdktn.IResolvable;
    set includeZero(value: boolean | cdktn.IResolvable);
    resetIncludeZero(): void;
    get includeZeroInput(): boolean | cdktn.IResolvable | undefined;
    private _max?;
    get max(): string;
    set max(value: string);
    resetMax(): void;
    get maxInput(): string | undefined;
    private _min?;
    get min(): string;
    set min(value: string);
    resetMin(): void;
    get minInput(): string | undefined;
    private _scale?;
    get scale(): string;
    set scale(value: string);
    resetScale(): void;
    get scaleInput(): string | undefined;
}
export interface PowerpackWidgetDistributionDefinitionYaxis {
    /**
    * Always include zero or fit the axis to the data range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#include_zero Powerpack#include_zero}
    */
    readonly includeZero?: boolean | cdktn.IResolvable;
    /**
    * The label of the axis to display on the graph.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label?: string;
    /**
    * Specify the maximum value to show on the Y-axis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#max Powerpack#max}
    */
    readonly max?: string;
    /**
    * Specify the minimum value to show on the Y-axis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#min Powerpack#min}
    */
    readonly min?: string;
    /**
    * Specify the scale type, options: `linear`, `log`, `pow`, `sqrt`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#scale Powerpack#scale}
    */
    readonly scale?: string;
}
export declare function powerpackWidgetDistributionDefinitionYaxisToTerraform(struct?: PowerpackWidgetDistributionDefinitionYaxisOutputReference | PowerpackWidgetDistributionDefinitionYaxis): any;
export declare function powerpackWidgetDistributionDefinitionYaxisToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionYaxisOutputReference | PowerpackWidgetDistributionDefinitionYaxis): any;
export declare class PowerpackWidgetDistributionDefinitionYaxisOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetDistributionDefinitionYaxis | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinitionYaxis | undefined);
    private _includeZero?;
    get includeZero(): boolean | cdktn.IResolvable;
    set includeZero(value: boolean | cdktn.IResolvable);
    resetIncludeZero(): void;
    get includeZeroInput(): boolean | cdktn.IResolvable | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _max?;
    get max(): string;
    set max(value: string);
    resetMax(): void;
    get maxInput(): string | undefined;
    private _min?;
    get min(): string;
    set min(value: string);
    resetMin(): void;
    get minInput(): string | undefined;
    private _scale?;
    get scale(): string;
    set scale(value: string);
    resetScale(): void;
    get scaleInput(): string | undefined;
}
export interface PowerpackWidgetDistributionDefinition {
    /**
    * Hide any portion of the widget's timeframe that is incomplete due to cost data not being available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_incomplete_cost_data Powerpack#hide_incomplete_cost_data}
    */
    readonly hideIncompleteCostData?: boolean | cdktn.IResolvable;
    /**
    * The size of the legend displayed in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#legend_size Powerpack#legend_size}
    */
    readonly legendSize?: string;
    /**
    * The timeframe to use when displaying the widget. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#live_span Powerpack#live_span}
    */
    readonly liveSpan?: string;
    /**
    * Whether or not to show the legend on this widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#show_legend Powerpack#show_legend}
    */
    readonly showLegend?: boolean | cdktn.IResolvable;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title Powerpack#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_align Powerpack#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_size Powerpack#title_size}
    */
    readonly titleSize?: string;
    /**
    * request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#request Powerpack#request}
    */
    readonly request?: PowerpackWidgetDistributionDefinitionRequest[] | cdktn.IResolvable;
    /**
    * xaxis block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#xaxis Powerpack#xaxis}
    */
    readonly xaxis?: PowerpackWidgetDistributionDefinitionXaxis;
    /**
    * yaxis block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#yaxis Powerpack#yaxis}
    */
    readonly yaxis?: PowerpackWidgetDistributionDefinitionYaxis;
}
export declare function powerpackWidgetDistributionDefinitionToTerraform(struct?: PowerpackWidgetDistributionDefinitionOutputReference | PowerpackWidgetDistributionDefinition): any;
export declare function powerpackWidgetDistributionDefinitionToHclTerraform(struct?: PowerpackWidgetDistributionDefinitionOutputReference | PowerpackWidgetDistributionDefinition): any;
export declare class PowerpackWidgetDistributionDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetDistributionDefinition | undefined;
    set internalValue(value: PowerpackWidgetDistributionDefinition | undefined);
    private _hideIncompleteCostData?;
    get hideIncompleteCostData(): boolean | cdktn.IResolvable;
    set hideIncompleteCostData(value: boolean | cdktn.IResolvable);
    resetHideIncompleteCostData(): void;
    get hideIncompleteCostDataInput(): boolean | cdktn.IResolvable | undefined;
    private _legendSize?;
    get legendSize(): string;
    set legendSize(value: string);
    resetLegendSize(): void;
    get legendSizeInput(): string | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _showLegend?;
    get showLegend(): boolean | cdktn.IResolvable;
    set showLegend(value: boolean | cdktn.IResolvable);
    resetShowLegend(): void;
    get showLegendInput(): boolean | cdktn.IResolvable | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _request;
    get request(): PowerpackWidgetDistributionDefinitionRequestList;
    putRequest(value: PowerpackWidgetDistributionDefinitionRequest[] | cdktn.IResolvable): void;
    resetRequest(): void;
    get requestInput(): cdktn.IResolvable | PowerpackWidgetDistributionDefinitionRequest[] | undefined;
    private _xaxis;
    get xaxis(): PowerpackWidgetDistributionDefinitionXaxisOutputReference;
    putXaxis(value: PowerpackWidgetDistributionDefinitionXaxis): void;
    resetXaxis(): void;
    get xaxisInput(): PowerpackWidgetDistributionDefinitionXaxis | undefined;
    private _yaxis;
    get yaxis(): PowerpackWidgetDistributionDefinitionYaxisOutputReference;
    putYaxis(value: PowerpackWidgetDistributionDefinitionYaxis): void;
    resetYaxis(): void;
    get yaxisInput(): PowerpackWidgetDistributionDefinitionYaxis | undefined;
}
export interface PowerpackWidgetEventStreamDefinition {
    /**
    * The size to use to display an event. Valid values are `s`, `l`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#event_size Powerpack#event_size}
    */
    readonly eventSize?: string;
    /**
    * Hide any portion of the widget's timeframe that is incomplete due to cost data not being available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_incomplete_cost_data Powerpack#hide_incomplete_cost_data}
    */
    readonly hideIncompleteCostData?: boolean | cdktn.IResolvable;
    /**
    * The timeframe to use when displaying the widget. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#live_span Powerpack#live_span}
    */
    readonly liveSpan?: string;
    /**
    * The query to use in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
    /**
    * The execution method for multi-value filters, options: `and` or `or`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#tags_execution Powerpack#tags_execution}
    */
    readonly tagsExecution?: string;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title Powerpack#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_align Powerpack#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_size Powerpack#title_size}
    */
    readonly titleSize?: string;
}
export declare function powerpackWidgetEventStreamDefinitionToTerraform(struct?: PowerpackWidgetEventStreamDefinitionOutputReference | PowerpackWidgetEventStreamDefinition): any;
export declare function powerpackWidgetEventStreamDefinitionToHclTerraform(struct?: PowerpackWidgetEventStreamDefinitionOutputReference | PowerpackWidgetEventStreamDefinition): any;
export declare class PowerpackWidgetEventStreamDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetEventStreamDefinition | undefined;
    set internalValue(value: PowerpackWidgetEventStreamDefinition | undefined);
    private _eventSize?;
    get eventSize(): string;
    set eventSize(value: string);
    resetEventSize(): void;
    get eventSizeInput(): string | undefined;
    private _hideIncompleteCostData?;
    get hideIncompleteCostData(): boolean | cdktn.IResolvable;
    set hideIncompleteCostData(value: boolean | cdktn.IResolvable);
    resetHideIncompleteCostData(): void;
    get hideIncompleteCostDataInput(): boolean | cdktn.IResolvable | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _tagsExecution?;
    get tagsExecution(): string;
    set tagsExecution(value: string);
    resetTagsExecution(): void;
    get tagsExecutionInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
}
export interface PowerpackWidgetEventTimelineDefinition {
    /**
    * Hide any portion of the widget's timeframe that is incomplete due to cost data not being available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_incomplete_cost_data Powerpack#hide_incomplete_cost_data}
    */
    readonly hideIncompleteCostData?: boolean | cdktn.IResolvable;
    /**
    * The timeframe to use when displaying the widget. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#live_span Powerpack#live_span}
    */
    readonly liveSpan?: string;
    /**
    * The query to use in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
    /**
    * The execution method for multi-value filters, options: `and` or `or`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#tags_execution Powerpack#tags_execution}
    */
    readonly tagsExecution?: string;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title Powerpack#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_align Powerpack#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_size Powerpack#title_size}
    */
    readonly titleSize?: string;
}
export declare function powerpackWidgetEventTimelineDefinitionToTerraform(struct?: PowerpackWidgetEventTimelineDefinitionOutputReference | PowerpackWidgetEventTimelineDefinition): any;
export declare function powerpackWidgetEventTimelineDefinitionToHclTerraform(struct?: PowerpackWidgetEventTimelineDefinitionOutputReference | PowerpackWidgetEventTimelineDefinition): any;
export declare class PowerpackWidgetEventTimelineDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetEventTimelineDefinition | undefined;
    set internalValue(value: PowerpackWidgetEventTimelineDefinition | undefined);
    private _hideIncompleteCostData?;
    get hideIncompleteCostData(): boolean | cdktn.IResolvable;
    set hideIncompleteCostData(value: boolean | cdktn.IResolvable);
    resetHideIncompleteCostData(): void;
    get hideIncompleteCostDataInput(): boolean | cdktn.IResolvable | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _tagsExecution?;
    get tagsExecution(): string;
    set tagsExecution(value: string);
    resetTagsExecution(): void;
    get tagsExecutionInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
}
export interface PowerpackWidgetFreeTextDefinition {
    /**
    * The color of the text in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#color Powerpack#color}
    */
    readonly color?: string;
    /**
    * The size of the text in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#font_size Powerpack#font_size}
    */
    readonly fontSize?: string;
    /**
    * The text to display in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#text Powerpack#text}
    */
    readonly text: string;
    /**
    * The alignment of the text in the widget. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#text_align Powerpack#text_align}
    */
    readonly textAlign?: string;
}
export declare function powerpackWidgetFreeTextDefinitionToTerraform(struct?: PowerpackWidgetFreeTextDefinitionOutputReference | PowerpackWidgetFreeTextDefinition): any;
export declare function powerpackWidgetFreeTextDefinitionToHclTerraform(struct?: PowerpackWidgetFreeTextDefinitionOutputReference | PowerpackWidgetFreeTextDefinition): any;
export declare class PowerpackWidgetFreeTextDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetFreeTextDefinition | undefined;
    set internalValue(value: PowerpackWidgetFreeTextDefinition | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _fontSize?;
    get fontSize(): string;
    set fontSize(value: string);
    resetFontSize(): void;
    get fontSizeInput(): string | undefined;
    private _text?;
    get text(): string;
    set text(value: string);
    get textInput(): string | undefined;
    private _textAlign?;
    get textAlign(): string;
    set textAlign(value: string);
    resetTextAlign(): void;
    get textAlignInput(): string | undefined;
}
export interface PowerpackWidgetGeomapDefinitionCustomLink {
    /**
    * The flag for toggling context menu link visibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_hidden Powerpack#is_hidden}
    */
    readonly isHidden?: boolean | cdktn.IResolvable;
    /**
    * The label for the custom link URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label?: string;
    /**
    * The URL of the custom link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#link Powerpack#link}
    */
    readonly link?: string;
    /**
    * The label ID that refers to a context menu link item. When `override_label` is provided, the client request omits the label field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#override_label Powerpack#override_label}
    */
    readonly overrideLabel?: string;
}
export declare function powerpackWidgetGeomapDefinitionCustomLinkToTerraform(struct?: PowerpackWidgetGeomapDefinitionCustomLink | cdktn.IResolvable): any;
export declare function powerpackWidgetGeomapDefinitionCustomLinkToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionCustomLink | cdktn.IResolvable): any;
export declare class PowerpackWidgetGeomapDefinitionCustomLinkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetGeomapDefinitionCustomLink | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionCustomLink | cdktn.IResolvable | undefined);
    private _isHidden?;
    get isHidden(): boolean | cdktn.IResolvable;
    set isHidden(value: boolean | cdktn.IResolvable);
    resetIsHidden(): void;
    get isHiddenInput(): boolean | cdktn.IResolvable | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _link?;
    get link(): string;
    set link(value: string);
    resetLink(): void;
    get linkInput(): string | undefined;
    private _overrideLabel?;
    get overrideLabel(): string;
    set overrideLabel(value: string);
    resetOverrideLabel(): void;
    get overrideLabelInput(): string | undefined;
}
export declare class PowerpackWidgetGeomapDefinitionCustomLinkList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetGeomapDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetGeomapDefinitionCustomLinkOutputReference;
}
export interface PowerpackWidgetGeomapDefinitionRequestFormulaConditionalFormats {
    /**
    * The comparator to use. Valid values are `=`, `>`, `>=`, `<`, `<=`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#comparator Powerpack#comparator}
    */
    readonly comparator: string;
    /**
    * The color palette to apply to the background, same values available as palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_bg_color Powerpack#custom_bg_color}
    */
    readonly customBgColor?: string;
    /**
    * The color palette to apply to the foreground, same values available as palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_fg_color Powerpack#custom_fg_color}
    */
    readonly customFgColor?: string;
    /**
    * Setting this to True hides values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_value Powerpack#hide_value}
    */
    readonly hideValue?: boolean | cdktn.IResolvable;
    /**
    * Displays an image as the background.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#image_url Powerpack#image_url}
    */
    readonly imageUrl?: string;
    /**
    * The metric from the request to correlate with this conditional format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
    /**
    * The color palette to apply. Valid values are `blue`, `custom_bg`, `custom_image`, `custom_text`, `gray_on_white`, `grey`, `green`, `orange`, `red`, `red_on_white`, `white_on_gray`, `white_on_green`, `green_on_white`, `white_on_red`, `white_on_yellow`, `yellow_on_white`, `black_on_light_yellow`, `black_on_light_green`, `black_on_light_red`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette Powerpack#palette}
    */
    readonly palette: string;
    /**
    * Defines the displayed timeframe.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#timeframe Powerpack#timeframe}
    */
    readonly timeframe?: string;
    /**
    * A value for the comparator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#value Powerpack#value}
    */
    readonly value: number;
}
export declare function powerpackWidgetGeomapDefinitionRequestFormulaConditionalFormatsToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable): any;
export declare function powerpackWidgetGeomapDefinitionRequestFormulaConditionalFormatsToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable): any;
export declare class PowerpackWidgetGeomapDefinitionRequestFormulaConditionalFormatsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable | undefined);
    private _comparator?;
    get comparator(): string;
    set comparator(value: string);
    get comparatorInput(): string | undefined;
    private _customBgColor?;
    get customBgColor(): string;
    set customBgColor(value: string);
    resetCustomBgColor(): void;
    get customBgColorInput(): string | undefined;
    private _customFgColor?;
    get customFgColor(): string;
    set customFgColor(value: string);
    resetCustomFgColor(): void;
    get customFgColorInput(): string | undefined;
    private _hideValue?;
    get hideValue(): boolean | cdktn.IResolvable;
    set hideValue(value: boolean | cdktn.IResolvable);
    resetHideValue(): void;
    get hideValueInput(): boolean | cdktn.IResolvable | undefined;
    private _imageUrl?;
    get imageUrl(): string;
    set imageUrl(value: string);
    resetImageUrl(): void;
    get imageUrlInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _palette?;
    get palette(): string;
    set palette(value: string);
    get paletteInput(): string | undefined;
    private _timeframe?;
    get timeframe(): string;
    set timeframe(value: string);
    resetTimeframe(): void;
    get timeframeInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class PowerpackWidgetGeomapDefinitionRequestFormulaConditionalFormatsList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetGeomapDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetGeomapDefinitionRequestFormulaConditionalFormatsOutputReference;
}
export interface PowerpackWidgetGeomapDefinitionRequestFormulaLimit {
    /**
    * The number of results to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#count Powerpack#count}
    */
    readonly count?: number;
    /**
    * The direction of the sort. Valid values are `asc`, `desc`. Defaults to `"desc"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order?: string;
}
export declare function powerpackWidgetGeomapDefinitionRequestFormulaLimitToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestFormulaLimitOutputReference | PowerpackWidgetGeomapDefinitionRequestFormulaLimit): any;
export declare function powerpackWidgetGeomapDefinitionRequestFormulaLimitToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestFormulaLimitOutputReference | PowerpackWidgetGeomapDefinitionRequestFormulaLimit): any;
export declare class PowerpackWidgetGeomapDefinitionRequestFormulaLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestFormulaLimit | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestFormulaLimit | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    resetCount(): void;
    get countInput(): number | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonical {
    /**
    * per unit name. If you want to represent megabytes/s, you set 'unit_name' = 'megabyte' and 'per_unit_name = 'second'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#per_unit_name Powerpack#per_unit_name}
    */
    readonly perUnitName?: string;
    /**
    * Unit name. It should be in singular form ('megabyte' and not 'megabytes')
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit_name Powerpack#unit_name}
    */
    readonly unitName: string;
}
export declare function powerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonicalToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference | PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonical): any;
export declare function powerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonicalToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference | PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonical): any;
export declare class PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonical | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonical | undefined);
    private _perUnitName?;
    get perUnitName(): string;
    set perUnitName(value: string);
    resetPerUnitName(): void;
    get perUnitNameInput(): string | undefined;
    private _unitName?;
    get unitName(): string;
    set unitName(value: string);
    get unitNameInput(): string | undefined;
}
export interface PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustom {
    /**
    * Unit label
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label: string;
}
export declare function powerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustomToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustomOutputReference | PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustom): any;
export declare function powerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustomToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustomOutputReference | PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustom): any;
export declare class PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustom | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustom | undefined);
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
}
export interface PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnit {
    /**
    * canonical block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#canonical Powerpack#canonical}
    */
    readonly canonical?: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonical;
    /**
    * custom block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom Powerpack#custom}
    */
    readonly custom?: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustom;
}
export declare function powerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitOutputReference | PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnit): any;
export declare function powerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitOutputReference | PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnit): any;
export declare class PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnit | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnit | undefined);
    private _canonical;
    get canonical(): PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference;
    putCanonical(value: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonical): void;
    resetCanonical(): void;
    get canonicalInput(): PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCanonical | undefined;
    private _custom;
    get custom(): PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustomOutputReference;
    putCustom(value: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustom): void;
    resetCustom(): void;
    get customInput(): PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitCustom | undefined;
}
export interface PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit_name Powerpack#unit_name}
    */
    readonly unitName: string;
}
export declare function powerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScaleToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScaleOutputReference | PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScale): any;
export declare function powerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScaleToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScaleOutputReference | PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScale): any;
export declare class PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScale | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScale | undefined);
    private _unitName?;
    get unitName(): string;
    set unitName(value: string);
    get unitNameInput(): string | undefined;
}
export interface PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormat {
    /**
    * unit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit Powerpack#unit}
    */
    readonly unit: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnit;
    /**
    * unit_scale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit_scale Powerpack#unit_scale}
    */
    readonly unitScale?: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScale;
}
export declare function powerpackWidgetGeomapDefinitionRequestFormulaNumberFormatToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatOutputReference | PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormat): any;
export declare function powerpackWidgetGeomapDefinitionRequestFormulaNumberFormatToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatOutputReference | PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormat): any;
export declare class PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormat | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormat | undefined);
    private _unit;
    get unit(): PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitOutputReference;
    putUnit(value: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnit): void;
    get unitInput(): PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnit | undefined;
    private _unitScale;
    get unitScale(): PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScaleOutputReference;
    putUnitScale(value: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScale): void;
    resetUnitScale(): void;
    get unitScaleInput(): PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatUnitScale | undefined;
}
export interface PowerpackWidgetGeomapDefinitionRequestFormulaStyle {
    /**
    * The color palette used to display the formula. A guide to the available color palettes can be found at https://docs.datadoghq.com/dashboards/guide/widget_colors.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette Powerpack#palette}
    */
    readonly palette?: string;
    /**
    * Index specifying which color to use within the palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette_index Powerpack#palette_index}
    */
    readonly paletteIndex?: number;
}
export declare function powerpackWidgetGeomapDefinitionRequestFormulaStyleToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestFormulaStyleOutputReference | PowerpackWidgetGeomapDefinitionRequestFormulaStyle): any;
export declare function powerpackWidgetGeomapDefinitionRequestFormulaStyleToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestFormulaStyleOutputReference | PowerpackWidgetGeomapDefinitionRequestFormulaStyle): any;
export declare class PowerpackWidgetGeomapDefinitionRequestFormulaStyleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestFormulaStyle | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestFormulaStyle | undefined);
    private _palette?;
    get palette(): string;
    set palette(value: string);
    resetPalette(): void;
    get paletteInput(): string | undefined;
    private _paletteIndex?;
    get paletteIndex(): number;
    set paletteIndex(value: number);
    resetPaletteIndex(): void;
    get paletteIndexInput(): number | undefined;
}
export interface PowerpackWidgetGeomapDefinitionRequestFormula {
    /**
    * An expression alias.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#alias Powerpack#alias}
    */
    readonly alias?: string;
    /**
    * A list of display modes for each table cell. Valid values are `number`, `bar`, `trend`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cell_display_mode Powerpack#cell_display_mode}
    */
    readonly cellDisplayMode?: string;
    /**
    * A string expression built from queries, formulas, and functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#formula_expression Powerpack#formula_expression}
    */
    readonly formulaExpression: string;
    /**
    * conditional_formats block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#conditional_formats Powerpack#conditional_formats}
    */
    readonly conditionalFormats?: PowerpackWidgetGeomapDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: PowerpackWidgetGeomapDefinitionRequestFormulaLimit;
    /**
    * number_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#number_format Powerpack#number_format}
    */
    readonly numberFormat?: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormat;
    /**
    * style block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#style Powerpack#style}
    */
    readonly style?: PowerpackWidgetGeomapDefinitionRequestFormulaStyle;
}
export declare function powerpackWidgetGeomapDefinitionRequestFormulaToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestFormula | cdktn.IResolvable): any;
export declare function powerpackWidgetGeomapDefinitionRequestFormulaToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestFormula | cdktn.IResolvable): any;
export declare class PowerpackWidgetGeomapDefinitionRequestFormulaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestFormula | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestFormula | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _cellDisplayMode?;
    get cellDisplayMode(): string;
    set cellDisplayMode(value: string);
    resetCellDisplayMode(): void;
    get cellDisplayModeInput(): string | undefined;
    private _formulaExpression?;
    get formulaExpression(): string;
    set formulaExpression(value: string);
    get formulaExpressionInput(): string | undefined;
    private _conditionalFormats;
    get conditionalFormats(): PowerpackWidgetGeomapDefinitionRequestFormulaConditionalFormatsList;
    putConditionalFormats(value: PowerpackWidgetGeomapDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable): void;
    resetConditionalFormats(): void;
    get conditionalFormatsInput(): cdktn.IResolvable | PowerpackWidgetGeomapDefinitionRequestFormulaConditionalFormats[] | undefined;
    private _limit;
    get limit(): PowerpackWidgetGeomapDefinitionRequestFormulaLimitOutputReference;
    putLimit(value: PowerpackWidgetGeomapDefinitionRequestFormulaLimit): void;
    resetLimit(): void;
    get limitInput(): PowerpackWidgetGeomapDefinitionRequestFormulaLimit | undefined;
    private _numberFormat;
    get numberFormat(): PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormatOutputReference;
    putNumberFormat(value: PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormat): void;
    resetNumberFormat(): void;
    get numberFormatInput(): PowerpackWidgetGeomapDefinitionRequestFormulaNumberFormat | undefined;
    private _style;
    get style(): PowerpackWidgetGeomapDefinitionRequestFormulaStyleOutputReference;
    putStyle(value: PowerpackWidgetGeomapDefinitionRequestFormulaStyle): void;
    resetStyle(): void;
    get styleInput(): PowerpackWidgetGeomapDefinitionRequestFormulaStyle | undefined;
}
export declare class PowerpackWidgetGeomapDefinitionRequestFormulaList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetGeomapDefinitionRequestFormula[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetGeomapDefinitionRequestFormulaOutputReference;
}
export interface PowerpackWidgetGeomapDefinitionRequestLogQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetGeomapDefinitionRequestLogQueryComputeQueryToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestLogQueryComputeQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestLogQueryComputeQuery): any;
export declare function powerpackWidgetGeomapDefinitionRequestLogQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestLogQueryComputeQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestLogQueryComputeQuery): any;
export declare class PowerpackWidgetGeomapDefinitionRequestLogQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestLogQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestLogQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetGeomapDefinitionRequestLogQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetGeomapDefinitionRequestLogQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestLogQueryGroupBySortQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestLogQueryGroupBySortQuery): any;
export declare function powerpackWidgetGeomapDefinitionRequestLogQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestLogQueryGroupBySortQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestLogQueryGroupBySortQuery): any;
export declare class PowerpackWidgetGeomapDefinitionRequestLogQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestLogQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestLogQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetGeomapDefinitionRequestLogQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetGeomapDefinitionRequestLogQueryGroupBySortQuery;
}
export declare function powerpackWidgetGeomapDefinitionRequestLogQueryGroupByToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestLogQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetGeomapDefinitionRequestLogQueryGroupByToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestLogQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetGeomapDefinitionRequestLogQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestLogQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestLogQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetGeomapDefinitionRequestLogQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetGeomapDefinitionRequestLogQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetGeomapDefinitionRequestLogQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetGeomapDefinitionRequestLogQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetGeomapDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetGeomapDefinitionRequestLogQueryGroupByOutputReference;
}
export interface PowerpackWidgetGeomapDefinitionRequestLogQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetGeomapDefinitionRequestLogQueryMultiComputeToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetGeomapDefinitionRequestLogQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetGeomapDefinitionRequestLogQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetGeomapDefinitionRequestLogQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetGeomapDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetGeomapDefinitionRequestLogQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetGeomapDefinitionRequestLogQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetGeomapDefinitionRequestLogQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetGeomapDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetGeomapDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetGeomapDefinitionRequestLogQueryToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestLogQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestLogQuery): any;
export declare function powerpackWidgetGeomapDefinitionRequestLogQueryToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestLogQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestLogQuery): any;
export declare class PowerpackWidgetGeomapDefinitionRequestLogQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestLogQuery | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestLogQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetGeomapDefinitionRequestLogQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetGeomapDefinitionRequestLogQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetGeomapDefinitionRequestLogQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetGeomapDefinitionRequestLogQueryGroupByList;
    putGroupBy(value: PowerpackWidgetGeomapDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetGeomapDefinitionRequestLogQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetGeomapDefinitionRequestLogQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetGeomapDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetGeomapDefinitionRequestLogQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetGeomapDefinitionRequestQueryApmDependencyStatsQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for APM Dependency Stats queries. Valid values are `apm_dependency_stats`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * APM environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#env Powerpack#env}
    */
    readonly env: string;
    /**
    * Determines whether stats for upstream or downstream dependencies should be queried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_upstream Powerpack#is_upstream}
    */
    readonly isUpstream?: boolean | cdktn.IResolvable;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Name of operation on service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#operation_name Powerpack#operation_name}
    */
    readonly operationName: string;
    /**
    * The name of the second primary tag used within APM; required when `primary_tag_value` is specified. See https://docs.datadoghq.com/tracing/guide/setting_primary_tags_to_scope/#add-a-second-primary-tag-in-datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_name Powerpack#primary_tag_name}
    */
    readonly primaryTagName?: string;
    /**
    * Filter APM data by the second primary tag. `primary_tag_name` must also be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_value Powerpack#primary_tag_value}
    */
    readonly primaryTagValue?: string;
    /**
    * APM resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#resource_name Powerpack#resource_name}
    */
    readonly resourceName: string;
    /**
    * APM service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#service Powerpack#service}
    */
    readonly service: string;
    /**
    * APM statistic. Valid values are `avg_duration`, `avg_root_duration`, `avg_spans_per_trace`, `error_rate`, `pct_exec_time`, `pct_of_traces`, `total_traces_count`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#stat Powerpack#stat}
    */
    readonly stat: string;
}
export declare function powerpackWidgetGeomapDefinitionRequestQueryApmDependencyStatsQueryToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQueryApmDependencyStatsQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestQueryApmDependencyStatsQuery): any;
export declare function powerpackWidgetGeomapDefinitionRequestQueryApmDependencyStatsQueryToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQueryApmDependencyStatsQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestQueryApmDependencyStatsQuery): any;
export declare class PowerpackWidgetGeomapDefinitionRequestQueryApmDependencyStatsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestQueryApmDependencyStatsQuery | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestQueryApmDependencyStatsQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    private _isUpstream?;
    get isUpstream(): boolean | cdktn.IResolvable;
    set isUpstream(value: boolean | cdktn.IResolvable);
    resetIsUpstream(): void;
    get isUpstreamInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    get operationNameInput(): string | undefined;
    private _primaryTagName?;
    get primaryTagName(): string;
    set primaryTagName(value: string);
    resetPrimaryTagName(): void;
    get primaryTagNameInput(): string | undefined;
    private _primaryTagValue?;
    get primaryTagValue(): string;
    set primaryTagValue(value: string);
    resetPrimaryTagValue(): void;
    get primaryTagValueInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    get resourceNameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    get statInput(): string | undefined;
}
export interface PowerpackWidgetGeomapDefinitionRequestQueryApmResourceStatsQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for APM Resource Stats queries. Valid values are `apm_resource_stats`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * APM environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#env Powerpack#env}
    */
    readonly env: string;
    /**
    * Array of fields to group results by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: string[];
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Name of operation on service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#operation_name Powerpack#operation_name}
    */
    readonly operationName?: string;
    /**
    * The name of the second primary tag used within APM; required when `primary_tag_value` is specified. See https://docs.datadoghq.com/tracing/guide/setting_primary_tags_to_scope/#add-a-second-primary-tag-in-datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_name Powerpack#primary_tag_name}
    */
    readonly primaryTagName?: string;
    /**
    * Filter APM data by the second primary tag. `primary_tag_name` must also be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_value Powerpack#primary_tag_value}
    */
    readonly primaryTagValue?: string;
    /**
    * APM resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#resource_name Powerpack#resource_name}
    */
    readonly resourceName?: string;
    /**
    * APM service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#service Powerpack#service}
    */
    readonly service: string;
    /**
    * APM statistic. Valid values are `errors`, `error_rate`, `hits`, `latency_avg`, `latency_distribution`, `latency_max`, `latency_p50`, `latency_p75`, `latency_p90`, `latency_p95`, `latency_p99`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#stat Powerpack#stat}
    */
    readonly stat: string;
}
export declare function powerpackWidgetGeomapDefinitionRequestQueryApmResourceStatsQueryToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQueryApmResourceStatsQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestQueryApmResourceStatsQuery): any;
export declare function powerpackWidgetGeomapDefinitionRequestQueryApmResourceStatsQueryToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQueryApmResourceStatsQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestQueryApmResourceStatsQuery): any;
export declare class PowerpackWidgetGeomapDefinitionRequestQueryApmResourceStatsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestQueryApmResourceStatsQuery | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestQueryApmResourceStatsQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    private _groupBy?;
    get groupBy(): string[];
    set groupBy(value: string[]);
    resetGroupBy(): void;
    get groupByInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    resetOperationName(): void;
    get operationNameInput(): string | undefined;
    private _primaryTagName?;
    get primaryTagName(): string;
    set primaryTagName(value: string);
    resetPrimaryTagName(): void;
    get primaryTagNameInput(): string | undefined;
    private _primaryTagValue?;
    get primaryTagValue(): string;
    set primaryTagValue(value: string);
    resetPrimaryTagValue(): void;
    get primaryTagValueInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    resetResourceName(): void;
    get resourceNameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    get statInput(): string | undefined;
}
export interface PowerpackWidgetGeomapDefinitionRequestQueryCloudCostQuery {
    /**
    * The aggregation methods available for cloud cost queries. Valid values are `avg`, `last`, `max`, `min`, `sum`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for cloud cost queries. Valid values are `cloud_cost`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The cloud cost query definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
}
export declare function powerpackWidgetGeomapDefinitionRequestQueryCloudCostQueryToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQueryCloudCostQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestQueryCloudCostQuery): any;
export declare function powerpackWidgetGeomapDefinitionRequestQueryCloudCostQueryToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQueryCloudCostQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestQueryCloudCostQuery): any;
export declare class PowerpackWidgetGeomapDefinitionRequestQueryCloudCostQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestQueryCloudCostQuery | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestQueryCloudCostQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface PowerpackWidgetGeomapDefinitionRequestQueryEventQueryCompute {
    /**
    * The aggregation methods for event platform queries. Valid values are `count`, `cardinality`, `median`, `pc75`, `pc90`, `pc95`, `pc98`, `pc99`, `sum`, `min`, `max`, `avg`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * A time interval in milliseconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
    /**
    * The measurable attribute to compute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
}
export declare function powerpackWidgetGeomapDefinitionRequestQueryEventQueryComputeToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetGeomapDefinitionRequestQueryEventQueryComputeToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetGeomapDefinitionRequestQueryEventQueryComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
}
export declare class PowerpackWidgetGeomapDefinitionRequestQueryEventQueryComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetGeomapDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetGeomapDefinitionRequestQueryEventQueryComputeOutputReference;
}
export interface PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBySort {
    /**
    * The aggregation methods for the event platform queries. Valid values are `count`, `cardinality`, `median`, `pc75`, `pc90`, `pc95`, `pc98`, `pc99`, `sum`, `min`, `max`, `avg`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The metric used for sorting group by results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
    /**
    * Direction of sort. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order?: string;
}
export declare function powerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBySortToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBySortOutputReference | PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBySort): any;
export declare function powerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBySortToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBySortOutputReference | PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBySort): any;
export declare class PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBySortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBySort | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBySort | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBy {
    /**
    * The event facet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet: string;
    /**
    * The number of groups to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort Powerpack#sort}
    */
    readonly sort?: PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBySort;
}
export declare function powerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupByToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupByToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sort;
    get sort(): PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBySortOutputReference;
    putSort(value: PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBySort): void;
    resetSort(): void;
    get sortInput(): PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBySort | undefined;
}
export declare class PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupByOutputReference;
}
export interface PowerpackWidgetGeomapDefinitionRequestQueryEventQuerySearch {
    /**
    * The events search string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
}
export declare function powerpackWidgetGeomapDefinitionRequestQueryEventQuerySearchToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQueryEventQuerySearchOutputReference | PowerpackWidgetGeomapDefinitionRequestQueryEventQuerySearch): any;
export declare function powerpackWidgetGeomapDefinitionRequestQueryEventQuerySearchToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQueryEventQuerySearchOutputReference | PowerpackWidgetGeomapDefinitionRequestQueryEventQuerySearch): any;
export declare class PowerpackWidgetGeomapDefinitionRequestQueryEventQuerySearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestQueryEventQuerySearch | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestQueryEventQuerySearch | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface PowerpackWidgetGeomapDefinitionRequestQueryEventQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for event platform-based queries. Valid values are `logs`, `spans`, `network`, `rum`, `security_signals`, `profiles`, `audit`, `events`, `ci_tests`, `ci_pipelines`, `incident_analytics`, `product_analytics`, `on_call_events`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * An array of index names to query in the stream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#indexes Powerpack#indexes}
    */
    readonly indexes?: string[];
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Storage location (private beta).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#storage Powerpack#storage}
    */
    readonly storage?: string;
    /**
    * compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute Powerpack#compute}
    */
    readonly compute: PowerpackWidgetGeomapDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable;
    /**
    * search block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search Powerpack#search}
    */
    readonly search?: PowerpackWidgetGeomapDefinitionRequestQueryEventQuerySearch;
}
export declare function powerpackWidgetGeomapDefinitionRequestQueryEventQueryToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQueryEventQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestQueryEventQuery): any;
export declare function powerpackWidgetGeomapDefinitionRequestQueryEventQueryToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQueryEventQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestQueryEventQuery): any;
export declare class PowerpackWidgetGeomapDefinitionRequestQueryEventQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestQueryEventQuery | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestQueryEventQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _indexes?;
    get indexes(): string[];
    set indexes(value: string[]);
    resetIndexes(): void;
    get indexesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _storage?;
    get storage(): string;
    set storage(value: string);
    resetStorage(): void;
    get storageInput(): string | undefined;
    private _compute;
    get compute(): PowerpackWidgetGeomapDefinitionRequestQueryEventQueryComputeList;
    putCompute(value: PowerpackWidgetGeomapDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable): void;
    get computeInput(): cdktn.IResolvable | PowerpackWidgetGeomapDefinitionRequestQueryEventQueryCompute[] | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupByList;
    putGroupBy(value: PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetGeomapDefinitionRequestQueryEventQueryGroupBy[] | undefined;
    private _search;
    get search(): PowerpackWidgetGeomapDefinitionRequestQueryEventQuerySearchOutputReference;
    putSearch(value: PowerpackWidgetGeomapDefinitionRequestQueryEventQuerySearch): void;
    resetSearch(): void;
    get searchInput(): PowerpackWidgetGeomapDefinitionRequestQueryEventQuerySearch | undefined;
}
export interface PowerpackWidgetGeomapDefinitionRequestQueryMetricQuery {
    /**
    * The aggregation methods available for metrics queries. Valid values are `avg`, `min`, `max`, `sum`, `last`, `area`, `l2norm`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for metrics queries. Defaults to `"metrics"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource?: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The metrics query definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
    /**
    * Semantic mode for metrics queries. This determines how metrics from different sources are combined or displayed. Valid values are `combined`, `native`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#semantic_mode Powerpack#semantic_mode}
    */
    readonly semanticMode?: string;
}
export declare function powerpackWidgetGeomapDefinitionRequestQueryMetricQueryToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQueryMetricQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestQueryMetricQuery): any;
export declare function powerpackWidgetGeomapDefinitionRequestQueryMetricQueryToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQueryMetricQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestQueryMetricQuery): any;
export declare class PowerpackWidgetGeomapDefinitionRequestQueryMetricQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestQueryMetricQuery | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestQueryMetricQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    resetDataSource(): void;
    get dataSourceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _semanticMode?;
    get semanticMode(): string;
    set semanticMode(value: string);
    resetSemanticMode(): void;
    get semanticModeInput(): string | undefined;
}
export interface PowerpackWidgetGeomapDefinitionRequestQueryProcessQuery {
    /**
    * The aggregation methods available for metrics queries. Valid values are `avg`, `min`, `max`, `sum`, `last`, `area`, `l2norm`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for process queries. Valid values are `process`, `container`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * Whether to normalize the CPU percentages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_normalized_cpu Powerpack#is_normalized_cpu}
    */
    readonly isNormalizedCpu?: boolean | cdktn.IResolvable;
    /**
    * The number of hits to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * The process metric name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric: string;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The direction of the sort. Valid values are `asc`, `desc`. Defaults to `"desc"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort Powerpack#sort}
    */
    readonly sort?: string;
    /**
    * An array of tags to filter by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#tag_filters Powerpack#tag_filters}
    */
    readonly tagFilters?: string[];
    /**
    * The text to use as a filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#text_filter Powerpack#text_filter}
    */
    readonly textFilter?: string;
}
export declare function powerpackWidgetGeomapDefinitionRequestQueryProcessQueryToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQueryProcessQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestQueryProcessQuery): any;
export declare function powerpackWidgetGeomapDefinitionRequestQueryProcessQueryToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQueryProcessQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestQueryProcessQuery): any;
export declare class PowerpackWidgetGeomapDefinitionRequestQueryProcessQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestQueryProcessQuery | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestQueryProcessQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _isNormalizedCpu?;
    get isNormalizedCpu(): boolean | cdktn.IResolvable;
    set isNormalizedCpu(value: boolean | cdktn.IResolvable);
    resetIsNormalizedCpu(): void;
    get isNormalizedCpuInput(): boolean | cdktn.IResolvable | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _sort?;
    get sort(): string;
    set sort(value: string);
    resetSort(): void;
    get sortInput(): string | undefined;
    private _tagFilters?;
    get tagFilters(): string[];
    set tagFilters(value: string[]);
    resetTagFilters(): void;
    get tagFiltersInput(): string[] | undefined;
    private _textFilter?;
    get textFilter(): string;
    set textFilter(value: string);
    resetTextFilter(): void;
    get textFilterInput(): string | undefined;
}
export interface PowerpackWidgetGeomapDefinitionRequestQuerySloQuery {
    /**
    * Additional filters applied to the SLO query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#additional_query_filters Powerpack#additional_query_filters}
    */
    readonly additionalQueryFilters?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for SLO queries. Valid values are `slo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * Group mode to query measures. Valid values are `overall`, `components`. Defaults to `"overall"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_mode Powerpack#group_mode}
    */
    readonly groupMode?: string;
    /**
    * SLO measures queries. Valid values are `good_events`, `bad_events`, `good_minutes`, `bad_minutes`, `slo_status`, `error_budget_remaining`, `burn_rate`, `error_budget_burndown`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#measure Powerpack#measure}
    */
    readonly measure: string;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name?: string;
    /**
    * ID of an SLO to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_id Powerpack#slo_id}
    */
    readonly sloId: string;
    /**
    * type of the SLO to query. Valid values are `metric`, `monitor`, `time_slice`. Defaults to `"metric"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_query_type Powerpack#slo_query_type}
    */
    readonly sloQueryType?: string;
}
export declare function powerpackWidgetGeomapDefinitionRequestQuerySloQueryToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQuerySloQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestQuerySloQuery): any;
export declare function powerpackWidgetGeomapDefinitionRequestQuerySloQueryToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQuerySloQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestQuerySloQuery): any;
export declare class PowerpackWidgetGeomapDefinitionRequestQuerySloQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestQuerySloQuery | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestQuerySloQuery | undefined);
    private _additionalQueryFilters?;
    get additionalQueryFilters(): string;
    set additionalQueryFilters(value: string);
    resetAdditionalQueryFilters(): void;
    get additionalQueryFiltersInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _groupMode?;
    get groupMode(): string;
    set groupMode(value: string);
    resetGroupMode(): void;
    get groupModeInput(): string | undefined;
    private _measure?;
    get measure(): string;
    set measure(value: string);
    get measureInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sloId?;
    get sloId(): string;
    set sloId(value: string);
    get sloIdInput(): string | undefined;
    private _sloQueryType?;
    get sloQueryType(): string;
    set sloQueryType(value: string);
    resetSloQueryType(): void;
    get sloQueryTypeInput(): string | undefined;
}
export interface PowerpackWidgetGeomapDefinitionRequestQuery {
    /**
    * apm_dependency_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_dependency_stats_query Powerpack#apm_dependency_stats_query}
    */
    readonly apmDependencyStatsQuery?: PowerpackWidgetGeomapDefinitionRequestQueryApmDependencyStatsQuery;
    /**
    * apm_resource_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_resource_stats_query Powerpack#apm_resource_stats_query}
    */
    readonly apmResourceStatsQuery?: PowerpackWidgetGeomapDefinitionRequestQueryApmResourceStatsQuery;
    /**
    * cloud_cost_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cloud_cost_query Powerpack#cloud_cost_query}
    */
    readonly cloudCostQuery?: PowerpackWidgetGeomapDefinitionRequestQueryCloudCostQuery;
    /**
    * event_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#event_query Powerpack#event_query}
    */
    readonly eventQuery?: PowerpackWidgetGeomapDefinitionRequestQueryEventQuery;
    /**
    * metric_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric_query Powerpack#metric_query}
    */
    readonly metricQuery?: PowerpackWidgetGeomapDefinitionRequestQueryMetricQuery;
    /**
    * process_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#process_query Powerpack#process_query}
    */
    readonly processQuery?: PowerpackWidgetGeomapDefinitionRequestQueryProcessQuery;
    /**
    * slo_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_query Powerpack#slo_query}
    */
    readonly sloQuery?: PowerpackWidgetGeomapDefinitionRequestQuerySloQuery;
}
export declare function powerpackWidgetGeomapDefinitionRequestQueryToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQuery | cdktn.IResolvable): any;
export declare function powerpackWidgetGeomapDefinitionRequestQueryToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestQuery | cdktn.IResolvable): any;
export declare class PowerpackWidgetGeomapDefinitionRequestQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestQuery | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestQuery | cdktn.IResolvable | undefined);
    private _apmDependencyStatsQuery;
    get apmDependencyStatsQuery(): PowerpackWidgetGeomapDefinitionRequestQueryApmDependencyStatsQueryOutputReference;
    putApmDependencyStatsQuery(value: PowerpackWidgetGeomapDefinitionRequestQueryApmDependencyStatsQuery): void;
    resetApmDependencyStatsQuery(): void;
    get apmDependencyStatsQueryInput(): PowerpackWidgetGeomapDefinitionRequestQueryApmDependencyStatsQuery | undefined;
    private _apmResourceStatsQuery;
    get apmResourceStatsQuery(): PowerpackWidgetGeomapDefinitionRequestQueryApmResourceStatsQueryOutputReference;
    putApmResourceStatsQuery(value: PowerpackWidgetGeomapDefinitionRequestQueryApmResourceStatsQuery): void;
    resetApmResourceStatsQuery(): void;
    get apmResourceStatsQueryInput(): PowerpackWidgetGeomapDefinitionRequestQueryApmResourceStatsQuery | undefined;
    private _cloudCostQuery;
    get cloudCostQuery(): PowerpackWidgetGeomapDefinitionRequestQueryCloudCostQueryOutputReference;
    putCloudCostQuery(value: PowerpackWidgetGeomapDefinitionRequestQueryCloudCostQuery): void;
    resetCloudCostQuery(): void;
    get cloudCostQueryInput(): PowerpackWidgetGeomapDefinitionRequestQueryCloudCostQuery | undefined;
    private _eventQuery;
    get eventQuery(): PowerpackWidgetGeomapDefinitionRequestQueryEventQueryOutputReference;
    putEventQuery(value: PowerpackWidgetGeomapDefinitionRequestQueryEventQuery): void;
    resetEventQuery(): void;
    get eventQueryInput(): PowerpackWidgetGeomapDefinitionRequestQueryEventQuery | undefined;
    private _metricQuery;
    get metricQuery(): PowerpackWidgetGeomapDefinitionRequestQueryMetricQueryOutputReference;
    putMetricQuery(value: PowerpackWidgetGeomapDefinitionRequestQueryMetricQuery): void;
    resetMetricQuery(): void;
    get metricQueryInput(): PowerpackWidgetGeomapDefinitionRequestQueryMetricQuery | undefined;
    private _processQuery;
    get processQuery(): PowerpackWidgetGeomapDefinitionRequestQueryProcessQueryOutputReference;
    putProcessQuery(value: PowerpackWidgetGeomapDefinitionRequestQueryProcessQuery): void;
    resetProcessQuery(): void;
    get processQueryInput(): PowerpackWidgetGeomapDefinitionRequestQueryProcessQuery | undefined;
    private _sloQuery;
    get sloQuery(): PowerpackWidgetGeomapDefinitionRequestQuerySloQueryOutputReference;
    putSloQuery(value: PowerpackWidgetGeomapDefinitionRequestQuerySloQuery): void;
    resetSloQuery(): void;
    get sloQueryInput(): PowerpackWidgetGeomapDefinitionRequestQuerySloQuery | undefined;
}
export declare class PowerpackWidgetGeomapDefinitionRequestQueryList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetGeomapDefinitionRequestQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetGeomapDefinitionRequestQueryOutputReference;
}
export interface PowerpackWidgetGeomapDefinitionRequestRumQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetGeomapDefinitionRequestRumQueryComputeQueryToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestRumQueryComputeQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestRumQueryComputeQuery): any;
export declare function powerpackWidgetGeomapDefinitionRequestRumQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestRumQueryComputeQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestRumQueryComputeQuery): any;
export declare class PowerpackWidgetGeomapDefinitionRequestRumQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestRumQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestRumQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetGeomapDefinitionRequestRumQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetGeomapDefinitionRequestRumQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestRumQueryGroupBySortQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestRumQueryGroupBySortQuery): any;
export declare function powerpackWidgetGeomapDefinitionRequestRumQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestRumQueryGroupBySortQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestRumQueryGroupBySortQuery): any;
export declare class PowerpackWidgetGeomapDefinitionRequestRumQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestRumQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestRumQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetGeomapDefinitionRequestRumQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetGeomapDefinitionRequestRumQueryGroupBySortQuery;
}
export declare function powerpackWidgetGeomapDefinitionRequestRumQueryGroupByToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestRumQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetGeomapDefinitionRequestRumQueryGroupByToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestRumQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetGeomapDefinitionRequestRumQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestRumQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestRumQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetGeomapDefinitionRequestRumQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetGeomapDefinitionRequestRumQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetGeomapDefinitionRequestRumQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetGeomapDefinitionRequestRumQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetGeomapDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetGeomapDefinitionRequestRumQueryGroupByOutputReference;
}
export interface PowerpackWidgetGeomapDefinitionRequestRumQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetGeomapDefinitionRequestRumQueryMultiComputeToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetGeomapDefinitionRequestRumQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetGeomapDefinitionRequestRumQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetGeomapDefinitionRequestRumQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetGeomapDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetGeomapDefinitionRequestRumQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetGeomapDefinitionRequestRumQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetGeomapDefinitionRequestRumQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetGeomapDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetGeomapDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetGeomapDefinitionRequestRumQueryToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestRumQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestRumQuery): any;
export declare function powerpackWidgetGeomapDefinitionRequestRumQueryToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequestRumQueryOutputReference | PowerpackWidgetGeomapDefinitionRequestRumQuery): any;
export declare class PowerpackWidgetGeomapDefinitionRequestRumQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequestRumQuery | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequestRumQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetGeomapDefinitionRequestRumQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetGeomapDefinitionRequestRumQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetGeomapDefinitionRequestRumQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetGeomapDefinitionRequestRumQueryGroupByList;
    putGroupBy(value: PowerpackWidgetGeomapDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetGeomapDefinitionRequestRumQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetGeomapDefinitionRequestRumQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetGeomapDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetGeomapDefinitionRequestRumQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetGeomapDefinitionRequest {
    /**
    * The metric query to use for this widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#q Powerpack#q}
    */
    readonly q?: string;
    /**
    * formula block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#formula Powerpack#formula}
    */
    readonly formula?: PowerpackWidgetGeomapDefinitionRequestFormula[] | cdktn.IResolvable;
    /**
    * log_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#log_query Powerpack#log_query}
    */
    readonly logQuery?: PowerpackWidgetGeomapDefinitionRequestLogQuery;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query?: PowerpackWidgetGeomapDefinitionRequestQuery[] | cdktn.IResolvable;
    /**
    * rum_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#rum_query Powerpack#rum_query}
    */
    readonly rumQuery?: PowerpackWidgetGeomapDefinitionRequestRumQuery;
}
export declare function powerpackWidgetGeomapDefinitionRequestToTerraform(struct?: PowerpackWidgetGeomapDefinitionRequest | cdktn.IResolvable): any;
export declare function powerpackWidgetGeomapDefinitionRequestToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionRequest | cdktn.IResolvable): any;
export declare class PowerpackWidgetGeomapDefinitionRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetGeomapDefinitionRequest | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionRequest | cdktn.IResolvable | undefined);
    private _q?;
    get q(): string;
    set q(value: string);
    resetQ(): void;
    get qInput(): string | undefined;
    private _formula;
    get formula(): PowerpackWidgetGeomapDefinitionRequestFormulaList;
    putFormula(value: PowerpackWidgetGeomapDefinitionRequestFormula[] | cdktn.IResolvable): void;
    resetFormula(): void;
    get formulaInput(): cdktn.IResolvable | PowerpackWidgetGeomapDefinitionRequestFormula[] | undefined;
    private _logQuery;
    get logQuery(): PowerpackWidgetGeomapDefinitionRequestLogQueryOutputReference;
    putLogQuery(value: PowerpackWidgetGeomapDefinitionRequestLogQuery): void;
    resetLogQuery(): void;
    get logQueryInput(): PowerpackWidgetGeomapDefinitionRequestLogQuery | undefined;
    private _query;
    get query(): PowerpackWidgetGeomapDefinitionRequestQueryList;
    putQuery(value: PowerpackWidgetGeomapDefinitionRequestQuery[] | cdktn.IResolvable): void;
    resetQuery(): void;
    get queryInput(): cdktn.IResolvable | PowerpackWidgetGeomapDefinitionRequestQuery[] | undefined;
    private _rumQuery;
    get rumQuery(): PowerpackWidgetGeomapDefinitionRequestRumQueryOutputReference;
    putRumQuery(value: PowerpackWidgetGeomapDefinitionRequestRumQuery): void;
    resetRumQuery(): void;
    get rumQueryInput(): PowerpackWidgetGeomapDefinitionRequestRumQuery | undefined;
}
export declare class PowerpackWidgetGeomapDefinitionRequestList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetGeomapDefinitionRequest[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetGeomapDefinitionRequestOutputReference;
}
export interface PowerpackWidgetGeomapDefinitionStyle {
    /**
    * The color palette to apply to the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette Powerpack#palette}
    */
    readonly palette: string;
    /**
    * A Boolean indicating whether to flip the palette tones.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette_flip Powerpack#palette_flip}
    */
    readonly paletteFlip: boolean | cdktn.IResolvable;
}
export declare function powerpackWidgetGeomapDefinitionStyleToTerraform(struct?: PowerpackWidgetGeomapDefinitionStyleOutputReference | PowerpackWidgetGeomapDefinitionStyle): any;
export declare function powerpackWidgetGeomapDefinitionStyleToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionStyleOutputReference | PowerpackWidgetGeomapDefinitionStyle): any;
export declare class PowerpackWidgetGeomapDefinitionStyleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionStyle | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionStyle | undefined);
    private _palette?;
    get palette(): string;
    set palette(value: string);
    get paletteInput(): string | undefined;
    private _paletteFlip?;
    get paletteFlip(): boolean | cdktn.IResolvable;
    set paletteFlip(value: boolean | cdktn.IResolvable);
    get paletteFlipInput(): boolean | cdktn.IResolvable | undefined;
}
export interface PowerpackWidgetGeomapDefinitionView {
    /**
    * The two-letter ISO code of a country to focus the map on (or `WORLD`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#focus Powerpack#focus}
    */
    readonly focus: string;
}
export declare function powerpackWidgetGeomapDefinitionViewToTerraform(struct?: PowerpackWidgetGeomapDefinitionViewOutputReference | PowerpackWidgetGeomapDefinitionView): any;
export declare function powerpackWidgetGeomapDefinitionViewToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionViewOutputReference | PowerpackWidgetGeomapDefinitionView): any;
export declare class PowerpackWidgetGeomapDefinitionViewOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinitionView | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinitionView | undefined);
    private _focus?;
    get focus(): string;
    set focus(value: string);
    get focusInput(): string | undefined;
}
export interface PowerpackWidgetGeomapDefinition {
    /**
    * Hide any portion of the widget's timeframe that is incomplete due to cost data not being available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_incomplete_cost_data Powerpack#hide_incomplete_cost_data}
    */
    readonly hideIncompleteCostData?: boolean | cdktn.IResolvable;
    /**
    * The timeframe to use when displaying the widget. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#live_span Powerpack#live_span}
    */
    readonly liveSpan?: string;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title Powerpack#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_align Powerpack#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_size Powerpack#title_size}
    */
    readonly titleSize?: string;
    /**
    * custom_link block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_link Powerpack#custom_link}
    */
    readonly customLink?: PowerpackWidgetGeomapDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#request Powerpack#request}
    */
    readonly request?: PowerpackWidgetGeomapDefinitionRequest[] | cdktn.IResolvable;
    /**
    * style block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#style Powerpack#style}
    */
    readonly style?: PowerpackWidgetGeomapDefinitionStyle;
    /**
    * view block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#view Powerpack#view}
    */
    readonly view: PowerpackWidgetGeomapDefinitionView;
}
export declare function powerpackWidgetGeomapDefinitionToTerraform(struct?: PowerpackWidgetGeomapDefinitionOutputReference | PowerpackWidgetGeomapDefinition): any;
export declare function powerpackWidgetGeomapDefinitionToHclTerraform(struct?: PowerpackWidgetGeomapDefinitionOutputReference | PowerpackWidgetGeomapDefinition): any;
export declare class PowerpackWidgetGeomapDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetGeomapDefinition | undefined;
    set internalValue(value: PowerpackWidgetGeomapDefinition | undefined);
    private _hideIncompleteCostData?;
    get hideIncompleteCostData(): boolean | cdktn.IResolvable;
    set hideIncompleteCostData(value: boolean | cdktn.IResolvable);
    resetHideIncompleteCostData(): void;
    get hideIncompleteCostDataInput(): boolean | cdktn.IResolvable | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _customLink;
    get customLink(): PowerpackWidgetGeomapDefinitionCustomLinkList;
    putCustomLink(value: PowerpackWidgetGeomapDefinitionCustomLink[] | cdktn.IResolvable): void;
    resetCustomLink(): void;
    get customLinkInput(): cdktn.IResolvable | PowerpackWidgetGeomapDefinitionCustomLink[] | undefined;
    private _request;
    get request(): PowerpackWidgetGeomapDefinitionRequestList;
    putRequest(value: PowerpackWidgetGeomapDefinitionRequest[] | cdktn.IResolvable): void;
    resetRequest(): void;
    get requestInput(): cdktn.IResolvable | PowerpackWidgetGeomapDefinitionRequest[] | undefined;
    private _style;
    get style(): PowerpackWidgetGeomapDefinitionStyleOutputReference;
    putStyle(value: PowerpackWidgetGeomapDefinitionStyle): void;
    resetStyle(): void;
    get styleInput(): PowerpackWidgetGeomapDefinitionStyle | undefined;
    private _view;
    get view(): PowerpackWidgetGeomapDefinitionViewOutputReference;
    putView(value: PowerpackWidgetGeomapDefinitionView): void;
    get viewInput(): PowerpackWidgetGeomapDefinitionView | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionCustomLink {
    /**
    * The flag for toggling context menu link visibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_hidden Powerpack#is_hidden}
    */
    readonly isHidden?: boolean | cdktn.IResolvable;
    /**
    * The label for the custom link URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label?: string;
    /**
    * The URL of the custom link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#link Powerpack#link}
    */
    readonly link?: string;
    /**
    * The label ID that refers to a context menu link item. When `override_label` is provided, the client request omits the label field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#override_label Powerpack#override_label}
    */
    readonly overrideLabel?: string;
}
export declare function powerpackWidgetHeatmapDefinitionCustomLinkToTerraform(struct?: PowerpackWidgetHeatmapDefinitionCustomLink | cdktn.IResolvable): any;
export declare function powerpackWidgetHeatmapDefinitionCustomLinkToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionCustomLink | cdktn.IResolvable): any;
export declare class PowerpackWidgetHeatmapDefinitionCustomLinkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHeatmapDefinitionCustomLink | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionCustomLink | cdktn.IResolvable | undefined);
    private _isHidden?;
    get isHidden(): boolean | cdktn.IResolvable;
    set isHidden(value: boolean | cdktn.IResolvable);
    resetIsHidden(): void;
    get isHiddenInput(): boolean | cdktn.IResolvable | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _link?;
    get link(): string;
    set link(value: string);
    resetLink(): void;
    get linkInput(): string | undefined;
    private _overrideLabel?;
    get overrideLabel(): string;
    set overrideLabel(value: string);
    resetOverrideLabel(): void;
    get overrideLabelInput(): string | undefined;
}
export declare class PowerpackWidgetHeatmapDefinitionCustomLinkList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHeatmapDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHeatmapDefinitionCustomLinkOutputReference;
}
export interface PowerpackWidgetHeatmapDefinitionEvent {
    /**
    * The event query to use in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#q Powerpack#q}
    */
    readonly q: string;
    /**
    * The execution method for multi-value filters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#tags_execution Powerpack#tags_execution}
    */
    readonly tagsExecution?: string;
}
export declare function powerpackWidgetHeatmapDefinitionEventToTerraform(struct?: PowerpackWidgetHeatmapDefinitionEvent | cdktn.IResolvable): any;
export declare function powerpackWidgetHeatmapDefinitionEventToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionEvent | cdktn.IResolvable): any;
export declare class PowerpackWidgetHeatmapDefinitionEventOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHeatmapDefinitionEvent | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionEvent | cdktn.IResolvable | undefined);
    private _q?;
    get q(): string;
    set q(value: string);
    get qInput(): string | undefined;
    private _tagsExecution?;
    get tagsExecution(): string;
    set tagsExecution(value: string);
    resetTagsExecution(): void;
    get tagsExecutionInput(): string | undefined;
}
export declare class PowerpackWidgetHeatmapDefinitionEventList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHeatmapDefinitionEvent[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHeatmapDefinitionEventOutputReference;
}
export interface PowerpackWidgetHeatmapDefinitionRequestApmQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHeatmapDefinitionRequestApmQueryComputeQueryToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestApmQueryComputeQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestApmQueryComputeQuery): any;
export declare function powerpackWidgetHeatmapDefinitionRequestApmQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestApmQueryComputeQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestApmQueryComputeQuery): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestApmQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestApmQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestApmQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
