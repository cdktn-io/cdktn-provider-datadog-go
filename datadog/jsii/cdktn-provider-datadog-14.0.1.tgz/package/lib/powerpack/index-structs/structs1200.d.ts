/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
import { PowerpackWidgetScatterplotDefinitionRequestXLogQueryComputeQuery, PowerpackWidgetScatterplotDefinitionRequestXLogQueryComputeQueryOutputReference, PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBy, PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupByList, PowerpackWidgetScatterplotDefinitionRequestXLogQueryMultiCompute, PowerpackWidgetScatterplotDefinitionRequestXLogQueryMultiComputeList, PowerpackWidgetScatterplotDefinitionRequestXApmQuery, PowerpackWidgetScatterplotDefinitionRequestXApmQueryOutputReference, PowerpackWidgetScatterplotDefinitionRequestScatterplotTable, PowerpackWidgetScatterplotDefinitionRequestScatterplotTableList, PowerpackWidgetScatterplotDefinitionCustomLink, PowerpackWidgetScatterplotDefinitionCustomLinkList } from './structs800';
export interface PowerpackWidgetScatterplotDefinitionRequestXLogQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetScatterplotDefinitionRequestXLogQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetScatterplotDefinitionRequestXLogQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetScatterplotDefinitionRequestXLogQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXLogQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXLogQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestXLogQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXLogQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXLogQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestXLogQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestXLogQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestXLogQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetScatterplotDefinitionRequestXLogQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetScatterplotDefinitionRequestXLogQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetScatterplotDefinitionRequestXLogQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupByList;
    putGroupBy(value: PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetScatterplotDefinitionRequestXLogQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetScatterplotDefinitionRequestXLogQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestXLogQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestXProcessQuery {
    /**
    * A list of processes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#filter_by Powerpack#filter_by}
    */
    readonly filterBy?: string[];
    /**
    * The max number of items in the filter list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * Your chosen metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric: string;
    /**
    * Your chosen search term.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_by Powerpack#search_by}
    */
    readonly searchBy?: string;
}
export declare function powerpackWidgetScatterplotDefinitionRequestXProcessQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXProcessQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXProcessQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestXProcessQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXProcessQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXProcessQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestXProcessQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestXProcessQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestXProcessQuery | undefined);
    private _filterBy?;
    get filterBy(): string[];
    set filterBy(value: string[]);
    resetFilterBy(): void;
    get filterByInput(): string[] | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _searchBy?;
    get searchBy(): string;
    set searchBy(value: string);
    resetSearchBy(): void;
    get searchByInput(): string | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestXRumQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetScatterplotDefinitionRequestXRumQueryComputeQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXRumQueryComputeQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXRumQueryComputeQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestXRumQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXRumQueryComputeQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXRumQueryComputeQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestXRumQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestXRumQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestXRumQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBySortQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBySortQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBySortQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBySortQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBySortQuery;
}
export declare function powerpackWidgetScatterplotDefinitionRequestXRumQueryGroupByToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestXRumQueryGroupByToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupByOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequestXRumQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetScatterplotDefinitionRequestXRumQueryMultiComputeToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXRumQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestXRumQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXRumQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestXRumQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestXRumQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestXRumQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestXRumQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestXRumQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestXRumQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequestXRumQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetScatterplotDefinitionRequestXRumQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetScatterplotDefinitionRequestXRumQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetScatterplotDefinitionRequestXRumQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXRumQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXRumQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestXRumQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXRumQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXRumQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestXRumQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestXRumQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestXRumQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetScatterplotDefinitionRequestXRumQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetScatterplotDefinitionRequestXRumQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetScatterplotDefinitionRequestXRumQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupByList;
    putGroupBy(value: PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestXRumQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetScatterplotDefinitionRequestXRumQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetScatterplotDefinitionRequestXRumQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestXRumQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetScatterplotDefinitionRequestXSecurityQueryComputeQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryComputeQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryComputeQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestXSecurityQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryComputeQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryComputeQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBySortQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBySortQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBySortQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBySortQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBySortQuery;
}
export declare function powerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupByToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupByToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupByOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetScatterplotDefinitionRequestXSecurityQueryMultiComputeToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestXSecurityQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequestXSecurityQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetScatterplotDefinitionRequestXSecurityQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXSecurityQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestXSecurityQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXSecurityQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestXSecurityQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestXSecurityQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupByList;
    putGroupBy(value: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestX {
    /**
    * Aggregator used for the request. Valid values are `avg`, `last`, `max`, `min`, `sum`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The metric query to use for this widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#q Powerpack#q}
    */
    readonly q?: string;
    /**
    * apm_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_query Powerpack#apm_query}
    */
    readonly apmQuery?: PowerpackWidgetScatterplotDefinitionRequestXApmQuery;
    /**
    * log_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#log_query Powerpack#log_query}
    */
    readonly logQuery?: PowerpackWidgetScatterplotDefinitionRequestXLogQuery;
    /**
    * process_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#process_query Powerpack#process_query}
    */
    readonly processQuery?: PowerpackWidgetScatterplotDefinitionRequestXProcessQuery;
    /**
    * rum_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#rum_query Powerpack#rum_query}
    */
    readonly rumQuery?: PowerpackWidgetScatterplotDefinitionRequestXRumQuery;
    /**
    * security_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#security_query Powerpack#security_query}
    */
    readonly securityQuery?: PowerpackWidgetScatterplotDefinitionRequestXSecurityQuery;
}
export declare function powerpackWidgetScatterplotDefinitionRequestXToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestX | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestXToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestX | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestXOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestX | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestX | cdktn.IResolvable | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _q?;
    get q(): string;
    set q(value: string);
    resetQ(): void;
    get qInput(): string | undefined;
    private _apmQuery;
    get apmQuery(): PowerpackWidgetScatterplotDefinitionRequestXApmQueryOutputReference;
    putApmQuery(value: PowerpackWidgetScatterplotDefinitionRequestXApmQuery): void;
    resetApmQuery(): void;
    get apmQueryInput(): PowerpackWidgetScatterplotDefinitionRequestXApmQuery | undefined;
    private _logQuery;
    get logQuery(): PowerpackWidgetScatterplotDefinitionRequestXLogQueryOutputReference;
    putLogQuery(value: PowerpackWidgetScatterplotDefinitionRequestXLogQuery): void;
    resetLogQuery(): void;
    get logQueryInput(): PowerpackWidgetScatterplotDefinitionRequestXLogQuery | undefined;
    private _processQuery;
    get processQuery(): PowerpackWidgetScatterplotDefinitionRequestXProcessQueryOutputReference;
    putProcessQuery(value: PowerpackWidgetScatterplotDefinitionRequestXProcessQuery): void;
    resetProcessQuery(): void;
    get processQueryInput(): PowerpackWidgetScatterplotDefinitionRequestXProcessQuery | undefined;
    private _rumQuery;
    get rumQuery(): PowerpackWidgetScatterplotDefinitionRequestXRumQueryOutputReference;
    putRumQuery(value: PowerpackWidgetScatterplotDefinitionRequestXRumQuery): void;
    resetRumQuery(): void;
    get rumQueryInput(): PowerpackWidgetScatterplotDefinitionRequestXRumQuery | undefined;
    private _securityQuery;
    get securityQuery(): PowerpackWidgetScatterplotDefinitionRequestXSecurityQueryOutputReference;
    putSecurityQuery(value: PowerpackWidgetScatterplotDefinitionRequestXSecurityQuery): void;
    resetSecurityQuery(): void;
    get securityQueryInput(): PowerpackWidgetScatterplotDefinitionRequestXSecurityQuery | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestXList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestX[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestXOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequestYApmQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetScatterplotDefinitionRequestYApmQueryComputeQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYApmQueryComputeQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYApmQueryComputeQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestYApmQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYApmQueryComputeQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYApmQueryComputeQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestYApmQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestYApmQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestYApmQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBySortQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBySortQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBySortQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBySortQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBySortQuery;
}
export declare function powerpackWidgetScatterplotDefinitionRequestYApmQueryGroupByToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestYApmQueryGroupByToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupByOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequestYApmQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetScatterplotDefinitionRequestYApmQueryMultiComputeToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYApmQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestYApmQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYApmQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestYApmQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestYApmQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestYApmQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestYApmQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestYApmQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestYApmQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequestYApmQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetScatterplotDefinitionRequestYApmQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetScatterplotDefinitionRequestYApmQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetScatterplotDefinitionRequestYApmQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYApmQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYApmQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestYApmQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYApmQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYApmQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestYApmQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestYApmQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestYApmQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetScatterplotDefinitionRequestYApmQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetScatterplotDefinitionRequestYApmQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetScatterplotDefinitionRequestYApmQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupByList;
    putGroupBy(value: PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestYApmQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetScatterplotDefinitionRequestYApmQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetScatterplotDefinitionRequestYApmQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestYApmQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestYLogQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetScatterplotDefinitionRequestYLogQueryComputeQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYLogQueryComputeQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYLogQueryComputeQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestYLogQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYLogQueryComputeQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYLogQueryComputeQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestYLogQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestYLogQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestYLogQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBySortQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBySortQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBySortQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBySortQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBySortQuery;
}
export declare function powerpackWidgetScatterplotDefinitionRequestYLogQueryGroupByToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestYLogQueryGroupByToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupByOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequestYLogQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetScatterplotDefinitionRequestYLogQueryMultiComputeToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYLogQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestYLogQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYLogQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestYLogQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestYLogQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestYLogQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestYLogQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestYLogQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestYLogQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequestYLogQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetScatterplotDefinitionRequestYLogQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetScatterplotDefinitionRequestYLogQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetScatterplotDefinitionRequestYLogQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYLogQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYLogQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestYLogQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYLogQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYLogQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestYLogQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestYLogQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestYLogQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetScatterplotDefinitionRequestYLogQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetScatterplotDefinitionRequestYLogQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetScatterplotDefinitionRequestYLogQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupByList;
    putGroupBy(value: PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestYLogQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetScatterplotDefinitionRequestYLogQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetScatterplotDefinitionRequestYLogQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestYLogQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestYProcessQuery {
    /**
    * A list of processes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#filter_by Powerpack#filter_by}
    */
    readonly filterBy?: string[];
    /**
    * The max number of items in the filter list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * Your chosen metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric: string;
    /**
    * Your chosen search term.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_by Powerpack#search_by}
    */
    readonly searchBy?: string;
}
export declare function powerpackWidgetScatterplotDefinitionRequestYProcessQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYProcessQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYProcessQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestYProcessQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYProcessQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYProcessQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestYProcessQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestYProcessQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestYProcessQuery | undefined);
    private _filterBy?;
    get filterBy(): string[];
    set filterBy(value: string[]);
    resetFilterBy(): void;
    get filterByInput(): string[] | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _searchBy?;
    get searchBy(): string;
    set searchBy(value: string);
    resetSearchBy(): void;
    get searchByInput(): string | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestYRumQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetScatterplotDefinitionRequestYRumQueryComputeQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYRumQueryComputeQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYRumQueryComputeQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestYRumQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYRumQueryComputeQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYRumQueryComputeQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestYRumQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestYRumQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestYRumQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBySortQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBySortQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBySortQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBySortQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBySortQuery;
}
export declare function powerpackWidgetScatterplotDefinitionRequestYRumQueryGroupByToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestYRumQueryGroupByToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupByOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequestYRumQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetScatterplotDefinitionRequestYRumQueryMultiComputeToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYRumQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestYRumQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYRumQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestYRumQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestYRumQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestYRumQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestYRumQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestYRumQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestYRumQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequestYRumQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetScatterplotDefinitionRequestYRumQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetScatterplotDefinitionRequestYRumQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetScatterplotDefinitionRequestYRumQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYRumQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYRumQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestYRumQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYRumQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYRumQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestYRumQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestYRumQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestYRumQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetScatterplotDefinitionRequestYRumQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetScatterplotDefinitionRequestYRumQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetScatterplotDefinitionRequestYRumQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupByList;
    putGroupBy(value: PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestYRumQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetScatterplotDefinitionRequestYRumQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetScatterplotDefinitionRequestYRumQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestYRumQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetScatterplotDefinitionRequestYSecurityQueryComputeQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryComputeQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryComputeQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestYSecurityQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryComputeQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryComputeQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBySortQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBySortQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBySortQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBySortQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBySortQuery;
}
export declare function powerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupByToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupByToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupByOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetScatterplotDefinitionRequestYSecurityQueryMultiComputeToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestYSecurityQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequestYSecurityQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetScatterplotDefinitionRequestYSecurityQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYSecurityQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestYSecurityQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestYSecurityQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestYSecurityQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestYSecurityQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupByList;
    putGroupBy(value: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestY {
    /**
    * Aggregator used for the request. Valid values are `avg`, `last`, `max`, `min`, `sum`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The metric query to use for this widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#q Powerpack#q}
    */
    readonly q?: string;
    /**
    * apm_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_query Powerpack#apm_query}
    */
    readonly apmQuery?: PowerpackWidgetScatterplotDefinitionRequestYApmQuery;
    /**
    * log_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#log_query Powerpack#log_query}
    */
    readonly logQuery?: PowerpackWidgetScatterplotDefinitionRequestYLogQuery;
    /**
    * process_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#process_query Powerpack#process_query}
    */
    readonly processQuery?: PowerpackWidgetScatterplotDefinitionRequestYProcessQuery;
    /**
    * rum_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#rum_query Powerpack#rum_query}
    */
    readonly rumQuery?: PowerpackWidgetScatterplotDefinitionRequestYRumQuery;
    /**
    * security_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#security_query Powerpack#security_query}
    */
    readonly securityQuery?: PowerpackWidgetScatterplotDefinitionRequestYSecurityQuery;
}
export declare function powerpackWidgetScatterplotDefinitionRequestYToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestY | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestYToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestY | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestYOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestY | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestY | cdktn.IResolvable | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _q?;
    get q(): string;
    set q(value: string);
    resetQ(): void;
    get qInput(): string | undefined;
    private _apmQuery;
    get apmQuery(): PowerpackWidgetScatterplotDefinitionRequestYApmQueryOutputReference;
    putApmQuery(value: PowerpackWidgetScatterplotDefinitionRequestYApmQuery): void;
    resetApmQuery(): void;
    get apmQueryInput(): PowerpackWidgetScatterplotDefinitionRequestYApmQuery | undefined;
    private _logQuery;
    get logQuery(): PowerpackWidgetScatterplotDefinitionRequestYLogQueryOutputReference;
    putLogQuery(value: PowerpackWidgetScatterplotDefinitionRequestYLogQuery): void;
    resetLogQuery(): void;
    get logQueryInput(): PowerpackWidgetScatterplotDefinitionRequestYLogQuery | undefined;
    private _processQuery;
    get processQuery(): PowerpackWidgetScatterplotDefinitionRequestYProcessQueryOutputReference;
    putProcessQuery(value: PowerpackWidgetScatterplotDefinitionRequestYProcessQuery): void;
    resetProcessQuery(): void;
    get processQueryInput(): PowerpackWidgetScatterplotDefinitionRequestYProcessQuery | undefined;
    private _rumQuery;
    get rumQuery(): PowerpackWidgetScatterplotDefinitionRequestYRumQueryOutputReference;
    putRumQuery(value: PowerpackWidgetScatterplotDefinitionRequestYRumQuery): void;
    resetRumQuery(): void;
    get rumQueryInput(): PowerpackWidgetScatterplotDefinitionRequestYRumQuery | undefined;
    private _securityQuery;
    get securityQuery(): PowerpackWidgetScatterplotDefinitionRequestYSecurityQueryOutputReference;
    putSecurityQuery(value: PowerpackWidgetScatterplotDefinitionRequestYSecurityQuery): void;
    resetSecurityQuery(): void;
    get securityQueryInput(): PowerpackWidgetScatterplotDefinitionRequestYSecurityQuery | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestYList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestY[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestYOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequest {
    /**
    * scatterplot_table block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#scatterplot_table Powerpack#scatterplot_table}
    */
    readonly scatterplotTable?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTable[] | cdktn.IResolvable;
    /**
    * x block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#x Powerpack#x}
    */
    readonly x?: PowerpackWidgetScatterplotDefinitionRequestX[] | cdktn.IResolvable;
    /**
    * y block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#y Powerpack#y}
    */
    readonly y?: PowerpackWidgetScatterplotDefinitionRequestY[] | cdktn.IResolvable;
}
export declare function powerpackWidgetScatterplotDefinitionRequestToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestOutputReference | PowerpackWidgetScatterplotDefinitionRequest): any;
export declare function powerpackWidgetScatterplotDefinitionRequestToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestOutputReference | PowerpackWidgetScatterplotDefinitionRequest): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequest | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequest | undefined);
    private _scatterplotTable;
    get scatterplotTable(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableList;
    putScatterplotTable(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTable[] | cdktn.IResolvable): void;
    resetScatterplotTable(): void;
    get scatterplotTableInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestScatterplotTable[] | undefined;
    private _x;
    get x(): PowerpackWidgetScatterplotDefinitionRequestXList;
    putX(value: PowerpackWidgetScatterplotDefinitionRequestX[] | cdktn.IResolvable): void;
    resetX(): void;
    get xInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestX[] | undefined;
    private _y;
    get y(): PowerpackWidgetScatterplotDefinitionRequestYList;
    putY(value: PowerpackWidgetScatterplotDefinitionRequestY[] | cdktn.IResolvable): void;
    resetY(): void;
    get yInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestY[] | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionXaxis {
    /**
    * Always include zero or fit the axis to the data range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#include_zero Powerpack#include_zero}
    */
    readonly includeZero?: boolean | cdktn.IResolvable;
    /**
    * The label of the axis to display on the graph.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label?: string;
    /**
    * Specify the maximum value to show on the Y-axis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#max Powerpack#max}
    */
    readonly max?: string;
    /**
    * Specify the minimum value to show on the Y-axis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#min Powerpack#min}
    */
    readonly min?: string;
    /**
    * Specify the scale type, options: `linear`, `log`, `pow`, `sqrt`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#scale Powerpack#scale}
    */
    readonly scale?: string;
}
export declare function powerpackWidgetScatterplotDefinitionXaxisToTerraform(struct?: PowerpackWidgetScatterplotDefinitionXaxisOutputReference | PowerpackWidgetScatterplotDefinitionXaxis): any;
export declare function powerpackWidgetScatterplotDefinitionXaxisToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionXaxisOutputReference | PowerpackWidgetScatterplotDefinitionXaxis): any;
export declare class PowerpackWidgetScatterplotDefinitionXaxisOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionXaxis | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionXaxis | undefined);
    private _includeZero?;
    get includeZero(): boolean | cdktn.IResolvable;
    set includeZero(value: boolean | cdktn.IResolvable);
    resetIncludeZero(): void;
    get includeZeroInput(): boolean | cdktn.IResolvable | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _max?;
    get max(): string;
    set max(value: string);
    resetMax(): void;
    get maxInput(): string | undefined;
    private _min?;
    get min(): string;
    set min(value: string);
    resetMin(): void;
    get minInput(): string | undefined;
    private _scale?;
    get scale(): string;
    set scale(value: string);
    resetScale(): void;
    get scaleInput(): string | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionYaxis {
    /**
    * Always include zero or fit the axis to the data range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#include_zero Powerpack#include_zero}
    */
    readonly includeZero?: boolean | cdktn.IResolvable;
    /**
    * The label of the axis to display on the graph.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label?: string;
    /**
    * Specify the maximum value to show on the Y-axis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#max Powerpack#max}
    */
    readonly max?: string;
    /**
    * Specify the minimum value to show on the Y-axis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#min Powerpack#min}
    */
    readonly min?: string;
    /**
    * Specify the scale type, options: `linear`, `log`, `pow`, `sqrt`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#scale Powerpack#scale}
    */
    readonly scale?: string;
}
export declare function powerpackWidgetScatterplotDefinitionYaxisToTerraform(struct?: PowerpackWidgetScatterplotDefinitionYaxisOutputReference | PowerpackWidgetScatterplotDefinitionYaxis): any;
export declare function powerpackWidgetScatterplotDefinitionYaxisToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionYaxisOutputReference | PowerpackWidgetScatterplotDefinitionYaxis): any;
export declare class PowerpackWidgetScatterplotDefinitionYaxisOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionYaxis | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionYaxis | undefined);
    private _includeZero?;
    get includeZero(): boolean | cdktn.IResolvable;
    set includeZero(value: boolean | cdktn.IResolvable);
    resetIncludeZero(): void;
    get includeZeroInput(): boolean | cdktn.IResolvable | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _max?;
    get max(): string;
    set max(value: string);
    resetMax(): void;
    get maxInput(): string | undefined;
    private _min?;
    get min(): string;
    set min(value: string);
    resetMin(): void;
    get minInput(): string | undefined;
    private _scale?;
    get scale(): string;
    set scale(value: string);
    resetScale(): void;
    get scaleInput(): string | undefined;
}
export interface PowerpackWidgetScatterplotDefinition {
    /**
    * List of groups used for colors.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#color_by_groups Powerpack#color_by_groups}
    */
    readonly colorByGroups?: string[];
    /**
    * Hide any portion of the widget's timeframe that is incomplete due to cost data not being available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_incomplete_cost_data Powerpack#hide_incomplete_cost_data}
    */
    readonly hideIncompleteCostData?: boolean | cdktn.IResolvable;
    /**
    * The timeframe to use when displaying the widget. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#live_span Powerpack#live_span}
    */
    readonly liveSpan?: string;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title Powerpack#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_align Powerpack#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_size Powerpack#title_size}
    */
    readonly titleSize?: string;
    /**
    * custom_link block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_link Powerpack#custom_link}
    */
    readonly customLink?: PowerpackWidgetScatterplotDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#request Powerpack#request}
    */
    readonly request?: PowerpackWidgetScatterplotDefinitionRequest;
    /**
    * xaxis block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#xaxis Powerpack#xaxis}
    */
    readonly xaxis?: PowerpackWidgetScatterplotDefinitionXaxis;
    /**
    * yaxis block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#yaxis Powerpack#yaxis}
    */
    readonly yaxis?: PowerpackWidgetScatterplotDefinitionYaxis;
}
export declare function powerpackWidgetScatterplotDefinitionToTerraform(struct?: PowerpackWidgetScatterplotDefinitionOutputReference | PowerpackWidgetScatterplotDefinition): any;
export declare function powerpackWidgetScatterplotDefinitionToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionOutputReference | PowerpackWidgetScatterplotDefinition): any;
export declare class PowerpackWidgetScatterplotDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinition | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinition | undefined);
    private _colorByGroups?;
    get colorByGroups(): string[];
    set colorByGroups(value: string[]);
    resetColorByGroups(): void;
    get colorByGroupsInput(): string[] | undefined;
    private _hideIncompleteCostData?;
    get hideIncompleteCostData(): boolean | cdktn.IResolvable;
    set hideIncompleteCostData(value: boolean | cdktn.IResolvable);
    resetHideIncompleteCostData(): void;
    get hideIncompleteCostDataInput(): boolean | cdktn.IResolvable | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _customLink;
    get customLink(): PowerpackWidgetScatterplotDefinitionCustomLinkList;
    putCustomLink(value: PowerpackWidgetScatterplotDefinitionCustomLink[] | cdktn.IResolvable): void;
    resetCustomLink(): void;
    get customLinkInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionCustomLink[] | undefined;
    private _request;
    get request(): PowerpackWidgetScatterplotDefinitionRequestOutputReference;
    putRequest(value: PowerpackWidgetScatterplotDefinitionRequest): void;
    resetRequest(): void;
    get requestInput(): PowerpackWidgetScatterplotDefinitionRequest | undefined;
    private _xaxis;
    get xaxis(): PowerpackWidgetScatterplotDefinitionXaxisOutputReference;
    putXaxis(value: PowerpackWidgetScatterplotDefinitionXaxis): void;
    resetXaxis(): void;
    get xaxisInput(): PowerpackWidgetScatterplotDefinitionXaxis | undefined;
    private _yaxis;
    get yaxis(): PowerpackWidgetScatterplotDefinitionYaxisOutputReference;
    putYaxis(value: PowerpackWidgetScatterplotDefinitionYaxis): void;
    resetYaxis(): void;
    get yaxisInput(): PowerpackWidgetScatterplotDefinitionYaxis | undefined;
}
export interface PowerpackWidgetServiceLevelObjectiveDefinition {
    /**
    * Additional filters applied to the SLO query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#additional_query_filters Powerpack#additional_query_filters}
    */
    readonly additionalQueryFilters?: string;
    /**
    * The global time target of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#global_time_target Powerpack#global_time_target}
    */
    readonly globalTimeTarget?: string;
    /**
    * Whether to show the error budget or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#show_error_budget Powerpack#show_error_budget}
    */
    readonly showErrorBudget?: boolean | cdktn.IResolvable;
    /**
    * The ID of the service level objective used by the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_id Powerpack#slo_id}
    */
    readonly sloId: string;
    /**
    * A list of time windows to display in the widget. Valid values are `7d`, `30d`, `90d`, `week_to_date`, `previous_week`, `month_to_date`, `previous_month`, `global_time`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#time_windows Powerpack#time_windows}
    */
    readonly timeWindows: string[];
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title Powerpack#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_align Powerpack#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_size Powerpack#title_size}
    */
    readonly titleSize?: string;
    /**
    * The view mode for the widget. Valid values are `overall`, `component`, `both`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#view_mode Powerpack#view_mode}
    */
    readonly viewMode: string;
    /**
    * The type of view to use when displaying the widget. Only `detail` is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#view_type Powerpack#view_type}
    */
    readonly viewType: string;
}
export declare function powerpackWidgetServiceLevelObjectiveDefinitionToTerraform(struct?: PowerpackWidgetServiceLevelObjectiveDefinitionOutputReference | PowerpackWidgetServiceLevelObjectiveDefinition): any;
export declare function powerpackWidgetServiceLevelObjectiveDefinitionToHclTerraform(struct?: PowerpackWidgetServiceLevelObjectiveDefinitionOutputReference | PowerpackWidgetServiceLevelObjectiveDefinition): any;
export declare class PowerpackWidgetServiceLevelObjectiveDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetServiceLevelObjectiveDefinition | undefined;
    set internalValue(value: PowerpackWidgetServiceLevelObjectiveDefinition | undefined);
    private _additionalQueryFilters?;
    get additionalQueryFilters(): string;
    set additionalQueryFilters(value: string);
    resetAdditionalQueryFilters(): void;
    get additionalQueryFiltersInput(): string | undefined;
    private _globalTimeTarget?;
    get globalTimeTarget(): string;
    set globalTimeTarget(value: string);
    resetGlobalTimeTarget(): void;
    get globalTimeTargetInput(): string | undefined;
    private _showErrorBudget?;
    get showErrorBudget(): boolean | cdktn.IResolvable;
    set showErrorBudget(value: boolean | cdktn.IResolvable);
    resetShowErrorBudget(): void;
    get showErrorBudgetInput(): boolean | cdktn.IResolvable | undefined;
    private _sloId?;
    get sloId(): string;
    set sloId(value: string);
    get sloIdInput(): string | undefined;
    private _timeWindows?;
    get timeWindows(): string[];
    set timeWindows(value: string[]);
    get timeWindowsInput(): string[] | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _viewMode?;
    get viewMode(): string;
    set viewMode(value: string);
    get viewModeInput(): string | undefined;
    private _viewType?;
    get viewType(): string;
    set viewType(value: string);
    get viewTypeInput(): string | undefined;
}
export interface PowerpackWidgetServicemapDefinitionCustomLink {
    /**
    * The flag for toggling context menu link visibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_hidden Powerpack#is_hidden}
    */
    readonly isHidden?: boolean | cdktn.IResolvable;
    /**
    * The label for the custom link URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label?: string;
    /**
    * The URL of the custom link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#link Powerpack#link}
    */
    readonly link?: string;
    /**
    * The label ID that refers to a context menu link item. When `override_label` is provided, the client request omits the label field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#override_label Powerpack#override_label}
    */
    readonly overrideLabel?: string;
}
export declare function powerpackWidgetServicemapDefinitionCustomLinkToTerraform(struct?: PowerpackWidgetServicemapDefinitionCustomLink | cdktn.IResolvable): any;
export declare function powerpackWidgetServicemapDefinitionCustomLinkToHclTerraform(struct?: PowerpackWidgetServicemapDefinitionCustomLink | cdktn.IResolvable): any;
export declare class PowerpackWidgetServicemapDefinitionCustomLinkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetServicemapDefinitionCustomLink | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetServicemapDefinitionCustomLink | cdktn.IResolvable | undefined);
    private _isHidden?;
    get isHidden(): boolean | cdktn.IResolvable;
    set isHidden(value: boolean | cdktn.IResolvable);
    resetIsHidden(): void;
    get isHiddenInput(): boolean | cdktn.IResolvable | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _link?;
    get link(): string;
    set link(value: string);
    resetLink(): void;
    get linkInput(): string | undefined;
    private _overrideLabel?;
    get overrideLabel(): string;
    set overrideLabel(value: string);
    resetOverrideLabel(): void;
    get overrideLabelInput(): string | undefined;
}
export declare class PowerpackWidgetServicemapDefinitionCustomLinkList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetServicemapDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetServicemapDefinitionCustomLinkOutputReference;
}
export interface PowerpackWidgetServicemapDefinition {
    /**
    * Your environment and primary tag (or `*` if enabled for your account).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#filters Powerpack#filters}
    */
    readonly filters: string[];
    /**
    * The ID of the service to map.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#service Powerpack#service}
    */
    readonly service: string;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title Powerpack#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_align Powerpack#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_size Powerpack#title_size}
    */
    readonly titleSize?: string;
    /**
    * custom_link block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_link Powerpack#custom_link}
    */
    readonly customLink?: PowerpackWidgetServicemapDefinitionCustomLink[] | cdktn.IResolvable;
}
export declare function powerpackWidgetServicemapDefinitionToTerraform(struct?: PowerpackWidgetServicemapDefinitionOutputReference | PowerpackWidgetServicemapDefinition): any;
export declare function powerpackWidgetServicemapDefinitionToHclTerraform(struct?: PowerpackWidgetServicemapDefinitionOutputReference | PowerpackWidgetServicemapDefinition): any;
export declare class PowerpackWidgetServicemapDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetServicemapDefinition | undefined;
    set internalValue(value: PowerpackWidgetServicemapDefinition | undefined);
    private _filters?;
    get filters(): string[];
    set filters(value: string[]);
    get filtersInput(): string[] | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _customLink;
    get customLink(): PowerpackWidgetServicemapDefinitionCustomLinkList;
    putCustomLink(value: PowerpackWidgetServicemapDefinitionCustomLink[] | cdktn.IResolvable): void;
    resetCustomLink(): void;
    get customLinkInput(): cdktn.IResolvable | PowerpackWidgetServicemapDefinitionCustomLink[] | undefined;
}
export interface PowerpackWidgetSloListDefinitionRequestQuerySort {
    /**
    * The facet path for the column.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#column Powerpack#column}
    */
    readonly column: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetSloListDefinitionRequestQuerySortToTerraform(struct?: PowerpackWidgetSloListDefinitionRequestQuerySortOutputReference | PowerpackWidgetSloListDefinitionRequestQuerySort): any;
export declare function powerpackWidgetSloListDefinitionRequestQuerySortToHclTerraform(struct?: PowerpackWidgetSloListDefinitionRequestQuerySortOutputReference | PowerpackWidgetSloListDefinitionRequestQuerySort): any;
export declare class PowerpackWidgetSloListDefinitionRequestQuerySortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSloListDefinitionRequestQuerySort | undefined;
    set internalValue(value: PowerpackWidgetSloListDefinitionRequestQuerySort | undefined);
    private _column?;
    get column(): string;
    set column(value: string);
    get columnInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetSloListDefinitionRequestQuery {
    /**
    * Maximum number of results to display in the table. Defaults to `100`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * Widget query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query_string Powerpack#query_string}
    */
    readonly queryString: string;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort Powerpack#sort}
    */
    readonly sort?: PowerpackWidgetSloListDefinitionRequestQuerySort;
}
export declare function powerpackWidgetSloListDefinitionRequestQueryToTerraform(struct?: PowerpackWidgetSloListDefinitionRequestQueryOutputReference | PowerpackWidgetSloListDefinitionRequestQuery): any;
export declare function powerpackWidgetSloListDefinitionRequestQueryToHclTerraform(struct?: PowerpackWidgetSloListDefinitionRequestQueryOutputReference | PowerpackWidgetSloListDefinitionRequestQuery): any;
export declare class PowerpackWidgetSloListDefinitionRequestQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSloListDefinitionRequestQuery | undefined;
    set internalValue(value: PowerpackWidgetSloListDefinitionRequestQuery | undefined);
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _queryString?;
    get queryString(): string;
    set queryString(value: string);
    get queryStringInput(): string | undefined;
    private _sort;
    get sort(): PowerpackWidgetSloListDefinitionRequestQuerySortOutputReference;
    putSort(value: PowerpackWidgetSloListDefinitionRequestQuerySort): void;
    resetSort(): void;
    get sortInput(): PowerpackWidgetSloListDefinitionRequestQuerySort | undefined;
}
export interface PowerpackWidgetSloListDefinitionRequest {
    /**
    * The request type for the SLO List request. Valid values are `slo_list`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#request_type Powerpack#request_type}
    */
    readonly requestType: string;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: PowerpackWidgetSloListDefinitionRequestQuery;
}
export declare function powerpackWidgetSloListDefinitionRequestToTerraform(struct?: PowerpackWidgetSloListDefinitionRequestOutputReference | PowerpackWidgetSloListDefinitionRequest): any;
export declare function powerpackWidgetSloListDefinitionRequestToHclTerraform(struct?: PowerpackWidgetSloListDefinitionRequestOutputReference | PowerpackWidgetSloListDefinitionRequest): any;
export declare class PowerpackWidgetSloListDefinitionRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSloListDefinitionRequest | undefined;
    set internalValue(value: PowerpackWidgetSloListDefinitionRequest | undefined);
    private _requestType?;
    get requestType(): string;
    set requestType(value: string);
    get requestTypeInput(): string | undefined;
    private _query;
    get query(): PowerpackWidgetSloListDefinitionRequestQueryOutputReference;
    putQuery(value: PowerpackWidgetSloListDefinitionRequestQuery): void;
    get queryInput(): PowerpackWidgetSloListDefinitionRequestQuery | undefined;
}
export interface PowerpackWidgetSloListDefinition {
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title Powerpack#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_align Powerpack#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_size Powerpack#title_size}
    */
    readonly titleSize?: string;
    /**
    * request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#request Powerpack#request}
    */
    readonly request: PowerpackWidgetSloListDefinitionRequest;
}
export declare function powerpackWidgetSloListDefinitionToTerraform(struct?: PowerpackWidgetSloListDefinitionOutputReference | PowerpackWidgetSloListDefinition): any;
export declare function powerpackWidgetSloListDefinitionToHclTerraform(struct?: PowerpackWidgetSloListDefinitionOutputReference | PowerpackWidgetSloListDefinition): any;
export declare class PowerpackWidgetSloListDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSloListDefinition | undefined;
    set internalValue(value: PowerpackWidgetSloListDefinition | undefined);
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _request;
    get request(): PowerpackWidgetSloListDefinitionRequestOutputReference;
    putRequest(value: PowerpackWidgetSloListDefinitionRequest): void;
    get requestInput(): PowerpackWidgetSloListDefinitionRequest | undefined;
}
export interface PowerpackWidgetSunburstDefinitionCustomLink {
    /**
    * The flag for toggling context menu link visibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_hidden Powerpack#is_hidden}
    */
    readonly isHidden?: boolean | cdktn.IResolvable;
    /**
    * The label for the custom link URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label?: string;
    /**
    * The URL of the custom link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#link Powerpack#link}
    */
    readonly link?: string;
    /**
    * The label ID that refers to a context menu link item. When `override_label` is provided, the client request omits the label field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#override_label Powerpack#override_label}
    */
    readonly overrideLabel?: string;
}
export declare function powerpackWidgetSunburstDefinitionCustomLinkToTerraform(struct?: PowerpackWidgetSunburstDefinitionCustomLink | cdktn.IResolvable): any;
export declare function powerpackWidgetSunburstDefinitionCustomLinkToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionCustomLink | cdktn.IResolvable): any;
export declare class PowerpackWidgetSunburstDefinitionCustomLinkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetSunburstDefinitionCustomLink | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionCustomLink | cdktn.IResolvable | undefined);
    private _isHidden?;
    get isHidden(): boolean | cdktn.IResolvable;
    set isHidden(value: boolean | cdktn.IResolvable);
    resetIsHidden(): void;
    get isHiddenInput(): boolean | cdktn.IResolvable | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _link?;
    get link(): string;
    set link(value: string);
    resetLink(): void;
    get linkInput(): string | undefined;
    private _overrideLabel?;
    get overrideLabel(): string;
    set overrideLabel(value: string);
    resetOverrideLabel(): void;
    get overrideLabelInput(): string | undefined;
}
export declare class PowerpackWidgetSunburstDefinitionCustomLinkList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetSunburstDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetSunburstDefinitionCustomLinkOutputReference;
}
export interface PowerpackWidgetSunburstDefinitionLegendInline {
    /**
    * Whether to hide the percentages of the groups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_percent Powerpack#hide_percent}
    */
    readonly hidePercent?: boolean | cdktn.IResolvable;
    /**
    * Whether to hide the values of the groups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_value Powerpack#hide_value}
    */
    readonly hideValue?: boolean | cdktn.IResolvable;
    /**
    * The type of legend (inline or automatic). Valid values are `inline`, `automatic`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#type Powerpack#type}
    */
    readonly type: string;
}
export declare function powerpackWidgetSunburstDefinitionLegendInlineToTerraform(struct?: PowerpackWidgetSunburstDefinitionLegendInlineOutputReference | PowerpackWidgetSunburstDefinitionLegendInline): any;
export declare function powerpackWidgetSunburstDefinitionLegendInlineToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionLegendInlineOutputReference | PowerpackWidgetSunburstDefinitionLegendInline): any;
export declare class PowerpackWidgetSunburstDefinitionLegendInlineOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionLegendInline | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionLegendInline | undefined);
    private _hidePercent?;
    get hidePercent(): boolean | cdktn.IResolvable;
    set hidePercent(value: boolean | cdktn.IResolvable);
    resetHidePercent(): void;
    get hidePercentInput(): boolean | cdktn.IResolvable | undefined;
    private _hideValue?;
    get hideValue(): boolean | cdktn.IResolvable;
    set hideValue(value: boolean | cdktn.IResolvable);
    resetHideValue(): void;
    get hideValueInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface PowerpackWidgetSunburstDefinitionLegendTable {
    /**
    * The type of legend (table or none). Valid values are `table`, `none`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#type Powerpack#type}
    */
    readonly type: string;
}
export declare function powerpackWidgetSunburstDefinitionLegendTableToTerraform(struct?: PowerpackWidgetSunburstDefinitionLegendTableOutputReference | PowerpackWidgetSunburstDefinitionLegendTable): any;
export declare function powerpackWidgetSunburstDefinitionLegendTableToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionLegendTableOutputReference | PowerpackWidgetSunburstDefinitionLegendTable): any;
export declare class PowerpackWidgetSunburstDefinitionLegendTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionLegendTable | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionLegendTable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestApmQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetSunburstDefinitionRequestApmQueryComputeQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestApmQueryComputeQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestApmQueryComputeQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestApmQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestApmQueryComputeQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestApmQueryComputeQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestApmQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestApmQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestApmQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestApmQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetSunburstDefinitionRequestApmQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestApmQueryGroupBySortQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestApmQueryGroupBySortQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestApmQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestApmQueryGroupBySortQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestApmQueryGroupBySortQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestApmQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestApmQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestApmQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestApmQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetSunburstDefinitionRequestApmQueryGroupBySortQuery;
}
export declare function powerpackWidgetSunburstDefinitionRequestApmQueryGroupByToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestApmQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetSunburstDefinitionRequestApmQueryGroupByToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestApmQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetSunburstDefinitionRequestApmQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestApmQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestApmQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetSunburstDefinitionRequestApmQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetSunburstDefinitionRequestApmQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetSunburstDefinitionRequestApmQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetSunburstDefinitionRequestApmQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetSunburstDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetSunburstDefinitionRequestApmQueryGroupByOutputReference;
}
export interface PowerpackWidgetSunburstDefinitionRequestApmQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetSunburstDefinitionRequestApmQueryMultiComputeToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetSunburstDefinitionRequestApmQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetSunburstDefinitionRequestApmQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetSunburstDefinitionRequestApmQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetSunburstDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetSunburstDefinitionRequestApmQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetSunburstDefinitionRequestApmQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetSunburstDefinitionRequestApmQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetSunburstDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetSunburstDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetSunburstDefinitionRequestApmQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestApmQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestApmQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestApmQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestApmQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestApmQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestApmQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestApmQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestApmQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetSunburstDefinitionRequestApmQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetSunburstDefinitionRequestApmQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetSunburstDefinitionRequestApmQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetSunburstDefinitionRequestApmQueryGroupByList;
    putGroupBy(value: PowerpackWidgetSunburstDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetSunburstDefinitionRequestApmQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetSunburstDefinitionRequestApmQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetSunburstDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetSunburstDefinitionRequestApmQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestAuditQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetSunburstDefinitionRequestAuditQueryComputeQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestAuditQueryComputeQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestAuditQueryComputeQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestAuditQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestAuditQueryComputeQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestAuditQueryComputeQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestAuditQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestAuditQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestAuditQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetSunburstDefinitionRequestAuditQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupBySortQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupBySortQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestAuditQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupBySortQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupBySortQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupBySortQuery;
}
export declare function powerpackWidgetSunburstDefinitionRequestAuditQueryGroupByToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetSunburstDefinitionRequestAuditQueryGroupByToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupByOutputReference;
}
export interface PowerpackWidgetSunburstDefinitionRequestAuditQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetSunburstDefinitionRequestAuditQueryMultiComputeToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestAuditQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetSunburstDefinitionRequestAuditQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestAuditQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetSunburstDefinitionRequestAuditQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestAuditQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestAuditQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetSunburstDefinitionRequestAuditQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetSunburstDefinitionRequestAuditQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetSunburstDefinitionRequestAuditQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetSunburstDefinitionRequestAuditQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetSunburstDefinitionRequestAuditQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetSunburstDefinitionRequestAuditQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetSunburstDefinitionRequestAuditQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestAuditQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestAuditQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestAuditQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestAuditQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestAuditQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestAuditQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestAuditQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestAuditQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetSunburstDefinitionRequestAuditQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetSunburstDefinitionRequestAuditQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetSunburstDefinitionRequestAuditQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupByList;
    putGroupBy(value: PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetSunburstDefinitionRequestAuditQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetSunburstDefinitionRequestAuditQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetSunburstDefinitionRequestAuditQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetSunburstDefinitionRequestAuditQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestFormulaConditionalFormats {
    /**
    * The comparator to use. Valid values are `=`, `>`, `>=`, `<`, `<=`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#comparator Powerpack#comparator}
    */
    readonly comparator: string;
    /**
    * The color palette to apply to the background, same values available as palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_bg_color Powerpack#custom_bg_color}
    */
    readonly customBgColor?: string;
    /**
    * The color palette to apply to the foreground, same values available as palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_fg_color Powerpack#custom_fg_color}
    */
    readonly customFgColor?: string;
    /**
    * Setting this to True hides values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_value Powerpack#hide_value}
    */
    readonly hideValue?: boolean | cdktn.IResolvable;
    /**
    * Displays an image as the background.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#image_url Powerpack#image_url}
    */
    readonly imageUrl?: string;
    /**
    * The metric from the request to correlate with this conditional format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
    /**
    * The color palette to apply. Valid values are `blue`, `custom_bg`, `custom_image`, `custom_text`, `gray_on_white`, `grey`, `green`, `orange`, `red`, `red_on_white`, `white_on_gray`, `white_on_green`, `green_on_white`, `white_on_red`, `white_on_yellow`, `yellow_on_white`, `black_on_light_yellow`, `black_on_light_green`, `black_on_light_red`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette Powerpack#palette}
    */
    readonly palette: string;
    /**
    * Defines the displayed timeframe.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#timeframe Powerpack#timeframe}
    */
    readonly timeframe?: string;
    /**
    * A value for the comparator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#value Powerpack#value}
    */
    readonly value: number;
}
export declare function powerpackWidgetSunburstDefinitionRequestFormulaConditionalFormatsToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable): any;
export declare function powerpackWidgetSunburstDefinitionRequestFormulaConditionalFormatsToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable): any;
export declare class PowerpackWidgetSunburstDefinitionRequestFormulaConditionalFormatsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable | undefined);
    private _comparator?;
    get comparator(): string;
    set comparator(value: string);
    get comparatorInput(): string | undefined;
    private _customBgColor?;
    get customBgColor(): string;
    set customBgColor(value: string);
    resetCustomBgColor(): void;
    get customBgColorInput(): string | undefined;
    private _customFgColor?;
    get customFgColor(): string;
    set customFgColor(value: string);
    resetCustomFgColor(): void;
    get customFgColorInput(): string | undefined;
    private _hideValue?;
    get hideValue(): boolean | cdktn.IResolvable;
    set hideValue(value: boolean | cdktn.IResolvable);
    resetHideValue(): void;
    get hideValueInput(): boolean | cdktn.IResolvable | undefined;
    private _imageUrl?;
    get imageUrl(): string;
    set imageUrl(value: string);
    resetImageUrl(): void;
    get imageUrlInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _palette?;
    get palette(): string;
    set palette(value: string);
    get paletteInput(): string | undefined;
    private _timeframe?;
    get timeframe(): string;
    set timeframe(value: string);
    resetTimeframe(): void;
    get timeframeInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class PowerpackWidgetSunburstDefinitionRequestFormulaConditionalFormatsList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetSunburstDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetSunburstDefinitionRequestFormulaConditionalFormatsOutputReference;
}
export interface PowerpackWidgetSunburstDefinitionRequestFormulaLimit {
    /**
    * The number of results to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#count Powerpack#count}
    */
    readonly count?: number;
    /**
    * The direction of the sort. Valid values are `asc`, `desc`. Defaults to `"desc"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order?: string;
}
export declare function powerpackWidgetSunburstDefinitionRequestFormulaLimitToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestFormulaLimitOutputReference | PowerpackWidgetSunburstDefinitionRequestFormulaLimit): any;
export declare function powerpackWidgetSunburstDefinitionRequestFormulaLimitToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestFormulaLimitOutputReference | PowerpackWidgetSunburstDefinitionRequestFormulaLimit): any;
export declare class PowerpackWidgetSunburstDefinitionRequestFormulaLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestFormulaLimit | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestFormulaLimit | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    resetCount(): void;
    get countInput(): number | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCanonical {
    /**
    * per unit name. If you want to represent megabytes/s, you set 'unit_name' = 'megabyte' and 'per_unit_name = 'second'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#per_unit_name Powerpack#per_unit_name}
    */
    readonly perUnitName?: string;
    /**
    * Unit name. It should be in singular form ('megabyte' and not 'megabytes')
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit_name Powerpack#unit_name}
    */
    readonly unitName: string;
}
export declare function powerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCanonicalToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference | PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCanonical): any;
export declare function powerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCanonicalToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference | PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCanonical): any;
export declare class PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCanonical | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCanonical | undefined);
    private _perUnitName?;
    get perUnitName(): string;
    set perUnitName(value: string);
    resetPerUnitName(): void;
    get perUnitNameInput(): string | undefined;
    private _unitName?;
    get unitName(): string;
    set unitName(value: string);
    get unitNameInput(): string | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCustom {
    /**
    * Unit label
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label: string;
}
export declare function powerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCustomToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCustomOutputReference | PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCustom): any;
export declare function powerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCustomToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCustomOutputReference | PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCustom): any;
export declare class PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCustom | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCustom | undefined);
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnit {
    /**
    * canonical block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#canonical Powerpack#canonical}
    */
    readonly canonical?: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCanonical;
    /**
    * custom block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom Powerpack#custom}
    */
    readonly custom?: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCustom;
}
export declare function powerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitOutputReference | PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnit): any;
export declare function powerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitOutputReference | PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnit): any;
export declare class PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnit | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnit | undefined);
    private _canonical;
    get canonical(): PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference;
    putCanonical(value: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCanonical): void;
    resetCanonical(): void;
    get canonicalInput(): PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCanonical | undefined;
    private _custom;
    get custom(): PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCustomOutputReference;
    putCustom(value: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCustom): void;
    resetCustom(): void;
    get customInput(): PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitCustom | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitScale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit_name Powerpack#unit_name}
    */
    readonly unitName: string;
}
export declare function powerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitScaleToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitScaleOutputReference | PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitScale): any;
export declare function powerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitScaleToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitScaleOutputReference | PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitScale): any;
export declare class PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitScaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitScale | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitScale | undefined);
    private _unitName?;
    get unitName(): string;
    set unitName(value: string);
    get unitNameInput(): string | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormat {
    /**
    * unit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit Powerpack#unit}
    */
    readonly unit: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnit;
    /**
    * unit_scale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit_scale Powerpack#unit_scale}
    */
    readonly unitScale?: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitScale;
}
export declare function powerpackWidgetSunburstDefinitionRequestFormulaNumberFormatToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatOutputReference | PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormat): any;
export declare function powerpackWidgetSunburstDefinitionRequestFormulaNumberFormatToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatOutputReference | PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormat): any;
export declare class PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormat | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormat | undefined);
    private _unit;
    get unit(): PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitOutputReference;
    putUnit(value: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnit): void;
    get unitInput(): PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnit | undefined;
    private _unitScale;
    get unitScale(): PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitScaleOutputReference;
    putUnitScale(value: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitScale): void;
    resetUnitScale(): void;
    get unitScaleInput(): PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatUnitScale | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestFormulaStyle {
    /**
    * The color palette used to display the formula. A guide to the available color palettes can be found at https://docs.datadoghq.com/dashboards/guide/widget_colors.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette Powerpack#palette}
    */
    readonly palette?: string;
    /**
    * Index specifying which color to use within the palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette_index Powerpack#palette_index}
    */
    readonly paletteIndex?: number;
}
export declare function powerpackWidgetSunburstDefinitionRequestFormulaStyleToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestFormulaStyleOutputReference | PowerpackWidgetSunburstDefinitionRequestFormulaStyle): any;
export declare function powerpackWidgetSunburstDefinitionRequestFormulaStyleToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestFormulaStyleOutputReference | PowerpackWidgetSunburstDefinitionRequestFormulaStyle): any;
export declare class PowerpackWidgetSunburstDefinitionRequestFormulaStyleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestFormulaStyle | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestFormulaStyle | undefined);
    private _palette?;
    get palette(): string;
    set palette(value: string);
    resetPalette(): void;
    get paletteInput(): string | undefined;
    private _paletteIndex?;
    get paletteIndex(): number;
    set paletteIndex(value: number);
    resetPaletteIndex(): void;
    get paletteIndexInput(): number | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestFormula {
    /**
    * An expression alias.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#alias Powerpack#alias}
    */
    readonly alias?: string;
    /**
    * A list of display modes for each table cell. Valid values are `number`, `bar`, `trend`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cell_display_mode Powerpack#cell_display_mode}
    */
    readonly cellDisplayMode?: string;
    /**
    * A string expression built from queries, formulas, and functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#formula_expression Powerpack#formula_expression}
    */
    readonly formulaExpression: string;
    /**
    * conditional_formats block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#conditional_formats Powerpack#conditional_formats}
    */
    readonly conditionalFormats?: PowerpackWidgetSunburstDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: PowerpackWidgetSunburstDefinitionRequestFormulaLimit;
    /**
    * number_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#number_format Powerpack#number_format}
    */
    readonly numberFormat?: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormat;
    /**
    * style block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#style Powerpack#style}
    */
    readonly style?: PowerpackWidgetSunburstDefinitionRequestFormulaStyle;
}
export declare function powerpackWidgetSunburstDefinitionRequestFormulaToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestFormula | cdktn.IResolvable): any;
export declare function powerpackWidgetSunburstDefinitionRequestFormulaToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestFormula | cdktn.IResolvable): any;
export declare class PowerpackWidgetSunburstDefinitionRequestFormulaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestFormula | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestFormula | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _cellDisplayMode?;
    get cellDisplayMode(): string;
    set cellDisplayMode(value: string);
    resetCellDisplayMode(): void;
    get cellDisplayModeInput(): string | undefined;
    private _formulaExpression?;
    get formulaExpression(): string;
    set formulaExpression(value: string);
    get formulaExpressionInput(): string | undefined;
    private _conditionalFormats;
    get conditionalFormats(): PowerpackWidgetSunburstDefinitionRequestFormulaConditionalFormatsList;
    putConditionalFormats(value: PowerpackWidgetSunburstDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable): void;
    resetConditionalFormats(): void;
    get conditionalFormatsInput(): cdktn.IResolvable | PowerpackWidgetSunburstDefinitionRequestFormulaConditionalFormats[] | undefined;
    private _limit;
    get limit(): PowerpackWidgetSunburstDefinitionRequestFormulaLimitOutputReference;
    putLimit(value: PowerpackWidgetSunburstDefinitionRequestFormulaLimit): void;
    resetLimit(): void;
    get limitInput(): PowerpackWidgetSunburstDefinitionRequestFormulaLimit | undefined;
    private _numberFormat;
    get numberFormat(): PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormatOutputReference;
    putNumberFormat(value: PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormat): void;
    resetNumberFormat(): void;
    get numberFormatInput(): PowerpackWidgetSunburstDefinitionRequestFormulaNumberFormat | undefined;
    private _style;
    get style(): PowerpackWidgetSunburstDefinitionRequestFormulaStyleOutputReference;
    putStyle(value: PowerpackWidgetSunburstDefinitionRequestFormulaStyle): void;
    resetStyle(): void;
    get styleInput(): PowerpackWidgetSunburstDefinitionRequestFormulaStyle | undefined;
}
export declare class PowerpackWidgetSunburstDefinitionRequestFormulaList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetSunburstDefinitionRequestFormula[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetSunburstDefinitionRequestFormulaOutputReference;
}
export interface PowerpackWidgetSunburstDefinitionRequestLogQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetSunburstDefinitionRequestLogQueryComputeQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestLogQueryComputeQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestLogQueryComputeQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestLogQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestLogQueryComputeQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestLogQueryComputeQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestLogQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestLogQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestLogQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestLogQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetSunburstDefinitionRequestLogQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestLogQueryGroupBySortQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestLogQueryGroupBySortQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestLogQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestLogQueryGroupBySortQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestLogQueryGroupBySortQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestLogQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestLogQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestLogQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestLogQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetSunburstDefinitionRequestLogQueryGroupBySortQuery;
}
export declare function powerpackWidgetSunburstDefinitionRequestLogQueryGroupByToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestLogQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetSunburstDefinitionRequestLogQueryGroupByToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestLogQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetSunburstDefinitionRequestLogQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestLogQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestLogQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetSunburstDefinitionRequestLogQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetSunburstDefinitionRequestLogQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetSunburstDefinitionRequestLogQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetSunburstDefinitionRequestLogQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetSunburstDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetSunburstDefinitionRequestLogQueryGroupByOutputReference;
}
export interface PowerpackWidgetSunburstDefinitionRequestLogQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetSunburstDefinitionRequestLogQueryMultiComputeToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetSunburstDefinitionRequestLogQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetSunburstDefinitionRequestLogQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetSunburstDefinitionRequestLogQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetSunburstDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetSunburstDefinitionRequestLogQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetSunburstDefinitionRequestLogQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetSunburstDefinitionRequestLogQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetSunburstDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetSunburstDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetSunburstDefinitionRequestLogQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestLogQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestLogQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestLogQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestLogQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestLogQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestLogQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestLogQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestLogQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetSunburstDefinitionRequestLogQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetSunburstDefinitionRequestLogQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetSunburstDefinitionRequestLogQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetSunburstDefinitionRequestLogQueryGroupByList;
    putGroupBy(value: PowerpackWidgetSunburstDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetSunburstDefinitionRequestLogQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetSunburstDefinitionRequestLogQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetSunburstDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetSunburstDefinitionRequestLogQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestNetworkQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetSunburstDefinitionRequestNetworkQueryComputeQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestNetworkQueryComputeQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestNetworkQueryComputeQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestNetworkQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestNetworkQueryComputeQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestNetworkQueryComputeQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestNetworkQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestNetworkQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestNetworkQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBySortQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBySortQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBySortQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBySortQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBySortQuery;
}
export declare function powerpackWidgetSunburstDefinitionRequestNetworkQueryGroupByToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetSunburstDefinitionRequestNetworkQueryGroupByToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupByOutputReference;
}
export interface PowerpackWidgetSunburstDefinitionRequestNetworkQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetSunburstDefinitionRequestNetworkQueryMultiComputeToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestNetworkQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetSunburstDefinitionRequestNetworkQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestNetworkQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetSunburstDefinitionRequestNetworkQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestNetworkQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestNetworkQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetSunburstDefinitionRequestNetworkQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetSunburstDefinitionRequestNetworkQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetSunburstDefinitionRequestNetworkQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetSunburstDefinitionRequestNetworkQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetSunburstDefinitionRequestNetworkQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetSunburstDefinitionRequestNetworkQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetSunburstDefinitionRequestNetworkQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestNetworkQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestNetworkQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestNetworkQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestNetworkQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestNetworkQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestNetworkQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestNetworkQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestNetworkQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetSunburstDefinitionRequestNetworkQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetSunburstDefinitionRequestNetworkQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetSunburstDefinitionRequestNetworkQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupByList;
    putGroupBy(value: PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetSunburstDefinitionRequestNetworkQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetSunburstDefinitionRequestNetworkQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetSunburstDefinitionRequestNetworkQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetSunburstDefinitionRequestNetworkQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestProcessQuery {
    /**
    * A list of processes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#filter_by Powerpack#filter_by}
    */
    readonly filterBy?: string[];
    /**
    * The max number of items in the filter list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * Your chosen metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric: string;
    /**
    * Your chosen search term.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_by Powerpack#search_by}
    */
    readonly searchBy?: string;
}
export declare function powerpackWidgetSunburstDefinitionRequestProcessQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestProcessQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestProcessQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestProcessQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestProcessQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestProcessQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestProcessQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestProcessQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestProcessQuery | undefined);
    private _filterBy?;
    get filterBy(): string[];
    set filterBy(value: string[]);
    resetFilterBy(): void;
    get filterByInput(): string[] | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _searchBy?;
    get searchBy(): string;
    set searchBy(value: string);
    resetSearchBy(): void;
    get searchByInput(): string | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestQueryApmDependencyStatsQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for APM Dependency Stats queries. Valid values are `apm_dependency_stats`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * APM environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#env Powerpack#env}
    */
    readonly env: string;
    /**
    * Determines whether stats for upstream or downstream dependencies should be queried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_upstream Powerpack#is_upstream}
    */
    readonly isUpstream?: boolean | cdktn.IResolvable;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Name of operation on service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#operation_name Powerpack#operation_name}
    */
    readonly operationName: string;
    /**
    * The name of the second primary tag used within APM; required when `primary_tag_value` is specified. See https://docs.datadoghq.com/tracing/guide/setting_primary_tags_to_scope/#add-a-second-primary-tag-in-datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_name Powerpack#primary_tag_name}
    */
    readonly primaryTagName?: string;
    /**
    * Filter APM data by the second primary tag. `primary_tag_name` must also be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_value Powerpack#primary_tag_value}
    */
    readonly primaryTagValue?: string;
    /**
    * APM resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#resource_name Powerpack#resource_name}
    */
    readonly resourceName: string;
    /**
    * APM service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#service Powerpack#service}
    */
    readonly service: string;
    /**
    * APM statistic. Valid values are `avg_duration`, `avg_root_duration`, `avg_spans_per_trace`, `error_rate`, `pct_exec_time`, `pct_of_traces`, `total_traces_count`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#stat Powerpack#stat}
    */
    readonly stat: string;
}
export declare function powerpackWidgetSunburstDefinitionRequestQueryApmDependencyStatsQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQueryApmDependencyStatsQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestQueryApmDependencyStatsQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestQueryApmDependencyStatsQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQueryApmDependencyStatsQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestQueryApmDependencyStatsQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestQueryApmDependencyStatsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestQueryApmDependencyStatsQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestQueryApmDependencyStatsQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    private _isUpstream?;
    get isUpstream(): boolean | cdktn.IResolvable;
    set isUpstream(value: boolean | cdktn.IResolvable);
    resetIsUpstream(): void;
    get isUpstreamInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    get operationNameInput(): string | undefined;
    private _primaryTagName?;
    get primaryTagName(): string;
    set primaryTagName(value: string);
    resetPrimaryTagName(): void;
    get primaryTagNameInput(): string | undefined;
    private _primaryTagValue?;
    get primaryTagValue(): string;
    set primaryTagValue(value: string);
    resetPrimaryTagValue(): void;
    get primaryTagValueInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    get resourceNameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    get statInput(): string | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestQueryApmResourceStatsQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for APM Resource Stats queries. Valid values are `apm_resource_stats`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * APM environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#env Powerpack#env}
    */
    readonly env: string;
    /**
    * Array of fields to group results by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: string[];
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Name of operation on service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#operation_name Powerpack#operation_name}
    */
    readonly operationName?: string;
    /**
    * The name of the second primary tag used within APM; required when `primary_tag_value` is specified. See https://docs.datadoghq.com/tracing/guide/setting_primary_tags_to_scope/#add-a-second-primary-tag-in-datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_name Powerpack#primary_tag_name}
    */
    readonly primaryTagName?: string;
    /**
    * Filter APM data by the second primary tag. `primary_tag_name` must also be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_value Powerpack#primary_tag_value}
    */
    readonly primaryTagValue?: string;
    /**
    * APM resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#resource_name Powerpack#resource_name}
    */
    readonly resourceName?: string;
    /**
    * APM service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#service Powerpack#service}
    */
    readonly service: string;
    /**
    * APM statistic. Valid values are `errors`, `error_rate`, `hits`, `latency_avg`, `latency_distribution`, `latency_max`, `latency_p50`, `latency_p75`, `latency_p90`, `latency_p95`, `latency_p99`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#stat Powerpack#stat}
    */
    readonly stat: string;
}
export declare function powerpackWidgetSunburstDefinitionRequestQueryApmResourceStatsQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQueryApmResourceStatsQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestQueryApmResourceStatsQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestQueryApmResourceStatsQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQueryApmResourceStatsQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestQueryApmResourceStatsQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestQueryApmResourceStatsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestQueryApmResourceStatsQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestQueryApmResourceStatsQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    private _groupBy?;
    get groupBy(): string[];
    set groupBy(value: string[]);
    resetGroupBy(): void;
    get groupByInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    resetOperationName(): void;
    get operationNameInput(): string | undefined;
    private _primaryTagName?;
    get primaryTagName(): string;
    set primaryTagName(value: string);
    resetPrimaryTagName(): void;
    get primaryTagNameInput(): string | undefined;
    private _primaryTagValue?;
    get primaryTagValue(): string;
    set primaryTagValue(value: string);
    resetPrimaryTagValue(): void;
    get primaryTagValueInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    resetResourceName(): void;
    get resourceNameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    get statInput(): string | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestQueryCloudCostQuery {
    /**
    * The aggregation methods available for cloud cost queries. Valid values are `avg`, `last`, `max`, `min`, `sum`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for cloud cost queries. Valid values are `cloud_cost`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The cloud cost query definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
}
export declare function powerpackWidgetSunburstDefinitionRequestQueryCloudCostQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQueryCloudCostQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestQueryCloudCostQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestQueryCloudCostQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQueryCloudCostQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestQueryCloudCostQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestQueryCloudCostQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestQueryCloudCostQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestQueryCloudCostQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestQueryEventQueryCompute {
    /**
    * The aggregation methods for event platform queries. Valid values are `count`, `cardinality`, `median`, `pc75`, `pc90`, `pc95`, `pc98`, `pc99`, `sum`, `min`, `max`, `avg`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * A time interval in milliseconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
    /**
    * The measurable attribute to compute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
}
export declare function powerpackWidgetSunburstDefinitionRequestQueryEventQueryComputeToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetSunburstDefinitionRequestQueryEventQueryComputeToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetSunburstDefinitionRequestQueryEventQueryComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
}
export declare class PowerpackWidgetSunburstDefinitionRequestQueryEventQueryComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetSunburstDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetSunburstDefinitionRequestQueryEventQueryComputeOutputReference;
}
export interface PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBySort {
    /**
    * The aggregation methods for the event platform queries. Valid values are `count`, `cardinality`, `median`, `pc75`, `pc90`, `pc95`, `pc98`, `pc99`, `sum`, `min`, `max`, `avg`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The metric used for sorting group by results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
    /**
    * Direction of sort. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order?: string;
}
export declare function powerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBySortToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBySortOutputReference | PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBySort): any;
export declare function powerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBySortToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBySortOutputReference | PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBySort): any;
export declare class PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBySortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBySort | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBySort | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBy {
    /**
    * The event facet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet: string;
    /**
    * The number of groups to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort Powerpack#sort}
    */
    readonly sort?: PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBySort;
}
export declare function powerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupByToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupByToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sort;
    get sort(): PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBySortOutputReference;
    putSort(value: PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBySort): void;
    resetSort(): void;
    get sortInput(): PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBySort | undefined;
}
export declare class PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupByOutputReference;
}
export interface PowerpackWidgetSunburstDefinitionRequestQueryEventQuerySearch {
    /**
    * The events search string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
}
export declare function powerpackWidgetSunburstDefinitionRequestQueryEventQuerySearchToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQueryEventQuerySearchOutputReference | PowerpackWidgetSunburstDefinitionRequestQueryEventQuerySearch): any;
export declare function powerpackWidgetSunburstDefinitionRequestQueryEventQuerySearchToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQueryEventQuerySearchOutputReference | PowerpackWidgetSunburstDefinitionRequestQueryEventQuerySearch): any;
export declare class PowerpackWidgetSunburstDefinitionRequestQueryEventQuerySearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestQueryEventQuerySearch | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestQueryEventQuerySearch | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestQueryEventQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for event platform-based queries. Valid values are `logs`, `spans`, `network`, `rum`, `security_signals`, `profiles`, `audit`, `events`, `ci_tests`, `ci_pipelines`, `incident_analytics`, `product_analytics`, `on_call_events`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * An array of index names to query in the stream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#indexes Powerpack#indexes}
    */
    readonly indexes?: string[];
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Storage location (private beta).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#storage Powerpack#storage}
    */
    readonly storage?: string;
    /**
    * compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute Powerpack#compute}
    */
    readonly compute: PowerpackWidgetSunburstDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable;
    /**
    * search block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search Powerpack#search}
    */
    readonly search?: PowerpackWidgetSunburstDefinitionRequestQueryEventQuerySearch;
}
export declare function powerpackWidgetSunburstDefinitionRequestQueryEventQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQueryEventQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestQueryEventQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestQueryEventQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQueryEventQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestQueryEventQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestQueryEventQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestQueryEventQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestQueryEventQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _indexes?;
    get indexes(): string[];
    set indexes(value: string[]);
    resetIndexes(): void;
    get indexesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _storage?;
    get storage(): string;
    set storage(value: string);
    resetStorage(): void;
    get storageInput(): string | undefined;
    private _compute;
    get compute(): PowerpackWidgetSunburstDefinitionRequestQueryEventQueryComputeList;
    putCompute(value: PowerpackWidgetSunburstDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable): void;
    get computeInput(): cdktn.IResolvable | PowerpackWidgetSunburstDefinitionRequestQueryEventQueryCompute[] | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupByList;
    putGroupBy(value: PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetSunburstDefinitionRequestQueryEventQueryGroupBy[] | undefined;
    private _search;
    get search(): PowerpackWidgetSunburstDefinitionRequestQueryEventQuerySearchOutputReference;
    putSearch(value: PowerpackWidgetSunburstDefinitionRequestQueryEventQuerySearch): void;
    resetSearch(): void;
    get searchInput(): PowerpackWidgetSunburstDefinitionRequestQueryEventQuerySearch | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestQueryMetricQuery {
    /**
    * The aggregation methods available for metrics queries. Valid values are `avg`, `min`, `max`, `sum`, `last`, `area`, `l2norm`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for metrics queries. Defaults to `"metrics"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource?: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The metrics query definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
    /**
    * Semantic mode for metrics queries. This determines how metrics from different sources are combined or displayed. Valid values are `combined`, `native`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#semantic_mode Powerpack#semantic_mode}
    */
    readonly semanticMode?: string;
}
export declare function powerpackWidgetSunburstDefinitionRequestQueryMetricQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQueryMetricQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestQueryMetricQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestQueryMetricQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQueryMetricQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestQueryMetricQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestQueryMetricQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestQueryMetricQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestQueryMetricQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    resetDataSource(): void;
    get dataSourceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _semanticMode?;
    get semanticMode(): string;
    set semanticMode(value: string);
    resetSemanticMode(): void;
    get semanticModeInput(): string | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestQueryProcessQuery {
    /**
    * The aggregation methods available for metrics queries. Valid values are `avg`, `min`, `max`, `sum`, `last`, `area`, `l2norm`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for process queries. Valid values are `process`, `container`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * Whether to normalize the CPU percentages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_normalized_cpu Powerpack#is_normalized_cpu}
    */
    readonly isNormalizedCpu?: boolean | cdktn.IResolvable;
    /**
    * The number of hits to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * The process metric name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric: string;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The direction of the sort. Valid values are `asc`, `desc`. Defaults to `"desc"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort Powerpack#sort}
    */
    readonly sort?: string;
    /**
    * An array of tags to filter by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#tag_filters Powerpack#tag_filters}
    */
    readonly tagFilters?: string[];
    /**
    * The text to use as a filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#text_filter Powerpack#text_filter}
    */
    readonly textFilter?: string;
}
export declare function powerpackWidgetSunburstDefinitionRequestQueryProcessQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQueryProcessQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestQueryProcessQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestQueryProcessQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQueryProcessQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestQueryProcessQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestQueryProcessQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestQueryProcessQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestQueryProcessQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _isNormalizedCpu?;
    get isNormalizedCpu(): boolean | cdktn.IResolvable;
    set isNormalizedCpu(value: boolean | cdktn.IResolvable);
    resetIsNormalizedCpu(): void;
    get isNormalizedCpuInput(): boolean | cdktn.IResolvable | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _sort?;
    get sort(): string;
    set sort(value: string);
    resetSort(): void;
    get sortInput(): string | undefined;
    private _tagFilters?;
    get tagFilters(): string[];
    set tagFilters(value: string[]);
    resetTagFilters(): void;
    get tagFiltersInput(): string[] | undefined;
    private _textFilter?;
    get textFilter(): string;
    set textFilter(value: string);
    resetTextFilter(): void;
    get textFilterInput(): string | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestQuerySloQuery {
    /**
    * Additional filters applied to the SLO query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#additional_query_filters Powerpack#additional_query_filters}
    */
    readonly additionalQueryFilters?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for SLO queries. Valid values are `slo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * Group mode to query measures. Valid values are `overall`, `components`. Defaults to `"overall"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_mode Powerpack#group_mode}
    */
    readonly groupMode?: string;
    /**
    * SLO measures queries. Valid values are `good_events`, `bad_events`, `good_minutes`, `bad_minutes`, `slo_status`, `error_budget_remaining`, `burn_rate`, `error_budget_burndown`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#measure Powerpack#measure}
    */
    readonly measure: string;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name?: string;
    /**
    * ID of an SLO to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_id Powerpack#slo_id}
    */
    readonly sloId: string;
    /**
    * type of the SLO to query. Valid values are `metric`, `monitor`, `time_slice`. Defaults to `"metric"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_query_type Powerpack#slo_query_type}
    */
    readonly sloQueryType?: string;
}
export declare function powerpackWidgetSunburstDefinitionRequestQuerySloQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQuerySloQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestQuerySloQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestQuerySloQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQuerySloQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestQuerySloQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestQuerySloQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestQuerySloQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestQuerySloQuery | undefined);
    private _additionalQueryFilters?;
    get additionalQueryFilters(): string;
    set additionalQueryFilters(value: string);
    resetAdditionalQueryFilters(): void;
    get additionalQueryFiltersInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _groupMode?;
    get groupMode(): string;
    set groupMode(value: string);
    resetGroupMode(): void;
    get groupModeInput(): string | undefined;
    private _measure?;
    get measure(): string;
    set measure(value: string);
    get measureInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sloId?;
    get sloId(): string;
    set sloId(value: string);
    get sloIdInput(): string | undefined;
    private _sloQueryType?;
    get sloQueryType(): string;
    set sloQueryType(value: string);
    resetSloQueryType(): void;
    get sloQueryTypeInput(): string | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestQuery {
    /**
    * apm_dependency_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_dependency_stats_query Powerpack#apm_dependency_stats_query}
    */
    readonly apmDependencyStatsQuery?: PowerpackWidgetSunburstDefinitionRequestQueryApmDependencyStatsQuery;
    /**
    * apm_resource_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_resource_stats_query Powerpack#apm_resource_stats_query}
    */
    readonly apmResourceStatsQuery?: PowerpackWidgetSunburstDefinitionRequestQueryApmResourceStatsQuery;
    /**
    * cloud_cost_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cloud_cost_query Powerpack#cloud_cost_query}
    */
    readonly cloudCostQuery?: PowerpackWidgetSunburstDefinitionRequestQueryCloudCostQuery;
    /**
    * event_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#event_query Powerpack#event_query}
    */
    readonly eventQuery?: PowerpackWidgetSunburstDefinitionRequestQueryEventQuery;
    /**
    * metric_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric_query Powerpack#metric_query}
    */
    readonly metricQuery?: PowerpackWidgetSunburstDefinitionRequestQueryMetricQuery;
    /**
    * process_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#process_query Powerpack#process_query}
    */
    readonly processQuery?: PowerpackWidgetSunburstDefinitionRequestQueryProcessQuery;
    /**
    * slo_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_query Powerpack#slo_query}
    */
    readonly sloQuery?: PowerpackWidgetSunburstDefinitionRequestQuerySloQuery;
}
export declare function powerpackWidgetSunburstDefinitionRequestQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQuery | cdktn.IResolvable): any;
export declare function powerpackWidgetSunburstDefinitionRequestQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestQuery | cdktn.IResolvable): any;
export declare class PowerpackWidgetSunburstDefinitionRequestQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestQuery | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestQuery | cdktn.IResolvable | undefined);
    private _apmDependencyStatsQuery;
    get apmDependencyStatsQuery(): PowerpackWidgetSunburstDefinitionRequestQueryApmDependencyStatsQueryOutputReference;
    putApmDependencyStatsQuery(value: PowerpackWidgetSunburstDefinitionRequestQueryApmDependencyStatsQuery): void;
    resetApmDependencyStatsQuery(): void;
    get apmDependencyStatsQueryInput(): PowerpackWidgetSunburstDefinitionRequestQueryApmDependencyStatsQuery | undefined;
    private _apmResourceStatsQuery;
    get apmResourceStatsQuery(): PowerpackWidgetSunburstDefinitionRequestQueryApmResourceStatsQueryOutputReference;
    putApmResourceStatsQuery(value: PowerpackWidgetSunburstDefinitionRequestQueryApmResourceStatsQuery): void;
    resetApmResourceStatsQuery(): void;
    get apmResourceStatsQueryInput(): PowerpackWidgetSunburstDefinitionRequestQueryApmResourceStatsQuery | undefined;
    private _cloudCostQuery;
    get cloudCostQuery(): PowerpackWidgetSunburstDefinitionRequestQueryCloudCostQueryOutputReference;
    putCloudCostQuery(value: PowerpackWidgetSunburstDefinitionRequestQueryCloudCostQuery): void;
    resetCloudCostQuery(): void;
    get cloudCostQueryInput(): PowerpackWidgetSunburstDefinitionRequestQueryCloudCostQuery | undefined;
    private _eventQuery;
    get eventQuery(): PowerpackWidgetSunburstDefinitionRequestQueryEventQueryOutputReference;
    putEventQuery(value: PowerpackWidgetSunburstDefinitionRequestQueryEventQuery): void;
    resetEventQuery(): void;
    get eventQueryInput(): PowerpackWidgetSunburstDefinitionRequestQueryEventQuery | undefined;
    private _metricQuery;
    get metricQuery(): PowerpackWidgetSunburstDefinitionRequestQueryMetricQueryOutputReference;
    putMetricQuery(value: PowerpackWidgetSunburstDefinitionRequestQueryMetricQuery): void;
    resetMetricQuery(): void;
    get metricQueryInput(): PowerpackWidgetSunburstDefinitionRequestQueryMetricQuery | undefined;
    private _processQuery;
    get processQuery(): PowerpackWidgetSunburstDefinitionRequestQueryProcessQueryOutputReference;
    putProcessQuery(value: PowerpackWidgetSunburstDefinitionRequestQueryProcessQuery): void;
    resetProcessQuery(): void;
    get processQueryInput(): PowerpackWidgetSunburstDefinitionRequestQueryProcessQuery | undefined;
    private _sloQuery;
    get sloQuery(): PowerpackWidgetSunburstDefinitionRequestQuerySloQueryOutputReference;
    putSloQuery(value: PowerpackWidgetSunburstDefinitionRequestQuerySloQuery): void;
    resetSloQuery(): void;
    get sloQueryInput(): PowerpackWidgetSunburstDefinitionRequestQuerySloQuery | undefined;
}
export declare class PowerpackWidgetSunburstDefinitionRequestQueryList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetSunburstDefinitionRequestQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetSunburstDefinitionRequestQueryOutputReference;
}
export interface PowerpackWidgetSunburstDefinitionRequestRumQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetSunburstDefinitionRequestRumQueryComputeQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestRumQueryComputeQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestRumQueryComputeQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestRumQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestRumQueryComputeQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestRumQueryComputeQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestRumQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestRumQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestRumQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestRumQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetSunburstDefinitionRequestRumQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestRumQueryGroupBySortQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestRumQueryGroupBySortQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestRumQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestRumQueryGroupBySortQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestRumQueryGroupBySortQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestRumQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestRumQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestRumQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestRumQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetSunburstDefinitionRequestRumQueryGroupBySortQuery;
}
export declare function powerpackWidgetSunburstDefinitionRequestRumQueryGroupByToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestRumQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetSunburstDefinitionRequestRumQueryGroupByToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestRumQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetSunburstDefinitionRequestRumQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestRumQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestRumQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetSunburstDefinitionRequestRumQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetSunburstDefinitionRequestRumQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetSunburstDefinitionRequestRumQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetSunburstDefinitionRequestRumQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetSunburstDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetSunburstDefinitionRequestRumQueryGroupByOutputReference;
}
export interface PowerpackWidgetSunburstDefinitionRequestRumQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetSunburstDefinitionRequestRumQueryMultiComputeToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetSunburstDefinitionRequestRumQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetSunburstDefinitionRequestRumQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetSunburstDefinitionRequestRumQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetSunburstDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetSunburstDefinitionRequestRumQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetSunburstDefinitionRequestRumQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetSunburstDefinitionRequestRumQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetSunburstDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetSunburstDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetSunburstDefinitionRequestRumQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestRumQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestRumQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestRumQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestRumQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestRumQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestRumQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestRumQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestRumQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetSunburstDefinitionRequestRumQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetSunburstDefinitionRequestRumQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetSunburstDefinitionRequestRumQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetSunburstDefinitionRequestRumQueryGroupByList;
    putGroupBy(value: PowerpackWidgetSunburstDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetSunburstDefinitionRequestRumQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetSunburstDefinitionRequestRumQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetSunburstDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetSunburstDefinitionRequestRumQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestSecurityQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetSunburstDefinitionRequestSecurityQueryComputeQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestSecurityQueryComputeQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestSecurityQueryComputeQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestSecurityQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestSecurityQueryComputeQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestSecurityQueryComputeQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestSecurityQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestSecurityQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestSecurityQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBySortQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBySortQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBySortQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBySortQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBySortQuery;
}
export declare function powerpackWidgetSunburstDefinitionRequestSecurityQueryGroupByToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetSunburstDefinitionRequestSecurityQueryGroupByToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupByOutputReference;
}
export interface PowerpackWidgetSunburstDefinitionRequestSecurityQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetSunburstDefinitionRequestSecurityQueryMultiComputeToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetSunburstDefinitionRequestSecurityQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetSunburstDefinitionRequestSecurityQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetSunburstDefinitionRequestSecurityQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetSunburstDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetSunburstDefinitionRequestSecurityQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetSunburstDefinitionRequestSecurityQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetSunburstDefinitionRequestSecurityQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetSunburstDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetSunburstDefinitionRequestSecurityQueryToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestSecurityQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestSecurityQuery): any;
export declare function powerpackWidgetSunburstDefinitionRequestSecurityQueryToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestSecurityQueryOutputReference | PowerpackWidgetSunburstDefinitionRequestSecurityQuery): any;
export declare class PowerpackWidgetSunburstDefinitionRequestSecurityQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestSecurityQuery | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestSecurityQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetSunburstDefinitionRequestSecurityQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetSunburstDefinitionRequestSecurityQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetSunburstDefinitionRequestSecurityQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupByList;
    putGroupBy(value: PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetSunburstDefinitionRequestSecurityQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetSunburstDefinitionRequestSecurityQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetSunburstDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetSunburstDefinitionRequestSecurityQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequestStyle {
    /**
    * A color palette to apply to the widget. The available options are available at: https://docs.datadoghq.com/dashboards/widgets/timeseries/#appearance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette Powerpack#palette}
    */
    readonly palette?: string;
}
export declare function powerpackWidgetSunburstDefinitionRequestStyleToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestStyleOutputReference | PowerpackWidgetSunburstDefinitionRequestStyle): any;
export declare function powerpackWidgetSunburstDefinitionRequestStyleToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequestStyleOutputReference | PowerpackWidgetSunburstDefinitionRequestStyle): any;
export declare class PowerpackWidgetSunburstDefinitionRequestStyleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequestStyle | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequestStyle | undefined);
    private _palette?;
    get palette(): string;
    set palette(value: string);
    resetPalette(): void;
    get paletteInput(): string | undefined;
}
export interface PowerpackWidgetSunburstDefinitionRequest {
    /**
    * The metric query to use for this widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#q Powerpack#q}
    */
    readonly q?: string;
    /**
    * apm_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_query Powerpack#apm_query}
    */
    readonly apmQuery?: PowerpackWidgetSunburstDefinitionRequestApmQuery;
    /**
    * audit_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#audit_query Powerpack#audit_query}
    */
    readonly auditQuery?: PowerpackWidgetSunburstDefinitionRequestAuditQuery;
    /**
    * formula block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#formula Powerpack#formula}
    */
    readonly formula?: PowerpackWidgetSunburstDefinitionRequestFormula[] | cdktn.IResolvable;
    /**
    * log_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#log_query Powerpack#log_query}
    */
    readonly logQuery?: PowerpackWidgetSunburstDefinitionRequestLogQuery;
    /**
    * network_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#network_query Powerpack#network_query}
    */
    readonly networkQuery?: PowerpackWidgetSunburstDefinitionRequestNetworkQuery;
    /**
    * process_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#process_query Powerpack#process_query}
    */
    readonly processQuery?: PowerpackWidgetSunburstDefinitionRequestProcessQuery;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query?: PowerpackWidgetSunburstDefinitionRequestQuery[] | cdktn.IResolvable;
    /**
    * rum_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#rum_query Powerpack#rum_query}
    */
    readonly rumQuery?: PowerpackWidgetSunburstDefinitionRequestRumQuery;
    /**
    * security_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#security_query Powerpack#security_query}
    */
    readonly securityQuery?: PowerpackWidgetSunburstDefinitionRequestSecurityQuery;
    /**
    * style block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#style Powerpack#style}
    */
    readonly style?: PowerpackWidgetSunburstDefinitionRequestStyle;
}
export declare function powerpackWidgetSunburstDefinitionRequestToTerraform(struct?: PowerpackWidgetSunburstDefinitionRequest | cdktn.IResolvable): any;
export declare function powerpackWidgetSunburstDefinitionRequestToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionRequest | cdktn.IResolvable): any;
export declare class PowerpackWidgetSunburstDefinitionRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetSunburstDefinitionRequest | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinitionRequest | cdktn.IResolvable | undefined);
    private _q?;
    get q(): string;
    set q(value: string);
    resetQ(): void;
    get qInput(): string | undefined;
    private _apmQuery;
    get apmQuery(): PowerpackWidgetSunburstDefinitionRequestApmQueryOutputReference;
    putApmQuery(value: PowerpackWidgetSunburstDefinitionRequestApmQuery): void;
    resetApmQuery(): void;
    get apmQueryInput(): PowerpackWidgetSunburstDefinitionRequestApmQuery | undefined;
    private _auditQuery;
    get auditQuery(): PowerpackWidgetSunburstDefinitionRequestAuditQueryOutputReference;
    putAuditQuery(value: PowerpackWidgetSunburstDefinitionRequestAuditQuery): void;
    resetAuditQuery(): void;
    get auditQueryInput(): PowerpackWidgetSunburstDefinitionRequestAuditQuery | undefined;
    private _formula;
    get formula(): PowerpackWidgetSunburstDefinitionRequestFormulaList;
    putFormula(value: PowerpackWidgetSunburstDefinitionRequestFormula[] | cdktn.IResolvable): void;
    resetFormula(): void;
    get formulaInput(): cdktn.IResolvable | PowerpackWidgetSunburstDefinitionRequestFormula[] | undefined;
    private _logQuery;
    get logQuery(): PowerpackWidgetSunburstDefinitionRequestLogQueryOutputReference;
    putLogQuery(value: PowerpackWidgetSunburstDefinitionRequestLogQuery): void;
    resetLogQuery(): void;
    get logQueryInput(): PowerpackWidgetSunburstDefinitionRequestLogQuery | undefined;
    private _networkQuery;
    get networkQuery(): PowerpackWidgetSunburstDefinitionRequestNetworkQueryOutputReference;
    putNetworkQuery(value: PowerpackWidgetSunburstDefinitionRequestNetworkQuery): void;
    resetNetworkQuery(): void;
    get networkQueryInput(): PowerpackWidgetSunburstDefinitionRequestNetworkQuery | undefined;
    private _processQuery;
    get processQuery(): PowerpackWidgetSunburstDefinitionRequestProcessQueryOutputReference;
    putProcessQuery(value: PowerpackWidgetSunburstDefinitionRequestProcessQuery): void;
    resetProcessQuery(): void;
    get processQueryInput(): PowerpackWidgetSunburstDefinitionRequestProcessQuery | undefined;
    private _query;
    get query(): PowerpackWidgetSunburstDefinitionRequestQueryList;
    putQuery(value: PowerpackWidgetSunburstDefinitionRequestQuery[] | cdktn.IResolvable): void;
    resetQuery(): void;
    get queryInput(): cdktn.IResolvable | PowerpackWidgetSunburstDefinitionRequestQuery[] | undefined;
    private _rumQuery;
    get rumQuery(): PowerpackWidgetSunburstDefinitionRequestRumQueryOutputReference;
    putRumQuery(value: PowerpackWidgetSunburstDefinitionRequestRumQuery): void;
    resetRumQuery(): void;
    get rumQueryInput(): PowerpackWidgetSunburstDefinitionRequestRumQuery | undefined;
    private _securityQuery;
    get securityQuery(): PowerpackWidgetSunburstDefinitionRequestSecurityQueryOutputReference;
    putSecurityQuery(value: PowerpackWidgetSunburstDefinitionRequestSecurityQuery): void;
    resetSecurityQuery(): void;
    get securityQueryInput(): PowerpackWidgetSunburstDefinitionRequestSecurityQuery | undefined;
    private _style;
    get style(): PowerpackWidgetSunburstDefinitionRequestStyleOutputReference;
    putStyle(value: PowerpackWidgetSunburstDefinitionRequestStyle): void;
    resetStyle(): void;
    get styleInput(): PowerpackWidgetSunburstDefinitionRequestStyle | undefined;
}
export declare class PowerpackWidgetSunburstDefinitionRequestList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetSunburstDefinitionRequest[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetSunburstDefinitionRequestOutputReference;
}
export interface PowerpackWidgetSunburstDefinition {
    /**
    * Hide any portion of the widget's timeframe that is incomplete due to cost data not being available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_incomplete_cost_data Powerpack#hide_incomplete_cost_data}
    */
    readonly hideIncompleteCostData?: boolean | cdktn.IResolvable;
    /**
    * Whether or not to show the total value in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_total Powerpack#hide_total}
    */
    readonly hideTotal?: boolean | cdktn.IResolvable;
    /**
    * The timeframe to use when displaying the widget. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#live_span Powerpack#live_span}
    */
    readonly liveSpan?: string;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title Powerpack#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. One of `left`, `center`, or `right`. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_align Powerpack#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title. Default is 16.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_size Powerpack#title_size}
    */
    readonly titleSize?: string;
    /**
    * custom_link block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_link Powerpack#custom_link}
    */
    readonly customLink?: PowerpackWidgetSunburstDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * legend_inline block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#legend_inline Powerpack#legend_inline}
    */
    readonly legendInline?: PowerpackWidgetSunburstDefinitionLegendInline;
    /**
    * legend_table block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#legend_table Powerpack#legend_table}
    */
    readonly legendTable?: PowerpackWidgetSunburstDefinitionLegendTable;
    /**
    * request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#request Powerpack#request}
    */
    readonly request?: PowerpackWidgetSunburstDefinitionRequest[] | cdktn.IResolvable;
}
export declare function powerpackWidgetSunburstDefinitionToTerraform(struct?: PowerpackWidgetSunburstDefinitionOutputReference | PowerpackWidgetSunburstDefinition): any;
export declare function powerpackWidgetSunburstDefinitionToHclTerraform(struct?: PowerpackWidgetSunburstDefinitionOutputReference | PowerpackWidgetSunburstDefinition): any;
export declare class PowerpackWidgetSunburstDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetSunburstDefinition | undefined;
    set internalValue(value: PowerpackWidgetSunburstDefinition | undefined);
    private _hideIncompleteCostData?;
    get hideIncompleteCostData(): boolean | cdktn.IResolvable;
    set hideIncompleteCostData(value: boolean | cdktn.IResolvable);
    resetHideIncompleteCostData(): void;
    get hideIncompleteCostDataInput(): boolean | cdktn.IResolvable | undefined;
    private _hideTotal?;
    get hideTotal(): boolean | cdktn.IResolvable;
    set hideTotal(value: boolean | cdktn.IResolvable);
    resetHideTotal(): void;
    get hideTotalInput(): boolean | cdktn.IResolvable | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _customLink;
    get customLink(): PowerpackWidgetSunburstDefinitionCustomLinkList;
    putCustomLink(value: PowerpackWidgetSunburstDefinitionCustomLink[] | cdktn.IResolvable): void;
    resetCustomLink(): void;
    get customLinkInput(): cdktn.IResolvable | PowerpackWidgetSunburstDefinitionCustomLink[] | undefined;
    private _legendInline;
    get legendInline(): PowerpackWidgetSunburstDefinitionLegendInlineOutputReference;
    putLegendInline(value: PowerpackWidgetSunburstDefinitionLegendInline): void;
    resetLegendInline(): void;
    get legendInlineInput(): PowerpackWidgetSunburstDefinitionLegendInline | undefined;
    private _legendTable;
    get legendTable(): PowerpackWidgetSunburstDefinitionLegendTableOutputReference;
    putLegendTable(value: PowerpackWidgetSunburstDefinitionLegendTable): void;
    resetLegendTable(): void;
    get legendTableInput(): PowerpackWidgetSunburstDefinitionLegendTable | undefined;
    private _request;
    get request(): PowerpackWidgetSunburstDefinitionRequestList;
    putRequest(value: PowerpackWidgetSunburstDefinitionRequest[] | cdktn.IResolvable): void;
    resetRequest(): void;
    get requestInput(): cdktn.IResolvable | PowerpackWidgetSunburstDefinitionRequest[] | undefined;
}
export interface PowerpackWidgetTimeseriesDefinitionCustomLink {
    /**
    * The flag for toggling context menu link visibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_hidden Powerpack#is_hidden}
    */
    readonly isHidden?: boolean | cdktn.IResolvable;
    /**
    * The label for the custom link URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label?: string;
    /**
    * The URL of the custom link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#link Powerpack#link}
    */
    readonly link?: string;
    /**
    * The label ID that refers to a context menu link item. When `override_label` is provided, the client request omits the label field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#override_label Powerpack#override_label}
    */
    readonly overrideLabel?: string;
}
export declare function powerpackWidgetTimeseriesDefinitionCustomLinkToTerraform(struct?: PowerpackWidgetTimeseriesDefinitionCustomLink | cdktn.IResolvable): any;
export declare function powerpackWidgetTimeseriesDefinitionCustomLinkToHclTerraform(struct?: PowerpackWidgetTimeseriesDefinitionCustomLink | cdktn.IResolvable): any;
export declare class PowerpackWidgetTimeseriesDefinitionCustomLinkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetTimeseriesDefinitionCustomLink | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetTimeseriesDefinitionCustomLink | cdktn.IResolvable | undefined);
    private _isHidden?;
    get isHidden(): boolean | cdktn.IResolvable;
    set isHidden(value: boolean | cdktn.IResolvable);
    resetIsHidden(): void;
    get isHiddenInput(): boolean | cdktn.IResolvable | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _link?;
    get link(): string;
    set link(value: string);
    resetLink(): void;
    get linkInput(): string | undefined;
    private _overrideLabel?;
    get overrideLabel(): string;
    set overrideLabel(value: string);
    resetOverrideLabel(): void;
    get overrideLabelInput(): string | undefined;
}
export declare class PowerpackWidgetTimeseriesDefinitionCustomLinkList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetTimeseriesDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetTimeseriesDefinitionCustomLinkOutputReference;
}
export interface PowerpackWidgetTimeseriesDefinitionEvent {
    /**
    * The event query to use in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#q Powerpack#q}
    */
    readonly q: string;
    /**
    * The execution method for multi-value filters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#tags_execution Powerpack#tags_execution}
    */
    readonly tagsExecution?: string;
}
export declare function powerpackWidgetTimeseriesDefinitionEventToTerraform(struct?: PowerpackWidgetTimeseriesDefinitionEvent | cdktn.IResolvable): any;
export declare function powerpackWidgetTimeseriesDefinitionEventToHclTerraform(struct?: PowerpackWidgetTimeseriesDefinitionEvent | cdktn.IResolvable): any;
export declare class PowerpackWidgetTimeseriesDefinitionEventOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetTimeseriesDefinitionEvent | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetTimeseriesDefinitionEvent | cdktn.IResolvable | undefined);
    private _q?;
    get q(): string;
    set q(value: string);
    get qInput(): string | undefined;
    private _tagsExecution?;
    get tagsExecution(): string;
    set tagsExecution(value: string);
    resetTagsExecution(): void;
    get tagsExecutionInput(): string | undefined;
}
export declare class PowerpackWidgetTimeseriesDefinitionEventList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetTimeseriesDefinitionEvent[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetTimeseriesDefinitionEventOutputReference;
}
export interface PowerpackWidgetTimeseriesDefinitionMarker {
    /**
    * How the marker lines are displayed, options are one of {`error`, `warning`, `info`, `ok`} combined with one of {`dashed`, `solid`, `bold`}. Example: `error dashed`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#display_type Powerpack#display_type}
    */
    readonly displayType?: string;
    /**
    * A label for the line or range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label?: string;
    /**
    * A mathematical expression describing the marker, for example: `y > 1`, `-5 < y < 0`, `y = 19`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#value Powerpack#value}
    */
    readonly value: string;
}
export declare function powerpackWidgetTimeseriesDefinitionMarkerToTerraform(struct?: PowerpackWidgetTimeseriesDefinitionMarker | cdktn.IResolvable): any;
export declare function powerpackWidgetTimeseriesDefinitionMarkerToHclTerraform(struct?: PowerpackWidgetTimeseriesDefinitionMarker | cdktn.IResolvable): any;
export declare class PowerpackWidgetTimeseriesDefinitionMarkerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetTimeseriesDefinitionMarker | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetTimeseriesDefinitionMarker | cdktn.IResolvable | undefined);
    private _displayType?;
    get displayType(): string;
    set displayType(value: string);
    resetDisplayType(): void;
    get displayTypeInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class PowerpackWidgetTimeseriesDefinitionMarkerList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetTimeseriesDefinitionMarker[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetTimeseriesDefinitionMarkerOutputReference;
}
export interface PowerpackWidgetTimeseriesDefinitionRequestApmQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetTimeseriesDefinitionRequestApmQueryComputeQueryToTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestApmQueryComputeQueryOutputReference | PowerpackWidgetTimeseriesDefinitionRequestApmQueryComputeQuery): any;
export declare function powerpackWidgetTimeseriesDefinitionRequestApmQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestApmQueryComputeQueryOutputReference | PowerpackWidgetTimeseriesDefinitionRequestApmQueryComputeQuery): any;
export declare class PowerpackWidgetTimeseriesDefinitionRequestApmQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetTimeseriesDefinitionRequestApmQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetTimeseriesDefinitionRequestApmQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBySortQueryOutputReference | PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBySortQuery): any;
export declare function powerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBySortQueryOutputReference | PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBySortQuery): any;
export declare class PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBySortQuery;
}
export declare function powerpackWidgetTimeseriesDefinitionRequestApmQueryGroupByToTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetTimeseriesDefinitionRequestApmQueryGroupByToHclTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupByOutputReference;
}
export interface PowerpackWidgetTimeseriesDefinitionRequestApmQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetTimeseriesDefinitionRequestApmQueryMultiComputeToTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetTimeseriesDefinitionRequestApmQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetTimeseriesDefinitionRequestApmQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetTimeseriesDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetTimeseriesDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetTimeseriesDefinitionRequestApmQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetTimeseriesDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetTimeseriesDefinitionRequestApmQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetTimeseriesDefinitionRequestApmQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetTimeseriesDefinitionRequestApmQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetTimeseriesDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetTimeseriesDefinitionRequestApmQueryToTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestApmQueryOutputReference | PowerpackWidgetTimeseriesDefinitionRequestApmQuery): any;
export declare function powerpackWidgetTimeseriesDefinitionRequestApmQueryToHclTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestApmQueryOutputReference | PowerpackWidgetTimeseriesDefinitionRequestApmQuery): any;
export declare class PowerpackWidgetTimeseriesDefinitionRequestApmQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetTimeseriesDefinitionRequestApmQuery | undefined;
    set internalValue(value: PowerpackWidgetTimeseriesDefinitionRequestApmQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetTimeseriesDefinitionRequestApmQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetTimeseriesDefinitionRequestApmQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetTimeseriesDefinitionRequestApmQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupByList;
    putGroupBy(value: PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetTimeseriesDefinitionRequestApmQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetTimeseriesDefinitionRequestApmQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetTimeseriesDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetTimeseriesDefinitionRequestApmQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetTimeseriesDefinitionRequestAuditQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetTimeseriesDefinitionRequestAuditQueryComputeQueryToTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryComputeQueryOutputReference | PowerpackWidgetTimeseriesDefinitionRequestAuditQueryComputeQuery): any;
export declare function powerpackWidgetTimeseriesDefinitionRequestAuditQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryComputeQueryOutputReference | PowerpackWidgetTimeseriesDefinitionRequestAuditQueryComputeQuery): any;
export declare class PowerpackWidgetTimeseriesDefinitionRequestAuditQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetTimeseriesDefinitionRequestAuditQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBySortQueryOutputReference | PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBySortQuery): any;
export declare function powerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBySortQueryOutputReference | PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBySortQuery): any;
export declare class PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBySortQuery;
}
export declare function powerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupByToTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupByToHclTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupByOutputReference;
}
export interface PowerpackWidgetTimeseriesDefinitionRequestAuditQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetTimeseriesDefinitionRequestAuditQueryMultiComputeToTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetTimeseriesDefinitionRequestAuditQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetTimeseriesDefinitionRequestAuditQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetTimeseriesDefinitionRequestAuditQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetTimeseriesDefinitionRequestAuditQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetTimeseriesDefinitionRequestAuditQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetTimeseriesDefinitionRequestAuditQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetTimeseriesDefinitionRequestAuditQueryToTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryOutputReference | PowerpackWidgetTimeseriesDefinitionRequestAuditQuery): any;
export declare function powerpackWidgetTimeseriesDefinitionRequestAuditQueryToHclTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryOutputReference | PowerpackWidgetTimeseriesDefinitionRequestAuditQuery): any;
export declare class PowerpackWidgetTimeseriesDefinitionRequestAuditQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetTimeseriesDefinitionRequestAuditQuery | undefined;
    set internalValue(value: PowerpackWidgetTimeseriesDefinitionRequestAuditQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetTimeseriesDefinitionRequestAuditQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetTimeseriesDefinitionRequestAuditQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupByList;
    putGroupBy(value: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetTimeseriesDefinitionRequestAuditQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetTimeseriesDefinitionRequestAuditQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetTimeseriesDefinitionRequestAuditQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetTimeseriesDefinitionRequestAuditQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetTimeseriesDefinitionRequestFormulaConditionalFormats {
    /**
    * The comparator to use. Valid values are `=`, `>`, `>=`, `<`, `<=`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#comparator Powerpack#comparator}
    */
    readonly comparator: string;
    /**
    * The color palette to apply to the background, same values available as palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_bg_color Powerpack#custom_bg_color}
    */
    readonly customBgColor?: string;
    /**
    * The color palette to apply to the foreground, same values available as palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_fg_color Powerpack#custom_fg_color}
    */
    readonly customFgColor?: string;
    /**
    * Setting this to True hides values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_value Powerpack#hide_value}
    */
    readonly hideValue?: boolean | cdktn.IResolvable;
    /**
    * Displays an image as the background.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#image_url Powerpack#image_url}
    */
    readonly imageUrl?: string;
    /**
    * The metric from the request to correlate with this conditional format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
    /**
    * The color palette to apply. Valid values are `blue`, `custom_bg`, `custom_image`, `custom_text`, `gray_on_white`, `grey`, `green`, `orange`, `red`, `red_on_white`, `white_on_gray`, `white_on_green`, `green_on_white`, `white_on_red`, `white_on_yellow`, `yellow_on_white`, `black_on_light_yellow`, `black_on_light_green`, `black_on_light_red`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette Powerpack#palette}
    */
    readonly palette: string;
    /**
    * Defines the displayed timeframe.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#timeframe Powerpack#timeframe}
    */
    readonly timeframe?: string;
    /**
    * A value for the comparator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#value Powerpack#value}
    */
    readonly value: number;
}
export declare function powerpackWidgetTimeseriesDefinitionRequestFormulaConditionalFormatsToTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable): any;
export declare function powerpackWidgetTimeseriesDefinitionRequestFormulaConditionalFormatsToHclTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable): any;
export declare class PowerpackWidgetTimeseriesDefinitionRequestFormulaConditionalFormatsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetTimeseriesDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetTimeseriesDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable | undefined);
    private _comparator?;
    get comparator(): string;
    set comparator(value: string);
    get comparatorInput(): string | undefined;
    private _customBgColor?;
    get customBgColor(): string;
    set customBgColor(value: string);
    resetCustomBgColor(): void;
    get customBgColorInput(): string | undefined;
    private _customFgColor?;
    get customFgColor(): string;
    set customFgColor(value: string);
    resetCustomFgColor(): void;
    get customFgColorInput(): string | undefined;
    private _hideValue?;
    get hideValue(): boolean | cdktn.IResolvable;
    set hideValue(value: boolean | cdktn.IResolvable);
    resetHideValue(): void;
    get hideValueInput(): boolean | cdktn.IResolvable | undefined;
    private _imageUrl?;
    get imageUrl(): string;
    set imageUrl(value: string);
    resetImageUrl(): void;
    get imageUrlInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _palette?;
    get palette(): string;
    set palette(value: string);
    get paletteInput(): string | undefined;
    private _timeframe?;
    get timeframe(): string;
    set timeframe(value: string);
    resetTimeframe(): void;
    get timeframeInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class PowerpackWidgetTimeseriesDefinitionRequestFormulaConditionalFormatsList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetTimeseriesDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetTimeseriesDefinitionRequestFormulaConditionalFormatsOutputReference;
}
export interface PowerpackWidgetTimeseriesDefinitionRequestFormulaLimit {
    /**
    * The number of results to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#count Powerpack#count}
    */
    readonly count?: number;
    /**
    * The direction of the sort. Valid values are `asc`, `desc`. Defaults to `"desc"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order?: string;
}
export declare function powerpackWidgetTimeseriesDefinitionRequestFormulaLimitToTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestFormulaLimitOutputReference | PowerpackWidgetTimeseriesDefinitionRequestFormulaLimit): any;
export declare function powerpackWidgetTimeseriesDefinitionRequestFormulaLimitToHclTerraform(struct?: PowerpackWidgetTimeseriesDefinitionRequestFormulaLimitOutputReference | PowerpackWidgetTimeseriesDefinitionRequestFormulaLimit): any;
export declare class PowerpackWidgetTimeseriesDefinitionRequestFormulaLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetTimeseriesDefinitionRequestFormulaLimit | undefined;
    set internalValue(value: PowerpackWidgetTimeseriesDefinitionRequestFormulaLimit | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    resetCount(): void;
    get countInput(): number | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
