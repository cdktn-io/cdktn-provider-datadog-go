/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
import { PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCanonical, PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference, PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCustom, PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCustomOutputReference, PowerpackWidgetQueryTableDefinitionRequestFormulaCellDisplayModeOptions, PowerpackWidgetQueryTableDefinitionRequestFormulaCellDisplayModeOptionsOutputReference, PowerpackWidgetQueryTableDefinitionRequestFormulaConditionalFormats, PowerpackWidgetQueryTableDefinitionRequestFormulaConditionalFormatsList, PowerpackWidgetQueryTableDefinitionRequestFormulaLimit, PowerpackWidgetQueryTableDefinitionRequestFormulaLimitOutputReference, PowerpackWidgetQueryTableDefinitionRequestApmQuery, PowerpackWidgetQueryTableDefinitionRequestApmQueryOutputReference, PowerpackWidgetQueryTableDefinitionRequestApmStatsQuery, PowerpackWidgetQueryTableDefinitionRequestApmStatsQueryOutputReference, PowerpackWidgetQueryTableDefinitionRequestConditionalFormats, PowerpackWidgetQueryTableDefinitionRequestConditionalFormatsList, PowerpackWidgetQueryTableDefinitionCustomLink, PowerpackWidgetQueryTableDefinitionCustomLinkList } from './structs400';
export interface PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnit {
    /**
    * canonical block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#canonical Powerpack#canonical}
    */
    readonly canonical?: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCanonical;
    /**
    * custom block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom Powerpack#custom}
    */
    readonly custom?: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCustom;
}
export declare function powerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitOutputReference | PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnit): any;
export declare function powerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitOutputReference | PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnit): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnit | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnit | undefined);
    private _canonical;
    get canonical(): PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference;
    putCanonical(value: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCanonical): void;
    resetCanonical(): void;
    get canonicalInput(): PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCanonical | undefined;
    private _custom;
    get custom(): PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCustomOutputReference;
    putCustom(value: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCustom): void;
    resetCustom(): void;
    get customInput(): PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCustom | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitScale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit_name Powerpack#unit_name}
    */
    readonly unitName: string;
}
export declare function powerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitScaleToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitScaleOutputReference | PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitScale): any;
export declare function powerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitScaleToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitScaleOutputReference | PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitScale): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitScaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitScale | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitScale | undefined);
    private _unitName?;
    get unitName(): string;
    set unitName(value: string);
    get unitNameInput(): string | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormat {
    /**
    * unit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit Powerpack#unit}
    */
    readonly unit: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnit;
    /**
    * unit_scale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit_scale Powerpack#unit_scale}
    */
    readonly unitScale?: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitScale;
}
export declare function powerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatOutputReference | PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormat): any;
export declare function powerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatOutputReference | PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormat): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormat | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormat | undefined);
    private _unit;
    get unit(): PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitOutputReference;
    putUnit(value: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnit): void;
    get unitInput(): PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnit | undefined;
    private _unitScale;
    get unitScale(): PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitScaleOutputReference;
    putUnitScale(value: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitScale): void;
    resetUnitScale(): void;
    get unitScaleInput(): PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitScale | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestFormulaStyle {
    /**
    * The color palette used to display the formula. A guide to the available color palettes can be found at https://docs.datadoghq.com/dashboards/guide/widget_colors.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette Powerpack#palette}
    */
    readonly palette?: string;
    /**
    * Index specifying which color to use within the palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette_index Powerpack#palette_index}
    */
    readonly paletteIndex?: number;
}
export declare function powerpackWidgetQueryTableDefinitionRequestFormulaStyleToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestFormulaStyleOutputReference | PowerpackWidgetQueryTableDefinitionRequestFormulaStyle): any;
export declare function powerpackWidgetQueryTableDefinitionRequestFormulaStyleToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestFormulaStyleOutputReference | PowerpackWidgetQueryTableDefinitionRequestFormulaStyle): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestFormulaStyleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestFormulaStyle | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestFormulaStyle | undefined);
    private _palette?;
    get palette(): string;
    set palette(value: string);
    resetPalette(): void;
    get paletteInput(): string | undefined;
    private _paletteIndex?;
    get paletteIndex(): number;
    set paletteIndex(value: number);
    resetPaletteIndex(): void;
    get paletteIndexInput(): number | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestFormula {
    /**
    * An expression alias.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#alias Powerpack#alias}
    */
    readonly alias?: string;
    /**
    * A list of display modes for each table cell. Valid values are `number`, `bar`, `trend`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cell_display_mode Powerpack#cell_display_mode}
    */
    readonly cellDisplayMode?: string;
    /**
    * A string expression built from queries, formulas, and functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#formula_expression Powerpack#formula_expression}
    */
    readonly formulaExpression: string;
    /**
    * cell_display_mode_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cell_display_mode_options Powerpack#cell_display_mode_options}
    */
    readonly cellDisplayModeOptions?: PowerpackWidgetQueryTableDefinitionRequestFormulaCellDisplayModeOptions;
    /**
    * conditional_formats block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#conditional_formats Powerpack#conditional_formats}
    */
    readonly conditionalFormats?: PowerpackWidgetQueryTableDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: PowerpackWidgetQueryTableDefinitionRequestFormulaLimit;
    /**
    * number_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#number_format Powerpack#number_format}
    */
    readonly numberFormat?: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormat;
    /**
    * style block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#style Powerpack#style}
    */
    readonly style?: PowerpackWidgetQueryTableDefinitionRequestFormulaStyle;
}
export declare function powerpackWidgetQueryTableDefinitionRequestFormulaToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestFormula | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryTableDefinitionRequestFormulaToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestFormula | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestFormulaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestFormula | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestFormula | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _cellDisplayMode?;
    get cellDisplayMode(): string;
    set cellDisplayMode(value: string);
    resetCellDisplayMode(): void;
    get cellDisplayModeInput(): string | undefined;
    private _formulaExpression?;
    get formulaExpression(): string;
    set formulaExpression(value: string);
    get formulaExpressionInput(): string | undefined;
    private _cellDisplayModeOptions;
    get cellDisplayModeOptions(): PowerpackWidgetQueryTableDefinitionRequestFormulaCellDisplayModeOptionsOutputReference;
    putCellDisplayModeOptions(value: PowerpackWidgetQueryTableDefinitionRequestFormulaCellDisplayModeOptions): void;
    resetCellDisplayModeOptions(): void;
    get cellDisplayModeOptionsInput(): PowerpackWidgetQueryTableDefinitionRequestFormulaCellDisplayModeOptions | undefined;
    private _conditionalFormats;
    get conditionalFormats(): PowerpackWidgetQueryTableDefinitionRequestFormulaConditionalFormatsList;
    putConditionalFormats(value: PowerpackWidgetQueryTableDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable): void;
    resetConditionalFormats(): void;
    get conditionalFormatsInput(): cdktn.IResolvable | PowerpackWidgetQueryTableDefinitionRequestFormulaConditionalFormats[] | undefined;
    private _limit;
    get limit(): PowerpackWidgetQueryTableDefinitionRequestFormulaLimitOutputReference;
    putLimit(value: PowerpackWidgetQueryTableDefinitionRequestFormulaLimit): void;
    resetLimit(): void;
    get limitInput(): PowerpackWidgetQueryTableDefinitionRequestFormulaLimit | undefined;
    private _numberFormat;
    get numberFormat(): PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatOutputReference;
    putNumberFormat(value: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormat): void;
    resetNumberFormat(): void;
    get numberFormatInput(): PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormat | undefined;
    private _style;
    get style(): PowerpackWidgetQueryTableDefinitionRequestFormulaStyleOutputReference;
    putStyle(value: PowerpackWidgetQueryTableDefinitionRequestFormulaStyle): void;
    resetStyle(): void;
    get styleInput(): PowerpackWidgetQueryTableDefinitionRequestFormulaStyle | undefined;
}
export declare class PowerpackWidgetQueryTableDefinitionRequestFormulaList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryTableDefinitionRequestFormula[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryTableDefinitionRequestFormulaOutputReference;
}
export interface PowerpackWidgetQueryTableDefinitionRequestLogQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetQueryTableDefinitionRequestLogQueryComputeQueryToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestLogQueryComputeQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestLogQueryComputeQuery): any;
export declare function powerpackWidgetQueryTableDefinitionRequestLogQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestLogQueryComputeQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestLogQueryComputeQuery): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestLogQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestLogQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestLogQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetQueryTableDefinitionRequestLogQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupBySortQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupBySortQuery): any;
export declare function powerpackWidgetQueryTableDefinitionRequestLogQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupBySortQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupBySortQuery): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupBySortQuery;
}
export declare function powerpackWidgetQueryTableDefinitionRequestLogQueryGroupByToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryTableDefinitionRequestLogQueryGroupByToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupByOutputReference;
}
export interface PowerpackWidgetQueryTableDefinitionRequestLogQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetQueryTableDefinitionRequestLogQueryMultiComputeToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryTableDefinitionRequestLogQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestLogQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetQueryTableDefinitionRequestLogQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryTableDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryTableDefinitionRequestLogQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetQueryTableDefinitionRequestLogQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetQueryTableDefinitionRequestLogQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetQueryTableDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetQueryTableDefinitionRequestLogQueryToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestLogQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestLogQuery): any;
export declare function powerpackWidgetQueryTableDefinitionRequestLogQueryToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestLogQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestLogQuery): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestLogQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestLogQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestLogQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetQueryTableDefinitionRequestLogQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetQueryTableDefinitionRequestLogQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetQueryTableDefinitionRequestLogQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupByList;
    putGroupBy(value: PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetQueryTableDefinitionRequestLogQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetQueryTableDefinitionRequestLogQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetQueryTableDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetQueryTableDefinitionRequestLogQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestProcessQuery {
    /**
    * A list of processes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#filter_by Powerpack#filter_by}
    */
    readonly filterBy?: string[];
    /**
    * The max number of items in the filter list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * Your chosen metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric: string;
    /**
    * Your chosen search term.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_by Powerpack#search_by}
    */
    readonly searchBy?: string;
}
export declare function powerpackWidgetQueryTableDefinitionRequestProcessQueryToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestProcessQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestProcessQuery): any;
export declare function powerpackWidgetQueryTableDefinitionRequestProcessQueryToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestProcessQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestProcessQuery): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestProcessQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestProcessQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestProcessQuery | undefined);
    private _filterBy?;
    get filterBy(): string[];
    set filterBy(value: string[]);
    resetFilterBy(): void;
    get filterByInput(): string[] | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _searchBy?;
    get searchBy(): string;
    set searchBy(value: string);
    resetSearchBy(): void;
    get searchByInput(): string | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestQueryApmDependencyStatsQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for APM Dependency Stats queries. Valid values are `apm_dependency_stats`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * APM environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#env Powerpack#env}
    */
    readonly env: string;
    /**
    * Determines whether stats for upstream or downstream dependencies should be queried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_upstream Powerpack#is_upstream}
    */
    readonly isUpstream?: boolean | cdktn.IResolvable;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Name of operation on service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#operation_name Powerpack#operation_name}
    */
    readonly operationName: string;
    /**
    * The name of the second primary tag used within APM; required when `primary_tag_value` is specified. See https://docs.datadoghq.com/tracing/guide/setting_primary_tags_to_scope/#add-a-second-primary-tag-in-datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_name Powerpack#primary_tag_name}
    */
    readonly primaryTagName?: string;
    /**
    * Filter APM data by the second primary tag. `primary_tag_name` must also be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_value Powerpack#primary_tag_value}
    */
    readonly primaryTagValue?: string;
    /**
    * APM resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#resource_name Powerpack#resource_name}
    */
    readonly resourceName: string;
    /**
    * APM service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#service Powerpack#service}
    */
    readonly service: string;
    /**
    * APM statistic. Valid values are `avg_duration`, `avg_root_duration`, `avg_spans_per_trace`, `error_rate`, `pct_exec_time`, `pct_of_traces`, `total_traces_count`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#stat Powerpack#stat}
    */
    readonly stat: string;
}
export declare function powerpackWidgetQueryTableDefinitionRequestQueryApmDependencyStatsQueryToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQueryApmDependencyStatsQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestQueryApmDependencyStatsQuery): any;
export declare function powerpackWidgetQueryTableDefinitionRequestQueryApmDependencyStatsQueryToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQueryApmDependencyStatsQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestQueryApmDependencyStatsQuery): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestQueryApmDependencyStatsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestQueryApmDependencyStatsQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestQueryApmDependencyStatsQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    private _isUpstream?;
    get isUpstream(): boolean | cdktn.IResolvable;
    set isUpstream(value: boolean | cdktn.IResolvable);
    resetIsUpstream(): void;
    get isUpstreamInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    get operationNameInput(): string | undefined;
    private _primaryTagName?;
    get primaryTagName(): string;
    set primaryTagName(value: string);
    resetPrimaryTagName(): void;
    get primaryTagNameInput(): string | undefined;
    private _primaryTagValue?;
    get primaryTagValue(): string;
    set primaryTagValue(value: string);
    resetPrimaryTagValue(): void;
    get primaryTagValueInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    get resourceNameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    get statInput(): string | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestQueryApmResourceStatsQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for APM Resource Stats queries. Valid values are `apm_resource_stats`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * APM environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#env Powerpack#env}
    */
    readonly env: string;
    /**
    * Array of fields to group results by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: string[];
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Name of operation on service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#operation_name Powerpack#operation_name}
    */
    readonly operationName?: string;
    /**
    * The name of the second primary tag used within APM; required when `primary_tag_value` is specified. See https://docs.datadoghq.com/tracing/guide/setting_primary_tags_to_scope/#add-a-second-primary-tag-in-datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_name Powerpack#primary_tag_name}
    */
    readonly primaryTagName?: string;
    /**
    * Filter APM data by the second primary tag. `primary_tag_name` must also be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_value Powerpack#primary_tag_value}
    */
    readonly primaryTagValue?: string;
    /**
    * APM resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#resource_name Powerpack#resource_name}
    */
    readonly resourceName?: string;
    /**
    * APM service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#service Powerpack#service}
    */
    readonly service: string;
    /**
    * APM statistic. Valid values are `errors`, `error_rate`, `hits`, `latency_avg`, `latency_distribution`, `latency_max`, `latency_p50`, `latency_p75`, `latency_p90`, `latency_p95`, `latency_p99`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#stat Powerpack#stat}
    */
    readonly stat: string;
}
export declare function powerpackWidgetQueryTableDefinitionRequestQueryApmResourceStatsQueryToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQueryApmResourceStatsQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestQueryApmResourceStatsQuery): any;
export declare function powerpackWidgetQueryTableDefinitionRequestQueryApmResourceStatsQueryToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQueryApmResourceStatsQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestQueryApmResourceStatsQuery): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestQueryApmResourceStatsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestQueryApmResourceStatsQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestQueryApmResourceStatsQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    private _groupBy?;
    get groupBy(): string[];
    set groupBy(value: string[]);
    resetGroupBy(): void;
    get groupByInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    resetOperationName(): void;
    get operationNameInput(): string | undefined;
    private _primaryTagName?;
    get primaryTagName(): string;
    set primaryTagName(value: string);
    resetPrimaryTagName(): void;
    get primaryTagNameInput(): string | undefined;
    private _primaryTagValue?;
    get primaryTagValue(): string;
    set primaryTagValue(value: string);
    resetPrimaryTagValue(): void;
    get primaryTagValueInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    resetResourceName(): void;
    get resourceNameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    get statInput(): string | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestQueryCloudCostQuery {
    /**
    * The aggregation methods available for cloud cost queries. Valid values are `avg`, `last`, `max`, `min`, `sum`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for cloud cost queries. Valid values are `cloud_cost`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The cloud cost query definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
}
export declare function powerpackWidgetQueryTableDefinitionRequestQueryCloudCostQueryToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQueryCloudCostQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestQueryCloudCostQuery): any;
export declare function powerpackWidgetQueryTableDefinitionRequestQueryCloudCostQueryToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQueryCloudCostQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestQueryCloudCostQuery): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestQueryCloudCostQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestQueryCloudCostQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestQueryCloudCostQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryCompute {
    /**
    * The aggregation methods for event platform queries. Valid values are `count`, `cardinality`, `median`, `pc75`, `pc90`, `pc95`, `pc98`, `pc99`, `sum`, `min`, `max`, `avg`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * A time interval in milliseconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
    /**
    * The measurable attribute to compute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
}
export declare function powerpackWidgetQueryTableDefinitionRequestQueryEventQueryComputeToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryTableDefinitionRequestQueryEventQueryComputeToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
}
export declare class PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryComputeOutputReference;
}
export interface PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBySort {
    /**
    * The aggregation methods for the event platform queries. Valid values are `count`, `cardinality`, `median`, `pc75`, `pc90`, `pc95`, `pc98`, `pc99`, `sum`, `min`, `max`, `avg`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The metric used for sorting group by results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
    /**
    * Direction of sort. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order?: string;
}
export declare function powerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBySortToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBySortOutputReference | PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBySort): any;
export declare function powerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBySortToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBySortOutputReference | PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBySort): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBySortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBySort | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBySort | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBy {
    /**
    * The event facet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet: string;
    /**
    * The number of groups to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort Powerpack#sort}
    */
    readonly sort?: PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBySort;
}
export declare function powerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupByToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupByToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sort;
    get sort(): PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBySortOutputReference;
    putSort(value: PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBySort): void;
    resetSort(): void;
    get sortInput(): PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBySort | undefined;
}
export declare class PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupByOutputReference;
}
export interface PowerpackWidgetQueryTableDefinitionRequestQueryEventQuerySearch {
    /**
    * The events search string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
}
export declare function powerpackWidgetQueryTableDefinitionRequestQueryEventQuerySearchToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQueryEventQuerySearchOutputReference | PowerpackWidgetQueryTableDefinitionRequestQueryEventQuerySearch): any;
export declare function powerpackWidgetQueryTableDefinitionRequestQueryEventQuerySearchToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQueryEventQuerySearchOutputReference | PowerpackWidgetQueryTableDefinitionRequestQueryEventQuerySearch): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestQueryEventQuerySearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestQueryEventQuerySearch | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestQueryEventQuerySearch | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestQueryEventQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for event platform-based queries. Valid values are `logs`, `spans`, `network`, `rum`, `security_signals`, `profiles`, `audit`, `events`, `ci_tests`, `ci_pipelines`, `incident_analytics`, `product_analytics`, `on_call_events`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * An array of index names to query in the stream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#indexes Powerpack#indexes}
    */
    readonly indexes?: string[];
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Storage location (private beta).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#storage Powerpack#storage}
    */
    readonly storage?: string;
    /**
    * compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute Powerpack#compute}
    */
    readonly compute: PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable;
    /**
    * search block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search Powerpack#search}
    */
    readonly search?: PowerpackWidgetQueryTableDefinitionRequestQueryEventQuerySearch;
}
export declare function powerpackWidgetQueryTableDefinitionRequestQueryEventQueryToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestQueryEventQuery): any;
export declare function powerpackWidgetQueryTableDefinitionRequestQueryEventQueryToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestQueryEventQuery): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestQueryEventQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestQueryEventQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _indexes?;
    get indexes(): string[];
    set indexes(value: string[]);
    resetIndexes(): void;
    get indexesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _storage?;
    get storage(): string;
    set storage(value: string);
    resetStorage(): void;
    get storageInput(): string | undefined;
    private _compute;
    get compute(): PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryComputeList;
    putCompute(value: PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable): void;
    get computeInput(): cdktn.IResolvable | PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryCompute[] | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupByList;
    putGroupBy(value: PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryGroupBy[] | undefined;
    private _search;
    get search(): PowerpackWidgetQueryTableDefinitionRequestQueryEventQuerySearchOutputReference;
    putSearch(value: PowerpackWidgetQueryTableDefinitionRequestQueryEventQuerySearch): void;
    resetSearch(): void;
    get searchInput(): PowerpackWidgetQueryTableDefinitionRequestQueryEventQuerySearch | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestQueryMetricQuery {
    /**
    * The aggregation methods available for metrics queries. Valid values are `avg`, `min`, `max`, `sum`, `last`, `area`, `l2norm`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for metrics queries. Defaults to `"metrics"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource?: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The metrics query definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
    /**
    * Semantic mode for metrics queries. This determines how metrics from different sources are combined or displayed. Valid values are `combined`, `native`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#semantic_mode Powerpack#semantic_mode}
    */
    readonly semanticMode?: string;
}
export declare function powerpackWidgetQueryTableDefinitionRequestQueryMetricQueryToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQueryMetricQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestQueryMetricQuery): any;
export declare function powerpackWidgetQueryTableDefinitionRequestQueryMetricQueryToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQueryMetricQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestQueryMetricQuery): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestQueryMetricQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestQueryMetricQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestQueryMetricQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    resetDataSource(): void;
    get dataSourceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _semanticMode?;
    get semanticMode(): string;
    set semanticMode(value: string);
    resetSemanticMode(): void;
    get semanticModeInput(): string | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestQueryProcessQuery {
    /**
    * The aggregation methods available for metrics queries. Valid values are `avg`, `min`, `max`, `sum`, `last`, `area`, `l2norm`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for process queries. Valid values are `process`, `container`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * Whether to normalize the CPU percentages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_normalized_cpu Powerpack#is_normalized_cpu}
    */
    readonly isNormalizedCpu?: boolean | cdktn.IResolvable;
    /**
    * The number of hits to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * The process metric name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric: string;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The direction of the sort. Valid values are `asc`, `desc`. Defaults to `"desc"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort Powerpack#sort}
    */
    readonly sort?: string;
    /**
    * An array of tags to filter by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#tag_filters Powerpack#tag_filters}
    */
    readonly tagFilters?: string[];
    /**
    * The text to use as a filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#text_filter Powerpack#text_filter}
    */
    readonly textFilter?: string;
}
export declare function powerpackWidgetQueryTableDefinitionRequestQueryProcessQueryToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQueryProcessQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestQueryProcessQuery): any;
export declare function powerpackWidgetQueryTableDefinitionRequestQueryProcessQueryToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQueryProcessQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestQueryProcessQuery): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestQueryProcessQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestQueryProcessQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestQueryProcessQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _isNormalizedCpu?;
    get isNormalizedCpu(): boolean | cdktn.IResolvable;
    set isNormalizedCpu(value: boolean | cdktn.IResolvable);
    resetIsNormalizedCpu(): void;
    get isNormalizedCpuInput(): boolean | cdktn.IResolvable | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _sort?;
    get sort(): string;
    set sort(value: string);
    resetSort(): void;
    get sortInput(): string | undefined;
    private _tagFilters?;
    get tagFilters(): string[];
    set tagFilters(value: string[]);
    resetTagFilters(): void;
    get tagFiltersInput(): string[] | undefined;
    private _textFilter?;
    get textFilter(): string;
    set textFilter(value: string);
    resetTextFilter(): void;
    get textFilterInput(): string | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestQuerySloQuery {
    /**
    * Additional filters applied to the SLO query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#additional_query_filters Powerpack#additional_query_filters}
    */
    readonly additionalQueryFilters?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for SLO queries. Valid values are `slo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * Group mode to query measures. Valid values are `overall`, `components`. Defaults to `"overall"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_mode Powerpack#group_mode}
    */
    readonly groupMode?: string;
    /**
    * SLO measures queries. Valid values are `good_events`, `bad_events`, `good_minutes`, `bad_minutes`, `slo_status`, `error_budget_remaining`, `burn_rate`, `error_budget_burndown`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#measure Powerpack#measure}
    */
    readonly measure: string;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name?: string;
    /**
    * ID of an SLO to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_id Powerpack#slo_id}
    */
    readonly sloId: string;
    /**
    * type of the SLO to query. Valid values are `metric`, `monitor`, `time_slice`. Defaults to `"metric"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_query_type Powerpack#slo_query_type}
    */
    readonly sloQueryType?: string;
}
export declare function powerpackWidgetQueryTableDefinitionRequestQuerySloQueryToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQuerySloQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestQuerySloQuery): any;
export declare function powerpackWidgetQueryTableDefinitionRequestQuerySloQueryToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQuerySloQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestQuerySloQuery): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestQuerySloQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestQuerySloQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestQuerySloQuery | undefined);
    private _additionalQueryFilters?;
    get additionalQueryFilters(): string;
    set additionalQueryFilters(value: string);
    resetAdditionalQueryFilters(): void;
    get additionalQueryFiltersInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _groupMode?;
    get groupMode(): string;
    set groupMode(value: string);
    resetGroupMode(): void;
    get groupModeInput(): string | undefined;
    private _measure?;
    get measure(): string;
    set measure(value: string);
    get measureInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sloId?;
    get sloId(): string;
    set sloId(value: string);
    get sloIdInput(): string | undefined;
    private _sloQueryType?;
    get sloQueryType(): string;
    set sloQueryType(value: string);
    resetSloQueryType(): void;
    get sloQueryTypeInput(): string | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestQuery {
    /**
    * apm_dependency_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_dependency_stats_query Powerpack#apm_dependency_stats_query}
    */
    readonly apmDependencyStatsQuery?: PowerpackWidgetQueryTableDefinitionRequestQueryApmDependencyStatsQuery;
    /**
    * apm_resource_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_resource_stats_query Powerpack#apm_resource_stats_query}
    */
    readonly apmResourceStatsQuery?: PowerpackWidgetQueryTableDefinitionRequestQueryApmResourceStatsQuery;
    /**
    * cloud_cost_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cloud_cost_query Powerpack#cloud_cost_query}
    */
    readonly cloudCostQuery?: PowerpackWidgetQueryTableDefinitionRequestQueryCloudCostQuery;
    /**
    * event_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#event_query Powerpack#event_query}
    */
    readonly eventQuery?: PowerpackWidgetQueryTableDefinitionRequestQueryEventQuery;
    /**
    * metric_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric_query Powerpack#metric_query}
    */
    readonly metricQuery?: PowerpackWidgetQueryTableDefinitionRequestQueryMetricQuery;
    /**
    * process_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#process_query Powerpack#process_query}
    */
    readonly processQuery?: PowerpackWidgetQueryTableDefinitionRequestQueryProcessQuery;
    /**
    * slo_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_query Powerpack#slo_query}
    */
    readonly sloQuery?: PowerpackWidgetQueryTableDefinitionRequestQuerySloQuery;
}
export declare function powerpackWidgetQueryTableDefinitionRequestQueryToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQuery | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryTableDefinitionRequestQueryToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestQuery | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestQuery | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestQuery | cdktn.IResolvable | undefined);
    private _apmDependencyStatsQuery;
    get apmDependencyStatsQuery(): PowerpackWidgetQueryTableDefinitionRequestQueryApmDependencyStatsQueryOutputReference;
    putApmDependencyStatsQuery(value: PowerpackWidgetQueryTableDefinitionRequestQueryApmDependencyStatsQuery): void;
    resetApmDependencyStatsQuery(): void;
    get apmDependencyStatsQueryInput(): PowerpackWidgetQueryTableDefinitionRequestQueryApmDependencyStatsQuery | undefined;
    private _apmResourceStatsQuery;
    get apmResourceStatsQuery(): PowerpackWidgetQueryTableDefinitionRequestQueryApmResourceStatsQueryOutputReference;
    putApmResourceStatsQuery(value: PowerpackWidgetQueryTableDefinitionRequestQueryApmResourceStatsQuery): void;
    resetApmResourceStatsQuery(): void;
    get apmResourceStatsQueryInput(): PowerpackWidgetQueryTableDefinitionRequestQueryApmResourceStatsQuery | undefined;
    private _cloudCostQuery;
    get cloudCostQuery(): PowerpackWidgetQueryTableDefinitionRequestQueryCloudCostQueryOutputReference;
    putCloudCostQuery(value: PowerpackWidgetQueryTableDefinitionRequestQueryCloudCostQuery): void;
    resetCloudCostQuery(): void;
    get cloudCostQueryInput(): PowerpackWidgetQueryTableDefinitionRequestQueryCloudCostQuery | undefined;
    private _eventQuery;
    get eventQuery(): PowerpackWidgetQueryTableDefinitionRequestQueryEventQueryOutputReference;
    putEventQuery(value: PowerpackWidgetQueryTableDefinitionRequestQueryEventQuery): void;
    resetEventQuery(): void;
    get eventQueryInput(): PowerpackWidgetQueryTableDefinitionRequestQueryEventQuery | undefined;
    private _metricQuery;
    get metricQuery(): PowerpackWidgetQueryTableDefinitionRequestQueryMetricQueryOutputReference;
    putMetricQuery(value: PowerpackWidgetQueryTableDefinitionRequestQueryMetricQuery): void;
    resetMetricQuery(): void;
    get metricQueryInput(): PowerpackWidgetQueryTableDefinitionRequestQueryMetricQuery | undefined;
    private _processQuery;
    get processQuery(): PowerpackWidgetQueryTableDefinitionRequestQueryProcessQueryOutputReference;
    putProcessQuery(value: PowerpackWidgetQueryTableDefinitionRequestQueryProcessQuery): void;
    resetProcessQuery(): void;
    get processQueryInput(): PowerpackWidgetQueryTableDefinitionRequestQueryProcessQuery | undefined;
    private _sloQuery;
    get sloQuery(): PowerpackWidgetQueryTableDefinitionRequestQuerySloQueryOutputReference;
    putSloQuery(value: PowerpackWidgetQueryTableDefinitionRequestQuerySloQuery): void;
    resetSloQuery(): void;
    get sloQueryInput(): PowerpackWidgetQueryTableDefinitionRequestQuerySloQuery | undefined;
}
export declare class PowerpackWidgetQueryTableDefinitionRequestQueryList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryTableDefinitionRequestQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryTableDefinitionRequestQueryOutputReference;
}
export interface PowerpackWidgetQueryTableDefinitionRequestRumQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetQueryTableDefinitionRequestRumQueryComputeQueryToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestRumQueryComputeQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestRumQueryComputeQuery): any;
export declare function powerpackWidgetQueryTableDefinitionRequestRumQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestRumQueryComputeQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestRumQueryComputeQuery): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestRumQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestRumQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestRumQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetQueryTableDefinitionRequestRumQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupBySortQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupBySortQuery): any;
export declare function powerpackWidgetQueryTableDefinitionRequestRumQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupBySortQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupBySortQuery): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupBySortQuery;
}
export declare function powerpackWidgetQueryTableDefinitionRequestRumQueryGroupByToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryTableDefinitionRequestRumQueryGroupByToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupByOutputReference;
}
export interface PowerpackWidgetQueryTableDefinitionRequestRumQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetQueryTableDefinitionRequestRumQueryMultiComputeToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryTableDefinitionRequestRumQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestRumQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetQueryTableDefinitionRequestRumQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryTableDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryTableDefinitionRequestRumQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetQueryTableDefinitionRequestRumQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetQueryTableDefinitionRequestRumQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetQueryTableDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetQueryTableDefinitionRequestRumQueryToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestRumQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestRumQuery): any;
export declare function powerpackWidgetQueryTableDefinitionRequestRumQueryToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestRumQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestRumQuery): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestRumQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestRumQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestRumQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetQueryTableDefinitionRequestRumQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetQueryTableDefinitionRequestRumQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetQueryTableDefinitionRequestRumQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupByList;
    putGroupBy(value: PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetQueryTableDefinitionRequestRumQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetQueryTableDefinitionRequestRumQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetQueryTableDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetQueryTableDefinitionRequestRumQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestSecurityQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetQueryTableDefinitionRequestSecurityQueryComputeQueryToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryComputeQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestSecurityQueryComputeQuery): any;
export declare function powerpackWidgetQueryTableDefinitionRequestSecurityQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryComputeQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestSecurityQueryComputeQuery): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestSecurityQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestSecurityQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBySortQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBySortQuery): any;
export declare function powerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBySortQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBySortQuery): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBySortQuery;
}
export declare function powerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupByToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupByToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupByOutputReference;
}
export interface PowerpackWidgetQueryTableDefinitionRequestSecurityQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetQueryTableDefinitionRequestSecurityQueryMultiComputeToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryTableDefinitionRequestSecurityQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestSecurityQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetQueryTableDefinitionRequestSecurityQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryTableDefinitionRequestSecurityQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetQueryTableDefinitionRequestSecurityQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetQueryTableDefinitionRequestSecurityQueryToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestSecurityQuery): any;
export declare function powerpackWidgetQueryTableDefinitionRequestSecurityQueryToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestSecurityQuery): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestSecurityQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestSecurityQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestSecurityQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetQueryTableDefinitionRequestSecurityQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetQueryTableDefinitionRequestSecurityQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupByList;
    putGroupBy(value: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetQueryTableDefinitionRequestSecurityQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetQueryTableDefinitionRequestSecurityQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetQueryTableDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetQueryTableDefinitionRequestSecurityQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatMatch {
    /**
    * Match or compare option. Valid values are `is`, `is_not`, `contains`, `does_not_contain`, `starts_with`, `ends_with`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#type Powerpack#type}
    */
    readonly type: string;
    /**
    * Table Widget Match String.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#value Powerpack#value}
    */
    readonly value: string;
}
export declare function powerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatMatchToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatMatchOutputReference | PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatMatch): any;
export declare function powerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatMatchToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatMatchOutputReference | PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatMatch): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatMatch | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatMatch | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatReplace {
    /**
    * Text that will be replaced. Must be used with type `substring`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#substring Powerpack#substring}
    */
    readonly substring?: string;
    /**
    * Table widget text format replace all type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#type Powerpack#type}
    */
    readonly type: string;
    /**
    * Table Widget Match String.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#with Powerpack#with}
    */
    readonly with: string;
}
export declare function powerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatReplaceToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatReplaceOutputReference | PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatReplace): any;
export declare function powerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatReplaceToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatReplaceOutputReference | PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatReplace): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatReplaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatReplace | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatReplace | undefined);
    private _substring?;
    get substring(): string;
    set substring(value: string);
    resetSubstring(): void;
    get substringInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _with?;
    get with(): string;
    set with(value: string);
    get withInput(): string | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormat {
    /**
    * The custom color palette to apply to the background.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_bg_color Powerpack#custom_bg_color}
    */
    readonly customBgColor?: string;
    /**
    * The custom color palette to apply to the foreground text.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_fg_color Powerpack#custom_fg_color}
    */
    readonly customFgColor?: string;
    /**
    * The color palette to apply. Valid values are `white_on_red`, `white_on_yellow`, `white_on_green`, `black_on_light_red`, `black_on_light_yellow`, `black_on_light_green`, `red_on_white`, `yellow_on_white`, `green_on_white`, `custom_bg`, `custom_text`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette Powerpack#palette}
    */
    readonly palette?: string;
    /**
    * match block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#match Powerpack#match}
    */
    readonly match: PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatMatch;
    /**
    * replace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#replace Powerpack#replace}
    */
    readonly replace?: PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatReplace;
}
export declare function powerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormat | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormat | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormat | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormat | cdktn.IResolvable | undefined);
    private _customBgColor?;
    get customBgColor(): string;
    set customBgColor(value: string);
    resetCustomBgColor(): void;
    get customBgColorInput(): string | undefined;
    private _customFgColor?;
    get customFgColor(): string;
    set customFgColor(value: string);
    resetCustomFgColor(): void;
    get customFgColorInput(): string | undefined;
    private _palette?;
    get palette(): string;
    set palette(value: string);
    resetPalette(): void;
    get paletteInput(): string | undefined;
    private _match;
    get match(): PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatMatchOutputReference;
    putMatch(value: PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatMatch): void;
    get matchInput(): PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatMatch | undefined;
    private _replace;
    get replace(): PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatReplaceOutputReference;
    putReplace(value: PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatReplace): void;
    resetReplace(): void;
    get replaceInput(): PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatReplace | undefined;
}
export declare class PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormat[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatOutputReference;
}
export interface PowerpackWidgetQueryTableDefinitionRequestTextFormats {
    /**
    * text_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#text_format Powerpack#text_format}
    */
    readonly textFormat?: PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormat[] | cdktn.IResolvable;
}
export declare function powerpackWidgetQueryTableDefinitionRequestTextFormatsToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestTextFormats | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryTableDefinitionRequestTextFormatsToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestTextFormats | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestTextFormatsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestTextFormats | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestTextFormats | cdktn.IResolvable | undefined);
    private _textFormat;
    get textFormat(): PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormatList;
    putTextFormat(value: PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormat[] | cdktn.IResolvable): void;
    resetTextFormat(): void;
    get textFormatInput(): cdktn.IResolvable | PowerpackWidgetQueryTableDefinitionRequestTextFormatsTextFormat[] | undefined;
}
export declare class PowerpackWidgetQueryTableDefinitionRequestTextFormatsList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryTableDefinitionRequestTextFormats[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryTableDefinitionRequestTextFormatsOutputReference;
}
export interface PowerpackWidgetQueryTableDefinitionRequest {
    /**
    * The aggregator to use for time aggregation. Valid values are `avg`, `last`, `max`, `min`, `sum`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The alias for the column name (defaults to metric name).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#alias Powerpack#alias}
    */
    readonly alias?: string;
    /**
    * A list of display modes for each table cell. Valid values are `number`, `bar`, `trend`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cell_display_mode Powerpack#cell_display_mode}
    */
    readonly cellDisplayMode?: string[];
    /**
    * The number of lines to show in the table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * The sort order for the rows. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order?: string;
    /**
    * The metric query to use for this widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#q Powerpack#q}
    */
    readonly q?: string;
    /**
    * apm_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_query Powerpack#apm_query}
    */
    readonly apmQuery?: PowerpackWidgetQueryTableDefinitionRequestApmQuery;
    /**
    * apm_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_stats_query Powerpack#apm_stats_query}
    */
    readonly apmStatsQuery?: PowerpackWidgetQueryTableDefinitionRequestApmStatsQuery;
    /**
    * conditional_formats block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#conditional_formats Powerpack#conditional_formats}
    */
    readonly conditionalFormats?: PowerpackWidgetQueryTableDefinitionRequestConditionalFormats[] | cdktn.IResolvable;
    /**
    * formula block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#formula Powerpack#formula}
    */
    readonly formula?: PowerpackWidgetQueryTableDefinitionRequestFormula[] | cdktn.IResolvable;
    /**
    * log_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#log_query Powerpack#log_query}
    */
    readonly logQuery?: PowerpackWidgetQueryTableDefinitionRequestLogQuery;
    /**
    * process_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#process_query Powerpack#process_query}
    */
    readonly processQuery?: PowerpackWidgetQueryTableDefinitionRequestProcessQuery;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query?: PowerpackWidgetQueryTableDefinitionRequestQuery[] | cdktn.IResolvable;
    /**
    * rum_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#rum_query Powerpack#rum_query}
    */
    readonly rumQuery?: PowerpackWidgetQueryTableDefinitionRequestRumQuery;
    /**
    * security_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#security_query Powerpack#security_query}
    */
    readonly securityQuery?: PowerpackWidgetQueryTableDefinitionRequestSecurityQuery;
    /**
    * text_formats block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#text_formats Powerpack#text_formats}
    */
    readonly textFormats?: PowerpackWidgetQueryTableDefinitionRequestTextFormats[] | cdktn.IResolvable;
}
export declare function powerpackWidgetQueryTableDefinitionRequestToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequest | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryTableDefinitionRequestToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequest | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequest | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequest | cdktn.IResolvable | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _cellDisplayMode?;
    get cellDisplayMode(): string[];
    set cellDisplayMode(value: string[]);
    resetCellDisplayMode(): void;
    get cellDisplayModeInput(): string[] | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _q?;
    get q(): string;
    set q(value: string);
    resetQ(): void;
    get qInput(): string | undefined;
    private _apmQuery;
    get apmQuery(): PowerpackWidgetQueryTableDefinitionRequestApmQueryOutputReference;
    putApmQuery(value: PowerpackWidgetQueryTableDefinitionRequestApmQuery): void;
    resetApmQuery(): void;
    get apmQueryInput(): PowerpackWidgetQueryTableDefinitionRequestApmQuery | undefined;
    private _apmStatsQuery;
    get apmStatsQuery(): PowerpackWidgetQueryTableDefinitionRequestApmStatsQueryOutputReference;
    putApmStatsQuery(value: PowerpackWidgetQueryTableDefinitionRequestApmStatsQuery): void;
    resetApmStatsQuery(): void;
    get apmStatsQueryInput(): PowerpackWidgetQueryTableDefinitionRequestApmStatsQuery | undefined;
    private _conditionalFormats;
    get conditionalFormats(): PowerpackWidgetQueryTableDefinitionRequestConditionalFormatsList;
    putConditionalFormats(value: PowerpackWidgetQueryTableDefinitionRequestConditionalFormats[] | cdktn.IResolvable): void;
    resetConditionalFormats(): void;
    get conditionalFormatsInput(): cdktn.IResolvable | PowerpackWidgetQueryTableDefinitionRequestConditionalFormats[] | undefined;
    private _formula;
    get formula(): PowerpackWidgetQueryTableDefinitionRequestFormulaList;
    putFormula(value: PowerpackWidgetQueryTableDefinitionRequestFormula[] | cdktn.IResolvable): void;
    resetFormula(): void;
    get formulaInput(): cdktn.IResolvable | PowerpackWidgetQueryTableDefinitionRequestFormula[] | undefined;
    private _logQuery;
    get logQuery(): PowerpackWidgetQueryTableDefinitionRequestLogQueryOutputReference;
    putLogQuery(value: PowerpackWidgetQueryTableDefinitionRequestLogQuery): void;
    resetLogQuery(): void;
    get logQueryInput(): PowerpackWidgetQueryTableDefinitionRequestLogQuery | undefined;
    private _processQuery;
    get processQuery(): PowerpackWidgetQueryTableDefinitionRequestProcessQueryOutputReference;
    putProcessQuery(value: PowerpackWidgetQueryTableDefinitionRequestProcessQuery): void;
    resetProcessQuery(): void;
    get processQueryInput(): PowerpackWidgetQueryTableDefinitionRequestProcessQuery | undefined;
    private _query;
    get query(): PowerpackWidgetQueryTableDefinitionRequestQueryList;
    putQuery(value: PowerpackWidgetQueryTableDefinitionRequestQuery[] | cdktn.IResolvable): void;
    resetQuery(): void;
    get queryInput(): cdktn.IResolvable | PowerpackWidgetQueryTableDefinitionRequestQuery[] | undefined;
    private _rumQuery;
    get rumQuery(): PowerpackWidgetQueryTableDefinitionRequestRumQueryOutputReference;
    putRumQuery(value: PowerpackWidgetQueryTableDefinitionRequestRumQuery): void;
    resetRumQuery(): void;
    get rumQueryInput(): PowerpackWidgetQueryTableDefinitionRequestRumQuery | undefined;
    private _securityQuery;
    get securityQuery(): PowerpackWidgetQueryTableDefinitionRequestSecurityQueryOutputReference;
    putSecurityQuery(value: PowerpackWidgetQueryTableDefinitionRequestSecurityQuery): void;
    resetSecurityQuery(): void;
    get securityQueryInput(): PowerpackWidgetQueryTableDefinitionRequestSecurityQuery | undefined;
    private _textFormats;
    get textFormats(): PowerpackWidgetQueryTableDefinitionRequestTextFormatsList;
    putTextFormats(value: PowerpackWidgetQueryTableDefinitionRequestTextFormats[] | cdktn.IResolvable): void;
    resetTextFormats(): void;
    get textFormatsInput(): cdktn.IResolvable | PowerpackWidgetQueryTableDefinitionRequestTextFormats[] | undefined;
}
export declare class PowerpackWidgetQueryTableDefinitionRequestList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryTableDefinitionRequest[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryTableDefinitionRequestOutputReference;
}
export interface PowerpackWidgetQueryTableDefinition {
    /**
    * Controls the display of the search bar. Valid values are `always`, `never`, `auto`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#has_search_bar Powerpack#has_search_bar}
    */
    readonly hasSearchBar?: string;
    /**
    * Hide any portion of the widget's timeframe that is incomplete due to cost data not being available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_incomplete_cost_data Powerpack#hide_incomplete_cost_data}
    */
    readonly hideIncompleteCostData?: boolean | cdktn.IResolvable;
    /**
    * The timeframe to use when displaying the widget. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#live_span Powerpack#live_span}
    */
    readonly liveSpan?: string;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title Powerpack#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_align Powerpack#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_size Powerpack#title_size}
    */
    readonly titleSize?: string;
    /**
    * custom_link block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_link Powerpack#custom_link}
    */
    readonly customLink?: PowerpackWidgetQueryTableDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#request Powerpack#request}
    */
    readonly request?: PowerpackWidgetQueryTableDefinitionRequest[] | cdktn.IResolvable;
}
export declare function powerpackWidgetQueryTableDefinitionToTerraform(struct?: PowerpackWidgetQueryTableDefinitionOutputReference | PowerpackWidgetQueryTableDefinition): any;
export declare function powerpackWidgetQueryTableDefinitionToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionOutputReference | PowerpackWidgetQueryTableDefinition): any;
export declare class PowerpackWidgetQueryTableDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinition | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinition | undefined);
    private _hasSearchBar?;
    get hasSearchBar(): string;
    set hasSearchBar(value: string);
    resetHasSearchBar(): void;
    get hasSearchBarInput(): string | undefined;
    private _hideIncompleteCostData?;
    get hideIncompleteCostData(): boolean | cdktn.IResolvable;
    set hideIncompleteCostData(value: boolean | cdktn.IResolvable);
    resetHideIncompleteCostData(): void;
    get hideIncompleteCostDataInput(): boolean | cdktn.IResolvable | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _customLink;
    get customLink(): PowerpackWidgetQueryTableDefinitionCustomLinkList;
    putCustomLink(value: PowerpackWidgetQueryTableDefinitionCustomLink[] | cdktn.IResolvable): void;
    resetCustomLink(): void;
    get customLinkInput(): cdktn.IResolvable | PowerpackWidgetQueryTableDefinitionCustomLink[] | undefined;
    private _request;
    get request(): PowerpackWidgetQueryTableDefinitionRequestList;
    putRequest(value: PowerpackWidgetQueryTableDefinitionRequest[] | cdktn.IResolvable): void;
    resetRequest(): void;
    get requestInput(): cdktn.IResolvable | PowerpackWidgetQueryTableDefinitionRequest[] | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionCustomLink {
    /**
    * The flag for toggling context menu link visibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_hidden Powerpack#is_hidden}
    */
    readonly isHidden?: boolean | cdktn.IResolvable;
    /**
    * The label for the custom link URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label?: string;
    /**
    * The URL of the custom link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#link Powerpack#link}
    */
    readonly link?: string;
    /**
    * The label ID that refers to a context menu link item. When `override_label` is provided, the client request omits the label field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#override_label Powerpack#override_label}
    */
    readonly overrideLabel?: string;
}
export declare function powerpackWidgetQueryValueDefinitionCustomLinkToTerraform(struct?: PowerpackWidgetQueryValueDefinitionCustomLink | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryValueDefinitionCustomLinkToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionCustomLink | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryValueDefinitionCustomLinkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryValueDefinitionCustomLink | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionCustomLink | cdktn.IResolvable | undefined);
    private _isHidden?;
    get isHidden(): boolean | cdktn.IResolvable;
    set isHidden(value: boolean | cdktn.IResolvable);
    resetIsHidden(): void;
    get isHiddenInput(): boolean | cdktn.IResolvable | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _link?;
    get link(): string;
    set link(value: string);
    resetLink(): void;
    get linkInput(): string | undefined;
    private _overrideLabel?;
    get overrideLabel(): string;
    set overrideLabel(value: string);
    resetOverrideLabel(): void;
    get overrideLabelInput(): string | undefined;
}
export declare class PowerpackWidgetQueryValueDefinitionCustomLinkList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryValueDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryValueDefinitionCustomLinkOutputReference;
}
export interface PowerpackWidgetQueryValueDefinitionRequestApmQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetQueryValueDefinitionRequestApmQueryComputeQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestApmQueryComputeQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestApmQueryComputeQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestApmQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestApmQueryComputeQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestApmQueryComputeQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestApmQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestApmQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestApmQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetQueryValueDefinitionRequestApmQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupBySortQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupBySortQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestApmQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupBySortQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupBySortQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupBySortQuery;
}
export declare function powerpackWidgetQueryValueDefinitionRequestApmQueryGroupByToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryValueDefinitionRequestApmQueryGroupByToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupByOutputReference;
}
export interface PowerpackWidgetQueryValueDefinitionRequestApmQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetQueryValueDefinitionRequestApmQueryMultiComputeToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryValueDefinitionRequestApmQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestApmQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetQueryValueDefinitionRequestApmQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryValueDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryValueDefinitionRequestApmQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetQueryValueDefinitionRequestApmQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetQueryValueDefinitionRequestApmQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetQueryValueDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetQueryValueDefinitionRequestApmQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestApmQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestApmQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestApmQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestApmQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestApmQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestApmQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestApmQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestApmQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetQueryValueDefinitionRequestApmQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetQueryValueDefinitionRequestApmQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetQueryValueDefinitionRequestApmQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupByList;
    putGroupBy(value: PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetQueryValueDefinitionRequestApmQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetQueryValueDefinitionRequestApmQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetQueryValueDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetQueryValueDefinitionRequestApmQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestAuditQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetQueryValueDefinitionRequestAuditQueryComputeQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestAuditQueryComputeQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestAuditQueryComputeQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestAuditQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestAuditQueryComputeQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestAuditQueryComputeQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestAuditQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestAuditQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestAuditQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBySortQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBySortQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBySortQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBySortQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBySortQuery;
}
export declare function powerpackWidgetQueryValueDefinitionRequestAuditQueryGroupByToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryValueDefinitionRequestAuditQueryGroupByToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupByOutputReference;
}
export interface PowerpackWidgetQueryValueDefinitionRequestAuditQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetQueryValueDefinitionRequestAuditQueryMultiComputeToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestAuditQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryValueDefinitionRequestAuditQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestAuditQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestAuditQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestAuditQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestAuditQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetQueryValueDefinitionRequestAuditQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryValueDefinitionRequestAuditQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryValueDefinitionRequestAuditQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetQueryValueDefinitionRequestAuditQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetQueryValueDefinitionRequestAuditQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetQueryValueDefinitionRequestAuditQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetQueryValueDefinitionRequestAuditQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestAuditQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestAuditQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestAuditQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestAuditQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestAuditQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestAuditQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestAuditQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestAuditQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetQueryValueDefinitionRequestAuditQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetQueryValueDefinitionRequestAuditQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetQueryValueDefinitionRequestAuditQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupByList;
    putGroupBy(value: PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetQueryValueDefinitionRequestAuditQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetQueryValueDefinitionRequestAuditQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetQueryValueDefinitionRequestAuditQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetQueryValueDefinitionRequestAuditQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestConditionalFormats {
    /**
    * The comparator to use. Valid values are `=`, `>`, `>=`, `<`, `<=`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#comparator Powerpack#comparator}
    */
    readonly comparator: string;
    /**
    * The color palette to apply to the background, same values available as palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_bg_color Powerpack#custom_bg_color}
    */
    readonly customBgColor?: string;
    /**
    * The color palette to apply to the foreground, same values available as palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_fg_color Powerpack#custom_fg_color}
    */
    readonly customFgColor?: string;
    /**
    * Setting this to True hides values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_value Powerpack#hide_value}
    */
    readonly hideValue?: boolean | cdktn.IResolvable;
    /**
    * Displays an image as the background.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#image_url Powerpack#image_url}
    */
    readonly imageUrl?: string;
    /**
    * The metric from the request to correlate with this conditional format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
    /**
    * The color palette to apply. Valid values are `blue`, `custom_bg`, `custom_image`, `custom_text`, `gray_on_white`, `grey`, `green`, `orange`, `red`, `red_on_white`, `white_on_gray`, `white_on_green`, `green_on_white`, `white_on_red`, `white_on_yellow`, `yellow_on_white`, `black_on_light_yellow`, `black_on_light_green`, `black_on_light_red`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette Powerpack#palette}
    */
    readonly palette: string;
    /**
    * Defines the displayed timeframe.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#timeframe Powerpack#timeframe}
    */
    readonly timeframe?: string;
    /**
    * A value for the comparator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#value Powerpack#value}
    */
    readonly value: number;
}
export declare function powerpackWidgetQueryValueDefinitionRequestConditionalFormatsToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestConditionalFormats | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryValueDefinitionRequestConditionalFormatsToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestConditionalFormats | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestConditionalFormatsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestConditionalFormats | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestConditionalFormats | cdktn.IResolvable | undefined);
    private _comparator?;
    get comparator(): string;
    set comparator(value: string);
    get comparatorInput(): string | undefined;
    private _customBgColor?;
    get customBgColor(): string;
    set customBgColor(value: string);
    resetCustomBgColor(): void;
    get customBgColorInput(): string | undefined;
    private _customFgColor?;
    get customFgColor(): string;
    set customFgColor(value: string);
    resetCustomFgColor(): void;
    get customFgColorInput(): string | undefined;
    private _hideValue?;
    get hideValue(): boolean | cdktn.IResolvable;
    set hideValue(value: boolean | cdktn.IResolvable);
    resetHideValue(): void;
    get hideValueInput(): boolean | cdktn.IResolvable | undefined;
    private _imageUrl?;
    get imageUrl(): string;
    set imageUrl(value: string);
    resetImageUrl(): void;
    get imageUrlInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _palette?;
    get palette(): string;
    set palette(value: string);
    get paletteInput(): string | undefined;
    private _timeframe?;
    get timeframe(): string;
    set timeframe(value: string);
    resetTimeframe(): void;
    get timeframeInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class PowerpackWidgetQueryValueDefinitionRequestConditionalFormatsList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryValueDefinitionRequestConditionalFormats[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryValueDefinitionRequestConditionalFormatsOutputReference;
}
export interface PowerpackWidgetQueryValueDefinitionRequestFormulaConditionalFormats {
    /**
    * The comparator to use. Valid values are `=`, `>`, `>=`, `<`, `<=`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#comparator Powerpack#comparator}
    */
    readonly comparator: string;
    /**
    * The color palette to apply to the background, same values available as palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_bg_color Powerpack#custom_bg_color}
    */
    readonly customBgColor?: string;
    /**
    * The color palette to apply to the foreground, same values available as palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_fg_color Powerpack#custom_fg_color}
    */
    readonly customFgColor?: string;
    /**
    * Setting this to True hides values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_value Powerpack#hide_value}
    */
    readonly hideValue?: boolean | cdktn.IResolvable;
    /**
    * Displays an image as the background.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#image_url Powerpack#image_url}
    */
    readonly imageUrl?: string;
    /**
    * The metric from the request to correlate with this conditional format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
    /**
    * The color palette to apply. Valid values are `blue`, `custom_bg`, `custom_image`, `custom_text`, `gray_on_white`, `grey`, `green`, `orange`, `red`, `red_on_white`, `white_on_gray`, `white_on_green`, `green_on_white`, `white_on_red`, `white_on_yellow`, `yellow_on_white`, `black_on_light_yellow`, `black_on_light_green`, `black_on_light_red`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette Powerpack#palette}
    */
    readonly palette: string;
    /**
    * Defines the displayed timeframe.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#timeframe Powerpack#timeframe}
    */
    readonly timeframe?: string;
    /**
    * A value for the comparator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#value Powerpack#value}
    */
    readonly value: number;
}
export declare function powerpackWidgetQueryValueDefinitionRequestFormulaConditionalFormatsToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryValueDefinitionRequestFormulaConditionalFormatsToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestFormulaConditionalFormatsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable | undefined);
    private _comparator?;
    get comparator(): string;
    set comparator(value: string);
    get comparatorInput(): string | undefined;
    private _customBgColor?;
    get customBgColor(): string;
    set customBgColor(value: string);
    resetCustomBgColor(): void;
    get customBgColorInput(): string | undefined;
    private _customFgColor?;
    get customFgColor(): string;
    set customFgColor(value: string);
    resetCustomFgColor(): void;
    get customFgColorInput(): string | undefined;
    private _hideValue?;
    get hideValue(): boolean | cdktn.IResolvable;
    set hideValue(value: boolean | cdktn.IResolvable);
    resetHideValue(): void;
    get hideValueInput(): boolean | cdktn.IResolvable | undefined;
    private _imageUrl?;
    get imageUrl(): string;
    set imageUrl(value: string);
    resetImageUrl(): void;
    get imageUrlInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _palette?;
    get palette(): string;
    set palette(value: string);
    get paletteInput(): string | undefined;
    private _timeframe?;
    get timeframe(): string;
    set timeframe(value: string);
    resetTimeframe(): void;
    get timeframeInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class PowerpackWidgetQueryValueDefinitionRequestFormulaConditionalFormatsList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryValueDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryValueDefinitionRequestFormulaConditionalFormatsOutputReference;
}
export interface PowerpackWidgetQueryValueDefinitionRequestFormulaLimit {
    /**
    * The number of results to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#count Powerpack#count}
    */
    readonly count?: number;
    /**
    * The direction of the sort. Valid values are `asc`, `desc`. Defaults to `"desc"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order?: string;
}
export declare function powerpackWidgetQueryValueDefinitionRequestFormulaLimitToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestFormulaLimitOutputReference | PowerpackWidgetQueryValueDefinitionRequestFormulaLimit): any;
export declare function powerpackWidgetQueryValueDefinitionRequestFormulaLimitToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestFormulaLimitOutputReference | PowerpackWidgetQueryValueDefinitionRequestFormulaLimit): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestFormulaLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestFormulaLimit | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestFormulaLimit | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    resetCount(): void;
    get countInput(): number | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCanonical {
    /**
    * per unit name. If you want to represent megabytes/s, you set 'unit_name' = 'megabyte' and 'per_unit_name = 'second'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#per_unit_name Powerpack#per_unit_name}
    */
    readonly perUnitName?: string;
    /**
    * Unit name. It should be in singular form ('megabyte' and not 'megabytes')
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit_name Powerpack#unit_name}
    */
    readonly unitName: string;
}
export declare function powerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCanonicalToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference | PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCanonical): any;
export declare function powerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCanonicalToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference | PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCanonical): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCanonical | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCanonical | undefined);
    private _perUnitName?;
    get perUnitName(): string;
    set perUnitName(value: string);
    resetPerUnitName(): void;
    get perUnitNameInput(): string | undefined;
    private _unitName?;
    get unitName(): string;
    set unitName(value: string);
    get unitNameInput(): string | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCustom {
    /**
    * Unit label
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label: string;
}
export declare function powerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCustomToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCustomOutputReference | PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCustom): any;
export declare function powerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCustomToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCustomOutputReference | PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCustom): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCustom | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCustom | undefined);
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnit {
    /**
    * canonical block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#canonical Powerpack#canonical}
    */
    readonly canonical?: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCanonical;
    /**
    * custom block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom Powerpack#custom}
    */
    readonly custom?: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCustom;
}
export declare function powerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitOutputReference | PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnit): any;
export declare function powerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitOutputReference | PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnit): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnit | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnit | undefined);
    private _canonical;
    get canonical(): PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference;
    putCanonical(value: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCanonical): void;
    resetCanonical(): void;
    get canonicalInput(): PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCanonical | undefined;
    private _custom;
    get custom(): PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCustomOutputReference;
    putCustom(value: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCustom): void;
    resetCustom(): void;
    get customInput(): PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitCustom | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitScale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit_name Powerpack#unit_name}
    */
    readonly unitName: string;
}
export declare function powerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitScaleToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitScaleOutputReference | PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitScale): any;
export declare function powerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitScaleToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitScaleOutputReference | PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitScale): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitScaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitScale | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitScale | undefined);
    private _unitName?;
    get unitName(): string;
    set unitName(value: string);
    get unitNameInput(): string | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormat {
    /**
    * unit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit Powerpack#unit}
    */
    readonly unit: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnit;
    /**
    * unit_scale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit_scale Powerpack#unit_scale}
    */
    readonly unitScale?: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitScale;
}
export declare function powerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatOutputReference | PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormat): any;
export declare function powerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatOutputReference | PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormat): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormat | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormat | undefined);
    private _unit;
    get unit(): PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitOutputReference;
    putUnit(value: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnit): void;
    get unitInput(): PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnit | undefined;
    private _unitScale;
    get unitScale(): PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitScaleOutputReference;
    putUnitScale(value: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitScale): void;
    resetUnitScale(): void;
    get unitScaleInput(): PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatUnitScale | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestFormulaStyle {
    /**
    * The color palette used to display the formula. A guide to the available color palettes can be found at https://docs.datadoghq.com/dashboards/guide/widget_colors.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette Powerpack#palette}
    */
    readonly palette?: string;
    /**
    * Index specifying which color to use within the palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette_index Powerpack#palette_index}
    */
    readonly paletteIndex?: number;
}
export declare function powerpackWidgetQueryValueDefinitionRequestFormulaStyleToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestFormulaStyleOutputReference | PowerpackWidgetQueryValueDefinitionRequestFormulaStyle): any;
export declare function powerpackWidgetQueryValueDefinitionRequestFormulaStyleToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestFormulaStyleOutputReference | PowerpackWidgetQueryValueDefinitionRequestFormulaStyle): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestFormulaStyleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestFormulaStyle | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestFormulaStyle | undefined);
    private _palette?;
    get palette(): string;
    set palette(value: string);
    resetPalette(): void;
    get paletteInput(): string | undefined;
    private _paletteIndex?;
    get paletteIndex(): number;
    set paletteIndex(value: number);
    resetPaletteIndex(): void;
    get paletteIndexInput(): number | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestFormula {
    /**
    * An expression alias.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#alias Powerpack#alias}
    */
    readonly alias?: string;
    /**
    * A list of display modes for each table cell. Valid values are `number`, `bar`, `trend`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cell_display_mode Powerpack#cell_display_mode}
    */
    readonly cellDisplayMode?: string;
    /**
    * A string expression built from queries, formulas, and functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#formula_expression Powerpack#formula_expression}
    */
    readonly formulaExpression: string;
    /**
    * conditional_formats block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#conditional_formats Powerpack#conditional_formats}
    */
    readonly conditionalFormats?: PowerpackWidgetQueryValueDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: PowerpackWidgetQueryValueDefinitionRequestFormulaLimit;
    /**
    * number_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#number_format Powerpack#number_format}
    */
    readonly numberFormat?: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormat;
    /**
    * style block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#style Powerpack#style}
    */
    readonly style?: PowerpackWidgetQueryValueDefinitionRequestFormulaStyle;
}
export declare function powerpackWidgetQueryValueDefinitionRequestFormulaToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestFormula | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryValueDefinitionRequestFormulaToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestFormula | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestFormulaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestFormula | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestFormula | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _cellDisplayMode?;
    get cellDisplayMode(): string;
    set cellDisplayMode(value: string);
    resetCellDisplayMode(): void;
    get cellDisplayModeInput(): string | undefined;
    private _formulaExpression?;
    get formulaExpression(): string;
    set formulaExpression(value: string);
    get formulaExpressionInput(): string | undefined;
    private _conditionalFormats;
    get conditionalFormats(): PowerpackWidgetQueryValueDefinitionRequestFormulaConditionalFormatsList;
    putConditionalFormats(value: PowerpackWidgetQueryValueDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable): void;
    resetConditionalFormats(): void;
    get conditionalFormatsInput(): cdktn.IResolvable | PowerpackWidgetQueryValueDefinitionRequestFormulaConditionalFormats[] | undefined;
    private _limit;
    get limit(): PowerpackWidgetQueryValueDefinitionRequestFormulaLimitOutputReference;
    putLimit(value: PowerpackWidgetQueryValueDefinitionRequestFormulaLimit): void;
    resetLimit(): void;
    get limitInput(): PowerpackWidgetQueryValueDefinitionRequestFormulaLimit | undefined;
    private _numberFormat;
    get numberFormat(): PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormatOutputReference;
    putNumberFormat(value: PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormat): void;
    resetNumberFormat(): void;
    get numberFormatInput(): PowerpackWidgetQueryValueDefinitionRequestFormulaNumberFormat | undefined;
    private _style;
    get style(): PowerpackWidgetQueryValueDefinitionRequestFormulaStyleOutputReference;
    putStyle(value: PowerpackWidgetQueryValueDefinitionRequestFormulaStyle): void;
    resetStyle(): void;
    get styleInput(): PowerpackWidgetQueryValueDefinitionRequestFormulaStyle | undefined;
}
export declare class PowerpackWidgetQueryValueDefinitionRequestFormulaList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryValueDefinitionRequestFormula[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryValueDefinitionRequestFormulaOutputReference;
}
export interface PowerpackWidgetQueryValueDefinitionRequestLogQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetQueryValueDefinitionRequestLogQueryComputeQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestLogQueryComputeQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestLogQueryComputeQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestLogQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestLogQueryComputeQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestLogQueryComputeQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestLogQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestLogQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestLogQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetQueryValueDefinitionRequestLogQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupBySortQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupBySortQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestLogQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupBySortQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupBySortQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupBySortQuery;
}
export declare function powerpackWidgetQueryValueDefinitionRequestLogQueryGroupByToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryValueDefinitionRequestLogQueryGroupByToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupByOutputReference;
}
export interface PowerpackWidgetQueryValueDefinitionRequestLogQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetQueryValueDefinitionRequestLogQueryMultiComputeToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryValueDefinitionRequestLogQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestLogQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetQueryValueDefinitionRequestLogQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryValueDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryValueDefinitionRequestLogQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetQueryValueDefinitionRequestLogQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetQueryValueDefinitionRequestLogQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetQueryValueDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetQueryValueDefinitionRequestLogQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestLogQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestLogQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestLogQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestLogQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestLogQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestLogQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestLogQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestLogQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetQueryValueDefinitionRequestLogQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetQueryValueDefinitionRequestLogQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetQueryValueDefinitionRequestLogQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupByList;
    putGroupBy(value: PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetQueryValueDefinitionRequestLogQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetQueryValueDefinitionRequestLogQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetQueryValueDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetQueryValueDefinitionRequestLogQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestProcessQuery {
    /**
    * A list of processes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#filter_by Powerpack#filter_by}
    */
    readonly filterBy?: string[];
    /**
    * The max number of items in the filter list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * Your chosen metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric: string;
    /**
    * Your chosen search term.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_by Powerpack#search_by}
    */
    readonly searchBy?: string;
}
export declare function powerpackWidgetQueryValueDefinitionRequestProcessQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestProcessQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestProcessQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestProcessQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestProcessQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestProcessQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestProcessQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestProcessQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestProcessQuery | undefined);
    private _filterBy?;
    get filterBy(): string[];
    set filterBy(value: string[]);
    resetFilterBy(): void;
    get filterByInput(): string[] | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _searchBy?;
    get searchBy(): string;
    set searchBy(value: string);
    resetSearchBy(): void;
    get searchByInput(): string | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestQueryApmDependencyStatsQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for APM Dependency Stats queries. Valid values are `apm_dependency_stats`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * APM environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#env Powerpack#env}
    */
    readonly env: string;
    /**
    * Determines whether stats for upstream or downstream dependencies should be queried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_upstream Powerpack#is_upstream}
    */
    readonly isUpstream?: boolean | cdktn.IResolvable;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Name of operation on service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#operation_name Powerpack#operation_name}
    */
    readonly operationName: string;
    /**
    * The name of the second primary tag used within APM; required when `primary_tag_value` is specified. See https://docs.datadoghq.com/tracing/guide/setting_primary_tags_to_scope/#add-a-second-primary-tag-in-datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_name Powerpack#primary_tag_name}
    */
    readonly primaryTagName?: string;
    /**
    * Filter APM data by the second primary tag. `primary_tag_name` must also be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_value Powerpack#primary_tag_value}
    */
    readonly primaryTagValue?: string;
    /**
    * APM resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#resource_name Powerpack#resource_name}
    */
    readonly resourceName: string;
    /**
    * APM service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#service Powerpack#service}
    */
    readonly service: string;
    /**
    * APM statistic. Valid values are `avg_duration`, `avg_root_duration`, `avg_spans_per_trace`, `error_rate`, `pct_exec_time`, `pct_of_traces`, `total_traces_count`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#stat Powerpack#stat}
    */
    readonly stat: string;
}
export declare function powerpackWidgetQueryValueDefinitionRequestQueryApmDependencyStatsQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQueryApmDependencyStatsQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestQueryApmDependencyStatsQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestQueryApmDependencyStatsQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQueryApmDependencyStatsQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestQueryApmDependencyStatsQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestQueryApmDependencyStatsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestQueryApmDependencyStatsQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestQueryApmDependencyStatsQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    private _isUpstream?;
    get isUpstream(): boolean | cdktn.IResolvable;
    set isUpstream(value: boolean | cdktn.IResolvable);
    resetIsUpstream(): void;
    get isUpstreamInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    get operationNameInput(): string | undefined;
    private _primaryTagName?;
    get primaryTagName(): string;
    set primaryTagName(value: string);
    resetPrimaryTagName(): void;
    get primaryTagNameInput(): string | undefined;
    private _primaryTagValue?;
    get primaryTagValue(): string;
    set primaryTagValue(value: string);
    resetPrimaryTagValue(): void;
    get primaryTagValueInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    get resourceNameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    get statInput(): string | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestQueryApmResourceStatsQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for APM Resource Stats queries. Valid values are `apm_resource_stats`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * APM environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#env Powerpack#env}
    */
    readonly env: string;
    /**
    * Array of fields to group results by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: string[];
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Name of operation on service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#operation_name Powerpack#operation_name}
    */
    readonly operationName?: string;
    /**
    * The name of the second primary tag used within APM; required when `primary_tag_value` is specified. See https://docs.datadoghq.com/tracing/guide/setting_primary_tags_to_scope/#add-a-second-primary-tag-in-datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_name Powerpack#primary_tag_name}
    */
    readonly primaryTagName?: string;
    /**
    * Filter APM data by the second primary tag. `primary_tag_name` must also be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_value Powerpack#primary_tag_value}
    */
    readonly primaryTagValue?: string;
    /**
    * APM resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#resource_name Powerpack#resource_name}
    */
    readonly resourceName?: string;
    /**
    * APM service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#service Powerpack#service}
    */
    readonly service: string;
    /**
    * APM statistic. Valid values are `errors`, `error_rate`, `hits`, `latency_avg`, `latency_distribution`, `latency_max`, `latency_p50`, `latency_p75`, `latency_p90`, `latency_p95`, `latency_p99`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#stat Powerpack#stat}
    */
    readonly stat: string;
}
export declare function powerpackWidgetQueryValueDefinitionRequestQueryApmResourceStatsQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQueryApmResourceStatsQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestQueryApmResourceStatsQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestQueryApmResourceStatsQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQueryApmResourceStatsQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestQueryApmResourceStatsQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestQueryApmResourceStatsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestQueryApmResourceStatsQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestQueryApmResourceStatsQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    private _groupBy?;
    get groupBy(): string[];
    set groupBy(value: string[]);
    resetGroupBy(): void;
    get groupByInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    resetOperationName(): void;
    get operationNameInput(): string | undefined;
    private _primaryTagName?;
    get primaryTagName(): string;
    set primaryTagName(value: string);
    resetPrimaryTagName(): void;
    get primaryTagNameInput(): string | undefined;
    private _primaryTagValue?;
    get primaryTagValue(): string;
    set primaryTagValue(value: string);
    resetPrimaryTagValue(): void;
    get primaryTagValueInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    resetResourceName(): void;
    get resourceNameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    get statInput(): string | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestQueryCloudCostQuery {
    /**
    * The aggregation methods available for cloud cost queries. Valid values are `avg`, `last`, `max`, `min`, `sum`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for cloud cost queries. Valid values are `cloud_cost`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The cloud cost query definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
}
export declare function powerpackWidgetQueryValueDefinitionRequestQueryCloudCostQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQueryCloudCostQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestQueryCloudCostQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestQueryCloudCostQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQueryCloudCostQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestQueryCloudCostQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestQueryCloudCostQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestQueryCloudCostQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestQueryCloudCostQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryCompute {
    /**
    * The aggregation methods for event platform queries. Valid values are `count`, `cardinality`, `median`, `pc75`, `pc90`, `pc95`, `pc98`, `pc99`, `sum`, `min`, `max`, `avg`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * A time interval in milliseconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
    /**
    * The measurable attribute to compute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
}
export declare function powerpackWidgetQueryValueDefinitionRequestQueryEventQueryComputeToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryValueDefinitionRequestQueryEventQueryComputeToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
}
export declare class PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryComputeOutputReference;
}
export interface PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBySort {
    /**
    * The aggregation methods for the event platform queries. Valid values are `count`, `cardinality`, `median`, `pc75`, `pc90`, `pc95`, `pc98`, `pc99`, `sum`, `min`, `max`, `avg`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The metric used for sorting group by results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
    /**
    * Direction of sort. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order?: string;
}
export declare function powerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBySortToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBySortOutputReference | PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBySort): any;
export declare function powerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBySortToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBySortOutputReference | PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBySort): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBySortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBySort | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBySort | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBy {
    /**
    * The event facet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet: string;
    /**
    * The number of groups to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort Powerpack#sort}
    */
    readonly sort?: PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBySort;
}
export declare function powerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupByToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupByToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sort;
    get sort(): PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBySortOutputReference;
    putSort(value: PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBySort): void;
    resetSort(): void;
    get sortInput(): PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBySort | undefined;
}
export declare class PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupByOutputReference;
}
export interface PowerpackWidgetQueryValueDefinitionRequestQueryEventQuerySearch {
    /**
    * The events search string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
}
export declare function powerpackWidgetQueryValueDefinitionRequestQueryEventQuerySearchToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQueryEventQuerySearchOutputReference | PowerpackWidgetQueryValueDefinitionRequestQueryEventQuerySearch): any;
export declare function powerpackWidgetQueryValueDefinitionRequestQueryEventQuerySearchToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQueryEventQuerySearchOutputReference | PowerpackWidgetQueryValueDefinitionRequestQueryEventQuerySearch): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestQueryEventQuerySearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestQueryEventQuerySearch | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestQueryEventQuerySearch | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestQueryEventQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for event platform-based queries. Valid values are `logs`, `spans`, `network`, `rum`, `security_signals`, `profiles`, `audit`, `events`, `ci_tests`, `ci_pipelines`, `incident_analytics`, `product_analytics`, `on_call_events`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * An array of index names to query in the stream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#indexes Powerpack#indexes}
    */
    readonly indexes?: string[];
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Storage location (private beta).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#storage Powerpack#storage}
    */
    readonly storage?: string;
    /**
    * compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute Powerpack#compute}
    */
    readonly compute: PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable;
    /**
    * search block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search Powerpack#search}
    */
    readonly search?: PowerpackWidgetQueryValueDefinitionRequestQueryEventQuerySearch;
}
export declare function powerpackWidgetQueryValueDefinitionRequestQueryEventQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestQueryEventQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestQueryEventQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestQueryEventQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestQueryEventQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestQueryEventQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _indexes?;
    get indexes(): string[];
    set indexes(value: string[]);
    resetIndexes(): void;
    get indexesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _storage?;
    get storage(): string;
    set storage(value: string);
    resetStorage(): void;
    get storageInput(): string | undefined;
    private _compute;
    get compute(): PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryComputeList;
    putCompute(value: PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable): void;
    get computeInput(): cdktn.IResolvable | PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryCompute[] | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupByList;
    putGroupBy(value: PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryGroupBy[] | undefined;
    private _search;
    get search(): PowerpackWidgetQueryValueDefinitionRequestQueryEventQuerySearchOutputReference;
    putSearch(value: PowerpackWidgetQueryValueDefinitionRequestQueryEventQuerySearch): void;
    resetSearch(): void;
    get searchInput(): PowerpackWidgetQueryValueDefinitionRequestQueryEventQuerySearch | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestQueryMetricQuery {
    /**
    * The aggregation methods available for metrics queries. Valid values are `avg`, `min`, `max`, `sum`, `last`, `area`, `l2norm`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for metrics queries. Defaults to `"metrics"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource?: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The metrics query definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
    /**
    * Semantic mode for metrics queries. This determines how metrics from different sources are combined or displayed. Valid values are `combined`, `native`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#semantic_mode Powerpack#semantic_mode}
    */
    readonly semanticMode?: string;
}
export declare function powerpackWidgetQueryValueDefinitionRequestQueryMetricQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQueryMetricQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestQueryMetricQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestQueryMetricQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQueryMetricQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestQueryMetricQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestQueryMetricQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestQueryMetricQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestQueryMetricQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    resetDataSource(): void;
    get dataSourceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _semanticMode?;
    get semanticMode(): string;
    set semanticMode(value: string);
    resetSemanticMode(): void;
    get semanticModeInput(): string | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestQueryProcessQuery {
    /**
    * The aggregation methods available for metrics queries. Valid values are `avg`, `min`, `max`, `sum`, `last`, `area`, `l2norm`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for process queries. Valid values are `process`, `container`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * Whether to normalize the CPU percentages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_normalized_cpu Powerpack#is_normalized_cpu}
    */
    readonly isNormalizedCpu?: boolean | cdktn.IResolvable;
    /**
    * The number of hits to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * The process metric name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric: string;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The direction of the sort. Valid values are `asc`, `desc`. Defaults to `"desc"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort Powerpack#sort}
    */
    readonly sort?: string;
    /**
    * An array of tags to filter by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#tag_filters Powerpack#tag_filters}
    */
    readonly tagFilters?: string[];
    /**
    * The text to use as a filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#text_filter Powerpack#text_filter}
    */
    readonly textFilter?: string;
}
export declare function powerpackWidgetQueryValueDefinitionRequestQueryProcessQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQueryProcessQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestQueryProcessQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestQueryProcessQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQueryProcessQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestQueryProcessQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestQueryProcessQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestQueryProcessQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestQueryProcessQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _isNormalizedCpu?;
    get isNormalizedCpu(): boolean | cdktn.IResolvable;
    set isNormalizedCpu(value: boolean | cdktn.IResolvable);
    resetIsNormalizedCpu(): void;
    get isNormalizedCpuInput(): boolean | cdktn.IResolvable | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _sort?;
    get sort(): string;
    set sort(value: string);
    resetSort(): void;
    get sortInput(): string | undefined;
    private _tagFilters?;
    get tagFilters(): string[];
    set tagFilters(value: string[]);
    resetTagFilters(): void;
    get tagFiltersInput(): string[] | undefined;
    private _textFilter?;
    get textFilter(): string;
    set textFilter(value: string);
    resetTextFilter(): void;
    get textFilterInput(): string | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestQuerySloQuery {
    /**
    * Additional filters applied to the SLO query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#additional_query_filters Powerpack#additional_query_filters}
    */
    readonly additionalQueryFilters?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for SLO queries. Valid values are `slo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * Group mode to query measures. Valid values are `overall`, `components`. Defaults to `"overall"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_mode Powerpack#group_mode}
    */
    readonly groupMode?: string;
    /**
    * SLO measures queries. Valid values are `good_events`, `bad_events`, `good_minutes`, `bad_minutes`, `slo_status`, `error_budget_remaining`, `burn_rate`, `error_budget_burndown`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#measure Powerpack#measure}
    */
    readonly measure: string;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name?: string;
    /**
    * ID of an SLO to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_id Powerpack#slo_id}
    */
    readonly sloId: string;
    /**
    * type of the SLO to query. Valid values are `metric`, `monitor`, `time_slice`. Defaults to `"metric"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_query_type Powerpack#slo_query_type}
    */
    readonly sloQueryType?: string;
}
export declare function powerpackWidgetQueryValueDefinitionRequestQuerySloQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQuerySloQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestQuerySloQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestQuerySloQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQuerySloQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestQuerySloQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestQuerySloQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestQuerySloQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestQuerySloQuery | undefined);
    private _additionalQueryFilters?;
    get additionalQueryFilters(): string;
    set additionalQueryFilters(value: string);
    resetAdditionalQueryFilters(): void;
    get additionalQueryFiltersInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _groupMode?;
    get groupMode(): string;
    set groupMode(value: string);
    resetGroupMode(): void;
    get groupModeInput(): string | undefined;
    private _measure?;
    get measure(): string;
    set measure(value: string);
    get measureInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sloId?;
    get sloId(): string;
    set sloId(value: string);
    get sloIdInput(): string | undefined;
    private _sloQueryType?;
    get sloQueryType(): string;
    set sloQueryType(value: string);
    resetSloQueryType(): void;
    get sloQueryTypeInput(): string | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestQuery {
    /**
    * apm_dependency_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_dependency_stats_query Powerpack#apm_dependency_stats_query}
    */
    readonly apmDependencyStatsQuery?: PowerpackWidgetQueryValueDefinitionRequestQueryApmDependencyStatsQuery;
    /**
    * apm_resource_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_resource_stats_query Powerpack#apm_resource_stats_query}
    */
    readonly apmResourceStatsQuery?: PowerpackWidgetQueryValueDefinitionRequestQueryApmResourceStatsQuery;
    /**
    * cloud_cost_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cloud_cost_query Powerpack#cloud_cost_query}
    */
    readonly cloudCostQuery?: PowerpackWidgetQueryValueDefinitionRequestQueryCloudCostQuery;
    /**
    * event_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#event_query Powerpack#event_query}
    */
    readonly eventQuery?: PowerpackWidgetQueryValueDefinitionRequestQueryEventQuery;
    /**
    * metric_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric_query Powerpack#metric_query}
    */
    readonly metricQuery?: PowerpackWidgetQueryValueDefinitionRequestQueryMetricQuery;
    /**
    * process_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#process_query Powerpack#process_query}
    */
    readonly processQuery?: PowerpackWidgetQueryValueDefinitionRequestQueryProcessQuery;
    /**
    * slo_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_query Powerpack#slo_query}
    */
    readonly sloQuery?: PowerpackWidgetQueryValueDefinitionRequestQuerySloQuery;
}
export declare function powerpackWidgetQueryValueDefinitionRequestQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQuery | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryValueDefinitionRequestQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestQuery | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestQuery | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestQuery | cdktn.IResolvable | undefined);
    private _apmDependencyStatsQuery;
    get apmDependencyStatsQuery(): PowerpackWidgetQueryValueDefinitionRequestQueryApmDependencyStatsQueryOutputReference;
    putApmDependencyStatsQuery(value: PowerpackWidgetQueryValueDefinitionRequestQueryApmDependencyStatsQuery): void;
    resetApmDependencyStatsQuery(): void;
    get apmDependencyStatsQueryInput(): PowerpackWidgetQueryValueDefinitionRequestQueryApmDependencyStatsQuery | undefined;
    private _apmResourceStatsQuery;
    get apmResourceStatsQuery(): PowerpackWidgetQueryValueDefinitionRequestQueryApmResourceStatsQueryOutputReference;
    putApmResourceStatsQuery(value: PowerpackWidgetQueryValueDefinitionRequestQueryApmResourceStatsQuery): void;
    resetApmResourceStatsQuery(): void;
    get apmResourceStatsQueryInput(): PowerpackWidgetQueryValueDefinitionRequestQueryApmResourceStatsQuery | undefined;
    private _cloudCostQuery;
    get cloudCostQuery(): PowerpackWidgetQueryValueDefinitionRequestQueryCloudCostQueryOutputReference;
    putCloudCostQuery(value: PowerpackWidgetQueryValueDefinitionRequestQueryCloudCostQuery): void;
    resetCloudCostQuery(): void;
    get cloudCostQueryInput(): PowerpackWidgetQueryValueDefinitionRequestQueryCloudCostQuery | undefined;
    private _eventQuery;
    get eventQuery(): PowerpackWidgetQueryValueDefinitionRequestQueryEventQueryOutputReference;
    putEventQuery(value: PowerpackWidgetQueryValueDefinitionRequestQueryEventQuery): void;
    resetEventQuery(): void;
    get eventQueryInput(): PowerpackWidgetQueryValueDefinitionRequestQueryEventQuery | undefined;
    private _metricQuery;
    get metricQuery(): PowerpackWidgetQueryValueDefinitionRequestQueryMetricQueryOutputReference;
    putMetricQuery(value: PowerpackWidgetQueryValueDefinitionRequestQueryMetricQuery): void;
    resetMetricQuery(): void;
    get metricQueryInput(): PowerpackWidgetQueryValueDefinitionRequestQueryMetricQuery | undefined;
    private _processQuery;
    get processQuery(): PowerpackWidgetQueryValueDefinitionRequestQueryProcessQueryOutputReference;
    putProcessQuery(value: PowerpackWidgetQueryValueDefinitionRequestQueryProcessQuery): void;
    resetProcessQuery(): void;
    get processQueryInput(): PowerpackWidgetQueryValueDefinitionRequestQueryProcessQuery | undefined;
    private _sloQuery;
    get sloQuery(): PowerpackWidgetQueryValueDefinitionRequestQuerySloQueryOutputReference;
    putSloQuery(value: PowerpackWidgetQueryValueDefinitionRequestQuerySloQuery): void;
    resetSloQuery(): void;
    get sloQueryInput(): PowerpackWidgetQueryValueDefinitionRequestQuerySloQuery | undefined;
}
export declare class PowerpackWidgetQueryValueDefinitionRequestQueryList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryValueDefinitionRequestQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryValueDefinitionRequestQueryOutputReference;
}
export interface PowerpackWidgetQueryValueDefinitionRequestRumQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetQueryValueDefinitionRequestRumQueryComputeQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestRumQueryComputeQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestRumQueryComputeQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestRumQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestRumQueryComputeQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestRumQueryComputeQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestRumQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestRumQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestRumQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetQueryValueDefinitionRequestRumQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupBySortQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupBySortQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestRumQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupBySortQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupBySortQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupBySortQuery;
}
export declare function powerpackWidgetQueryValueDefinitionRequestRumQueryGroupByToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryValueDefinitionRequestRumQueryGroupByToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupByOutputReference;
}
export interface PowerpackWidgetQueryValueDefinitionRequestRumQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetQueryValueDefinitionRequestRumQueryMultiComputeToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryValueDefinitionRequestRumQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestRumQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetQueryValueDefinitionRequestRumQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryValueDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryValueDefinitionRequestRumQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetQueryValueDefinitionRequestRumQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetQueryValueDefinitionRequestRumQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetQueryValueDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetQueryValueDefinitionRequestRumQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestRumQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestRumQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestRumQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestRumQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestRumQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestRumQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestRumQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestRumQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetQueryValueDefinitionRequestRumQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetQueryValueDefinitionRequestRumQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetQueryValueDefinitionRequestRumQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupByList;
    putGroupBy(value: PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetQueryValueDefinitionRequestRumQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetQueryValueDefinitionRequestRumQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetQueryValueDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetQueryValueDefinitionRequestRumQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestSecurityQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetQueryValueDefinitionRequestSecurityQueryComputeQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryComputeQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestSecurityQueryComputeQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestSecurityQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryComputeQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestSecurityQueryComputeQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestSecurityQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestSecurityQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBySortQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBySortQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBySortQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBySortQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBySortQuery;
}
export declare function powerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupByToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupByToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupByOutputReference;
}
export interface PowerpackWidgetQueryValueDefinitionRequestSecurityQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetQueryValueDefinitionRequestSecurityQueryMultiComputeToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryValueDefinitionRequestSecurityQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestSecurityQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetQueryValueDefinitionRequestSecurityQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryValueDefinitionRequestSecurityQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetQueryValueDefinitionRequestSecurityQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetQueryValueDefinitionRequestSecurityQueryToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestSecurityQuery): any;
export declare function powerpackWidgetQueryValueDefinitionRequestSecurityQueryToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryOutputReference | PowerpackWidgetQueryValueDefinitionRequestSecurityQuery): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestSecurityQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequestSecurityQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequestSecurityQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetQueryValueDefinitionRequestSecurityQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetQueryValueDefinitionRequestSecurityQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupByList;
    putGroupBy(value: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetQueryValueDefinitionRequestSecurityQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetQueryValueDefinitionRequestSecurityQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetQueryValueDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetQueryValueDefinitionRequestSecurityQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionRequest {
    /**
    * The aggregator to use for time aggregation. Valid values are `avg`, `last`, `max`, `min`, `sum`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The metric query to use for this widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#q Powerpack#q}
    */
    readonly q?: string;
    /**
    * apm_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_query Powerpack#apm_query}
    */
    readonly apmQuery?: PowerpackWidgetQueryValueDefinitionRequestApmQuery;
    /**
    * audit_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#audit_query Powerpack#audit_query}
    */
    readonly auditQuery?: PowerpackWidgetQueryValueDefinitionRequestAuditQuery;
    /**
    * conditional_formats block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#conditional_formats Powerpack#conditional_formats}
    */
    readonly conditionalFormats?: PowerpackWidgetQueryValueDefinitionRequestConditionalFormats[] | cdktn.IResolvable;
    /**
    * formula block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#formula Powerpack#formula}
    */
    readonly formula?: PowerpackWidgetQueryValueDefinitionRequestFormula[] | cdktn.IResolvable;
    /**
    * log_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#log_query Powerpack#log_query}
    */
    readonly logQuery?: PowerpackWidgetQueryValueDefinitionRequestLogQuery;
    /**
    * process_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#process_query Powerpack#process_query}
    */
    readonly processQuery?: PowerpackWidgetQueryValueDefinitionRequestProcessQuery;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query?: PowerpackWidgetQueryValueDefinitionRequestQuery[] | cdktn.IResolvable;
    /**
    * rum_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#rum_query Powerpack#rum_query}
    */
    readonly rumQuery?: PowerpackWidgetQueryValueDefinitionRequestRumQuery;
    /**
    * security_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#security_query Powerpack#security_query}
    */
    readonly securityQuery?: PowerpackWidgetQueryValueDefinitionRequestSecurityQuery;
}
export declare function powerpackWidgetQueryValueDefinitionRequestToTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequest | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryValueDefinitionRequestToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionRequest | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryValueDefinitionRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryValueDefinitionRequest | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionRequest | cdktn.IResolvable | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _q?;
    get q(): string;
    set q(value: string);
    resetQ(): void;
    get qInput(): string | undefined;
    private _apmQuery;
    get apmQuery(): PowerpackWidgetQueryValueDefinitionRequestApmQueryOutputReference;
    putApmQuery(value: PowerpackWidgetQueryValueDefinitionRequestApmQuery): void;
    resetApmQuery(): void;
    get apmQueryInput(): PowerpackWidgetQueryValueDefinitionRequestApmQuery | undefined;
    private _auditQuery;
    get auditQuery(): PowerpackWidgetQueryValueDefinitionRequestAuditQueryOutputReference;
    putAuditQuery(value: PowerpackWidgetQueryValueDefinitionRequestAuditQuery): void;
    resetAuditQuery(): void;
    get auditQueryInput(): PowerpackWidgetQueryValueDefinitionRequestAuditQuery | undefined;
    private _conditionalFormats;
    get conditionalFormats(): PowerpackWidgetQueryValueDefinitionRequestConditionalFormatsList;
    putConditionalFormats(value: PowerpackWidgetQueryValueDefinitionRequestConditionalFormats[] | cdktn.IResolvable): void;
    resetConditionalFormats(): void;
    get conditionalFormatsInput(): cdktn.IResolvable | PowerpackWidgetQueryValueDefinitionRequestConditionalFormats[] | undefined;
    private _formula;
    get formula(): PowerpackWidgetQueryValueDefinitionRequestFormulaList;
    putFormula(value: PowerpackWidgetQueryValueDefinitionRequestFormula[] | cdktn.IResolvable): void;
    resetFormula(): void;
    get formulaInput(): cdktn.IResolvable | PowerpackWidgetQueryValueDefinitionRequestFormula[] | undefined;
    private _logQuery;
    get logQuery(): PowerpackWidgetQueryValueDefinitionRequestLogQueryOutputReference;
    putLogQuery(value: PowerpackWidgetQueryValueDefinitionRequestLogQuery): void;
    resetLogQuery(): void;
    get logQueryInput(): PowerpackWidgetQueryValueDefinitionRequestLogQuery | undefined;
    private _processQuery;
    get processQuery(): PowerpackWidgetQueryValueDefinitionRequestProcessQueryOutputReference;
    putProcessQuery(value: PowerpackWidgetQueryValueDefinitionRequestProcessQuery): void;
    resetProcessQuery(): void;
    get processQueryInput(): PowerpackWidgetQueryValueDefinitionRequestProcessQuery | undefined;
    private _query;
    get query(): PowerpackWidgetQueryValueDefinitionRequestQueryList;
    putQuery(value: PowerpackWidgetQueryValueDefinitionRequestQuery[] | cdktn.IResolvable): void;
    resetQuery(): void;
    get queryInput(): cdktn.IResolvable | PowerpackWidgetQueryValueDefinitionRequestQuery[] | undefined;
    private _rumQuery;
    get rumQuery(): PowerpackWidgetQueryValueDefinitionRequestRumQueryOutputReference;
    putRumQuery(value: PowerpackWidgetQueryValueDefinitionRequestRumQuery): void;
    resetRumQuery(): void;
    get rumQueryInput(): PowerpackWidgetQueryValueDefinitionRequestRumQuery | undefined;
    private _securityQuery;
    get securityQuery(): PowerpackWidgetQueryValueDefinitionRequestSecurityQueryOutputReference;
    putSecurityQuery(value: PowerpackWidgetQueryValueDefinitionRequestSecurityQuery): void;
    resetSecurityQuery(): void;
    get securityQueryInput(): PowerpackWidgetQueryValueDefinitionRequestSecurityQuery | undefined;
}
export declare class PowerpackWidgetQueryValueDefinitionRequestList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryValueDefinitionRequest[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryValueDefinitionRequestOutputReference;
}
export interface PowerpackWidgetQueryValueDefinitionTimeseriesBackgroundYaxis {
    /**
    * Always include zero or fit the axis to the data range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#include_zero Powerpack#include_zero}
    */
    readonly includeZero?: boolean | cdktn.IResolvable;
    /**
    * The label of the axis to display on the graph.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label?: string;
    /**
    * Specify the maximum value to show on the Y-axis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#max Powerpack#max}
    */
    readonly max?: string;
    /**
    * Specify the minimum value to show on the Y-axis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#min Powerpack#min}
    */
    readonly min?: string;
    /**
    * Specify the scale type, options: `linear`, `log`, `pow`, `sqrt`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#scale Powerpack#scale}
    */
    readonly scale?: string;
}
export declare function powerpackWidgetQueryValueDefinitionTimeseriesBackgroundYaxisToTerraform(struct?: PowerpackWidgetQueryValueDefinitionTimeseriesBackgroundYaxisOutputReference | PowerpackWidgetQueryValueDefinitionTimeseriesBackgroundYaxis): any;
export declare function powerpackWidgetQueryValueDefinitionTimeseriesBackgroundYaxisToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionTimeseriesBackgroundYaxisOutputReference | PowerpackWidgetQueryValueDefinitionTimeseriesBackgroundYaxis): any;
export declare class PowerpackWidgetQueryValueDefinitionTimeseriesBackgroundYaxisOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionTimeseriesBackgroundYaxis | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionTimeseriesBackgroundYaxis | undefined);
    private _includeZero?;
    get includeZero(): boolean | cdktn.IResolvable;
    set includeZero(value: boolean | cdktn.IResolvable);
    resetIncludeZero(): void;
    get includeZeroInput(): boolean | cdktn.IResolvable | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _max?;
    get max(): string;
    set max(value: string);
    resetMax(): void;
    get maxInput(): string | undefined;
    private _min?;
    get min(): string;
    set min(value: string);
    resetMin(): void;
    get minInput(): string | undefined;
    private _scale?;
    get scale(): string;
    set scale(value: string);
    resetScale(): void;
    get scaleInput(): string | undefined;
}
export interface PowerpackWidgetQueryValueDefinitionTimeseriesBackground {
    /**
    * Whether the Timeseries is made using an area or bars. Valid values are `bars`, `area`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#type Powerpack#type}
    */
    readonly type: string;
    /**
    * yaxis block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#yaxis Powerpack#yaxis}
    */
    readonly yaxis?: PowerpackWidgetQueryValueDefinitionTimeseriesBackgroundYaxis;
}
export declare function powerpackWidgetQueryValueDefinitionTimeseriesBackgroundToTerraform(struct?: PowerpackWidgetQueryValueDefinitionTimeseriesBackgroundOutputReference | PowerpackWidgetQueryValueDefinitionTimeseriesBackground): any;
export declare function powerpackWidgetQueryValueDefinitionTimeseriesBackgroundToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionTimeseriesBackgroundOutputReference | PowerpackWidgetQueryValueDefinitionTimeseriesBackground): any;
export declare class PowerpackWidgetQueryValueDefinitionTimeseriesBackgroundOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinitionTimeseriesBackground | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinitionTimeseriesBackground | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _yaxis;
    get yaxis(): PowerpackWidgetQueryValueDefinitionTimeseriesBackgroundYaxisOutputReference;
    putYaxis(value: PowerpackWidgetQueryValueDefinitionTimeseriesBackgroundYaxis): void;
    resetYaxis(): void;
    get yaxisInput(): PowerpackWidgetQueryValueDefinitionTimeseriesBackgroundYaxis | undefined;
}
export interface PowerpackWidgetQueryValueDefinition {
    /**
    * A Boolean indicating whether to automatically scale the tile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#autoscale Powerpack#autoscale}
    */
    readonly autoscale?: boolean | cdktn.IResolvable;
    /**
    * The unit for the value displayed in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_unit Powerpack#custom_unit}
    */
    readonly customUnit?: string;
    /**
    * Hide any portion of the widget's timeframe that is incomplete due to cost data not being available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_incomplete_cost_data Powerpack#hide_incomplete_cost_data}
    */
    readonly hideIncompleteCostData?: boolean | cdktn.IResolvable;
    /**
    * The timeframe to use when displaying the widget. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#live_span Powerpack#live_span}
    */
    readonly liveSpan?: string;
    /**
    * The precision to use when displaying the tile.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#precision Powerpack#precision}
    */
    readonly precision?: number;
    /**
    * The alignment of the widget's text. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#text_align Powerpack#text_align}
    */
    readonly textAlign?: string;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title Powerpack#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_align Powerpack#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_size Powerpack#title_size}
    */
    readonly titleSize?: string;
    /**
    * custom_link block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_link Powerpack#custom_link}
    */
    readonly customLink?: PowerpackWidgetQueryValueDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#request Powerpack#request}
    */
    readonly request?: PowerpackWidgetQueryValueDefinitionRequest[] | cdktn.IResolvable;
    /**
    * timeseries_background block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#timeseries_background Powerpack#timeseries_background}
    */
    readonly timeseriesBackground?: PowerpackWidgetQueryValueDefinitionTimeseriesBackground;
}
export declare function powerpackWidgetQueryValueDefinitionToTerraform(struct?: PowerpackWidgetQueryValueDefinitionOutputReference | PowerpackWidgetQueryValueDefinition): any;
export declare function powerpackWidgetQueryValueDefinitionToHclTerraform(struct?: PowerpackWidgetQueryValueDefinitionOutputReference | PowerpackWidgetQueryValueDefinition): any;
export declare class PowerpackWidgetQueryValueDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryValueDefinition | undefined;
    set internalValue(value: PowerpackWidgetQueryValueDefinition | undefined);
    private _autoscale?;
    get autoscale(): boolean | cdktn.IResolvable;
    set autoscale(value: boolean | cdktn.IResolvable);
    resetAutoscale(): void;
    get autoscaleInput(): boolean | cdktn.IResolvable | undefined;
    private _customUnit?;
    get customUnit(): string;
    set customUnit(value: string);
    resetCustomUnit(): void;
    get customUnitInput(): string | undefined;
    private _hideIncompleteCostData?;
    get hideIncompleteCostData(): boolean | cdktn.IResolvable;
    set hideIncompleteCostData(value: boolean | cdktn.IResolvable);
    resetHideIncompleteCostData(): void;
    get hideIncompleteCostDataInput(): boolean | cdktn.IResolvable | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _precision?;
    get precision(): number;
    set precision(value: number);
    resetPrecision(): void;
    get precisionInput(): number | undefined;
    private _textAlign?;
    get textAlign(): string;
    set textAlign(value: string);
    resetTextAlign(): void;
    get textAlignInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _customLink;
    get customLink(): PowerpackWidgetQueryValueDefinitionCustomLinkList;
    putCustomLink(value: PowerpackWidgetQueryValueDefinitionCustomLink[] | cdktn.IResolvable): void;
    resetCustomLink(): void;
    get customLinkInput(): cdktn.IResolvable | PowerpackWidgetQueryValueDefinitionCustomLink[] | undefined;
    private _request;
    get request(): PowerpackWidgetQueryValueDefinitionRequestList;
    putRequest(value: PowerpackWidgetQueryValueDefinitionRequest[] | cdktn.IResolvable): void;
    resetRequest(): void;
    get requestInput(): cdktn.IResolvable | PowerpackWidgetQueryValueDefinitionRequest[] | undefined;
    private _timeseriesBackground;
    get timeseriesBackground(): PowerpackWidgetQueryValueDefinitionTimeseriesBackgroundOutputReference;
    putTimeseriesBackground(value: PowerpackWidgetQueryValueDefinitionTimeseriesBackground): void;
    resetTimeseriesBackground(): void;
    get timeseriesBackgroundInput(): PowerpackWidgetQueryValueDefinitionTimeseriesBackground | undefined;
}
export interface PowerpackWidgetRunWorkflowDefinitionCustomLink {
    /**
    * The flag for toggling context menu link visibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_hidden Powerpack#is_hidden}
    */
    readonly isHidden?: boolean | cdktn.IResolvable;
    /**
    * The label for the custom link URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label?: string;
    /**
    * The URL of the custom link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#link Powerpack#link}
    */
    readonly link?: string;
    /**
    * The label ID that refers to a context menu link item. When `override_label` is provided, the client request omits the label field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#override_label Powerpack#override_label}
    */
    readonly overrideLabel?: string;
}
export declare function powerpackWidgetRunWorkflowDefinitionCustomLinkToTerraform(struct?: PowerpackWidgetRunWorkflowDefinitionCustomLink | cdktn.IResolvable): any;
export declare function powerpackWidgetRunWorkflowDefinitionCustomLinkToHclTerraform(struct?: PowerpackWidgetRunWorkflowDefinitionCustomLink | cdktn.IResolvable): any;
export declare class PowerpackWidgetRunWorkflowDefinitionCustomLinkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetRunWorkflowDefinitionCustomLink | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetRunWorkflowDefinitionCustomLink | cdktn.IResolvable | undefined);
    private _isHidden?;
    get isHidden(): boolean | cdktn.IResolvable;
    set isHidden(value: boolean | cdktn.IResolvable);
    resetIsHidden(): void;
    get isHiddenInput(): boolean | cdktn.IResolvable | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _link?;
    get link(): string;
    set link(value: string);
    resetLink(): void;
    get linkInput(): string | undefined;
    private _overrideLabel?;
    get overrideLabel(): string;
    set overrideLabel(value: string);
    resetOverrideLabel(): void;
    get overrideLabelInput(): string | undefined;
}
export declare class PowerpackWidgetRunWorkflowDefinitionCustomLinkList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetRunWorkflowDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetRunWorkflowDefinitionCustomLinkOutputReference;
}
export interface PowerpackWidgetRunWorkflowDefinitionInput {
    /**
    * Name of the workflow input.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Dashboard template variable. Can be suffixed with `.value` or `.key`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#value Powerpack#value}
    */
    readonly value: string;
}
export declare function powerpackWidgetRunWorkflowDefinitionInputToTerraform(struct?: PowerpackWidgetRunWorkflowDefinitionInput | cdktn.IResolvable): any;
export declare function powerpackWidgetRunWorkflowDefinitionInputToHclTerraform(struct?: PowerpackWidgetRunWorkflowDefinitionInput | cdktn.IResolvable): any;
export declare class PowerpackWidgetRunWorkflowDefinitionInputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetRunWorkflowDefinitionInput | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetRunWorkflowDefinitionInput | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class PowerpackWidgetRunWorkflowDefinitionInputList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetRunWorkflowDefinitionInput[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetRunWorkflowDefinitionInputOutputReference;
}
export interface PowerpackWidgetRunWorkflowDefinition {
    /**
    * Hide any portion of the widget's timeframe that is incomplete due to cost data not being available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_incomplete_cost_data Powerpack#hide_incomplete_cost_data}
    */
    readonly hideIncompleteCostData?: boolean | cdktn.IResolvable;
    /**
    * The timeframe to use when displaying the widget. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#live_span Powerpack#live_span}
    */
    readonly liveSpan?: string;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title Powerpack#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_align Powerpack#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_size Powerpack#title_size}
    */
    readonly titleSize?: string;
    /**
    * Workflow ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#workflow_id Powerpack#workflow_id}
    */
    readonly workflowId: string;
    /**
    * custom_link block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_link Powerpack#custom_link}
    */
    readonly customLink?: PowerpackWidgetRunWorkflowDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * input block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#input Powerpack#input}
    */
    readonly input?: PowerpackWidgetRunWorkflowDefinitionInput[] | cdktn.IResolvable;
}
export declare function powerpackWidgetRunWorkflowDefinitionToTerraform(struct?: PowerpackWidgetRunWorkflowDefinitionOutputReference | PowerpackWidgetRunWorkflowDefinition): any;
export declare function powerpackWidgetRunWorkflowDefinitionToHclTerraform(struct?: PowerpackWidgetRunWorkflowDefinitionOutputReference | PowerpackWidgetRunWorkflowDefinition): any;
export declare class PowerpackWidgetRunWorkflowDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetRunWorkflowDefinition | undefined;
    set internalValue(value: PowerpackWidgetRunWorkflowDefinition | undefined);
    private _hideIncompleteCostData?;
    get hideIncompleteCostData(): boolean | cdktn.IResolvable;
    set hideIncompleteCostData(value: boolean | cdktn.IResolvable);
    resetHideIncompleteCostData(): void;
    get hideIncompleteCostDataInput(): boolean | cdktn.IResolvable | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _workflowId?;
    get workflowId(): string;
    set workflowId(value: string);
    get workflowIdInput(): string | undefined;
    private _customLink;
    get customLink(): PowerpackWidgetRunWorkflowDefinitionCustomLinkList;
    putCustomLink(value: PowerpackWidgetRunWorkflowDefinitionCustomLink[] | cdktn.IResolvable): void;
    resetCustomLink(): void;
    get customLinkInput(): cdktn.IResolvable | PowerpackWidgetRunWorkflowDefinitionCustomLink[] | undefined;
    private _input;
    get input(): PowerpackWidgetRunWorkflowDefinitionInputList;
    putInput(value: PowerpackWidgetRunWorkflowDefinitionInput[] | cdktn.IResolvable): void;
    resetInput(): void;
    get inputInput(): cdktn.IResolvable | PowerpackWidgetRunWorkflowDefinitionInput[] | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionCustomLink {
    /**
    * The flag for toggling context menu link visibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_hidden Powerpack#is_hidden}
    */
    readonly isHidden?: boolean | cdktn.IResolvable;
    /**
    * The label for the custom link URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label?: string;
    /**
    * The URL of the custom link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#link Powerpack#link}
    */
    readonly link?: string;
    /**
    * The label ID that refers to a context menu link item. When `override_label` is provided, the client request omits the label field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#override_label Powerpack#override_label}
    */
    readonly overrideLabel?: string;
}
export declare function powerpackWidgetScatterplotDefinitionCustomLinkToTerraform(struct?: PowerpackWidgetScatterplotDefinitionCustomLink | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionCustomLinkToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionCustomLink | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionCustomLinkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionCustomLink | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionCustomLink | cdktn.IResolvable | undefined);
    private _isHidden?;
    get isHidden(): boolean | cdktn.IResolvable;
    set isHidden(value: boolean | cdktn.IResolvable);
    resetIsHidden(): void;
    get isHiddenInput(): boolean | cdktn.IResolvable | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _link?;
    get link(): string;
    set link(value: string);
    resetLink(): void;
    get linkInput(): string | undefined;
    private _overrideLabel?;
    get overrideLabel(): string;
    set overrideLabel(value: string);
    resetOverrideLabel(): void;
    get overrideLabelInput(): string | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionCustomLinkList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionCustomLinkOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequestScatterplotTableFormula {
    /**
    * An expression alias.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#alias Powerpack#alias}
    */
    readonly alias?: string;
    /**
    * Dimension of the Scatterplot. Valid values are `x`, `y`, `radius`, `color`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#dimension Powerpack#dimension}
    */
    readonly dimension: string;
    /**
    * A string expression built from queries, formulas, and functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#formula_expression Powerpack#formula_expression}
    */
    readonly formulaExpression: string;
}
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableFormulaToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableFormula | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableFormulaToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableFormula | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestScatterplotTableFormulaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableFormula | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableFormula | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _dimension?;
    get dimension(): string;
    set dimension(value: string);
    get dimensionInput(): string | undefined;
    private _formulaExpression?;
    get formulaExpression(): string;
    set formulaExpression(value: string);
    get formulaExpressionInput(): string | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestScatterplotTableFormulaList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableFormula[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableFormulaOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmDependencyStatsQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for APM Dependency Stats queries. Valid values are `apm_dependency_stats`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * APM environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#env Powerpack#env}
    */
    readonly env: string;
    /**
    * Determines whether stats for upstream or downstream dependencies should be queried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_upstream Powerpack#is_upstream}
    */
    readonly isUpstream?: boolean | cdktn.IResolvable;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Name of operation on service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#operation_name Powerpack#operation_name}
    */
    readonly operationName: string;
    /**
    * The name of the second primary tag used within APM; required when `primary_tag_value` is specified. See https://docs.datadoghq.com/tracing/guide/setting_primary_tags_to_scope/#add-a-second-primary-tag-in-datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_name Powerpack#primary_tag_name}
    */
    readonly primaryTagName?: string;
    /**
    * Filter APM data by the second primary tag. `primary_tag_name` must also be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_value Powerpack#primary_tag_value}
    */
    readonly primaryTagValue?: string;
    /**
    * APM resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#resource_name Powerpack#resource_name}
    */
    readonly resourceName: string;
    /**
    * APM service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#service Powerpack#service}
    */
    readonly service: string;
    /**
    * APM statistic. Valid values are `avg_duration`, `avg_root_duration`, `avg_spans_per_trace`, `error_rate`, `pct_exec_time`, `pct_of_traces`, `total_traces_count`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#stat Powerpack#stat}
    */
    readonly stat: string;
}
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmDependencyStatsQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmDependencyStatsQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmDependencyStatsQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmDependencyStatsQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmDependencyStatsQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmDependencyStatsQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmDependencyStatsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmDependencyStatsQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmDependencyStatsQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    private _isUpstream?;
    get isUpstream(): boolean | cdktn.IResolvable;
    set isUpstream(value: boolean | cdktn.IResolvable);
    resetIsUpstream(): void;
    get isUpstreamInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    get operationNameInput(): string | undefined;
    private _primaryTagName?;
    get primaryTagName(): string;
    set primaryTagName(value: string);
    resetPrimaryTagName(): void;
    get primaryTagNameInput(): string | undefined;
    private _primaryTagValue?;
    get primaryTagValue(): string;
    set primaryTagValue(value: string);
    resetPrimaryTagValue(): void;
    get primaryTagValueInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    get resourceNameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    get statInput(): string | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmResourceStatsQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for APM Resource Stats queries. Valid values are `apm_resource_stats`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * APM environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#env Powerpack#env}
    */
    readonly env: string;
    /**
    * Array of fields to group results by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: string[];
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Name of operation on service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#operation_name Powerpack#operation_name}
    */
    readonly operationName?: string;
    /**
    * The name of the second primary tag used within APM; required when `primary_tag_value` is specified. See https://docs.datadoghq.com/tracing/guide/setting_primary_tags_to_scope/#add-a-second-primary-tag-in-datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_name Powerpack#primary_tag_name}
    */
    readonly primaryTagName?: string;
    /**
    * Filter APM data by the second primary tag. `primary_tag_name` must also be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_value Powerpack#primary_tag_value}
    */
    readonly primaryTagValue?: string;
    /**
    * APM resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#resource_name Powerpack#resource_name}
    */
    readonly resourceName?: string;
    /**
    * APM service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#service Powerpack#service}
    */
    readonly service: string;
    /**
    * APM statistic. Valid values are `errors`, `error_rate`, `hits`, `latency_avg`, `latency_distribution`, `latency_max`, `latency_p50`, `latency_p75`, `latency_p90`, `latency_p95`, `latency_p99`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#stat Powerpack#stat}
    */
    readonly stat: string;
}
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmResourceStatsQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmResourceStatsQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmResourceStatsQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmResourceStatsQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmResourceStatsQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmResourceStatsQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmResourceStatsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmResourceStatsQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmResourceStatsQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    private _groupBy?;
    get groupBy(): string[];
    set groupBy(value: string[]);
    resetGroupBy(): void;
    get groupByInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    resetOperationName(): void;
    get operationNameInput(): string | undefined;
    private _primaryTagName?;
    get primaryTagName(): string;
    set primaryTagName(value: string);
    resetPrimaryTagName(): void;
    get primaryTagNameInput(): string | undefined;
    private _primaryTagValue?;
    get primaryTagValue(): string;
    set primaryTagValue(value: string);
    resetPrimaryTagValue(): void;
    get primaryTagValueInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    resetResourceName(): void;
    get resourceNameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    get statInput(): string | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryCloudCostQuery {
    /**
    * The aggregation methods available for cloud cost queries. Valid values are `avg`, `last`, `max`, `min`, `sum`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for cloud cost queries. Valid values are `cloud_cost`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The cloud cost query definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
}
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryCloudCostQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryCloudCostQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryCloudCostQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryCloudCostQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryCloudCostQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryCloudCostQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryCloudCostQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryCloudCostQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryCloudCostQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryCompute {
    /**
    * The aggregation methods for event platform queries. Valid values are `count`, `cardinality`, `median`, `pc75`, `pc90`, `pc95`, `pc98`, `pc99`, `sum`, `min`, `max`, `avg`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * A time interval in milliseconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
    /**
    * The measurable attribute to compute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
}
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryComputeToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryComputeToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryComputeOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBySort {
    /**
    * The aggregation methods for the event platform queries. Valid values are `count`, `cardinality`, `median`, `pc75`, `pc90`, `pc95`, `pc98`, `pc99`, `sum`, `min`, `max`, `avg`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The metric used for sorting group by results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
    /**
    * Direction of sort. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order?: string;
}
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBySortToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBySortOutputReference | PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBySort): any;
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBySortToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBySortOutputReference | PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBySort): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBySortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBySort | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBySort | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBy {
    /**
    * The event facet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet: string;
    /**
    * The number of groups to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort Powerpack#sort}
    */
    readonly sort?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBySort;
}
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupByToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupByToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sort;
    get sort(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBySortOutputReference;
    putSort(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBySort): void;
    resetSort(): void;
    get sortInput(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBySort | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupByOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQuerySearch {
    /**
    * The events search string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
}
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQuerySearchToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQuerySearchOutputReference | PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQuerySearch): any;
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQuerySearchToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQuerySearchOutputReference | PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQuerySearch): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQuerySearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQuerySearch | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQuerySearch | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for event platform-based queries. Valid values are `logs`, `spans`, `network`, `rum`, `security_signals`, `profiles`, `audit`, `events`, `ci_tests`, `ci_pipelines`, `incident_analytics`, `product_analytics`, `on_call_events`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * An array of index names to query in the stream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#indexes Powerpack#indexes}
    */
    readonly indexes?: string[];
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Storage location (private beta).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#storage Powerpack#storage}
    */
    readonly storage?: string;
    /**
    * compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute Powerpack#compute}
    */
    readonly compute: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryCompute[] | cdktn.IResolvable;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBy[] | cdktn.IResolvable;
    /**
    * search block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search Powerpack#search}
    */
    readonly search?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQuerySearch;
}
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _indexes?;
    get indexes(): string[];
    set indexes(value: string[]);
    resetIndexes(): void;
    get indexesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _storage?;
    get storage(): string;
    set storage(value: string);
    resetStorage(): void;
    get storageInput(): string | undefined;
    private _compute;
    get compute(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryComputeList;
    putCompute(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryCompute[] | cdktn.IResolvable): void;
    get computeInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryCompute[] | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupByList;
    putGroupBy(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryGroupBy[] | undefined;
    private _search;
    get search(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQuerySearchOutputReference;
    putSearch(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQuerySearch): void;
    resetSearch(): void;
    get searchInput(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQuerySearch | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryMetricQuery {
    /**
    * The aggregation methods available for metrics queries. Valid values are `avg`, `min`, `max`, `sum`, `last`, `area`, `l2norm`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for metrics queries. Defaults to `"metrics"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource?: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The metrics query definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
    /**
    * Semantic mode for metrics queries. This determines how metrics from different sources are combined or displayed. Valid values are `combined`, `native`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#semantic_mode Powerpack#semantic_mode}
    */
    readonly semanticMode?: string;
}
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryMetricQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryMetricQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryMetricQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryMetricQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryMetricQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryMetricQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryMetricQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryMetricQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryMetricQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    resetDataSource(): void;
    get dataSourceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _semanticMode?;
    get semanticMode(): string;
    set semanticMode(value: string);
    resetSemanticMode(): void;
    get semanticModeInput(): string | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryProcessQuery {
    /**
    * The aggregation methods available for metrics queries. Valid values are `avg`, `min`, `max`, `sum`, `last`, `area`, `l2norm`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for process queries. Valid values are `process`, `container`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * Whether to normalize the CPU percentages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_normalized_cpu Powerpack#is_normalized_cpu}
    */
    readonly isNormalizedCpu?: boolean | cdktn.IResolvable;
    /**
    * The number of hits to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * The process metric name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric: string;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The direction of the sort. Valid values are `asc`, `desc`. Defaults to `"desc"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort Powerpack#sort}
    */
    readonly sort?: string;
    /**
    * An array of tags to filter by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#tag_filters Powerpack#tag_filters}
    */
    readonly tagFilters?: string[];
    /**
    * The text to use as a filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#text_filter Powerpack#text_filter}
    */
    readonly textFilter?: string;
}
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryProcessQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryProcessQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryProcessQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryProcessQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryProcessQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryProcessQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryProcessQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryProcessQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryProcessQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _isNormalizedCpu?;
    get isNormalizedCpu(): boolean | cdktn.IResolvable;
    set isNormalizedCpu(value: boolean | cdktn.IResolvable);
    resetIsNormalizedCpu(): void;
    get isNormalizedCpuInput(): boolean | cdktn.IResolvable | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _sort?;
    get sort(): string;
    set sort(value: string);
    resetSort(): void;
    get sortInput(): string | undefined;
    private _tagFilters?;
    get tagFilters(): string[];
    set tagFilters(value: string[]);
    resetTagFilters(): void;
    get tagFiltersInput(): string[] | undefined;
    private _textFilter?;
    get textFilter(): string;
    set textFilter(value: string);
    resetTextFilter(): void;
    get textFilterInput(): string | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQuerySloQuery {
    /**
    * Additional filters applied to the SLO query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#additional_query_filters Powerpack#additional_query_filters}
    */
    readonly additionalQueryFilters?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for SLO queries. Valid values are `slo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * Group mode to query measures. Valid values are `overall`, `components`. Defaults to `"overall"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_mode Powerpack#group_mode}
    */
    readonly groupMode?: string;
    /**
    * SLO measures queries. Valid values are `good_events`, `bad_events`, `good_minutes`, `bad_minutes`, `slo_status`, `error_budget_remaining`, `burn_rate`, `error_budget_burndown`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#measure Powerpack#measure}
    */
    readonly measure: string;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name?: string;
    /**
    * ID of an SLO to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_id Powerpack#slo_id}
    */
    readonly sloId: string;
    /**
    * type of the SLO to query. Valid values are `metric`, `monitor`, `time_slice`. Defaults to `"metric"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_query_type Powerpack#slo_query_type}
    */
    readonly sloQueryType?: string;
}
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQuerySloQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQuerySloQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQuerySloQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQuerySloQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQuerySloQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQuerySloQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQuerySloQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQuerySloQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQuerySloQuery | undefined);
    private _additionalQueryFilters?;
    get additionalQueryFilters(): string;
    set additionalQueryFilters(value: string);
    resetAdditionalQueryFilters(): void;
    get additionalQueryFiltersInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _groupMode?;
    get groupMode(): string;
    set groupMode(value: string);
    resetGroupMode(): void;
    get groupModeInput(): string | undefined;
    private _measure?;
    get measure(): string;
    set measure(value: string);
    get measureInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sloId?;
    get sloId(): string;
    set sloId(value: string);
    get sloIdInput(): string | undefined;
    private _sloQueryType?;
    get sloQueryType(): string;
    set sloQueryType(value: string);
    resetSloQueryType(): void;
    get sloQueryTypeInput(): string | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQuery {
    /**
    * apm_dependency_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_dependency_stats_query Powerpack#apm_dependency_stats_query}
    */
    readonly apmDependencyStatsQuery?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmDependencyStatsQuery;
    /**
    * apm_resource_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_resource_stats_query Powerpack#apm_resource_stats_query}
    */
    readonly apmResourceStatsQuery?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmResourceStatsQuery;
    /**
    * cloud_cost_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cloud_cost_query Powerpack#cloud_cost_query}
    */
    readonly cloudCostQuery?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryCloudCostQuery;
    /**
    * event_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#event_query Powerpack#event_query}
    */
    readonly eventQuery?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQuery;
    /**
    * metric_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric_query Powerpack#metric_query}
    */
    readonly metricQuery?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryMetricQuery;
    /**
    * process_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#process_query Powerpack#process_query}
    */
    readonly processQuery?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryProcessQuery;
    /**
    * slo_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_query Powerpack#slo_query}
    */
    readonly sloQuery?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQuerySloQuery;
}
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQuery | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQuery | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQuery | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQuery | cdktn.IResolvable | undefined);
    private _apmDependencyStatsQuery;
    get apmDependencyStatsQuery(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmDependencyStatsQueryOutputReference;
    putApmDependencyStatsQuery(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmDependencyStatsQuery): void;
    resetApmDependencyStatsQuery(): void;
    get apmDependencyStatsQueryInput(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmDependencyStatsQuery | undefined;
    private _apmResourceStatsQuery;
    get apmResourceStatsQuery(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmResourceStatsQueryOutputReference;
    putApmResourceStatsQuery(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmResourceStatsQuery): void;
    resetApmResourceStatsQuery(): void;
    get apmResourceStatsQueryInput(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryApmResourceStatsQuery | undefined;
    private _cloudCostQuery;
    get cloudCostQuery(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryCloudCostQueryOutputReference;
    putCloudCostQuery(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryCloudCostQuery): void;
    resetCloudCostQuery(): void;
    get cloudCostQueryInput(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryCloudCostQuery | undefined;
    private _eventQuery;
    get eventQuery(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQueryOutputReference;
    putEventQuery(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQuery): void;
    resetEventQuery(): void;
    get eventQueryInput(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryEventQuery | undefined;
    private _metricQuery;
    get metricQuery(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryMetricQueryOutputReference;
    putMetricQuery(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryMetricQuery): void;
    resetMetricQuery(): void;
    get metricQueryInput(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryMetricQuery | undefined;
    private _processQuery;
    get processQuery(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryProcessQueryOutputReference;
    putProcessQuery(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryProcessQuery): void;
    resetProcessQuery(): void;
    get processQueryInput(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryProcessQuery | undefined;
    private _sloQuery;
    get sloQuery(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQuerySloQueryOutputReference;
    putSloQuery(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQuerySloQuery): void;
    resetSloQuery(): void;
    get sloQueryInput(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQuerySloQuery | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequestScatterplotTable {
    /**
    * formula block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#formula Powerpack#formula}
    */
    readonly formula?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableFormula[] | cdktn.IResolvable;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQuery[] | cdktn.IResolvable;
}
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTable | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestScatterplotTableToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTable | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestScatterplotTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTable | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTable | cdktn.IResolvable | undefined);
    private _formula;
    get formula(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableFormulaList;
    putFormula(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableFormula[] | cdktn.IResolvable): void;
    resetFormula(): void;
    get formulaInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestScatterplotTableFormula[] | undefined;
    private _query;
    get query(): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQueryList;
    putQuery(value: PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQuery[] | cdktn.IResolvable): void;
    resetQuery(): void;
    get queryInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestScatterplotTableQuery[] | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestScatterplotTableList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestScatterplotTable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestScatterplotTableOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequestXApmQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetScatterplotDefinitionRequestXApmQueryComputeQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXApmQueryComputeQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXApmQueryComputeQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestXApmQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXApmQueryComputeQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXApmQueryComputeQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestXApmQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestXApmQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestXApmQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBySortQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBySortQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBySortQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBySortQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBySortQuery;
}
export declare function powerpackWidgetScatterplotDefinitionRequestXApmQueryGroupByToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestXApmQueryGroupByToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupByOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequestXApmQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetScatterplotDefinitionRequestXApmQueryMultiComputeToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXApmQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestXApmQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXApmQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestXApmQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestXApmQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestXApmQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestXApmQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestXApmQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestXApmQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequestXApmQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetScatterplotDefinitionRequestXApmQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetScatterplotDefinitionRequestXApmQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetScatterplotDefinitionRequestXApmQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXApmQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXApmQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestXApmQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXApmQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXApmQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestXApmQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestXApmQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestXApmQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetScatterplotDefinitionRequestXApmQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetScatterplotDefinitionRequestXApmQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetScatterplotDefinitionRequestXApmQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupByList;
    putGroupBy(value: PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestXApmQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetScatterplotDefinitionRequestXApmQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetScatterplotDefinitionRequestXApmQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetScatterplotDefinitionRequestXApmQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestXLogQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetScatterplotDefinitionRequestXLogQueryComputeQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXLogQueryComputeQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXLogQueryComputeQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestXLogQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXLogQueryComputeQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXLogQueryComputeQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestXLogQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestXLogQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestXLogQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBySortQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBySortQuery): any;
export declare function powerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBySortQueryOutputReference | PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBySortQuery): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBySortQuery;
}
export declare function powerpackWidgetScatterplotDefinitionRequestXLogQueryGroupByToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestXLogQueryGroupByToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestXLogQueryGroupByOutputReference;
}
export interface PowerpackWidgetScatterplotDefinitionRequestXLogQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetScatterplotDefinitionRequestXLogQueryMultiComputeToTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXLogQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetScatterplotDefinitionRequestXLogQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetScatterplotDefinitionRequestXLogQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetScatterplotDefinitionRequestXLogQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetScatterplotDefinitionRequestXLogQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetScatterplotDefinitionRequestXLogQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetScatterplotDefinitionRequestXLogQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetScatterplotDefinitionRequestXLogQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetScatterplotDefinitionRequestXLogQueryMultiComputeOutputReference;
}
