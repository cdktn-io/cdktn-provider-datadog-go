/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
import { PowerpackWidgetTreemapDefinitionRequestQueryEventQueryCompute, PowerpackWidgetTreemapDefinitionRequestQueryEventQueryComputeList, PowerpackWidgetTreemapDefinitionRequestQueryApmDependencyStatsQuery, PowerpackWidgetTreemapDefinitionRequestQueryApmDependencyStatsQueryOutputReference, PowerpackWidgetTreemapDefinitionRequestQueryApmResourceStatsQuery, PowerpackWidgetTreemapDefinitionRequestQueryApmResourceStatsQueryOutputReference, PowerpackWidgetTreemapDefinitionRequestQueryCloudCostQuery, PowerpackWidgetTreemapDefinitionRequestQueryCloudCostQueryOutputReference, PowerpackWidgetTreemapDefinitionRequestFormula, PowerpackWidgetTreemapDefinitionRequestFormulaList, PowerpackWidgetTreemapDefinitionCustomLinks, PowerpackWidgetTreemapDefinitionCustomLinksList, PowerpackWidgetTimeseriesDefinition, PowerpackWidgetTimeseriesDefinitionOutputReference, PowerpackWidgetToplistDefinition, PowerpackWidgetToplistDefinitionOutputReference, PowerpackWidgetTopologyMapDefinition, PowerpackWidgetTopologyMapDefinitionOutputReference, PowerpackWidgetTraceServiceDefinition, PowerpackWidgetTraceServiceDefinitionOutputReference } from './structs1600';
import { PowerpackWidgetAlertGraphDefinition, PowerpackWidgetAlertGraphDefinitionOutputReference, PowerpackWidgetAlertValueDefinition, PowerpackWidgetAlertValueDefinitionOutputReference, PowerpackWidgetChangeDefinition, PowerpackWidgetChangeDefinitionOutputReference, PowerpackWidgetCheckStatusDefinition, PowerpackWidgetCheckStatusDefinitionOutputReference, PowerpackWidgetDistributionDefinition, PowerpackWidgetDistributionDefinitionOutputReference, PowerpackWidgetEventStreamDefinition, PowerpackWidgetEventStreamDefinitionOutputReference, PowerpackWidgetEventTimelineDefinition, PowerpackWidgetEventTimelineDefinitionOutputReference, PowerpackWidgetFreeTextDefinition, PowerpackWidgetFreeTextDefinitionOutputReference, PowerpackWidgetGeomapDefinition, PowerpackWidgetGeomapDefinitionOutputReference } from './structs0';
import { PowerpackWidgetHeatmapDefinition, PowerpackWidgetHeatmapDefinitionOutputReference, PowerpackWidgetHostmapDefinition, PowerpackWidgetHostmapDefinitionOutputReference, PowerpackWidgetIframeDefinition, PowerpackWidgetIframeDefinitionOutputReference, PowerpackWidgetImageDefinition, PowerpackWidgetImageDefinitionOutputReference, PowerpackWidgetListStreamDefinition, PowerpackWidgetListStreamDefinitionOutputReference, PowerpackWidgetLogStreamDefinition, PowerpackWidgetLogStreamDefinitionOutputReference, PowerpackWidgetManageStatusDefinition, PowerpackWidgetManageStatusDefinitionOutputReference, PowerpackWidgetNoteDefinition, PowerpackWidgetNoteDefinitionOutputReference } from './structs400';
import { PowerpackWidgetQueryTableDefinition, PowerpackWidgetQueryTableDefinitionOutputReference, PowerpackWidgetQueryValueDefinition, PowerpackWidgetQueryValueDefinitionOutputReference, PowerpackWidgetRunWorkflowDefinition, PowerpackWidgetRunWorkflowDefinitionOutputReference } from './structs800';
import { PowerpackWidgetScatterplotDefinition, PowerpackWidgetScatterplotDefinitionOutputReference, PowerpackWidgetServiceLevelObjectiveDefinition, PowerpackWidgetServiceLevelObjectiveDefinitionOutputReference, PowerpackWidgetServicemapDefinition, PowerpackWidgetServicemapDefinitionOutputReference, PowerpackWidgetSloListDefinition, PowerpackWidgetSloListDefinitionOutputReference, PowerpackWidgetSunburstDefinition, PowerpackWidgetSunburstDefinitionOutputReference } from './structs1200';
export interface PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBySort {
    /**
    * The aggregation methods for the event platform queries. Valid values are `count`, `cardinality`, `median`, `pc75`, `pc90`, `pc95`, `pc98`, `pc99`, `sum`, `min`, `max`, `avg`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The metric used for sorting group by results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
    /**
    * Direction of sort. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order?: string;
}
export declare function powerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBySortToTerraform(struct?: PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBySortOutputReference | PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBySort): any;
export declare function powerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBySortToHclTerraform(struct?: PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBySortOutputReference | PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBySort): any;
export declare class PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBySortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBySort | undefined;
    set internalValue(value: PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBySort | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBy {
    /**
    * The event facet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet: string;
    /**
    * The number of groups to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort Powerpack#sort}
    */
    readonly sort?: PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBySort;
}
export declare function powerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupByToTerraform(struct?: PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupByToHclTerraform(struct?: PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sort;
    get sort(): PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBySortOutputReference;
    putSort(value: PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBySort): void;
    resetSort(): void;
    get sortInput(): PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBySort | undefined;
}
export declare class PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupByOutputReference;
}
export interface PowerpackWidgetTreemapDefinitionRequestQueryEventQuerySearch {
    /**
    * The events search string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
}
export declare function powerpackWidgetTreemapDefinitionRequestQueryEventQuerySearchToTerraform(struct?: PowerpackWidgetTreemapDefinitionRequestQueryEventQuerySearchOutputReference | PowerpackWidgetTreemapDefinitionRequestQueryEventQuerySearch): any;
export declare function powerpackWidgetTreemapDefinitionRequestQueryEventQuerySearchToHclTerraform(struct?: PowerpackWidgetTreemapDefinitionRequestQueryEventQuerySearchOutputReference | PowerpackWidgetTreemapDefinitionRequestQueryEventQuerySearch): any;
export declare class PowerpackWidgetTreemapDefinitionRequestQueryEventQuerySearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetTreemapDefinitionRequestQueryEventQuerySearch | undefined;
    set internalValue(value: PowerpackWidgetTreemapDefinitionRequestQueryEventQuerySearch | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface PowerpackWidgetTreemapDefinitionRequestQueryEventQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for event platform-based queries. Valid values are `logs`, `spans`, `network`, `rum`, `security_signals`, `profiles`, `audit`, `events`, `ci_tests`, `ci_pipelines`, `incident_analytics`, `product_analytics`, `on_call_events`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * An array of index names to query in the stream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#indexes Powerpack#indexes}
    */
    readonly indexes?: string[];
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Storage location (private beta).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#storage Powerpack#storage}
    */
    readonly storage?: string;
    /**
    * compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute Powerpack#compute}
    */
    readonly compute: PowerpackWidgetTreemapDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable;
    /**
    * search block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search Powerpack#search}
    */
    readonly search?: PowerpackWidgetTreemapDefinitionRequestQueryEventQuerySearch;
}
export declare function powerpackWidgetTreemapDefinitionRequestQueryEventQueryToTerraform(struct?: PowerpackWidgetTreemapDefinitionRequestQueryEventQueryOutputReference | PowerpackWidgetTreemapDefinitionRequestQueryEventQuery): any;
export declare function powerpackWidgetTreemapDefinitionRequestQueryEventQueryToHclTerraform(struct?: PowerpackWidgetTreemapDefinitionRequestQueryEventQueryOutputReference | PowerpackWidgetTreemapDefinitionRequestQueryEventQuery): any;
export declare class PowerpackWidgetTreemapDefinitionRequestQueryEventQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetTreemapDefinitionRequestQueryEventQuery | undefined;
    set internalValue(value: PowerpackWidgetTreemapDefinitionRequestQueryEventQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _indexes?;
    get indexes(): string[];
    set indexes(value: string[]);
    resetIndexes(): void;
    get indexesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _storage?;
    get storage(): string;
    set storage(value: string);
    resetStorage(): void;
    get storageInput(): string | undefined;
    private _compute;
    get compute(): PowerpackWidgetTreemapDefinitionRequestQueryEventQueryComputeList;
    putCompute(value: PowerpackWidgetTreemapDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable): void;
    get computeInput(): cdktn.IResolvable | PowerpackWidgetTreemapDefinitionRequestQueryEventQueryCompute[] | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupByList;
    putGroupBy(value: PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetTreemapDefinitionRequestQueryEventQueryGroupBy[] | undefined;
    private _search;
    get search(): PowerpackWidgetTreemapDefinitionRequestQueryEventQuerySearchOutputReference;
    putSearch(value: PowerpackWidgetTreemapDefinitionRequestQueryEventQuerySearch): void;
    resetSearch(): void;
    get searchInput(): PowerpackWidgetTreemapDefinitionRequestQueryEventQuerySearch | undefined;
}
export interface PowerpackWidgetTreemapDefinitionRequestQueryMetricQuery {
    /**
    * The aggregation methods available for metrics queries. Valid values are `avg`, `min`, `max`, `sum`, `last`, `area`, `l2norm`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for metrics queries. Defaults to `"metrics"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource?: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The metrics query definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
    /**
    * Semantic mode for metrics queries. This determines how metrics from different sources are combined or displayed. Valid values are `combined`, `native`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#semantic_mode Powerpack#semantic_mode}
    */
    readonly semanticMode?: string;
}
export declare function powerpackWidgetTreemapDefinitionRequestQueryMetricQueryToTerraform(struct?: PowerpackWidgetTreemapDefinitionRequestQueryMetricQueryOutputReference | PowerpackWidgetTreemapDefinitionRequestQueryMetricQuery): any;
export declare function powerpackWidgetTreemapDefinitionRequestQueryMetricQueryToHclTerraform(struct?: PowerpackWidgetTreemapDefinitionRequestQueryMetricQueryOutputReference | PowerpackWidgetTreemapDefinitionRequestQueryMetricQuery): any;
export declare class PowerpackWidgetTreemapDefinitionRequestQueryMetricQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetTreemapDefinitionRequestQueryMetricQuery | undefined;
    set internalValue(value: PowerpackWidgetTreemapDefinitionRequestQueryMetricQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    resetDataSource(): void;
    get dataSourceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _semanticMode?;
    get semanticMode(): string;
    set semanticMode(value: string);
    resetSemanticMode(): void;
    get semanticModeInput(): string | undefined;
}
export interface PowerpackWidgetTreemapDefinitionRequestQueryProcessQuery {
    /**
    * The aggregation methods available for metrics queries. Valid values are `avg`, `min`, `max`, `sum`, `last`, `area`, `l2norm`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for process queries. Valid values are `process`, `container`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * Whether to normalize the CPU percentages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_normalized_cpu Powerpack#is_normalized_cpu}
    */
    readonly isNormalizedCpu?: boolean | cdktn.IResolvable;
    /**
    * The number of hits to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * The process metric name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric: string;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The direction of the sort. Valid values are `asc`, `desc`. Defaults to `"desc"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort Powerpack#sort}
    */
    readonly sort?: string;
    /**
    * An array of tags to filter by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#tag_filters Powerpack#tag_filters}
    */
    readonly tagFilters?: string[];
    /**
    * The text to use as a filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#text_filter Powerpack#text_filter}
    */
    readonly textFilter?: string;
}
export declare function powerpackWidgetTreemapDefinitionRequestQueryProcessQueryToTerraform(struct?: PowerpackWidgetTreemapDefinitionRequestQueryProcessQueryOutputReference | PowerpackWidgetTreemapDefinitionRequestQueryProcessQuery): any;
export declare function powerpackWidgetTreemapDefinitionRequestQueryProcessQueryToHclTerraform(struct?: PowerpackWidgetTreemapDefinitionRequestQueryProcessQueryOutputReference | PowerpackWidgetTreemapDefinitionRequestQueryProcessQuery): any;
export declare class PowerpackWidgetTreemapDefinitionRequestQueryProcessQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetTreemapDefinitionRequestQueryProcessQuery | undefined;
    set internalValue(value: PowerpackWidgetTreemapDefinitionRequestQueryProcessQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _isNormalizedCpu?;
    get isNormalizedCpu(): boolean | cdktn.IResolvable;
    set isNormalizedCpu(value: boolean | cdktn.IResolvable);
    resetIsNormalizedCpu(): void;
    get isNormalizedCpuInput(): boolean | cdktn.IResolvable | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _sort?;
    get sort(): string;
    set sort(value: string);
    resetSort(): void;
    get sortInput(): string | undefined;
    private _tagFilters?;
    get tagFilters(): string[];
    set tagFilters(value: string[]);
    resetTagFilters(): void;
    get tagFiltersInput(): string[] | undefined;
    private _textFilter?;
    get textFilter(): string;
    set textFilter(value: string);
    resetTextFilter(): void;
    get textFilterInput(): string | undefined;
}
export interface PowerpackWidgetTreemapDefinitionRequestQuerySloQuery {
    /**
    * Additional filters applied to the SLO query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#additional_query_filters Powerpack#additional_query_filters}
    */
    readonly additionalQueryFilters?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for SLO queries. Valid values are `slo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * Group mode to query measures. Valid values are `overall`, `components`. Defaults to `"overall"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_mode Powerpack#group_mode}
    */
    readonly groupMode?: string;
    /**
    * SLO measures queries. Valid values are `good_events`, `bad_events`, `good_minutes`, `bad_minutes`, `slo_status`, `error_budget_remaining`, `burn_rate`, `error_budget_burndown`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#measure Powerpack#measure}
    */
    readonly measure: string;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name?: string;
    /**
    * ID of an SLO to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_id Powerpack#slo_id}
    */
    readonly sloId: string;
    /**
    * type of the SLO to query. Valid values are `metric`, `monitor`, `time_slice`. Defaults to `"metric"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_query_type Powerpack#slo_query_type}
    */
    readonly sloQueryType?: string;
}
export declare function powerpackWidgetTreemapDefinitionRequestQuerySloQueryToTerraform(struct?: PowerpackWidgetTreemapDefinitionRequestQuerySloQueryOutputReference | PowerpackWidgetTreemapDefinitionRequestQuerySloQuery): any;
export declare function powerpackWidgetTreemapDefinitionRequestQuerySloQueryToHclTerraform(struct?: PowerpackWidgetTreemapDefinitionRequestQuerySloQueryOutputReference | PowerpackWidgetTreemapDefinitionRequestQuerySloQuery): any;
export declare class PowerpackWidgetTreemapDefinitionRequestQuerySloQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetTreemapDefinitionRequestQuerySloQuery | undefined;
    set internalValue(value: PowerpackWidgetTreemapDefinitionRequestQuerySloQuery | undefined);
    private _additionalQueryFilters?;
    get additionalQueryFilters(): string;
    set additionalQueryFilters(value: string);
    resetAdditionalQueryFilters(): void;
    get additionalQueryFiltersInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _groupMode?;
    get groupMode(): string;
    set groupMode(value: string);
    resetGroupMode(): void;
    get groupModeInput(): string | undefined;
    private _measure?;
    get measure(): string;
    set measure(value: string);
    get measureInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sloId?;
    get sloId(): string;
    set sloId(value: string);
    get sloIdInput(): string | undefined;
    private _sloQueryType?;
    get sloQueryType(): string;
    set sloQueryType(value: string);
    resetSloQueryType(): void;
    get sloQueryTypeInput(): string | undefined;
}
export interface PowerpackWidgetTreemapDefinitionRequestQuery {
    /**
    * apm_dependency_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_dependency_stats_query Powerpack#apm_dependency_stats_query}
    */
    readonly apmDependencyStatsQuery?: PowerpackWidgetTreemapDefinitionRequestQueryApmDependencyStatsQuery;
    /**
    * apm_resource_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_resource_stats_query Powerpack#apm_resource_stats_query}
    */
    readonly apmResourceStatsQuery?: PowerpackWidgetTreemapDefinitionRequestQueryApmResourceStatsQuery;
    /**
    * cloud_cost_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cloud_cost_query Powerpack#cloud_cost_query}
    */
    readonly cloudCostQuery?: PowerpackWidgetTreemapDefinitionRequestQueryCloudCostQuery;
    /**
    * event_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#event_query Powerpack#event_query}
    */
    readonly eventQuery?: PowerpackWidgetTreemapDefinitionRequestQueryEventQuery;
    /**
    * metric_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric_query Powerpack#metric_query}
    */
    readonly metricQuery?: PowerpackWidgetTreemapDefinitionRequestQueryMetricQuery;
    /**
    * process_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#process_query Powerpack#process_query}
    */
    readonly processQuery?: PowerpackWidgetTreemapDefinitionRequestQueryProcessQuery;
    /**
    * slo_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_query Powerpack#slo_query}
    */
    readonly sloQuery?: PowerpackWidgetTreemapDefinitionRequestQuerySloQuery;
}
export declare function powerpackWidgetTreemapDefinitionRequestQueryToTerraform(struct?: PowerpackWidgetTreemapDefinitionRequestQuery | cdktn.IResolvable): any;
export declare function powerpackWidgetTreemapDefinitionRequestQueryToHclTerraform(struct?: PowerpackWidgetTreemapDefinitionRequestQuery | cdktn.IResolvable): any;
export declare class PowerpackWidgetTreemapDefinitionRequestQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetTreemapDefinitionRequestQuery | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetTreemapDefinitionRequestQuery | cdktn.IResolvable | undefined);
    private _apmDependencyStatsQuery;
    get apmDependencyStatsQuery(): PowerpackWidgetTreemapDefinitionRequestQueryApmDependencyStatsQueryOutputReference;
    putApmDependencyStatsQuery(value: PowerpackWidgetTreemapDefinitionRequestQueryApmDependencyStatsQuery): void;
    resetApmDependencyStatsQuery(): void;
    get apmDependencyStatsQueryInput(): PowerpackWidgetTreemapDefinitionRequestQueryApmDependencyStatsQuery | undefined;
    private _apmResourceStatsQuery;
    get apmResourceStatsQuery(): PowerpackWidgetTreemapDefinitionRequestQueryApmResourceStatsQueryOutputReference;
    putApmResourceStatsQuery(value: PowerpackWidgetTreemapDefinitionRequestQueryApmResourceStatsQuery): void;
    resetApmResourceStatsQuery(): void;
    get apmResourceStatsQueryInput(): PowerpackWidgetTreemapDefinitionRequestQueryApmResourceStatsQuery | undefined;
    private _cloudCostQuery;
    get cloudCostQuery(): PowerpackWidgetTreemapDefinitionRequestQueryCloudCostQueryOutputReference;
    putCloudCostQuery(value: PowerpackWidgetTreemapDefinitionRequestQueryCloudCostQuery): void;
    resetCloudCostQuery(): void;
    get cloudCostQueryInput(): PowerpackWidgetTreemapDefinitionRequestQueryCloudCostQuery | undefined;
    private _eventQuery;
    get eventQuery(): PowerpackWidgetTreemapDefinitionRequestQueryEventQueryOutputReference;
    putEventQuery(value: PowerpackWidgetTreemapDefinitionRequestQueryEventQuery): void;
    resetEventQuery(): void;
    get eventQueryInput(): PowerpackWidgetTreemapDefinitionRequestQueryEventQuery | undefined;
    private _metricQuery;
    get metricQuery(): PowerpackWidgetTreemapDefinitionRequestQueryMetricQueryOutputReference;
    putMetricQuery(value: PowerpackWidgetTreemapDefinitionRequestQueryMetricQuery): void;
    resetMetricQuery(): void;
    get metricQueryInput(): PowerpackWidgetTreemapDefinitionRequestQueryMetricQuery | undefined;
    private _processQuery;
    get processQuery(): PowerpackWidgetTreemapDefinitionRequestQueryProcessQueryOutputReference;
    putProcessQuery(value: PowerpackWidgetTreemapDefinitionRequestQueryProcessQuery): void;
    resetProcessQuery(): void;
    get processQueryInput(): PowerpackWidgetTreemapDefinitionRequestQueryProcessQuery | undefined;
    private _sloQuery;
    get sloQuery(): PowerpackWidgetTreemapDefinitionRequestQuerySloQueryOutputReference;
    putSloQuery(value: PowerpackWidgetTreemapDefinitionRequestQuerySloQuery): void;
    resetSloQuery(): void;
    get sloQueryInput(): PowerpackWidgetTreemapDefinitionRequestQuerySloQuery | undefined;
}
export declare class PowerpackWidgetTreemapDefinitionRequestQueryList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetTreemapDefinitionRequestQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetTreemapDefinitionRequestQueryOutputReference;
}
export interface PowerpackWidgetTreemapDefinitionRequest {
    /**
    * formula block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#formula Powerpack#formula}
    */
    readonly formula?: PowerpackWidgetTreemapDefinitionRequestFormula[] | cdktn.IResolvable;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query?: PowerpackWidgetTreemapDefinitionRequestQuery[] | cdktn.IResolvable;
}
export declare function powerpackWidgetTreemapDefinitionRequestToTerraform(struct?: PowerpackWidgetTreemapDefinitionRequest | cdktn.IResolvable): any;
export declare function powerpackWidgetTreemapDefinitionRequestToHclTerraform(struct?: PowerpackWidgetTreemapDefinitionRequest | cdktn.IResolvable): any;
export declare class PowerpackWidgetTreemapDefinitionRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetTreemapDefinitionRequest | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetTreemapDefinitionRequest | cdktn.IResolvable | undefined);
    private _formula;
    get formula(): PowerpackWidgetTreemapDefinitionRequestFormulaList;
    putFormula(value: PowerpackWidgetTreemapDefinitionRequestFormula[] | cdktn.IResolvable): void;
    resetFormula(): void;
    get formulaInput(): cdktn.IResolvable | PowerpackWidgetTreemapDefinitionRequestFormula[] | undefined;
    private _query;
    get query(): PowerpackWidgetTreemapDefinitionRequestQueryList;
    putQuery(value: PowerpackWidgetTreemapDefinitionRequestQuery[] | cdktn.IResolvable): void;
    resetQuery(): void;
    get queryInput(): cdktn.IResolvable | PowerpackWidgetTreemapDefinitionRequestQuery[] | undefined;
}
export declare class PowerpackWidgetTreemapDefinitionRequestList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetTreemapDefinitionRequest[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetTreemapDefinitionRequestOutputReference;
}
export interface PowerpackWidgetTreemapDefinition {
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title Powerpack#title}
    */
    readonly title?: string;
    /**
    * custom_links block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_links Powerpack#custom_links}
    */
    readonly customLinks?: PowerpackWidgetTreemapDefinitionCustomLinks[] | cdktn.IResolvable;
    /**
    * request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#request Powerpack#request}
    */
    readonly request?: PowerpackWidgetTreemapDefinitionRequest[] | cdktn.IResolvable;
}
export declare function powerpackWidgetTreemapDefinitionToTerraform(struct?: PowerpackWidgetTreemapDefinitionOutputReference | PowerpackWidgetTreemapDefinition): any;
export declare function powerpackWidgetTreemapDefinitionToHclTerraform(struct?: PowerpackWidgetTreemapDefinitionOutputReference | PowerpackWidgetTreemapDefinition): any;
export declare class PowerpackWidgetTreemapDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetTreemapDefinition | undefined;
    set internalValue(value: PowerpackWidgetTreemapDefinition | undefined);
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _customLinks;
    get customLinks(): PowerpackWidgetTreemapDefinitionCustomLinksList;
    putCustomLinks(value: PowerpackWidgetTreemapDefinitionCustomLinks[] | cdktn.IResolvable): void;
    resetCustomLinks(): void;
    get customLinksInput(): cdktn.IResolvable | PowerpackWidgetTreemapDefinitionCustomLinks[] | undefined;
    private _request;
    get request(): PowerpackWidgetTreemapDefinitionRequestList;
    putRequest(value: PowerpackWidgetTreemapDefinitionRequest[] | cdktn.IResolvable): void;
    resetRequest(): void;
    get requestInput(): cdktn.IResolvable | PowerpackWidgetTreemapDefinitionRequest[] | undefined;
}
export interface PowerpackWidgetWidgetLayout {
    /**
    * The height of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#height Powerpack#height}
    */
    readonly height: number;
    /**
    * Whether the widget should be the first one on the second column in high density or not. Only one widget in the dashboard should have this property set to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_column_break Powerpack#is_column_break}
    */
    readonly isColumnBreak?: boolean | cdktn.IResolvable;
    /**
    * The width of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#width Powerpack#width}
    */
    readonly width: number;
    /**
    * The position of the widget on the x (horizontal) axis. Must be greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#x Powerpack#x}
    */
    readonly x: number;
    /**
    * The position of the widget on the y (vertical) axis. Must be greater than or equal to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#y Powerpack#y}
    */
    readonly y: number;
}
export declare function powerpackWidgetWidgetLayoutToTerraform(struct?: PowerpackWidgetWidgetLayoutOutputReference | PowerpackWidgetWidgetLayout): any;
export declare function powerpackWidgetWidgetLayoutToHclTerraform(struct?: PowerpackWidgetWidgetLayoutOutputReference | PowerpackWidgetWidgetLayout): any;
export declare class PowerpackWidgetWidgetLayoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetWidgetLayout | undefined;
    set internalValue(value: PowerpackWidgetWidgetLayout | undefined);
    private _height?;
    get height(): number;
    set height(value: number);
    get heightInput(): number | undefined;
    private _isColumnBreak?;
    get isColumnBreak(): boolean | cdktn.IResolvable;
    set isColumnBreak(value: boolean | cdktn.IResolvable);
    resetIsColumnBreak(): void;
    get isColumnBreakInput(): boolean | cdktn.IResolvable | undefined;
    private _width?;
    get width(): number;
    set width(value: number);
    get widthInput(): number | undefined;
    private _x?;
    get x(): number;
    set x(value: number);
    get xInput(): number | undefined;
    private _y?;
    get y(): number;
    set y(value: number);
    get yInput(): number | undefined;
}
export interface PowerpackWidget {
    /**
    * alert_graph_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#alert_graph_definition Powerpack#alert_graph_definition}
    */
    readonly alertGraphDefinition?: PowerpackWidgetAlertGraphDefinition;
    /**
    * alert_value_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#alert_value_definition Powerpack#alert_value_definition}
    */
    readonly alertValueDefinition?: PowerpackWidgetAlertValueDefinition;
    /**
    * change_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#change_definition Powerpack#change_definition}
    */
    readonly changeDefinition?: PowerpackWidgetChangeDefinition;
    /**
    * check_status_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#check_status_definition Powerpack#check_status_definition}
    */
    readonly checkStatusDefinition?: PowerpackWidgetCheckStatusDefinition;
    /**
    * distribution_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#distribution_definition Powerpack#distribution_definition}
    */
    readonly distributionDefinition?: PowerpackWidgetDistributionDefinition;
    /**
    * event_stream_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#event_stream_definition Powerpack#event_stream_definition}
    */
    readonly eventStreamDefinition?: PowerpackWidgetEventStreamDefinition;
    /**
    * event_timeline_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#event_timeline_definition Powerpack#event_timeline_definition}
    */
    readonly eventTimelineDefinition?: PowerpackWidgetEventTimelineDefinition;
    /**
    * free_text_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#free_text_definition Powerpack#free_text_definition}
    */
    readonly freeTextDefinition?: PowerpackWidgetFreeTextDefinition;
    /**
    * geomap_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#geomap_definition Powerpack#geomap_definition}
    */
    readonly geomapDefinition?: PowerpackWidgetGeomapDefinition;
    /**
    * heatmap_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#heatmap_definition Powerpack#heatmap_definition}
    */
    readonly heatmapDefinition?: PowerpackWidgetHeatmapDefinition;
    /**
    * hostmap_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hostmap_definition Powerpack#hostmap_definition}
    */
    readonly hostmapDefinition?: PowerpackWidgetHostmapDefinition;
    /**
    * iframe_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#iframe_definition Powerpack#iframe_definition}
    */
    readonly iframeDefinition?: PowerpackWidgetIframeDefinition;
    /**
    * image_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#image_definition Powerpack#image_definition}
    */
    readonly imageDefinition?: PowerpackWidgetImageDefinition;
    /**
    * list_stream_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#list_stream_definition Powerpack#list_stream_definition}
    */
    readonly listStreamDefinition?: PowerpackWidgetListStreamDefinition;
    /**
    * log_stream_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#log_stream_definition Powerpack#log_stream_definition}
    */
    readonly logStreamDefinition?: PowerpackWidgetLogStreamDefinition;
    /**
    * manage_status_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#manage_status_definition Powerpack#manage_status_definition}
    */
    readonly manageStatusDefinition?: PowerpackWidgetManageStatusDefinition;
    /**
    * note_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#note_definition Powerpack#note_definition}
    */
    readonly noteDefinition?: PowerpackWidgetNoteDefinition;
    /**
    * query_table_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query_table_definition Powerpack#query_table_definition}
    */
    readonly queryTableDefinition?: PowerpackWidgetQueryTableDefinition;
    /**
    * query_value_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query_value_definition Powerpack#query_value_definition}
    */
    readonly queryValueDefinition?: PowerpackWidgetQueryValueDefinition;
    /**
    * run_workflow_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#run_workflow_definition Powerpack#run_workflow_definition}
    */
    readonly runWorkflowDefinition?: PowerpackWidgetRunWorkflowDefinition;
    /**
    * scatterplot_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#scatterplot_definition Powerpack#scatterplot_definition}
    */
    readonly scatterplotDefinition?: PowerpackWidgetScatterplotDefinition;
    /**
    * service_level_objective_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#service_level_objective_definition Powerpack#service_level_objective_definition}
    */
    readonly serviceLevelObjectiveDefinition?: PowerpackWidgetServiceLevelObjectiveDefinition;
    /**
    * servicemap_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#servicemap_definition Powerpack#servicemap_definition}
    */
    readonly servicemapDefinition?: PowerpackWidgetServicemapDefinition;
    /**
    * slo_list_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_list_definition Powerpack#slo_list_definition}
    */
    readonly sloListDefinition?: PowerpackWidgetSloListDefinition;
    /**
    * sunburst_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sunburst_definition Powerpack#sunburst_definition}
    */
    readonly sunburstDefinition?: PowerpackWidgetSunburstDefinition;
    /**
    * timeseries_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#timeseries_definition Powerpack#timeseries_definition}
    */
    readonly timeseriesDefinition?: PowerpackWidgetTimeseriesDefinition;
    /**
    * toplist_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#toplist_definition Powerpack#toplist_definition}
    */
    readonly toplistDefinition?: PowerpackWidgetToplistDefinition;
    /**
    * topology_map_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#topology_map_definition Powerpack#topology_map_definition}
    */
    readonly topologyMapDefinition?: PowerpackWidgetTopologyMapDefinition;
    /**
    * trace_service_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#trace_service_definition Powerpack#trace_service_definition}
    */
    readonly traceServiceDefinition?: PowerpackWidgetTraceServiceDefinition;
    /**
    * treemap_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#treemap_definition Powerpack#treemap_definition}
    */
    readonly treemapDefinition?: PowerpackWidgetTreemapDefinition;
    /**
    * widget_layout block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#widget_layout Powerpack#widget_layout}
    */
    readonly widgetLayout?: PowerpackWidgetWidgetLayout;
}
export declare function powerpackWidgetToTerraform(struct?: PowerpackWidget | cdktn.IResolvable): any;
export declare function powerpackWidgetToHclTerraform(struct?: PowerpackWidget | cdktn.IResolvable): any;
export declare class PowerpackWidgetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidget | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidget | cdktn.IResolvable | undefined);
    get id(): number;
    private _alertGraphDefinition;
    get alertGraphDefinition(): PowerpackWidgetAlertGraphDefinitionOutputReference;
    putAlertGraphDefinition(value: PowerpackWidgetAlertGraphDefinition): void;
    resetAlertGraphDefinition(): void;
    get alertGraphDefinitionInput(): PowerpackWidgetAlertGraphDefinition | undefined;
    private _alertValueDefinition;
    get alertValueDefinition(): PowerpackWidgetAlertValueDefinitionOutputReference;
    putAlertValueDefinition(value: PowerpackWidgetAlertValueDefinition): void;
    resetAlertValueDefinition(): void;
    get alertValueDefinitionInput(): PowerpackWidgetAlertValueDefinition | undefined;
    private _changeDefinition;
    get changeDefinition(): PowerpackWidgetChangeDefinitionOutputReference;
    putChangeDefinition(value: PowerpackWidgetChangeDefinition): void;
    resetChangeDefinition(): void;
    get changeDefinitionInput(): PowerpackWidgetChangeDefinition | undefined;
    private _checkStatusDefinition;
    get checkStatusDefinition(): PowerpackWidgetCheckStatusDefinitionOutputReference;
    putCheckStatusDefinition(value: PowerpackWidgetCheckStatusDefinition): void;
    resetCheckStatusDefinition(): void;
    get checkStatusDefinitionInput(): PowerpackWidgetCheckStatusDefinition | undefined;
    private _distributionDefinition;
    get distributionDefinition(): PowerpackWidgetDistributionDefinitionOutputReference;
    putDistributionDefinition(value: PowerpackWidgetDistributionDefinition): void;
    resetDistributionDefinition(): void;
    get distributionDefinitionInput(): PowerpackWidgetDistributionDefinition | undefined;
    private _eventStreamDefinition;
    get eventStreamDefinition(): PowerpackWidgetEventStreamDefinitionOutputReference;
    putEventStreamDefinition(value: PowerpackWidgetEventStreamDefinition): void;
    resetEventStreamDefinition(): void;
    get eventStreamDefinitionInput(): PowerpackWidgetEventStreamDefinition | undefined;
    private _eventTimelineDefinition;
    get eventTimelineDefinition(): PowerpackWidgetEventTimelineDefinitionOutputReference;
    putEventTimelineDefinition(value: PowerpackWidgetEventTimelineDefinition): void;
    resetEventTimelineDefinition(): void;
    get eventTimelineDefinitionInput(): PowerpackWidgetEventTimelineDefinition | undefined;
    private _freeTextDefinition;
    get freeTextDefinition(): PowerpackWidgetFreeTextDefinitionOutputReference;
    putFreeTextDefinition(value: PowerpackWidgetFreeTextDefinition): void;
    resetFreeTextDefinition(): void;
    get freeTextDefinitionInput(): PowerpackWidgetFreeTextDefinition | undefined;
    private _geomapDefinition;
    get geomapDefinition(): PowerpackWidgetGeomapDefinitionOutputReference;
    putGeomapDefinition(value: PowerpackWidgetGeomapDefinition): void;
    resetGeomapDefinition(): void;
    get geomapDefinitionInput(): PowerpackWidgetGeomapDefinition | undefined;
    private _heatmapDefinition;
    get heatmapDefinition(): PowerpackWidgetHeatmapDefinitionOutputReference;
    putHeatmapDefinition(value: PowerpackWidgetHeatmapDefinition): void;
    resetHeatmapDefinition(): void;
    get heatmapDefinitionInput(): PowerpackWidgetHeatmapDefinition | undefined;
    private _hostmapDefinition;
    get hostmapDefinition(): PowerpackWidgetHostmapDefinitionOutputReference;
    putHostmapDefinition(value: PowerpackWidgetHostmapDefinition): void;
    resetHostmapDefinition(): void;
    get hostmapDefinitionInput(): PowerpackWidgetHostmapDefinition | undefined;
    private _iframeDefinition;
    get iframeDefinition(): PowerpackWidgetIframeDefinitionOutputReference;
    putIframeDefinition(value: PowerpackWidgetIframeDefinition): void;
    resetIframeDefinition(): void;
    get iframeDefinitionInput(): PowerpackWidgetIframeDefinition | undefined;
    private _imageDefinition;
    get imageDefinition(): PowerpackWidgetImageDefinitionOutputReference;
    putImageDefinition(value: PowerpackWidgetImageDefinition): void;
    resetImageDefinition(): void;
    get imageDefinitionInput(): PowerpackWidgetImageDefinition | undefined;
    private _listStreamDefinition;
    get listStreamDefinition(): PowerpackWidgetListStreamDefinitionOutputReference;
    putListStreamDefinition(value: PowerpackWidgetListStreamDefinition): void;
    resetListStreamDefinition(): void;
    get listStreamDefinitionInput(): PowerpackWidgetListStreamDefinition | undefined;
    private _logStreamDefinition;
    get logStreamDefinition(): PowerpackWidgetLogStreamDefinitionOutputReference;
    putLogStreamDefinition(value: PowerpackWidgetLogStreamDefinition): void;
    resetLogStreamDefinition(): void;
    get logStreamDefinitionInput(): PowerpackWidgetLogStreamDefinition | undefined;
    private _manageStatusDefinition;
    get manageStatusDefinition(): PowerpackWidgetManageStatusDefinitionOutputReference;
    putManageStatusDefinition(value: PowerpackWidgetManageStatusDefinition): void;
    resetManageStatusDefinition(): void;
    get manageStatusDefinitionInput(): PowerpackWidgetManageStatusDefinition | undefined;
    private _noteDefinition;
    get noteDefinition(): PowerpackWidgetNoteDefinitionOutputReference;
    putNoteDefinition(value: PowerpackWidgetNoteDefinition): void;
    resetNoteDefinition(): void;
    get noteDefinitionInput(): PowerpackWidgetNoteDefinition | undefined;
    private _queryTableDefinition;
    get queryTableDefinition(): PowerpackWidgetQueryTableDefinitionOutputReference;
    putQueryTableDefinition(value: PowerpackWidgetQueryTableDefinition): void;
    resetQueryTableDefinition(): void;
    get queryTableDefinitionInput(): PowerpackWidgetQueryTableDefinition | undefined;
    private _queryValueDefinition;
    get queryValueDefinition(): PowerpackWidgetQueryValueDefinitionOutputReference;
    putQueryValueDefinition(value: PowerpackWidgetQueryValueDefinition): void;
    resetQueryValueDefinition(): void;
    get queryValueDefinitionInput(): PowerpackWidgetQueryValueDefinition | undefined;
    private _runWorkflowDefinition;
    get runWorkflowDefinition(): PowerpackWidgetRunWorkflowDefinitionOutputReference;
    putRunWorkflowDefinition(value: PowerpackWidgetRunWorkflowDefinition): void;
    resetRunWorkflowDefinition(): void;
    get runWorkflowDefinitionInput(): PowerpackWidgetRunWorkflowDefinition | undefined;
    private _scatterplotDefinition;
    get scatterplotDefinition(): PowerpackWidgetScatterplotDefinitionOutputReference;
    putScatterplotDefinition(value: PowerpackWidgetScatterplotDefinition): void;
    resetScatterplotDefinition(): void;
    get scatterplotDefinitionInput(): PowerpackWidgetScatterplotDefinition | undefined;
    private _serviceLevelObjectiveDefinition;
    get serviceLevelObjectiveDefinition(): PowerpackWidgetServiceLevelObjectiveDefinitionOutputReference;
    putServiceLevelObjectiveDefinition(value: PowerpackWidgetServiceLevelObjectiveDefinition): void;
    resetServiceLevelObjectiveDefinition(): void;
    get serviceLevelObjectiveDefinitionInput(): PowerpackWidgetServiceLevelObjectiveDefinition | undefined;
    private _servicemapDefinition;
    get servicemapDefinition(): PowerpackWidgetServicemapDefinitionOutputReference;
    putServicemapDefinition(value: PowerpackWidgetServicemapDefinition): void;
    resetServicemapDefinition(): void;
    get servicemapDefinitionInput(): PowerpackWidgetServicemapDefinition | undefined;
    private _sloListDefinition;
    get sloListDefinition(): PowerpackWidgetSloListDefinitionOutputReference;
    putSloListDefinition(value: PowerpackWidgetSloListDefinition): void;
    resetSloListDefinition(): void;
    get sloListDefinitionInput(): PowerpackWidgetSloListDefinition | undefined;
    private _sunburstDefinition;
    get sunburstDefinition(): PowerpackWidgetSunburstDefinitionOutputReference;
    putSunburstDefinition(value: PowerpackWidgetSunburstDefinition): void;
    resetSunburstDefinition(): void;
    get sunburstDefinitionInput(): PowerpackWidgetSunburstDefinition | undefined;
    private _timeseriesDefinition;
    get timeseriesDefinition(): PowerpackWidgetTimeseriesDefinitionOutputReference;
    putTimeseriesDefinition(value: PowerpackWidgetTimeseriesDefinition): void;
    resetTimeseriesDefinition(): void;
    get timeseriesDefinitionInput(): PowerpackWidgetTimeseriesDefinition | undefined;
    private _toplistDefinition;
    get toplistDefinition(): PowerpackWidgetToplistDefinitionOutputReference;
    putToplistDefinition(value: PowerpackWidgetToplistDefinition): void;
    resetToplistDefinition(): void;
    get toplistDefinitionInput(): PowerpackWidgetToplistDefinition | undefined;
    private _topologyMapDefinition;
    get topologyMapDefinition(): PowerpackWidgetTopologyMapDefinitionOutputReference;
    putTopologyMapDefinition(value: PowerpackWidgetTopologyMapDefinition): void;
    resetTopologyMapDefinition(): void;
    get topologyMapDefinitionInput(): PowerpackWidgetTopologyMapDefinition | undefined;
    private _traceServiceDefinition;
    get traceServiceDefinition(): PowerpackWidgetTraceServiceDefinitionOutputReference;
    putTraceServiceDefinition(value: PowerpackWidgetTraceServiceDefinition): void;
    resetTraceServiceDefinition(): void;
    get traceServiceDefinitionInput(): PowerpackWidgetTraceServiceDefinition | undefined;
    private _treemapDefinition;
    get treemapDefinition(): PowerpackWidgetTreemapDefinitionOutputReference;
    putTreemapDefinition(value: PowerpackWidgetTreemapDefinition): void;
    resetTreemapDefinition(): void;
    get treemapDefinitionInput(): PowerpackWidgetTreemapDefinition | undefined;
    private _widgetLayout;
    get widgetLayout(): PowerpackWidgetWidgetLayoutOutputReference;
    putWidgetLayout(value: PowerpackWidgetWidgetLayout): void;
    resetWidgetLayout(): void;
    get widgetLayoutInput(): PowerpackWidgetWidgetLayout | undefined;
}
export declare class PowerpackWidgetList extends cdktn.ComplexList {
    internalValue?: PowerpackWidget[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetOutputReference;
}
