/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
import { PowerpackWidgetHeatmapDefinitionRequestApmQueryComputeQuery, PowerpackWidgetHeatmapDefinitionRequestApmQueryComputeQueryOutputReference, PowerpackWidgetHeatmapDefinitionCustomLink, PowerpackWidgetHeatmapDefinitionCustomLinkList, PowerpackWidgetHeatmapDefinitionEvent, PowerpackWidgetHeatmapDefinitionEventList } from './structs0';
export interface PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetHeatmapDefinitionRequestApmQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupBySortQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupBySortQuery): any;
export declare function powerpackWidgetHeatmapDefinitionRequestApmQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupBySortQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupBySortQuery): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupBySortQuery;
}
export declare function powerpackWidgetHeatmapDefinitionRequestApmQueryGroupByToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetHeatmapDefinitionRequestApmQueryGroupByToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupByOutputReference;
}
export interface PowerpackWidgetHeatmapDefinitionRequestApmQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHeatmapDefinitionRequestApmQueryMultiComputeToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetHeatmapDefinitionRequestApmQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestApmQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetHeatmapDefinitionRequestApmQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHeatmapDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHeatmapDefinitionRequestApmQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetHeatmapDefinitionRequestApmQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetHeatmapDefinitionRequestApmQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetHeatmapDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetHeatmapDefinitionRequestApmQueryToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestApmQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestApmQuery): any;
export declare function powerpackWidgetHeatmapDefinitionRequestApmQueryToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestApmQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestApmQuery): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestApmQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestApmQuery | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestApmQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetHeatmapDefinitionRequestApmQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetHeatmapDefinitionRequestApmQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetHeatmapDefinitionRequestApmQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupByList;
    putGroupBy(value: PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetHeatmapDefinitionRequestApmQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetHeatmapDefinitionRequestApmQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetHeatmapDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetHeatmapDefinitionRequestApmQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestFormulaConditionalFormats {
    /**
    * The comparator to use. Valid values are `=`, `>`, `>=`, `<`, `<=`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#comparator Powerpack#comparator}
    */
    readonly comparator: string;
    /**
    * The color palette to apply to the background, same values available as palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_bg_color Powerpack#custom_bg_color}
    */
    readonly customBgColor?: string;
    /**
    * The color palette to apply to the foreground, same values available as palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_fg_color Powerpack#custom_fg_color}
    */
    readonly customFgColor?: string;
    /**
    * Setting this to True hides values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_value Powerpack#hide_value}
    */
    readonly hideValue?: boolean | cdktn.IResolvable;
    /**
    * Displays an image as the background.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#image_url Powerpack#image_url}
    */
    readonly imageUrl?: string;
    /**
    * The metric from the request to correlate with this conditional format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
    /**
    * The color palette to apply. Valid values are `blue`, `custom_bg`, `custom_image`, `custom_text`, `gray_on_white`, `grey`, `green`, `orange`, `red`, `red_on_white`, `white_on_gray`, `white_on_green`, `green_on_white`, `white_on_red`, `white_on_yellow`, `yellow_on_white`, `black_on_light_yellow`, `black_on_light_green`, `black_on_light_red`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette Powerpack#palette}
    */
    readonly palette: string;
    /**
    * Defines the displayed timeframe.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#timeframe Powerpack#timeframe}
    */
    readonly timeframe?: string;
    /**
    * A value for the comparator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#value Powerpack#value}
    */
    readonly value: number;
}
export declare function powerpackWidgetHeatmapDefinitionRequestFormulaConditionalFormatsToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable): any;
export declare function powerpackWidgetHeatmapDefinitionRequestFormulaConditionalFormatsToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestFormulaConditionalFormatsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable | undefined);
    private _comparator?;
    get comparator(): string;
    set comparator(value: string);
    get comparatorInput(): string | undefined;
    private _customBgColor?;
    get customBgColor(): string;
    set customBgColor(value: string);
    resetCustomBgColor(): void;
    get customBgColorInput(): string | undefined;
    private _customFgColor?;
    get customFgColor(): string;
    set customFgColor(value: string);
    resetCustomFgColor(): void;
    get customFgColorInput(): string | undefined;
    private _hideValue?;
    get hideValue(): boolean | cdktn.IResolvable;
    set hideValue(value: boolean | cdktn.IResolvable);
    resetHideValue(): void;
    get hideValueInput(): boolean | cdktn.IResolvable | undefined;
    private _imageUrl?;
    get imageUrl(): string;
    set imageUrl(value: string);
    resetImageUrl(): void;
    get imageUrlInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _palette?;
    get palette(): string;
    set palette(value: string);
    get paletteInput(): string | undefined;
    private _timeframe?;
    get timeframe(): string;
    set timeframe(value: string);
    resetTimeframe(): void;
    get timeframeInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class PowerpackWidgetHeatmapDefinitionRequestFormulaConditionalFormatsList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHeatmapDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHeatmapDefinitionRequestFormulaConditionalFormatsOutputReference;
}
export interface PowerpackWidgetHeatmapDefinitionRequestFormulaLimit {
    /**
    * The number of results to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#count Powerpack#count}
    */
    readonly count?: number;
    /**
    * The direction of the sort. Valid values are `asc`, `desc`. Defaults to `"desc"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order?: string;
}
export declare function powerpackWidgetHeatmapDefinitionRequestFormulaLimitToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestFormulaLimitOutputReference | PowerpackWidgetHeatmapDefinitionRequestFormulaLimit): any;
export declare function powerpackWidgetHeatmapDefinitionRequestFormulaLimitToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestFormulaLimitOutputReference | PowerpackWidgetHeatmapDefinitionRequestFormulaLimit): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestFormulaLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestFormulaLimit | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestFormulaLimit | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    resetCount(): void;
    get countInput(): number | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCanonical {
    /**
    * per unit name. If you want to represent megabytes/s, you set 'unit_name' = 'megabyte' and 'per_unit_name = 'second'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#per_unit_name Powerpack#per_unit_name}
    */
    readonly perUnitName?: string;
    /**
    * Unit name. It should be in singular form ('megabyte' and not 'megabytes')
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit_name Powerpack#unit_name}
    */
    readonly unitName: string;
}
export declare function powerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCanonicalToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference | PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCanonical): any;
export declare function powerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCanonicalToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference | PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCanonical): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCanonical | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCanonical | undefined);
    private _perUnitName?;
    get perUnitName(): string;
    set perUnitName(value: string);
    resetPerUnitName(): void;
    get perUnitNameInput(): string | undefined;
    private _unitName?;
    get unitName(): string;
    set unitName(value: string);
    get unitNameInput(): string | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCustom {
    /**
    * Unit label
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label: string;
}
export declare function powerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCustomToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCustomOutputReference | PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCustom): any;
export declare function powerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCustomToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCustomOutputReference | PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCustom): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCustom | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCustom | undefined);
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnit {
    /**
    * canonical block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#canonical Powerpack#canonical}
    */
    readonly canonical?: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCanonical;
    /**
    * custom block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom Powerpack#custom}
    */
    readonly custom?: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCustom;
}
export declare function powerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitOutputReference | PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnit): any;
export declare function powerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitOutputReference | PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnit): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnit | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnit | undefined);
    private _canonical;
    get canonical(): PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference;
    putCanonical(value: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCanonical): void;
    resetCanonical(): void;
    get canonicalInput(): PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCanonical | undefined;
    private _custom;
    get custom(): PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCustomOutputReference;
    putCustom(value: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCustom): void;
    resetCustom(): void;
    get customInput(): PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitCustom | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitScale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit_name Powerpack#unit_name}
    */
    readonly unitName: string;
}
export declare function powerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitScaleToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitScaleOutputReference | PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitScale): any;
export declare function powerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitScaleToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitScaleOutputReference | PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitScale): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitScaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitScale | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitScale | undefined);
    private _unitName?;
    get unitName(): string;
    set unitName(value: string);
    get unitNameInput(): string | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormat {
    /**
    * unit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit Powerpack#unit}
    */
    readonly unit: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnit;
    /**
    * unit_scale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit_scale Powerpack#unit_scale}
    */
    readonly unitScale?: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitScale;
}
export declare function powerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatOutputReference | PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormat): any;
export declare function powerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatOutputReference | PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormat): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormat | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormat | undefined);
    private _unit;
    get unit(): PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitOutputReference;
    putUnit(value: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnit): void;
    get unitInput(): PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnit | undefined;
    private _unitScale;
    get unitScale(): PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitScaleOutputReference;
    putUnitScale(value: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitScale): void;
    resetUnitScale(): void;
    get unitScaleInput(): PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatUnitScale | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestFormulaStyle {
    /**
    * The color palette used to display the formula. A guide to the available color palettes can be found at https://docs.datadoghq.com/dashboards/guide/widget_colors.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette Powerpack#palette}
    */
    readonly palette?: string;
    /**
    * Index specifying which color to use within the palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette_index Powerpack#palette_index}
    */
    readonly paletteIndex?: number;
}
export declare function powerpackWidgetHeatmapDefinitionRequestFormulaStyleToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestFormulaStyleOutputReference | PowerpackWidgetHeatmapDefinitionRequestFormulaStyle): any;
export declare function powerpackWidgetHeatmapDefinitionRequestFormulaStyleToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestFormulaStyleOutputReference | PowerpackWidgetHeatmapDefinitionRequestFormulaStyle): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestFormulaStyleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestFormulaStyle | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestFormulaStyle | undefined);
    private _palette?;
    get palette(): string;
    set palette(value: string);
    resetPalette(): void;
    get paletteInput(): string | undefined;
    private _paletteIndex?;
    get paletteIndex(): number;
    set paletteIndex(value: number);
    resetPaletteIndex(): void;
    get paletteIndexInput(): number | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestFormula {
    /**
    * An expression alias.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#alias Powerpack#alias}
    */
    readonly alias?: string;
    /**
    * A list of display modes for each table cell. Valid values are `number`, `bar`, `trend`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cell_display_mode Powerpack#cell_display_mode}
    */
    readonly cellDisplayMode?: string;
    /**
    * A string expression built from queries, formulas, and functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#formula_expression Powerpack#formula_expression}
    */
    readonly formulaExpression: string;
    /**
    * conditional_formats block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#conditional_formats Powerpack#conditional_formats}
    */
    readonly conditionalFormats?: PowerpackWidgetHeatmapDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable;
    /**
    * limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: PowerpackWidgetHeatmapDefinitionRequestFormulaLimit;
    /**
    * number_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#number_format Powerpack#number_format}
    */
    readonly numberFormat?: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormat;
    /**
    * style block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#style Powerpack#style}
    */
    readonly style?: PowerpackWidgetHeatmapDefinitionRequestFormulaStyle;
}
export declare function powerpackWidgetHeatmapDefinitionRequestFormulaToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestFormula | cdktn.IResolvable): any;
export declare function powerpackWidgetHeatmapDefinitionRequestFormulaToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestFormula | cdktn.IResolvable): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestFormulaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestFormula | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestFormula | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _cellDisplayMode?;
    get cellDisplayMode(): string;
    set cellDisplayMode(value: string);
    resetCellDisplayMode(): void;
    get cellDisplayModeInput(): string | undefined;
    private _formulaExpression?;
    get formulaExpression(): string;
    set formulaExpression(value: string);
    get formulaExpressionInput(): string | undefined;
    private _conditionalFormats;
    get conditionalFormats(): PowerpackWidgetHeatmapDefinitionRequestFormulaConditionalFormatsList;
    putConditionalFormats(value: PowerpackWidgetHeatmapDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable): void;
    resetConditionalFormats(): void;
    get conditionalFormatsInput(): cdktn.IResolvable | PowerpackWidgetHeatmapDefinitionRequestFormulaConditionalFormats[] | undefined;
    private _limit;
    get limit(): PowerpackWidgetHeatmapDefinitionRequestFormulaLimitOutputReference;
    putLimit(value: PowerpackWidgetHeatmapDefinitionRequestFormulaLimit): void;
    resetLimit(): void;
    get limitInput(): PowerpackWidgetHeatmapDefinitionRequestFormulaLimit | undefined;
    private _numberFormat;
    get numberFormat(): PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormatOutputReference;
    putNumberFormat(value: PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormat): void;
    resetNumberFormat(): void;
    get numberFormatInput(): PowerpackWidgetHeatmapDefinitionRequestFormulaNumberFormat | undefined;
    private _style;
    get style(): PowerpackWidgetHeatmapDefinitionRequestFormulaStyleOutputReference;
    putStyle(value: PowerpackWidgetHeatmapDefinitionRequestFormulaStyle): void;
    resetStyle(): void;
    get styleInput(): PowerpackWidgetHeatmapDefinitionRequestFormulaStyle | undefined;
}
export declare class PowerpackWidgetHeatmapDefinitionRequestFormulaList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHeatmapDefinitionRequestFormula[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHeatmapDefinitionRequestFormulaOutputReference;
}
export interface PowerpackWidgetHeatmapDefinitionRequestLogQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHeatmapDefinitionRequestLogQueryComputeQueryToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestLogQueryComputeQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestLogQueryComputeQuery): any;
export declare function powerpackWidgetHeatmapDefinitionRequestLogQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestLogQueryComputeQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestLogQueryComputeQuery): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestLogQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestLogQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestLogQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetHeatmapDefinitionRequestLogQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupBySortQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupBySortQuery): any;
export declare function powerpackWidgetHeatmapDefinitionRequestLogQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupBySortQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupBySortQuery): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupBySortQuery;
}
export declare function powerpackWidgetHeatmapDefinitionRequestLogQueryGroupByToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetHeatmapDefinitionRequestLogQueryGroupByToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupByOutputReference;
}
export interface PowerpackWidgetHeatmapDefinitionRequestLogQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHeatmapDefinitionRequestLogQueryMultiComputeToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetHeatmapDefinitionRequestLogQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestLogQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestLogQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetHeatmapDefinitionRequestLogQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHeatmapDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHeatmapDefinitionRequestLogQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetHeatmapDefinitionRequestLogQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetHeatmapDefinitionRequestLogQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetHeatmapDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetHeatmapDefinitionRequestLogQueryToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestLogQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestLogQuery): any;
export declare function powerpackWidgetHeatmapDefinitionRequestLogQueryToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestLogQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestLogQuery): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestLogQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestLogQuery | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestLogQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetHeatmapDefinitionRequestLogQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetHeatmapDefinitionRequestLogQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetHeatmapDefinitionRequestLogQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupByList;
    putGroupBy(value: PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetHeatmapDefinitionRequestLogQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetHeatmapDefinitionRequestLogQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetHeatmapDefinitionRequestLogQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetHeatmapDefinitionRequestLogQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestProcessQuery {
    /**
    * A list of processes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#filter_by Powerpack#filter_by}
    */
    readonly filterBy?: string[];
    /**
    * The max number of items in the filter list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * Your chosen metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric: string;
    /**
    * Your chosen search term.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_by Powerpack#search_by}
    */
    readonly searchBy?: string;
}
export declare function powerpackWidgetHeatmapDefinitionRequestProcessQueryToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestProcessQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestProcessQuery): any;
export declare function powerpackWidgetHeatmapDefinitionRequestProcessQueryToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestProcessQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestProcessQuery): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestProcessQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestProcessQuery | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestProcessQuery | undefined);
    private _filterBy?;
    get filterBy(): string[];
    set filterBy(value: string[]);
    resetFilterBy(): void;
    get filterByInput(): string[] | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _searchBy?;
    get searchBy(): string;
    set searchBy(value: string);
    resetSearchBy(): void;
    get searchByInput(): string | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestQueryApmDependencyStatsQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for APM Dependency Stats queries. Valid values are `apm_dependency_stats`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * APM environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#env Powerpack#env}
    */
    readonly env: string;
    /**
    * Determines whether stats for upstream or downstream dependencies should be queried.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_upstream Powerpack#is_upstream}
    */
    readonly isUpstream?: boolean | cdktn.IResolvable;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Name of operation on service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#operation_name Powerpack#operation_name}
    */
    readonly operationName: string;
    /**
    * The name of the second primary tag used within APM; required when `primary_tag_value` is specified. See https://docs.datadoghq.com/tracing/guide/setting_primary_tags_to_scope/#add-a-second-primary-tag-in-datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_name Powerpack#primary_tag_name}
    */
    readonly primaryTagName?: string;
    /**
    * Filter APM data by the second primary tag. `primary_tag_name` must also be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_value Powerpack#primary_tag_value}
    */
    readonly primaryTagValue?: string;
    /**
    * APM resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#resource_name Powerpack#resource_name}
    */
    readonly resourceName: string;
    /**
    * APM service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#service Powerpack#service}
    */
    readonly service: string;
    /**
    * APM statistic. Valid values are `avg_duration`, `avg_root_duration`, `avg_spans_per_trace`, `error_rate`, `pct_exec_time`, `pct_of_traces`, `total_traces_count`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#stat Powerpack#stat}
    */
    readonly stat: string;
}
export declare function powerpackWidgetHeatmapDefinitionRequestQueryApmDependencyStatsQueryToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQueryApmDependencyStatsQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestQueryApmDependencyStatsQuery): any;
export declare function powerpackWidgetHeatmapDefinitionRequestQueryApmDependencyStatsQueryToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQueryApmDependencyStatsQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestQueryApmDependencyStatsQuery): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestQueryApmDependencyStatsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestQueryApmDependencyStatsQuery | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestQueryApmDependencyStatsQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    private _isUpstream?;
    get isUpstream(): boolean | cdktn.IResolvable;
    set isUpstream(value: boolean | cdktn.IResolvable);
    resetIsUpstream(): void;
    get isUpstreamInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    get operationNameInput(): string | undefined;
    private _primaryTagName?;
    get primaryTagName(): string;
    set primaryTagName(value: string);
    resetPrimaryTagName(): void;
    get primaryTagNameInput(): string | undefined;
    private _primaryTagValue?;
    get primaryTagValue(): string;
    set primaryTagValue(value: string);
    resetPrimaryTagValue(): void;
    get primaryTagValueInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    get resourceNameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    get statInput(): string | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestQueryApmResourceStatsQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for APM Resource Stats queries. Valid values are `apm_resource_stats`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * APM environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#env Powerpack#env}
    */
    readonly env: string;
    /**
    * Array of fields to group results by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: string[];
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Name of operation on service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#operation_name Powerpack#operation_name}
    */
    readonly operationName?: string;
    /**
    * The name of the second primary tag used within APM; required when `primary_tag_value` is specified. See https://docs.datadoghq.com/tracing/guide/setting_primary_tags_to_scope/#add-a-second-primary-tag-in-datadog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_name Powerpack#primary_tag_name}
    */
    readonly primaryTagName?: string;
    /**
    * Filter APM data by the second primary tag. `primary_tag_name` must also be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag_value Powerpack#primary_tag_value}
    */
    readonly primaryTagValue?: string;
    /**
    * APM resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#resource_name Powerpack#resource_name}
    */
    readonly resourceName?: string;
    /**
    * APM service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#service Powerpack#service}
    */
    readonly service: string;
    /**
    * APM statistic. Valid values are `errors`, `error_rate`, `hits`, `latency_avg`, `latency_distribution`, `latency_max`, `latency_p50`, `latency_p75`, `latency_p90`, `latency_p95`, `latency_p99`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#stat Powerpack#stat}
    */
    readonly stat: string;
}
export declare function powerpackWidgetHeatmapDefinitionRequestQueryApmResourceStatsQueryToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQueryApmResourceStatsQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestQueryApmResourceStatsQuery): any;
export declare function powerpackWidgetHeatmapDefinitionRequestQueryApmResourceStatsQueryToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQueryApmResourceStatsQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestQueryApmResourceStatsQuery): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestQueryApmResourceStatsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestQueryApmResourceStatsQuery | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestQueryApmResourceStatsQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    private _groupBy?;
    get groupBy(): string[];
    set groupBy(value: string[]);
    resetGroupBy(): void;
    get groupByInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationName?;
    get operationName(): string;
    set operationName(value: string);
    resetOperationName(): void;
    get operationNameInput(): string | undefined;
    private _primaryTagName?;
    get primaryTagName(): string;
    set primaryTagName(value: string);
    resetPrimaryTagName(): void;
    get primaryTagNameInput(): string | undefined;
    private _primaryTagValue?;
    get primaryTagValue(): string;
    set primaryTagValue(value: string);
    resetPrimaryTagValue(): void;
    get primaryTagValueInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    resetResourceName(): void;
    get resourceNameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    get statInput(): string | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestQueryCloudCostQuery {
    /**
    * The aggregation methods available for cloud cost queries. Valid values are `avg`, `last`, `max`, `min`, `sum`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for cloud cost queries. Valid values are `cloud_cost`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The cloud cost query definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
}
export declare function powerpackWidgetHeatmapDefinitionRequestQueryCloudCostQueryToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQueryCloudCostQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestQueryCloudCostQuery): any;
export declare function powerpackWidgetHeatmapDefinitionRequestQueryCloudCostQueryToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQueryCloudCostQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestQueryCloudCostQuery): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestQueryCloudCostQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestQueryCloudCostQuery | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestQueryCloudCostQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryCompute {
    /**
    * The aggregation methods for event platform queries. Valid values are `count`, `cardinality`, `median`, `pc75`, `pc90`, `pc95`, `pc98`, `pc99`, `sum`, `min`, `max`, `avg`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * A time interval in milliseconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
    /**
    * The measurable attribute to compute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
}
export declare function powerpackWidgetHeatmapDefinitionRequestQueryEventQueryComputeToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetHeatmapDefinitionRequestQueryEventQueryComputeToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
}
export declare class PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryComputeOutputReference;
}
export interface PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBySort {
    /**
    * The aggregation methods for the event platform queries. Valid values are `count`, `cardinality`, `median`, `pc75`, `pc90`, `pc95`, `pc98`, `pc99`, `sum`, `min`, `max`, `avg`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The metric used for sorting group by results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
    /**
    * Direction of sort. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order?: string;
}
export declare function powerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBySortToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBySortOutputReference | PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBySort): any;
export declare function powerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBySortToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBySortOutputReference | PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBySort): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBySortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBySort | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBySort | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBy {
    /**
    * The event facet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet: string;
    /**
    * The number of groups to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort Powerpack#sort}
    */
    readonly sort?: PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBySort;
}
export declare function powerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupByToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupByToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sort;
    get sort(): PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBySortOutputReference;
    putSort(value: PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBySort): void;
    resetSort(): void;
    get sortInput(): PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBySort | undefined;
}
export declare class PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupByOutputReference;
}
export interface PowerpackWidgetHeatmapDefinitionRequestQueryEventQuerySearch {
    /**
    * The events search string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
}
export declare function powerpackWidgetHeatmapDefinitionRequestQueryEventQuerySearchToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQueryEventQuerySearchOutputReference | PowerpackWidgetHeatmapDefinitionRequestQueryEventQuerySearch): any;
export declare function powerpackWidgetHeatmapDefinitionRequestQueryEventQuerySearchToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQueryEventQuerySearchOutputReference | PowerpackWidgetHeatmapDefinitionRequestQueryEventQuerySearch): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestQueryEventQuerySearchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestQueryEventQuerySearch | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestQueryEventQuerySearch | undefined);
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestQueryEventQuery {
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for event platform-based queries. Valid values are `logs`, `spans`, `network`, `rum`, `security_signals`, `profiles`, `audit`, `events`, `ci_tests`, `ci_pipelines`, `incident_analytics`, `product_analytics`, `on_call_events`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * An array of index names to query in the stream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#indexes Powerpack#indexes}
    */
    readonly indexes?: string[];
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Storage location (private beta).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#storage Powerpack#storage}
    */
    readonly storage?: string;
    /**
    * compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute Powerpack#compute}
    */
    readonly compute: PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable;
    /**
    * search block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search Powerpack#search}
    */
    readonly search?: PowerpackWidgetHeatmapDefinitionRequestQueryEventQuerySearch;
}
export declare function powerpackWidgetHeatmapDefinitionRequestQueryEventQueryToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestQueryEventQuery): any;
export declare function powerpackWidgetHeatmapDefinitionRequestQueryEventQueryToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestQueryEventQuery): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestQueryEventQuery | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestQueryEventQuery | undefined);
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _indexes?;
    get indexes(): string[];
    set indexes(value: string[]);
    resetIndexes(): void;
    get indexesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _storage?;
    get storage(): string;
    set storage(value: string);
    resetStorage(): void;
    get storageInput(): string | undefined;
    private _compute;
    get compute(): PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryComputeList;
    putCompute(value: PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryCompute[] | cdktn.IResolvable): void;
    get computeInput(): cdktn.IResolvable | PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryCompute[] | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupByList;
    putGroupBy(value: PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryGroupBy[] | undefined;
    private _search;
    get search(): PowerpackWidgetHeatmapDefinitionRequestQueryEventQuerySearchOutputReference;
    putSearch(value: PowerpackWidgetHeatmapDefinitionRequestQueryEventQuerySearch): void;
    resetSearch(): void;
    get searchInput(): PowerpackWidgetHeatmapDefinitionRequestQueryEventQuerySearch | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestQueryMetricQuery {
    /**
    * The aggregation methods available for metrics queries. Valid values are `avg`, `min`, `max`, `sum`, `last`, `area`, `l2norm`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for metrics queries. Defaults to `"metrics"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource?: string;
    /**
    * The name of the query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The metrics query definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
    /**
    * Semantic mode for metrics queries. This determines how metrics from different sources are combined or displayed. Valid values are `combined`, `native`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#semantic_mode Powerpack#semantic_mode}
    */
    readonly semanticMode?: string;
}
export declare function powerpackWidgetHeatmapDefinitionRequestQueryMetricQueryToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQueryMetricQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestQueryMetricQuery): any;
export declare function powerpackWidgetHeatmapDefinitionRequestQueryMetricQueryToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQueryMetricQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestQueryMetricQuery): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestQueryMetricQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestQueryMetricQuery | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestQueryMetricQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    resetDataSource(): void;
    get dataSourceInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _semanticMode?;
    get semanticMode(): string;
    set semanticMode(value: string);
    resetSemanticMode(): void;
    get semanticModeInput(): string | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestQueryProcessQuery {
    /**
    * The aggregation methods available for metrics queries. Valid values are `avg`, `min`, `max`, `sum`, `last`, `area`, `l2norm`, `percentile`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregator Powerpack#aggregator}
    */
    readonly aggregator?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for process queries. Valid values are `process`, `container`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * Whether to normalize the CPU percentages.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_normalized_cpu Powerpack#is_normalized_cpu}
    */
    readonly isNormalizedCpu?: boolean | cdktn.IResolvable;
    /**
    * The number of hits to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * The process metric name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric: string;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The direction of the sort. Valid values are `asc`, `desc`. Defaults to `"desc"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort Powerpack#sort}
    */
    readonly sort?: string;
    /**
    * An array of tags to filter by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#tag_filters Powerpack#tag_filters}
    */
    readonly tagFilters?: string[];
    /**
    * The text to use as a filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#text_filter Powerpack#text_filter}
    */
    readonly textFilter?: string;
}
export declare function powerpackWidgetHeatmapDefinitionRequestQueryProcessQueryToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQueryProcessQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestQueryProcessQuery): any;
export declare function powerpackWidgetHeatmapDefinitionRequestQueryProcessQueryToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQueryProcessQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestQueryProcessQuery): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestQueryProcessQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestQueryProcessQuery | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestQueryProcessQuery | undefined);
    private _aggregator?;
    get aggregator(): string;
    set aggregator(value: string);
    resetAggregator(): void;
    get aggregatorInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _isNormalizedCpu?;
    get isNormalizedCpu(): boolean | cdktn.IResolvable;
    set isNormalizedCpu(value: boolean | cdktn.IResolvable);
    resetIsNormalizedCpu(): void;
    get isNormalizedCpuInput(): boolean | cdktn.IResolvable | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _sort?;
    get sort(): string;
    set sort(value: string);
    resetSort(): void;
    get sortInput(): string | undefined;
    private _tagFilters?;
    get tagFilters(): string[];
    set tagFilters(value: string[]);
    resetTagFilters(): void;
    get tagFiltersInput(): string[] | undefined;
    private _textFilter?;
    get textFilter(): string;
    set textFilter(value: string);
    resetTextFilter(): void;
    get textFilterInput(): string | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestQuerySloQuery {
    /**
    * Additional filters applied to the SLO query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#additional_query_filters Powerpack#additional_query_filters}
    */
    readonly additionalQueryFilters?: string;
    /**
    * The source organization UUID for cross organization queries. Feature in Private Beta.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cross_org_uuids Powerpack#cross_org_uuids}
    */
    readonly crossOrgUuids?: string[];
    /**
    * The data source for SLO queries. Valid values are `slo`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * Group mode to query measures. Valid values are `overall`, `components`. Defaults to `"overall"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_mode Powerpack#group_mode}
    */
    readonly groupMode?: string;
    /**
    * SLO measures queries. Valid values are `good_events`, `bad_events`, `good_minutes`, `bad_minutes`, `slo_status`, `error_budget_remaining`, `burn_rate`, `error_budget_burndown`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#measure Powerpack#measure}
    */
    readonly measure: string;
    /**
    * The name of query for use in formulas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name?: string;
    /**
    * ID of an SLO to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_id Powerpack#slo_id}
    */
    readonly sloId: string;
    /**
    * type of the SLO to query. Valid values are `metric`, `monitor`, `time_slice`. Defaults to `"metric"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_query_type Powerpack#slo_query_type}
    */
    readonly sloQueryType?: string;
}
export declare function powerpackWidgetHeatmapDefinitionRequestQuerySloQueryToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQuerySloQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestQuerySloQuery): any;
export declare function powerpackWidgetHeatmapDefinitionRequestQuerySloQueryToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQuerySloQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestQuerySloQuery): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestQuerySloQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestQuerySloQuery | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestQuerySloQuery | undefined);
    private _additionalQueryFilters?;
    get additionalQueryFilters(): string;
    set additionalQueryFilters(value: string);
    resetAdditionalQueryFilters(): void;
    get additionalQueryFiltersInput(): string | undefined;
    private _crossOrgUuids?;
    get crossOrgUuids(): string[];
    set crossOrgUuids(value: string[]);
    resetCrossOrgUuids(): void;
    get crossOrgUuidsInput(): string[] | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _groupMode?;
    get groupMode(): string;
    set groupMode(value: string);
    resetGroupMode(): void;
    get groupModeInput(): string | undefined;
    private _measure?;
    get measure(): string;
    set measure(value: string);
    get measureInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _sloId?;
    get sloId(): string;
    set sloId(value: string);
    get sloIdInput(): string | undefined;
    private _sloQueryType?;
    get sloQueryType(): string;
    set sloQueryType(value: string);
    resetSloQueryType(): void;
    get sloQueryTypeInput(): string | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestQuery {
    /**
    * apm_dependency_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_dependency_stats_query Powerpack#apm_dependency_stats_query}
    */
    readonly apmDependencyStatsQuery?: PowerpackWidgetHeatmapDefinitionRequestQueryApmDependencyStatsQuery;
    /**
    * apm_resource_stats_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_resource_stats_query Powerpack#apm_resource_stats_query}
    */
    readonly apmResourceStatsQuery?: PowerpackWidgetHeatmapDefinitionRequestQueryApmResourceStatsQuery;
    /**
    * cloud_cost_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cloud_cost_query Powerpack#cloud_cost_query}
    */
    readonly cloudCostQuery?: PowerpackWidgetHeatmapDefinitionRequestQueryCloudCostQuery;
    /**
    * event_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#event_query Powerpack#event_query}
    */
    readonly eventQuery?: PowerpackWidgetHeatmapDefinitionRequestQueryEventQuery;
    /**
    * metric_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric_query Powerpack#metric_query}
    */
    readonly metricQuery?: PowerpackWidgetHeatmapDefinitionRequestQueryMetricQuery;
    /**
    * process_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#process_query Powerpack#process_query}
    */
    readonly processQuery?: PowerpackWidgetHeatmapDefinitionRequestQueryProcessQuery;
    /**
    * slo_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#slo_query Powerpack#slo_query}
    */
    readonly sloQuery?: PowerpackWidgetHeatmapDefinitionRequestQuerySloQuery;
}
export declare function powerpackWidgetHeatmapDefinitionRequestQueryToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQuery | cdktn.IResolvable): any;
export declare function powerpackWidgetHeatmapDefinitionRequestQueryToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestQuery | cdktn.IResolvable): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestQuery | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestQuery | cdktn.IResolvable | undefined);
    private _apmDependencyStatsQuery;
    get apmDependencyStatsQuery(): PowerpackWidgetHeatmapDefinitionRequestQueryApmDependencyStatsQueryOutputReference;
    putApmDependencyStatsQuery(value: PowerpackWidgetHeatmapDefinitionRequestQueryApmDependencyStatsQuery): void;
    resetApmDependencyStatsQuery(): void;
    get apmDependencyStatsQueryInput(): PowerpackWidgetHeatmapDefinitionRequestQueryApmDependencyStatsQuery | undefined;
    private _apmResourceStatsQuery;
    get apmResourceStatsQuery(): PowerpackWidgetHeatmapDefinitionRequestQueryApmResourceStatsQueryOutputReference;
    putApmResourceStatsQuery(value: PowerpackWidgetHeatmapDefinitionRequestQueryApmResourceStatsQuery): void;
    resetApmResourceStatsQuery(): void;
    get apmResourceStatsQueryInput(): PowerpackWidgetHeatmapDefinitionRequestQueryApmResourceStatsQuery | undefined;
    private _cloudCostQuery;
    get cloudCostQuery(): PowerpackWidgetHeatmapDefinitionRequestQueryCloudCostQueryOutputReference;
    putCloudCostQuery(value: PowerpackWidgetHeatmapDefinitionRequestQueryCloudCostQuery): void;
    resetCloudCostQuery(): void;
    get cloudCostQueryInput(): PowerpackWidgetHeatmapDefinitionRequestQueryCloudCostQuery | undefined;
    private _eventQuery;
    get eventQuery(): PowerpackWidgetHeatmapDefinitionRequestQueryEventQueryOutputReference;
    putEventQuery(value: PowerpackWidgetHeatmapDefinitionRequestQueryEventQuery): void;
    resetEventQuery(): void;
    get eventQueryInput(): PowerpackWidgetHeatmapDefinitionRequestQueryEventQuery | undefined;
    private _metricQuery;
    get metricQuery(): PowerpackWidgetHeatmapDefinitionRequestQueryMetricQueryOutputReference;
    putMetricQuery(value: PowerpackWidgetHeatmapDefinitionRequestQueryMetricQuery): void;
    resetMetricQuery(): void;
    get metricQueryInput(): PowerpackWidgetHeatmapDefinitionRequestQueryMetricQuery | undefined;
    private _processQuery;
    get processQuery(): PowerpackWidgetHeatmapDefinitionRequestQueryProcessQueryOutputReference;
    putProcessQuery(value: PowerpackWidgetHeatmapDefinitionRequestQueryProcessQuery): void;
    resetProcessQuery(): void;
    get processQueryInput(): PowerpackWidgetHeatmapDefinitionRequestQueryProcessQuery | undefined;
    private _sloQuery;
    get sloQuery(): PowerpackWidgetHeatmapDefinitionRequestQuerySloQueryOutputReference;
    putSloQuery(value: PowerpackWidgetHeatmapDefinitionRequestQuerySloQuery): void;
    resetSloQuery(): void;
    get sloQueryInput(): PowerpackWidgetHeatmapDefinitionRequestQuerySloQuery | undefined;
}
export declare class PowerpackWidgetHeatmapDefinitionRequestQueryList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHeatmapDefinitionRequestQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHeatmapDefinitionRequestQueryOutputReference;
}
export interface PowerpackWidgetHeatmapDefinitionRequestRumQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHeatmapDefinitionRequestRumQueryComputeQueryToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestRumQueryComputeQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestRumQueryComputeQuery): any;
export declare function powerpackWidgetHeatmapDefinitionRequestRumQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestRumQueryComputeQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestRumQueryComputeQuery): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestRumQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestRumQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestRumQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetHeatmapDefinitionRequestRumQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupBySortQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupBySortQuery): any;
export declare function powerpackWidgetHeatmapDefinitionRequestRumQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupBySortQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupBySortQuery): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupBySortQuery;
}
export declare function powerpackWidgetHeatmapDefinitionRequestRumQueryGroupByToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetHeatmapDefinitionRequestRumQueryGroupByToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupByOutputReference;
}
export interface PowerpackWidgetHeatmapDefinitionRequestRumQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHeatmapDefinitionRequestRumQueryMultiComputeToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetHeatmapDefinitionRequestRumQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestRumQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestRumQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetHeatmapDefinitionRequestRumQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHeatmapDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHeatmapDefinitionRequestRumQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetHeatmapDefinitionRequestRumQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetHeatmapDefinitionRequestRumQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetHeatmapDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetHeatmapDefinitionRequestRumQueryToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestRumQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestRumQuery): any;
export declare function powerpackWidgetHeatmapDefinitionRequestRumQueryToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestRumQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestRumQuery): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestRumQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestRumQuery | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestRumQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetHeatmapDefinitionRequestRumQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetHeatmapDefinitionRequestRumQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetHeatmapDefinitionRequestRumQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupByList;
    putGroupBy(value: PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetHeatmapDefinitionRequestRumQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetHeatmapDefinitionRequestRumQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetHeatmapDefinitionRequestRumQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetHeatmapDefinitionRequestRumQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestSecurityQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHeatmapDefinitionRequestSecurityQueryComputeQueryToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryComputeQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestSecurityQueryComputeQuery): any;
export declare function powerpackWidgetHeatmapDefinitionRequestSecurityQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryComputeQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestSecurityQueryComputeQuery): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestSecurityQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestSecurityQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBySortQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBySortQuery): any;
export declare function powerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBySortQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBySortQuery): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBySortQuery;
}
export declare function powerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupByToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupByToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupByOutputReference;
}
export interface PowerpackWidgetHeatmapDefinitionRequestSecurityQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHeatmapDefinitionRequestSecurityQueryMultiComputeToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetHeatmapDefinitionRequestSecurityQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestSecurityQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetHeatmapDefinitionRequestSecurityQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHeatmapDefinitionRequestSecurityQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetHeatmapDefinitionRequestSecurityQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetHeatmapDefinitionRequestSecurityQueryToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestSecurityQuery): any;
export declare function powerpackWidgetHeatmapDefinitionRequestSecurityQueryToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryOutputReference | PowerpackWidgetHeatmapDefinitionRequestSecurityQuery): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestSecurityQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestSecurityQuery | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestSecurityQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetHeatmapDefinitionRequestSecurityQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetHeatmapDefinitionRequestSecurityQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupByList;
    putGroupBy(value: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetHeatmapDefinitionRequestSecurityQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetHeatmapDefinitionRequestSecurityQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetHeatmapDefinitionRequestSecurityQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetHeatmapDefinitionRequestSecurityQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequestStyle {
    /**
    * A color palette to apply to the widget. The available options are available at: https://docs.datadoghq.com/dashboards/widgets/timeseries/#appearance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette Powerpack#palette}
    */
    readonly palette?: string;
}
export declare function powerpackWidgetHeatmapDefinitionRequestStyleToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestStyleOutputReference | PowerpackWidgetHeatmapDefinitionRequestStyle): any;
export declare function powerpackWidgetHeatmapDefinitionRequestStyleToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequestStyleOutputReference | PowerpackWidgetHeatmapDefinitionRequestStyle): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestStyleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequestStyle | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequestStyle | undefined);
    private _palette?;
    get palette(): string;
    set palette(value: string);
    resetPalette(): void;
    get paletteInput(): string | undefined;
}
export interface PowerpackWidgetHeatmapDefinitionRequest {
    /**
    * The metric query to use for this widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#q Powerpack#q}
    */
    readonly q?: string;
    /**
    * apm_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_query Powerpack#apm_query}
    */
    readonly apmQuery?: PowerpackWidgetHeatmapDefinitionRequestApmQuery;
    /**
    * formula block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#formula Powerpack#formula}
    */
    readonly formula?: PowerpackWidgetHeatmapDefinitionRequestFormula[] | cdktn.IResolvable;
    /**
    * log_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#log_query Powerpack#log_query}
    */
    readonly logQuery?: PowerpackWidgetHeatmapDefinitionRequestLogQuery;
    /**
    * process_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#process_query Powerpack#process_query}
    */
    readonly processQuery?: PowerpackWidgetHeatmapDefinitionRequestProcessQuery;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query?: PowerpackWidgetHeatmapDefinitionRequestQuery[] | cdktn.IResolvable;
    /**
    * rum_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#rum_query Powerpack#rum_query}
    */
    readonly rumQuery?: PowerpackWidgetHeatmapDefinitionRequestRumQuery;
    /**
    * security_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#security_query Powerpack#security_query}
    */
    readonly securityQuery?: PowerpackWidgetHeatmapDefinitionRequestSecurityQuery;
    /**
    * style block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#style Powerpack#style}
    */
    readonly style?: PowerpackWidgetHeatmapDefinitionRequestStyle;
}
export declare function powerpackWidgetHeatmapDefinitionRequestToTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequest | cdktn.IResolvable): any;
export declare function powerpackWidgetHeatmapDefinitionRequestToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionRequest | cdktn.IResolvable): any;
export declare class PowerpackWidgetHeatmapDefinitionRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHeatmapDefinitionRequest | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionRequest | cdktn.IResolvable | undefined);
    private _q?;
    get q(): string;
    set q(value: string);
    resetQ(): void;
    get qInput(): string | undefined;
    private _apmQuery;
    get apmQuery(): PowerpackWidgetHeatmapDefinitionRequestApmQueryOutputReference;
    putApmQuery(value: PowerpackWidgetHeatmapDefinitionRequestApmQuery): void;
    resetApmQuery(): void;
    get apmQueryInput(): PowerpackWidgetHeatmapDefinitionRequestApmQuery | undefined;
    private _formula;
    get formula(): PowerpackWidgetHeatmapDefinitionRequestFormulaList;
    putFormula(value: PowerpackWidgetHeatmapDefinitionRequestFormula[] | cdktn.IResolvable): void;
    resetFormula(): void;
    get formulaInput(): cdktn.IResolvable | PowerpackWidgetHeatmapDefinitionRequestFormula[] | undefined;
    private _logQuery;
    get logQuery(): PowerpackWidgetHeatmapDefinitionRequestLogQueryOutputReference;
    putLogQuery(value: PowerpackWidgetHeatmapDefinitionRequestLogQuery): void;
    resetLogQuery(): void;
    get logQueryInput(): PowerpackWidgetHeatmapDefinitionRequestLogQuery | undefined;
    private _processQuery;
    get processQuery(): PowerpackWidgetHeatmapDefinitionRequestProcessQueryOutputReference;
    putProcessQuery(value: PowerpackWidgetHeatmapDefinitionRequestProcessQuery): void;
    resetProcessQuery(): void;
    get processQueryInput(): PowerpackWidgetHeatmapDefinitionRequestProcessQuery | undefined;
    private _query;
    get query(): PowerpackWidgetHeatmapDefinitionRequestQueryList;
    putQuery(value: PowerpackWidgetHeatmapDefinitionRequestQuery[] | cdktn.IResolvable): void;
    resetQuery(): void;
    get queryInput(): cdktn.IResolvable | PowerpackWidgetHeatmapDefinitionRequestQuery[] | undefined;
    private _rumQuery;
    get rumQuery(): PowerpackWidgetHeatmapDefinitionRequestRumQueryOutputReference;
    putRumQuery(value: PowerpackWidgetHeatmapDefinitionRequestRumQuery): void;
    resetRumQuery(): void;
    get rumQueryInput(): PowerpackWidgetHeatmapDefinitionRequestRumQuery | undefined;
    private _securityQuery;
    get securityQuery(): PowerpackWidgetHeatmapDefinitionRequestSecurityQueryOutputReference;
    putSecurityQuery(value: PowerpackWidgetHeatmapDefinitionRequestSecurityQuery): void;
    resetSecurityQuery(): void;
    get securityQueryInput(): PowerpackWidgetHeatmapDefinitionRequestSecurityQuery | undefined;
    private _style;
    get style(): PowerpackWidgetHeatmapDefinitionRequestStyleOutputReference;
    putStyle(value: PowerpackWidgetHeatmapDefinitionRequestStyle): void;
    resetStyle(): void;
    get styleInput(): PowerpackWidgetHeatmapDefinitionRequestStyle | undefined;
}
export declare class PowerpackWidgetHeatmapDefinitionRequestList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHeatmapDefinitionRequest[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHeatmapDefinitionRequestOutputReference;
}
export interface PowerpackWidgetHeatmapDefinitionYaxis {
    /**
    * Always include zero or fit the axis to the data range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#include_zero Powerpack#include_zero}
    */
    readonly includeZero?: boolean | cdktn.IResolvable;
    /**
    * The label of the axis to display on the graph.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label?: string;
    /**
    * Specify the maximum value to show on the Y-axis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#max Powerpack#max}
    */
    readonly max?: string;
    /**
    * Specify the minimum value to show on the Y-axis.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#min Powerpack#min}
    */
    readonly min?: string;
    /**
    * Specify the scale type, options: `linear`, `log`, `pow`, `sqrt`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#scale Powerpack#scale}
    */
    readonly scale?: string;
}
export declare function powerpackWidgetHeatmapDefinitionYaxisToTerraform(struct?: PowerpackWidgetHeatmapDefinitionYaxisOutputReference | PowerpackWidgetHeatmapDefinitionYaxis): any;
export declare function powerpackWidgetHeatmapDefinitionYaxisToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionYaxisOutputReference | PowerpackWidgetHeatmapDefinitionYaxis): any;
export declare class PowerpackWidgetHeatmapDefinitionYaxisOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinitionYaxis | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinitionYaxis | undefined);
    private _includeZero?;
    get includeZero(): boolean | cdktn.IResolvable;
    set includeZero(value: boolean | cdktn.IResolvable);
    resetIncludeZero(): void;
    get includeZeroInput(): boolean | cdktn.IResolvable | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _max?;
    get max(): string;
    set max(value: string);
    resetMax(): void;
    get maxInput(): string | undefined;
    private _min?;
    get min(): string;
    set min(value: string);
    resetMin(): void;
    get minInput(): string | undefined;
    private _scale?;
    get scale(): string;
    set scale(value: string);
    resetScale(): void;
    get scaleInput(): string | undefined;
}
export interface PowerpackWidgetHeatmapDefinition {
    /**
    * Hide any portion of the widget's timeframe that is incomplete due to cost data not being available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_incomplete_cost_data Powerpack#hide_incomplete_cost_data}
    */
    readonly hideIncompleteCostData?: boolean | cdktn.IResolvable;
    /**
    * The size of the legend displayed in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#legend_size Powerpack#legend_size}
    */
    readonly legendSize?: string;
    /**
    * The timeframe to use when displaying the widget. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#live_span Powerpack#live_span}
    */
    readonly liveSpan?: string;
    /**
    * Whether or not to show the legend on this widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#show_legend Powerpack#show_legend}
    */
    readonly showLegend?: boolean | cdktn.IResolvable;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title Powerpack#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_align Powerpack#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_size Powerpack#title_size}
    */
    readonly titleSize?: string;
    /**
    * custom_link block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_link Powerpack#custom_link}
    */
    readonly customLink?: PowerpackWidgetHeatmapDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * event block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#event Powerpack#event}
    */
    readonly event?: PowerpackWidgetHeatmapDefinitionEvent[] | cdktn.IResolvable;
    /**
    * request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#request Powerpack#request}
    */
    readonly request?: PowerpackWidgetHeatmapDefinitionRequest[] | cdktn.IResolvable;
    /**
    * yaxis block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#yaxis Powerpack#yaxis}
    */
    readonly yaxis?: PowerpackWidgetHeatmapDefinitionYaxis;
}
export declare function powerpackWidgetHeatmapDefinitionToTerraform(struct?: PowerpackWidgetHeatmapDefinitionOutputReference | PowerpackWidgetHeatmapDefinition): any;
export declare function powerpackWidgetHeatmapDefinitionToHclTerraform(struct?: PowerpackWidgetHeatmapDefinitionOutputReference | PowerpackWidgetHeatmapDefinition): any;
export declare class PowerpackWidgetHeatmapDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHeatmapDefinition | undefined;
    set internalValue(value: PowerpackWidgetHeatmapDefinition | undefined);
    private _hideIncompleteCostData?;
    get hideIncompleteCostData(): boolean | cdktn.IResolvable;
    set hideIncompleteCostData(value: boolean | cdktn.IResolvable);
    resetHideIncompleteCostData(): void;
    get hideIncompleteCostDataInput(): boolean | cdktn.IResolvable | undefined;
    private _legendSize?;
    get legendSize(): string;
    set legendSize(value: string);
    resetLegendSize(): void;
    get legendSizeInput(): string | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _showLegend?;
    get showLegend(): boolean | cdktn.IResolvable;
    set showLegend(value: boolean | cdktn.IResolvable);
    resetShowLegend(): void;
    get showLegendInput(): boolean | cdktn.IResolvable | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _customLink;
    get customLink(): PowerpackWidgetHeatmapDefinitionCustomLinkList;
    putCustomLink(value: PowerpackWidgetHeatmapDefinitionCustomLink[] | cdktn.IResolvable): void;
    resetCustomLink(): void;
    get customLinkInput(): cdktn.IResolvable | PowerpackWidgetHeatmapDefinitionCustomLink[] | undefined;
    private _event;
    get event(): PowerpackWidgetHeatmapDefinitionEventList;
    putEvent(value: PowerpackWidgetHeatmapDefinitionEvent[] | cdktn.IResolvable): void;
    resetEvent(): void;
    get eventInput(): cdktn.IResolvable | PowerpackWidgetHeatmapDefinitionEvent[] | undefined;
    private _request;
    get request(): PowerpackWidgetHeatmapDefinitionRequestList;
    putRequest(value: PowerpackWidgetHeatmapDefinitionRequest[] | cdktn.IResolvable): void;
    resetRequest(): void;
    get requestInput(): cdktn.IResolvable | PowerpackWidgetHeatmapDefinitionRequest[] | undefined;
    private _yaxis;
    get yaxis(): PowerpackWidgetHeatmapDefinitionYaxisOutputReference;
    putYaxis(value: PowerpackWidgetHeatmapDefinitionYaxis): void;
    resetYaxis(): void;
    get yaxisInput(): PowerpackWidgetHeatmapDefinitionYaxis | undefined;
}
export interface PowerpackWidgetHostmapDefinitionCustomLink {
    /**
    * The flag for toggling context menu link visibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_hidden Powerpack#is_hidden}
    */
    readonly isHidden?: boolean | cdktn.IResolvable;
    /**
    * The label for the custom link URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label?: string;
    /**
    * The URL of the custom link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#link Powerpack#link}
    */
    readonly link?: string;
    /**
    * The label ID that refers to a context menu link item. When `override_label` is provided, the client request omits the label field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#override_label Powerpack#override_label}
    */
    readonly overrideLabel?: string;
}
export declare function powerpackWidgetHostmapDefinitionCustomLinkToTerraform(struct?: PowerpackWidgetHostmapDefinitionCustomLink | cdktn.IResolvable): any;
export declare function powerpackWidgetHostmapDefinitionCustomLinkToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionCustomLink | cdktn.IResolvable): any;
export declare class PowerpackWidgetHostmapDefinitionCustomLinkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHostmapDefinitionCustomLink | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionCustomLink | cdktn.IResolvable | undefined);
    private _isHidden?;
    get isHidden(): boolean | cdktn.IResolvable;
    set isHidden(value: boolean | cdktn.IResolvable);
    resetIsHidden(): void;
    get isHiddenInput(): boolean | cdktn.IResolvable | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _link?;
    get link(): string;
    set link(value: string);
    resetLink(): void;
    get linkInput(): string | undefined;
    private _overrideLabel?;
    get overrideLabel(): string;
    set overrideLabel(value: string);
    resetOverrideLabel(): void;
    get overrideLabelInput(): string | undefined;
}
export declare class PowerpackWidgetHostmapDefinitionCustomLinkList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHostmapDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHostmapDefinitionCustomLinkOutputReference;
}
export interface PowerpackWidgetHostmapDefinitionRequestFillApmQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHostmapDefinitionRequestFillApmQueryComputeQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillApmQueryComputeQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillApmQueryComputeQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestFillApmQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillApmQueryComputeQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillApmQueryComputeQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestFillApmQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestFillApmQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestFillApmQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBySortQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBySortQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBySortQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBySortQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBySortQuery;
}
export declare function powerpackWidgetHostmapDefinitionRequestFillApmQueryGroupByToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetHostmapDefinitionRequestFillApmQueryGroupByToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupByOutputReference;
}
export interface PowerpackWidgetHostmapDefinitionRequestFillApmQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHostmapDefinitionRequestFillApmQueryMultiComputeToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillApmQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetHostmapDefinitionRequestFillApmQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillApmQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetHostmapDefinitionRequestFillApmQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestFillApmQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestFillApmQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetHostmapDefinitionRequestFillApmQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHostmapDefinitionRequestFillApmQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHostmapDefinitionRequestFillApmQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetHostmapDefinitionRequestFillApmQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetHostmapDefinitionRequestFillApmQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetHostmapDefinitionRequestFillApmQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetHostmapDefinitionRequestFillApmQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillApmQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillApmQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestFillApmQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillApmQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillApmQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestFillApmQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestFillApmQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestFillApmQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetHostmapDefinitionRequestFillApmQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetHostmapDefinitionRequestFillApmQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetHostmapDefinitionRequestFillApmQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupByList;
    putGroupBy(value: PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetHostmapDefinitionRequestFillApmQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetHostmapDefinitionRequestFillApmQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetHostmapDefinitionRequestFillApmQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetHostmapDefinitionRequestFillApmQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestFillLogQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHostmapDefinitionRequestFillLogQueryComputeQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillLogQueryComputeQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillLogQueryComputeQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestFillLogQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillLogQueryComputeQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillLogQueryComputeQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestFillLogQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestFillLogQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestFillLogQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBySortQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBySortQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBySortQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBySortQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBySortQuery;
}
export declare function powerpackWidgetHostmapDefinitionRequestFillLogQueryGroupByToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetHostmapDefinitionRequestFillLogQueryGroupByToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupByOutputReference;
}
export interface PowerpackWidgetHostmapDefinitionRequestFillLogQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHostmapDefinitionRequestFillLogQueryMultiComputeToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillLogQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetHostmapDefinitionRequestFillLogQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillLogQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetHostmapDefinitionRequestFillLogQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestFillLogQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestFillLogQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetHostmapDefinitionRequestFillLogQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHostmapDefinitionRequestFillLogQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHostmapDefinitionRequestFillLogQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetHostmapDefinitionRequestFillLogQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetHostmapDefinitionRequestFillLogQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetHostmapDefinitionRequestFillLogQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetHostmapDefinitionRequestFillLogQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillLogQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillLogQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestFillLogQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillLogQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillLogQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestFillLogQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestFillLogQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestFillLogQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetHostmapDefinitionRequestFillLogQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetHostmapDefinitionRequestFillLogQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetHostmapDefinitionRequestFillLogQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupByList;
    putGroupBy(value: PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetHostmapDefinitionRequestFillLogQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetHostmapDefinitionRequestFillLogQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetHostmapDefinitionRequestFillLogQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetHostmapDefinitionRequestFillLogQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestFillProcessQuery {
    /**
    * A list of processes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#filter_by Powerpack#filter_by}
    */
    readonly filterBy?: string[];
    /**
    * The max number of items in the filter list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * Your chosen metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric: string;
    /**
    * Your chosen search term.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_by Powerpack#search_by}
    */
    readonly searchBy?: string;
}
export declare function powerpackWidgetHostmapDefinitionRequestFillProcessQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillProcessQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillProcessQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestFillProcessQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillProcessQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillProcessQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestFillProcessQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestFillProcessQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestFillProcessQuery | undefined);
    private _filterBy?;
    get filterBy(): string[];
    set filterBy(value: string[]);
    resetFilterBy(): void;
    get filterByInput(): string[] | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _searchBy?;
    get searchBy(): string;
    set searchBy(value: string);
    resetSearchBy(): void;
    get searchByInput(): string | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestFillRumQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHostmapDefinitionRequestFillRumQueryComputeQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillRumQueryComputeQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillRumQueryComputeQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestFillRumQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillRumQueryComputeQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillRumQueryComputeQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestFillRumQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestFillRumQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestFillRumQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBySortQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBySortQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBySortQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBySortQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBySortQuery;
}
export declare function powerpackWidgetHostmapDefinitionRequestFillRumQueryGroupByToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetHostmapDefinitionRequestFillRumQueryGroupByToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupByOutputReference;
}
export interface PowerpackWidgetHostmapDefinitionRequestFillRumQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHostmapDefinitionRequestFillRumQueryMultiComputeToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillRumQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetHostmapDefinitionRequestFillRumQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillRumQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetHostmapDefinitionRequestFillRumQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestFillRumQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestFillRumQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetHostmapDefinitionRequestFillRumQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHostmapDefinitionRequestFillRumQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHostmapDefinitionRequestFillRumQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetHostmapDefinitionRequestFillRumQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetHostmapDefinitionRequestFillRumQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetHostmapDefinitionRequestFillRumQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetHostmapDefinitionRequestFillRumQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillRumQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillRumQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestFillRumQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillRumQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillRumQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestFillRumQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestFillRumQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestFillRumQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetHostmapDefinitionRequestFillRumQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetHostmapDefinitionRequestFillRumQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetHostmapDefinitionRequestFillRumQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupByList;
    putGroupBy(value: PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetHostmapDefinitionRequestFillRumQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetHostmapDefinitionRequestFillRumQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetHostmapDefinitionRequestFillRumQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetHostmapDefinitionRequestFillRumQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHostmapDefinitionRequestFillSecurityQueryComputeQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryComputeQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryComputeQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestFillSecurityQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryComputeQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryComputeQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBySortQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBySortQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBySortQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBySortQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBySortQuery;
}
export declare function powerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupByToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupByToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupByOutputReference;
}
export interface PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHostmapDefinitionRequestFillSecurityQueryMultiComputeToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetHostmapDefinitionRequestFillSecurityQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetHostmapDefinitionRequestFillSecurityQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetHostmapDefinitionRequestFillSecurityQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillSecurityQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestFillSecurityQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestFillSecurityQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestFillSecurityQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestFillSecurityQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupByList;
    putGroupBy(value: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestFill {
    /**
    * The metric query to use for this widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#q Powerpack#q}
    */
    readonly q?: string;
    /**
    * apm_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_query Powerpack#apm_query}
    */
    readonly apmQuery?: PowerpackWidgetHostmapDefinitionRequestFillApmQuery;
    /**
    * log_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#log_query Powerpack#log_query}
    */
    readonly logQuery?: PowerpackWidgetHostmapDefinitionRequestFillLogQuery;
    /**
    * process_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#process_query Powerpack#process_query}
    */
    readonly processQuery?: PowerpackWidgetHostmapDefinitionRequestFillProcessQuery;
    /**
    * rum_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#rum_query Powerpack#rum_query}
    */
    readonly rumQuery?: PowerpackWidgetHostmapDefinitionRequestFillRumQuery;
    /**
    * security_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#security_query Powerpack#security_query}
    */
    readonly securityQuery?: PowerpackWidgetHostmapDefinitionRequestFillSecurityQuery;
}
export declare function powerpackWidgetHostmapDefinitionRequestFillToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFill | cdktn.IResolvable): any;
export declare function powerpackWidgetHostmapDefinitionRequestFillToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestFill | cdktn.IResolvable): any;
export declare class PowerpackWidgetHostmapDefinitionRequestFillOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestFill | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestFill | cdktn.IResolvable | undefined);
    private _q?;
    get q(): string;
    set q(value: string);
    resetQ(): void;
    get qInput(): string | undefined;
    private _apmQuery;
    get apmQuery(): PowerpackWidgetHostmapDefinitionRequestFillApmQueryOutputReference;
    putApmQuery(value: PowerpackWidgetHostmapDefinitionRequestFillApmQuery): void;
    resetApmQuery(): void;
    get apmQueryInput(): PowerpackWidgetHostmapDefinitionRequestFillApmQuery | undefined;
    private _logQuery;
    get logQuery(): PowerpackWidgetHostmapDefinitionRequestFillLogQueryOutputReference;
    putLogQuery(value: PowerpackWidgetHostmapDefinitionRequestFillLogQuery): void;
    resetLogQuery(): void;
    get logQueryInput(): PowerpackWidgetHostmapDefinitionRequestFillLogQuery | undefined;
    private _processQuery;
    get processQuery(): PowerpackWidgetHostmapDefinitionRequestFillProcessQueryOutputReference;
    putProcessQuery(value: PowerpackWidgetHostmapDefinitionRequestFillProcessQuery): void;
    resetProcessQuery(): void;
    get processQueryInput(): PowerpackWidgetHostmapDefinitionRequestFillProcessQuery | undefined;
    private _rumQuery;
    get rumQuery(): PowerpackWidgetHostmapDefinitionRequestFillRumQueryOutputReference;
    putRumQuery(value: PowerpackWidgetHostmapDefinitionRequestFillRumQuery): void;
    resetRumQuery(): void;
    get rumQueryInput(): PowerpackWidgetHostmapDefinitionRequestFillRumQuery | undefined;
    private _securityQuery;
    get securityQuery(): PowerpackWidgetHostmapDefinitionRequestFillSecurityQueryOutputReference;
    putSecurityQuery(value: PowerpackWidgetHostmapDefinitionRequestFillSecurityQuery): void;
    resetSecurityQuery(): void;
    get securityQueryInput(): PowerpackWidgetHostmapDefinitionRequestFillSecurityQuery | undefined;
}
export declare class PowerpackWidgetHostmapDefinitionRequestFillList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHostmapDefinitionRequestFill[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHostmapDefinitionRequestFillOutputReference;
}
export interface PowerpackWidgetHostmapDefinitionRequestSizeApmQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHostmapDefinitionRequestSizeApmQueryComputeQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryComputeQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeApmQueryComputeQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestSizeApmQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryComputeQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeApmQueryComputeQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestSizeApmQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestSizeApmQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBySortQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBySortQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBySortQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBySortQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBySortQuery;
}
export declare function powerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupByToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupByToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupByOutputReference;
}
export interface PowerpackWidgetHostmapDefinitionRequestSizeApmQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHostmapDefinitionRequestSizeApmQueryMultiComputeToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetHostmapDefinitionRequestSizeApmQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetHostmapDefinitionRequestSizeApmQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestSizeApmQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetHostmapDefinitionRequestSizeApmQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHostmapDefinitionRequestSizeApmQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetHostmapDefinitionRequestSizeApmQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetHostmapDefinitionRequestSizeApmQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeApmQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestSizeApmQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeApmQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestSizeApmQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestSizeApmQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestSizeApmQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetHostmapDefinitionRequestSizeApmQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetHostmapDefinitionRequestSizeApmQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupByList;
    putGroupBy(value: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetHostmapDefinitionRequestSizeApmQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetHostmapDefinitionRequestSizeApmQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetHostmapDefinitionRequestSizeApmQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetHostmapDefinitionRequestSizeApmQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestSizeLogQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHostmapDefinitionRequestSizeLogQueryComputeQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryComputeQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeLogQueryComputeQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestSizeLogQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryComputeQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeLogQueryComputeQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestSizeLogQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestSizeLogQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBySortQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBySortQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBySortQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBySortQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBySortQuery;
}
export declare function powerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupByToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupByToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupByOutputReference;
}
export interface PowerpackWidgetHostmapDefinitionRequestSizeLogQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHostmapDefinitionRequestSizeLogQueryMultiComputeToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetHostmapDefinitionRequestSizeLogQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetHostmapDefinitionRequestSizeLogQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestSizeLogQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetHostmapDefinitionRequestSizeLogQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHostmapDefinitionRequestSizeLogQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetHostmapDefinitionRequestSizeLogQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetHostmapDefinitionRequestSizeLogQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeLogQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestSizeLogQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeLogQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestSizeLogQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestSizeLogQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestSizeLogQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetHostmapDefinitionRequestSizeLogQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetHostmapDefinitionRequestSizeLogQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupByList;
    putGroupBy(value: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetHostmapDefinitionRequestSizeLogQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetHostmapDefinitionRequestSizeLogQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetHostmapDefinitionRequestSizeLogQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetHostmapDefinitionRequestSizeLogQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestSizeProcessQuery {
    /**
    * A list of processes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#filter_by Powerpack#filter_by}
    */
    readonly filterBy?: string[];
    /**
    * The max number of items in the filter list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * Your chosen metric.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric: string;
    /**
    * Your chosen search term.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_by Powerpack#search_by}
    */
    readonly searchBy?: string;
}
export declare function powerpackWidgetHostmapDefinitionRequestSizeProcessQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeProcessQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeProcessQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestSizeProcessQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeProcessQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeProcessQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestSizeProcessQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestSizeProcessQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestSizeProcessQuery | undefined);
    private _filterBy?;
    get filterBy(): string[];
    set filterBy(value: string[]);
    resetFilterBy(): void;
    get filterByInput(): string[] | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _searchBy?;
    get searchBy(): string;
    set searchBy(value: string);
    resetSearchBy(): void;
    get searchByInput(): string | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestSizeRumQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHostmapDefinitionRequestSizeRumQueryComputeQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryComputeQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeRumQueryComputeQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestSizeRumQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryComputeQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeRumQueryComputeQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestSizeRumQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestSizeRumQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBySortQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBySortQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBySortQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBySortQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBySortQuery;
}
export declare function powerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupByToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupByToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupByOutputReference;
}
export interface PowerpackWidgetHostmapDefinitionRequestSizeRumQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHostmapDefinitionRequestSizeRumQueryMultiComputeToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetHostmapDefinitionRequestSizeRumQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetHostmapDefinitionRequestSizeRumQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestSizeRumQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetHostmapDefinitionRequestSizeRumQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHostmapDefinitionRequestSizeRumQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetHostmapDefinitionRequestSizeRumQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetHostmapDefinitionRequestSizeRumQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeRumQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestSizeRumQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeRumQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestSizeRumQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestSizeRumQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestSizeRumQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetHostmapDefinitionRequestSizeRumQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetHostmapDefinitionRequestSizeRumQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupByList;
    putGroupBy(value: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetHostmapDefinitionRequestSizeRumQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetHostmapDefinitionRequestSizeRumQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetHostmapDefinitionRequestSizeRumQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetHostmapDefinitionRequestSizeRumQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHostmapDefinitionRequestSizeSecurityQueryComputeQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryComputeQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryComputeQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestSizeSecurityQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryComputeQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryComputeQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBySortQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBySortQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBySortQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBySortQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBySortQuery;
}
export declare function powerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupByToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupByToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupByOutputReference;
}
export interface PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetHostmapDefinitionRequestSizeSecurityQueryMultiComputeToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetHostmapDefinitionRequestSizeSecurityQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetHostmapDefinitionRequestSizeSecurityQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetHostmapDefinitionRequestSizeSecurityQueryToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeSecurityQuery): any;
export declare function powerpackWidgetHostmapDefinitionRequestSizeSecurityQueryToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryOutputReference | PowerpackWidgetHostmapDefinitionRequestSizeSecurityQuery): any;
export declare class PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestSizeSecurityQuery | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupByList;
    putGroupBy(value: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetHostmapDefinitionRequestSize {
    /**
    * The metric query to use for this widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#q Powerpack#q}
    */
    readonly q?: string;
    /**
    * apm_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#apm_query Powerpack#apm_query}
    */
    readonly apmQuery?: PowerpackWidgetHostmapDefinitionRequestSizeApmQuery;
    /**
    * log_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#log_query Powerpack#log_query}
    */
    readonly logQuery?: PowerpackWidgetHostmapDefinitionRequestSizeLogQuery;
    /**
    * process_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#process_query Powerpack#process_query}
    */
    readonly processQuery?: PowerpackWidgetHostmapDefinitionRequestSizeProcessQuery;
    /**
    * rum_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#rum_query Powerpack#rum_query}
    */
    readonly rumQuery?: PowerpackWidgetHostmapDefinitionRequestSizeRumQuery;
    /**
    * security_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#security_query Powerpack#security_query}
    */
    readonly securityQuery?: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQuery;
}
export declare function powerpackWidgetHostmapDefinitionRequestSizeToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSize | cdktn.IResolvable): any;
export declare function powerpackWidgetHostmapDefinitionRequestSizeToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestSize | cdktn.IResolvable): any;
export declare class PowerpackWidgetHostmapDefinitionRequestSizeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequestSize | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequestSize | cdktn.IResolvable | undefined);
    private _q?;
    get q(): string;
    set q(value: string);
    resetQ(): void;
    get qInput(): string | undefined;
    private _apmQuery;
    get apmQuery(): PowerpackWidgetHostmapDefinitionRequestSizeApmQueryOutputReference;
    putApmQuery(value: PowerpackWidgetHostmapDefinitionRequestSizeApmQuery): void;
    resetApmQuery(): void;
    get apmQueryInput(): PowerpackWidgetHostmapDefinitionRequestSizeApmQuery | undefined;
    private _logQuery;
    get logQuery(): PowerpackWidgetHostmapDefinitionRequestSizeLogQueryOutputReference;
    putLogQuery(value: PowerpackWidgetHostmapDefinitionRequestSizeLogQuery): void;
    resetLogQuery(): void;
    get logQueryInput(): PowerpackWidgetHostmapDefinitionRequestSizeLogQuery | undefined;
    private _processQuery;
    get processQuery(): PowerpackWidgetHostmapDefinitionRequestSizeProcessQueryOutputReference;
    putProcessQuery(value: PowerpackWidgetHostmapDefinitionRequestSizeProcessQuery): void;
    resetProcessQuery(): void;
    get processQueryInput(): PowerpackWidgetHostmapDefinitionRequestSizeProcessQuery | undefined;
    private _rumQuery;
    get rumQuery(): PowerpackWidgetHostmapDefinitionRequestSizeRumQueryOutputReference;
    putRumQuery(value: PowerpackWidgetHostmapDefinitionRequestSizeRumQuery): void;
    resetRumQuery(): void;
    get rumQueryInput(): PowerpackWidgetHostmapDefinitionRequestSizeRumQuery | undefined;
    private _securityQuery;
    get securityQuery(): PowerpackWidgetHostmapDefinitionRequestSizeSecurityQueryOutputReference;
    putSecurityQuery(value: PowerpackWidgetHostmapDefinitionRequestSizeSecurityQuery): void;
    resetSecurityQuery(): void;
    get securityQueryInput(): PowerpackWidgetHostmapDefinitionRequestSizeSecurityQuery | undefined;
}
export declare class PowerpackWidgetHostmapDefinitionRequestSizeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetHostmapDefinitionRequestSize[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetHostmapDefinitionRequestSizeOutputReference;
}
export interface PowerpackWidgetHostmapDefinitionRequest {
    /**
    * fill block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#fill Powerpack#fill}
    */
    readonly fill?: PowerpackWidgetHostmapDefinitionRequestFill[] | cdktn.IResolvable;
    /**
    * size block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#size Powerpack#size}
    */
    readonly size?: PowerpackWidgetHostmapDefinitionRequestSize[] | cdktn.IResolvable;
}
export declare function powerpackWidgetHostmapDefinitionRequestToTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestOutputReference | PowerpackWidgetHostmapDefinitionRequest): any;
export declare function powerpackWidgetHostmapDefinitionRequestToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionRequestOutputReference | PowerpackWidgetHostmapDefinitionRequest): any;
export declare class PowerpackWidgetHostmapDefinitionRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionRequest | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionRequest | undefined);
    private _fill;
    get fill(): PowerpackWidgetHostmapDefinitionRequestFillList;
    putFill(value: PowerpackWidgetHostmapDefinitionRequestFill[] | cdktn.IResolvable): void;
    resetFill(): void;
    get fillInput(): cdktn.IResolvable | PowerpackWidgetHostmapDefinitionRequestFill[] | undefined;
    private _size;
    get size(): PowerpackWidgetHostmapDefinitionRequestSizeList;
    putSize(value: PowerpackWidgetHostmapDefinitionRequestSize[] | cdktn.IResolvable): void;
    resetSize(): void;
    get sizeInput(): cdktn.IResolvable | PowerpackWidgetHostmapDefinitionRequestSize[] | undefined;
}
export interface PowerpackWidgetHostmapDefinitionStyle {
    /**
    * The max value to use to color the map.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#fill_max Powerpack#fill_max}
    */
    readonly fillMax?: string;
    /**
    * The min value to use to color the map.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#fill_min Powerpack#fill_min}
    */
    readonly fillMin?: string;
    /**
    * A color palette to apply to the widget. The available options are available at: https://docs.datadoghq.com/dashboards/widgets/timeseries/#appearance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette Powerpack#palette}
    */
    readonly palette?: string;
    /**
    * A Boolean indicating whether to flip the palette tones.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette_flip Powerpack#palette_flip}
    */
    readonly paletteFlip?: boolean | cdktn.IResolvable;
}
export declare function powerpackWidgetHostmapDefinitionStyleToTerraform(struct?: PowerpackWidgetHostmapDefinitionStyleOutputReference | PowerpackWidgetHostmapDefinitionStyle): any;
export declare function powerpackWidgetHostmapDefinitionStyleToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionStyleOutputReference | PowerpackWidgetHostmapDefinitionStyle): any;
export declare class PowerpackWidgetHostmapDefinitionStyleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinitionStyle | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinitionStyle | undefined);
    private _fillMax?;
    get fillMax(): string;
    set fillMax(value: string);
    resetFillMax(): void;
    get fillMaxInput(): string | undefined;
    private _fillMin?;
    get fillMin(): string;
    set fillMin(value: string);
    resetFillMin(): void;
    get fillMinInput(): string | undefined;
    private _palette?;
    get palette(): string;
    set palette(value: string);
    resetPalette(): void;
    get paletteInput(): string | undefined;
    private _paletteFlip?;
    get paletteFlip(): boolean | cdktn.IResolvable;
    set paletteFlip(value: boolean | cdktn.IResolvable);
    resetPaletteFlip(): void;
    get paletteFlipInput(): boolean | cdktn.IResolvable | undefined;
}
export interface PowerpackWidgetHostmapDefinition {
    /**
    * The list of tags to group nodes by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group Powerpack#group}
    */
    readonly group?: string[];
    /**
    * A Boolean indicating whether to show ungrouped nodes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#no_group_hosts Powerpack#no_group_hosts}
    */
    readonly noGroupHosts?: boolean | cdktn.IResolvable;
    /**
    * A Boolean indicating whether to show nodes with no metrics.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#no_metric_hosts Powerpack#no_metric_hosts}
    */
    readonly noMetricHosts?: boolean | cdktn.IResolvable;
    /**
    * The type of node used. Valid values are `host`, `container`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#node_type Powerpack#node_type}
    */
    readonly nodeType?: string;
    /**
    * The list of tags to filter nodes by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#scope Powerpack#scope}
    */
    readonly scope?: string[];
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title Powerpack#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_align Powerpack#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_size Powerpack#title_size}
    */
    readonly titleSize?: string;
    /**
    * custom_link block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_link Powerpack#custom_link}
    */
    readonly customLink?: PowerpackWidgetHostmapDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#request Powerpack#request}
    */
    readonly request?: PowerpackWidgetHostmapDefinitionRequest;
    /**
    * style block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#style Powerpack#style}
    */
    readonly style?: PowerpackWidgetHostmapDefinitionStyle;
}
export declare function powerpackWidgetHostmapDefinitionToTerraform(struct?: PowerpackWidgetHostmapDefinitionOutputReference | PowerpackWidgetHostmapDefinition): any;
export declare function powerpackWidgetHostmapDefinitionToHclTerraform(struct?: PowerpackWidgetHostmapDefinitionOutputReference | PowerpackWidgetHostmapDefinition): any;
export declare class PowerpackWidgetHostmapDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetHostmapDefinition | undefined;
    set internalValue(value: PowerpackWidgetHostmapDefinition | undefined);
    private _group?;
    get group(): string[];
    set group(value: string[]);
    resetGroup(): void;
    get groupInput(): string[] | undefined;
    private _noGroupHosts?;
    get noGroupHosts(): boolean | cdktn.IResolvable;
    set noGroupHosts(value: boolean | cdktn.IResolvable);
    resetNoGroupHosts(): void;
    get noGroupHostsInput(): boolean | cdktn.IResolvable | undefined;
    private _noMetricHosts?;
    get noMetricHosts(): boolean | cdktn.IResolvable;
    set noMetricHosts(value: boolean | cdktn.IResolvable);
    resetNoMetricHosts(): void;
    get noMetricHostsInput(): boolean | cdktn.IResolvable | undefined;
    private _nodeType?;
    get nodeType(): string;
    set nodeType(value: string);
    resetNodeType(): void;
    get nodeTypeInput(): string | undefined;
    private _scope?;
    get scope(): string[];
    set scope(value: string[]);
    resetScope(): void;
    get scopeInput(): string[] | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _customLink;
    get customLink(): PowerpackWidgetHostmapDefinitionCustomLinkList;
    putCustomLink(value: PowerpackWidgetHostmapDefinitionCustomLink[] | cdktn.IResolvable): void;
    resetCustomLink(): void;
    get customLinkInput(): cdktn.IResolvable | PowerpackWidgetHostmapDefinitionCustomLink[] | undefined;
    private _request;
    get request(): PowerpackWidgetHostmapDefinitionRequestOutputReference;
    putRequest(value: PowerpackWidgetHostmapDefinitionRequest): void;
    resetRequest(): void;
    get requestInput(): PowerpackWidgetHostmapDefinitionRequest | undefined;
    private _style;
    get style(): PowerpackWidgetHostmapDefinitionStyleOutputReference;
    putStyle(value: PowerpackWidgetHostmapDefinitionStyle): void;
    resetStyle(): void;
    get styleInput(): PowerpackWidgetHostmapDefinitionStyle | undefined;
}
export interface PowerpackWidgetIframeDefinition {
    /**
    * The URL to use as a data source for the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#url Powerpack#url}
    */
    readonly url: string;
}
export declare function powerpackWidgetIframeDefinitionToTerraform(struct?: PowerpackWidgetIframeDefinitionOutputReference | PowerpackWidgetIframeDefinition): any;
export declare function powerpackWidgetIframeDefinitionToHclTerraform(struct?: PowerpackWidgetIframeDefinitionOutputReference | PowerpackWidgetIframeDefinition): any;
export declare class PowerpackWidgetIframeDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetIframeDefinition | undefined;
    set internalValue(value: PowerpackWidgetIframeDefinition | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface PowerpackWidgetImageDefinition {
    /**
    * Whether to display a background or not. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#has_background Powerpack#has_background}
    */
    readonly hasBackground?: boolean | cdktn.IResolvable;
    /**
    * Whether to display a border or not. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#has_border Powerpack#has_border}
    */
    readonly hasBorder?: boolean | cdktn.IResolvable;
    /**
    * The horizontal alignment for the widget. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#horizontal_align Powerpack#horizontal_align}
    */
    readonly horizontalAlign?: string;
    /**
    * The margins to use around the image. Note: `small` and `large` values are deprecated. Valid values are `sm`, `md`, `lg`, `small`, `large`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#margin Powerpack#margin}
    */
    readonly margin?: string;
    /**
    * The preferred method to adapt the dimensions of the image. The values are based on the image `object-fit` CSS properties. Note: `zoom`, `fit` and `center` values are deprecated. Valid values are `fill`, `contain`, `cover`, `none`, `scale-down`, `zoom`, `fit`, `center`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sizing Powerpack#sizing}
    */
    readonly sizing?: string;
    /**
    * The URL to use as a data source for the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#url Powerpack#url}
    */
    readonly url: string;
    /**
    * The URL in dark mode to use as a data source for the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#url_dark_theme Powerpack#url_dark_theme}
    */
    readonly urlDarkTheme?: string;
    /**
    * The vertical alignment for the widget. Valid values are `center`, `top`, `bottom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#vertical_align Powerpack#vertical_align}
    */
    readonly verticalAlign?: string;
}
export declare function powerpackWidgetImageDefinitionToTerraform(struct?: PowerpackWidgetImageDefinitionOutputReference | PowerpackWidgetImageDefinition): any;
export declare function powerpackWidgetImageDefinitionToHclTerraform(struct?: PowerpackWidgetImageDefinitionOutputReference | PowerpackWidgetImageDefinition): any;
export declare class PowerpackWidgetImageDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetImageDefinition | undefined;
    set internalValue(value: PowerpackWidgetImageDefinition | undefined);
    private _hasBackground?;
    get hasBackground(): boolean | cdktn.IResolvable;
    set hasBackground(value: boolean | cdktn.IResolvable);
    resetHasBackground(): void;
    get hasBackgroundInput(): boolean | cdktn.IResolvable | undefined;
    private _hasBorder?;
    get hasBorder(): boolean | cdktn.IResolvable;
    set hasBorder(value: boolean | cdktn.IResolvable);
    resetHasBorder(): void;
    get hasBorderInput(): boolean | cdktn.IResolvable | undefined;
    private _horizontalAlign?;
    get horizontalAlign(): string;
    set horizontalAlign(value: string);
    resetHorizontalAlign(): void;
    get horizontalAlignInput(): string | undefined;
    private _margin?;
    get margin(): string;
    set margin(value: string);
    resetMargin(): void;
    get marginInput(): string | undefined;
    private _sizing?;
    get sizing(): string;
    set sizing(value: string);
    resetSizing(): void;
    get sizingInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _urlDarkTheme?;
    get urlDarkTheme(): string;
    set urlDarkTheme(value: string);
    resetUrlDarkTheme(): void;
    get urlDarkThemeInput(): string | undefined;
    private _verticalAlign?;
    get verticalAlign(): string;
    set verticalAlign(value: string);
    resetVerticalAlign(): void;
    get verticalAlignInput(): string | undefined;
}
export interface PowerpackWidgetListStreamDefinitionRequestColumns {
    /**
    * Widget column field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#field Powerpack#field}
    */
    readonly field?: string;
    /**
    * Widget column width. Valid values are `auto`, `compact`, `full`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#width Powerpack#width}
    */
    readonly width?: string;
}
export declare function powerpackWidgetListStreamDefinitionRequestColumnsToTerraform(struct?: PowerpackWidgetListStreamDefinitionRequestColumns | cdktn.IResolvable): any;
export declare function powerpackWidgetListStreamDefinitionRequestColumnsToHclTerraform(struct?: PowerpackWidgetListStreamDefinitionRequestColumns | cdktn.IResolvable): any;
export declare class PowerpackWidgetListStreamDefinitionRequestColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetListStreamDefinitionRequestColumns | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetListStreamDefinitionRequestColumns | cdktn.IResolvable | undefined);
    private _field?;
    get field(): string;
    set field(value: string);
    resetField(): void;
    get fieldInput(): string | undefined;
    private _width?;
    get width(): string;
    set width(value: string);
    resetWidth(): void;
    get widthInput(): string | undefined;
}
export declare class PowerpackWidgetListStreamDefinitionRequestColumnsList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetListStreamDefinitionRequestColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetListStreamDefinitionRequestColumnsOutputReference;
}
export interface PowerpackWidgetListStreamDefinitionRequestQueryGroupBy {
    /**
    * Facet name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet: string;
}
export declare function powerpackWidgetListStreamDefinitionRequestQueryGroupByToTerraform(struct?: PowerpackWidgetListStreamDefinitionRequestQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetListStreamDefinitionRequestQueryGroupByToHclTerraform(struct?: PowerpackWidgetListStreamDefinitionRequestQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetListStreamDefinitionRequestQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetListStreamDefinitionRequestQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetListStreamDefinitionRequestQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    get facetInput(): string | undefined;
}
export declare class PowerpackWidgetListStreamDefinitionRequestQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetListStreamDefinitionRequestQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetListStreamDefinitionRequestQueryGroupByOutputReference;
}
export interface PowerpackWidgetListStreamDefinitionRequestQuerySort {
    /**
    * The facet path for the column.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#column Powerpack#column}
    */
    readonly column: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetListStreamDefinitionRequestQuerySortToTerraform(struct?: PowerpackWidgetListStreamDefinitionRequestQuerySortOutputReference | PowerpackWidgetListStreamDefinitionRequestQuerySort): any;
export declare function powerpackWidgetListStreamDefinitionRequestQuerySortToHclTerraform(struct?: PowerpackWidgetListStreamDefinitionRequestQuerySortOutputReference | PowerpackWidgetListStreamDefinitionRequestQuerySort): any;
export declare class PowerpackWidgetListStreamDefinitionRequestQuerySortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetListStreamDefinitionRequestQuerySort | undefined;
    set internalValue(value: PowerpackWidgetListStreamDefinitionRequestQuerySort | undefined);
    private _column?;
    get column(): string;
    set column(value: string);
    get columnInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetListStreamDefinitionRequestQuery {
    /**
    * Specifies the field for logs pattern clustering. Can only be used with `logs_pattern_stream`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#clustering_pattern_field_path Powerpack#clustering_pattern_field_path}
    */
    readonly clusteringPatternFieldPath?: string;
    /**
    * Source from which to query items to display in the stream. Valid values are `logs_stream`, `audit_stream`, `ci_pipeline_stream`, `ci_test_stream`, `rum_issue_stream`, `apm_issue_stream`, `trace_stream`, `logs_issue_stream`, `logs_pattern_stream`, `logs_transaction_stream`, `event_stream`, `rum_stream`, `llm_observability_stream`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#data_source Powerpack#data_source}
    */
    readonly dataSource: string;
    /**
    * Size of events displayed in widget. Required if `data_source` is `event_stream`. Valid values are `s`, `l`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#event_size Powerpack#event_size}
    */
    readonly eventSize?: string;
    /**
    * List of indexes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#indexes Powerpack#indexes}
    */
    readonly indexes?: string[];
    /**
    * Widget query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query_string Powerpack#query_string}
    */
    readonly queryString?: string;
    /**
    * Storage location (private beta).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#storage Powerpack#storage}
    */
    readonly storage?: string;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetListStreamDefinitionRequestQueryGroupBy[] | cdktn.IResolvable;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort Powerpack#sort}
    */
    readonly sort?: PowerpackWidgetListStreamDefinitionRequestQuerySort;
}
export declare function powerpackWidgetListStreamDefinitionRequestQueryToTerraform(struct?: PowerpackWidgetListStreamDefinitionRequestQueryOutputReference | PowerpackWidgetListStreamDefinitionRequestQuery): any;
export declare function powerpackWidgetListStreamDefinitionRequestQueryToHclTerraform(struct?: PowerpackWidgetListStreamDefinitionRequestQueryOutputReference | PowerpackWidgetListStreamDefinitionRequestQuery): any;
export declare class PowerpackWidgetListStreamDefinitionRequestQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetListStreamDefinitionRequestQuery | undefined;
    set internalValue(value: PowerpackWidgetListStreamDefinitionRequestQuery | undefined);
    private _clusteringPatternFieldPath?;
    get clusteringPatternFieldPath(): string;
    set clusteringPatternFieldPath(value: string);
    resetClusteringPatternFieldPath(): void;
    get clusteringPatternFieldPathInput(): string | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _eventSize?;
    get eventSize(): string;
    set eventSize(value: string);
    resetEventSize(): void;
    get eventSizeInput(): string | undefined;
    private _indexes?;
    get indexes(): string[];
    set indexes(value: string[]);
    resetIndexes(): void;
    get indexesInput(): string[] | undefined;
    private _queryString?;
    get queryString(): string;
    set queryString(value: string);
    resetQueryString(): void;
    get queryStringInput(): string | undefined;
    private _storage?;
    get storage(): string;
    set storage(value: string);
    resetStorage(): void;
    get storageInput(): string | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetListStreamDefinitionRequestQueryGroupByList;
    putGroupBy(value: PowerpackWidgetListStreamDefinitionRequestQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetListStreamDefinitionRequestQueryGroupBy[] | undefined;
    private _sort;
    get sort(): PowerpackWidgetListStreamDefinitionRequestQuerySortOutputReference;
    putSort(value: PowerpackWidgetListStreamDefinitionRequestQuerySort): void;
    resetSort(): void;
    get sortInput(): PowerpackWidgetListStreamDefinitionRequestQuerySort | undefined;
}
export interface PowerpackWidgetListStreamDefinitionRequest {
    /**
    * Widget response format. Valid values are `event_list`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#response_format Powerpack#response_format}
    */
    readonly responseFormat: string;
    /**
    * columns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#columns Powerpack#columns}
    */
    readonly columns: PowerpackWidgetListStreamDefinitionRequestColumns[] | cdktn.IResolvable;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: PowerpackWidgetListStreamDefinitionRequestQuery;
}
export declare function powerpackWidgetListStreamDefinitionRequestToTerraform(struct?: PowerpackWidgetListStreamDefinitionRequest | cdktn.IResolvable): any;
export declare function powerpackWidgetListStreamDefinitionRequestToHclTerraform(struct?: PowerpackWidgetListStreamDefinitionRequest | cdktn.IResolvable): any;
export declare class PowerpackWidgetListStreamDefinitionRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetListStreamDefinitionRequest | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetListStreamDefinitionRequest | cdktn.IResolvable | undefined);
    private _responseFormat?;
    get responseFormat(): string;
    set responseFormat(value: string);
    get responseFormatInput(): string | undefined;
    private _columns;
    get columns(): PowerpackWidgetListStreamDefinitionRequestColumnsList;
    putColumns(value: PowerpackWidgetListStreamDefinitionRequestColumns[] | cdktn.IResolvable): void;
    get columnsInput(): cdktn.IResolvable | PowerpackWidgetListStreamDefinitionRequestColumns[] | undefined;
    private _query;
    get query(): PowerpackWidgetListStreamDefinitionRequestQueryOutputReference;
    putQuery(value: PowerpackWidgetListStreamDefinitionRequestQuery): void;
    get queryInput(): PowerpackWidgetListStreamDefinitionRequestQuery | undefined;
}
export declare class PowerpackWidgetListStreamDefinitionRequestList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetListStreamDefinitionRequest[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetListStreamDefinitionRequestOutputReference;
}
export interface PowerpackWidgetListStreamDefinition {
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title Powerpack#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_align Powerpack#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title. Default is 16.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_size Powerpack#title_size}
    */
    readonly titleSize?: string;
    /**
    * request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#request Powerpack#request}
    */
    readonly request: PowerpackWidgetListStreamDefinitionRequest[] | cdktn.IResolvable;
}
export declare function powerpackWidgetListStreamDefinitionToTerraform(struct?: PowerpackWidgetListStreamDefinitionOutputReference | PowerpackWidgetListStreamDefinition): any;
export declare function powerpackWidgetListStreamDefinitionToHclTerraform(struct?: PowerpackWidgetListStreamDefinitionOutputReference | PowerpackWidgetListStreamDefinition): any;
export declare class PowerpackWidgetListStreamDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetListStreamDefinition | undefined;
    set internalValue(value: PowerpackWidgetListStreamDefinition | undefined);
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _request;
    get request(): PowerpackWidgetListStreamDefinitionRequestList;
    putRequest(value: PowerpackWidgetListStreamDefinitionRequest[] | cdktn.IResolvable): void;
    get requestInput(): cdktn.IResolvable | PowerpackWidgetListStreamDefinitionRequest[] | undefined;
}
export interface PowerpackWidgetLogStreamDefinitionSort {
    /**
    * The facet path for the column.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#column Powerpack#column}
    */
    readonly column: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetLogStreamDefinitionSortToTerraform(struct?: PowerpackWidgetLogStreamDefinitionSortOutputReference | PowerpackWidgetLogStreamDefinitionSort): any;
export declare function powerpackWidgetLogStreamDefinitionSortToHclTerraform(struct?: PowerpackWidgetLogStreamDefinitionSortOutputReference | PowerpackWidgetLogStreamDefinitionSort): any;
export declare class PowerpackWidgetLogStreamDefinitionSortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetLogStreamDefinitionSort | undefined;
    set internalValue(value: PowerpackWidgetLogStreamDefinitionSort | undefined);
    private _column?;
    get column(): string;
    set column(value: string);
    get columnInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetLogStreamDefinition {
    /**
    * Stringified list of columns to use, for example: `["column1","column2","column3"]`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#columns Powerpack#columns}
    */
    readonly columns?: string[];
    /**
    * Hide any portion of the widget's timeframe that is incomplete due to cost data not being available.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_incomplete_cost_data Powerpack#hide_incomplete_cost_data}
    */
    readonly hideIncompleteCostData?: boolean | cdktn.IResolvable;
    /**
    * An array of index names to query in the stream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#indexes Powerpack#indexes}
    */
    readonly indexes?: string[];
    /**
    * The timeframe to use when displaying the widget. Valid values are `1m`, `5m`, `10m`, `15m`, `30m`, `1h`, `4h`, `1d`, `2d`, `1w`, `1mo`, `3mo`, `6mo`, `week_to_date`, `month_to_date`, `1y`, `alert`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#live_span Powerpack#live_span}
    */
    readonly liveSpan?: string;
    /**
    * The number of log lines to display. Valid values are `inline`, `expanded-md`, `expanded-lg`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#message_display Powerpack#message_display}
    */
    readonly messageDisplay?: string;
    /**
    * The query to use in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query?: string;
    /**
    * If the date column should be displayed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#show_date_column Powerpack#show_date_column}
    */
    readonly showDateColumn?: boolean | cdktn.IResolvable;
    /**
    * If the message column should be displayed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#show_message_column Powerpack#show_message_column}
    */
    readonly showMessageColumn?: boolean | cdktn.IResolvable;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title Powerpack#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_align Powerpack#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_size Powerpack#title_size}
    */
    readonly titleSize?: string;
    /**
    * sort block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort Powerpack#sort}
    */
    readonly sort?: PowerpackWidgetLogStreamDefinitionSort;
}
export declare function powerpackWidgetLogStreamDefinitionToTerraform(struct?: PowerpackWidgetLogStreamDefinitionOutputReference | PowerpackWidgetLogStreamDefinition): any;
export declare function powerpackWidgetLogStreamDefinitionToHclTerraform(struct?: PowerpackWidgetLogStreamDefinitionOutputReference | PowerpackWidgetLogStreamDefinition): any;
export declare class PowerpackWidgetLogStreamDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetLogStreamDefinition | undefined;
    set internalValue(value: PowerpackWidgetLogStreamDefinition | undefined);
    private _columns?;
    get columns(): string[];
    set columns(value: string[]);
    resetColumns(): void;
    get columnsInput(): string[] | undefined;
    private _hideIncompleteCostData?;
    get hideIncompleteCostData(): boolean | cdktn.IResolvable;
    set hideIncompleteCostData(value: boolean | cdktn.IResolvable);
    resetHideIncompleteCostData(): void;
    get hideIncompleteCostDataInput(): boolean | cdktn.IResolvable | undefined;
    private _indexes?;
    get indexes(): string[];
    set indexes(value: string[]);
    resetIndexes(): void;
    get indexesInput(): string[] | undefined;
    private _liveSpan?;
    get liveSpan(): string;
    set liveSpan(value: string);
    resetLiveSpan(): void;
    get liveSpanInput(): string | undefined;
    private _messageDisplay?;
    get messageDisplay(): string;
    set messageDisplay(value: string);
    resetMessageDisplay(): void;
    get messageDisplayInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
    private _showDateColumn?;
    get showDateColumn(): boolean | cdktn.IResolvable;
    set showDateColumn(value: boolean | cdktn.IResolvable);
    resetShowDateColumn(): void;
    get showDateColumnInput(): boolean | cdktn.IResolvable | undefined;
    private _showMessageColumn?;
    get showMessageColumn(): boolean | cdktn.IResolvable;
    set showMessageColumn(value: boolean | cdktn.IResolvable);
    resetShowMessageColumn(): void;
    get showMessageColumnInput(): boolean | cdktn.IResolvable | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
    private _sort;
    get sort(): PowerpackWidgetLogStreamDefinitionSortOutputReference;
    putSort(value: PowerpackWidgetLogStreamDefinitionSort): void;
    resetSort(): void;
    get sortInput(): PowerpackWidgetLogStreamDefinitionSort | undefined;
}
export interface PowerpackWidgetManageStatusDefinition {
    /**
    * Whether to colorize text or background. Valid values are `background`, `text`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#color_preference Powerpack#color_preference}
    */
    readonly colorPreference?: string;
    /**
    * The display setting to use. Valid values are `counts`, `countsAndList`, `list`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#display_format Powerpack#display_format}
    */
    readonly displayFormat?: string;
    /**
    * A Boolean indicating whether to hide empty categories.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_zero_counts Powerpack#hide_zero_counts}
    */
    readonly hideZeroCounts?: boolean | cdktn.IResolvable;
    /**
    * The query to use in the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#query Powerpack#query}
    */
    readonly query: string;
    /**
    * A Boolean indicating whether to show when monitors/groups last triggered.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#show_last_triggered Powerpack#show_last_triggered}
    */
    readonly showLastTriggered?: boolean | cdktn.IResolvable;
    /**
    * Whether to show the priorities column.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#show_priority Powerpack#show_priority}
    */
    readonly showPriority?: boolean | cdktn.IResolvable;
    /**
    * The method to sort the monitors. Valid values are `name`, `group`, `status`, `tags`, `triggered`, `group,asc`, `group,desc`, `name,asc`, `name,desc`, `status,asc`, `status,desc`, `tags,asc`, `tags,desc`, `triggered,asc`, `triggered,desc`, `priority,asc`, `priority,desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort Powerpack#sort}
    */
    readonly sort?: string;
    /**
    * The summary type to use. Valid values are `monitors`, `groups`, `combined`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#summary_type Powerpack#summary_type}
    */
    readonly summaryType?: string;
    /**
    * The title of the widget.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title Powerpack#title}
    */
    readonly title?: string;
    /**
    * The alignment of the widget's title. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_align Powerpack#title_align}
    */
    readonly titleAlign?: string;
    /**
    * The size of the widget's title (defaults to 16).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#title_size Powerpack#title_size}
    */
    readonly titleSize?: string;
}
export declare function powerpackWidgetManageStatusDefinitionToTerraform(struct?: PowerpackWidgetManageStatusDefinitionOutputReference | PowerpackWidgetManageStatusDefinition): any;
export declare function powerpackWidgetManageStatusDefinitionToHclTerraform(struct?: PowerpackWidgetManageStatusDefinitionOutputReference | PowerpackWidgetManageStatusDefinition): any;
export declare class PowerpackWidgetManageStatusDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetManageStatusDefinition | undefined;
    set internalValue(value: PowerpackWidgetManageStatusDefinition | undefined);
    private _colorPreference?;
    get colorPreference(): string;
    set colorPreference(value: string);
    resetColorPreference(): void;
    get colorPreferenceInput(): string | undefined;
    private _displayFormat?;
    get displayFormat(): string;
    set displayFormat(value: string);
    resetDisplayFormat(): void;
    get displayFormatInput(): string | undefined;
    private _hideZeroCounts?;
    get hideZeroCounts(): boolean | cdktn.IResolvable;
    set hideZeroCounts(value: boolean | cdktn.IResolvable);
    resetHideZeroCounts(): void;
    get hideZeroCountsInput(): boolean | cdktn.IResolvable | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _showLastTriggered?;
    get showLastTriggered(): boolean | cdktn.IResolvable;
    set showLastTriggered(value: boolean | cdktn.IResolvable);
    resetShowLastTriggered(): void;
    get showLastTriggeredInput(): boolean | cdktn.IResolvable | undefined;
    private _showPriority?;
    get showPriority(): boolean | cdktn.IResolvable;
    set showPriority(value: boolean | cdktn.IResolvable);
    resetShowPriority(): void;
    get showPriorityInput(): boolean | cdktn.IResolvable | undefined;
    private _sort?;
    get sort(): string;
    set sort(value: string);
    resetSort(): void;
    get sortInput(): string | undefined;
    private _summaryType?;
    get summaryType(): string;
    set summaryType(value: string);
    resetSummaryType(): void;
    get summaryTypeInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _titleAlign?;
    get titleAlign(): string;
    set titleAlign(value: string);
    resetTitleAlign(): void;
    get titleAlignInput(): string | undefined;
    private _titleSize?;
    get titleSize(): string;
    set titleSize(value: string);
    resetTitleSize(): void;
    get titleSizeInput(): string | undefined;
}
export interface PowerpackWidgetNoteDefinition {
    /**
    * The background color of the note.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#background_color Powerpack#background_color}
    */
    readonly backgroundColor?: string;
    /**
    * The content of the note.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#content Powerpack#content}
    */
    readonly content: string;
    /**
    * The size of the text.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#font_size Powerpack#font_size}
    */
    readonly fontSize?: string;
    /**
    * Whether to add padding or not. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#has_padding Powerpack#has_padding}
    */
    readonly hasPadding?: boolean | cdktn.IResolvable;
    /**
    * Whether to show a tick or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#show_tick Powerpack#show_tick}
    */
    readonly showTick?: boolean | cdktn.IResolvable;
    /**
    * The alignment of the widget's text. Valid values are `center`, `left`, `right`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#text_align Powerpack#text_align}
    */
    readonly textAlign?: string;
    /**
    * When `tick = true`, a string indicating on which side of the widget the tick should be displayed. Valid values are `bottom`, `left`, `right`, `top`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#tick_edge Powerpack#tick_edge}
    */
    readonly tickEdge?: string;
    /**
    * When `tick = true`, a string with a percent sign indicating the position of the tick, for example: `tick_pos = "50%"` is centered alignment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#tick_pos Powerpack#tick_pos}
    */
    readonly tickPos?: string;
    /**
    * The vertical alignment for the widget. Valid values are `center`, `top`, `bottom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#vertical_align Powerpack#vertical_align}
    */
    readonly verticalAlign?: string;
}
export declare function powerpackWidgetNoteDefinitionToTerraform(struct?: PowerpackWidgetNoteDefinitionOutputReference | PowerpackWidgetNoteDefinition): any;
export declare function powerpackWidgetNoteDefinitionToHclTerraform(struct?: PowerpackWidgetNoteDefinitionOutputReference | PowerpackWidgetNoteDefinition): any;
export declare class PowerpackWidgetNoteDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetNoteDefinition | undefined;
    set internalValue(value: PowerpackWidgetNoteDefinition | undefined);
    private _backgroundColor?;
    get backgroundColor(): string;
    set backgroundColor(value: string);
    resetBackgroundColor(): void;
    get backgroundColorInput(): string | undefined;
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _fontSize?;
    get fontSize(): string;
    set fontSize(value: string);
    resetFontSize(): void;
    get fontSizeInput(): string | undefined;
    private _hasPadding?;
    get hasPadding(): boolean | cdktn.IResolvable;
    set hasPadding(value: boolean | cdktn.IResolvable);
    resetHasPadding(): void;
    get hasPaddingInput(): boolean | cdktn.IResolvable | undefined;
    private _showTick?;
    get showTick(): boolean | cdktn.IResolvable;
    set showTick(value: boolean | cdktn.IResolvable);
    resetShowTick(): void;
    get showTickInput(): boolean | cdktn.IResolvable | undefined;
    private _textAlign?;
    get textAlign(): string;
    set textAlign(value: string);
    resetTextAlign(): void;
    get textAlignInput(): string | undefined;
    private _tickEdge?;
    get tickEdge(): string;
    set tickEdge(value: string);
    resetTickEdge(): void;
    get tickEdgeInput(): string | undefined;
    private _tickPos?;
    get tickPos(): string;
    set tickPos(value: string);
    resetTickPos(): void;
    get tickPosInput(): string | undefined;
    private _verticalAlign?;
    get verticalAlign(): string;
    set verticalAlign(value: string);
    resetVerticalAlign(): void;
    get verticalAlignInput(): string | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionCustomLink {
    /**
    * The flag for toggling context menu link visibility.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#is_hidden Powerpack#is_hidden}
    */
    readonly isHidden?: boolean | cdktn.IResolvable;
    /**
    * The label for the custom link URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label?: string;
    /**
    * The URL of the custom link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#link Powerpack#link}
    */
    readonly link?: string;
    /**
    * The label ID that refers to a context menu link item. When `override_label` is provided, the client request omits the label field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#override_label Powerpack#override_label}
    */
    readonly overrideLabel?: string;
}
export declare function powerpackWidgetQueryTableDefinitionCustomLinkToTerraform(struct?: PowerpackWidgetQueryTableDefinitionCustomLink | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryTableDefinitionCustomLinkToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionCustomLink | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryTableDefinitionCustomLinkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryTableDefinitionCustomLink | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionCustomLink | cdktn.IResolvable | undefined);
    private _isHidden?;
    get isHidden(): boolean | cdktn.IResolvable;
    set isHidden(value: boolean | cdktn.IResolvable);
    resetIsHidden(): void;
    get isHiddenInput(): boolean | cdktn.IResolvable | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _link?;
    get link(): string;
    set link(value: string);
    resetLink(): void;
    get linkInput(): string | undefined;
    private _overrideLabel?;
    get overrideLabel(): string;
    set overrideLabel(value: string);
    resetOverrideLabel(): void;
    get overrideLabelInput(): string | undefined;
}
export declare class PowerpackWidgetQueryTableDefinitionCustomLinkList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryTableDefinitionCustomLink[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryTableDefinitionCustomLinkOutputReference;
}
export interface PowerpackWidgetQueryTableDefinitionRequestApmQueryComputeQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetQueryTableDefinitionRequestApmQueryComputeQueryToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestApmQueryComputeQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestApmQueryComputeQuery): any;
export declare function powerpackWidgetQueryTableDefinitionRequestApmQueryComputeQueryToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestApmQueryComputeQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestApmQueryComputeQuery): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestApmQueryComputeQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestApmQueryComputeQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestApmQueryComputeQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupBySortQuery {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order: string;
}
export declare function powerpackWidgetQueryTableDefinitionRequestApmQueryGroupBySortQueryToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupBySortQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupBySortQuery): any;
export declare function powerpackWidgetQueryTableDefinitionRequestApmQueryGroupBySortQueryToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupBySortQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupBySortQuery): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupBySortQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupBySortQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupBySortQuery | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupBy {
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * The maximum number of items in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#limit Powerpack#limit}
    */
    readonly limit?: number;
    /**
    * sort_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#sort_query Powerpack#sort_query}
    */
    readonly sortQuery?: PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupBySortQuery;
}
export declare function powerpackWidgetQueryTableDefinitionRequestApmQueryGroupByToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupBy | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryTableDefinitionRequestApmQueryGroupByToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupBy | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupBy | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupBy | cdktn.IResolvable | undefined);
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _sortQuery;
    get sortQuery(): PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupBySortQueryOutputReference;
    putSortQuery(value: PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupBySortQuery): void;
    resetSortQuery(): void;
    get sortQueryInput(): PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupBySortQuery | undefined;
}
export declare class PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupByList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupByOutputReference;
}
export interface PowerpackWidgetQueryTableDefinitionRequestApmQueryMultiCompute {
    /**
    * The aggregation method.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#aggregation Powerpack#aggregation}
    */
    readonly aggregation: string;
    /**
    * The facet name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#facet Powerpack#facet}
    */
    readonly facet?: string;
    /**
    * Define the time interval in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#interval Powerpack#interval}
    */
    readonly interval?: number;
}
export declare function powerpackWidgetQueryTableDefinitionRequestApmQueryMultiComputeToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryTableDefinitionRequestApmQueryMultiComputeToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestApmQueryMultiComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestApmQueryMultiCompute | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    get aggregationInput(): string | undefined;
    private _facet?;
    get facet(): string;
    set facet(value: string);
    resetFacet(): void;
    get facetInput(): string | undefined;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    resetInterval(): void;
    get intervalInput(): number | undefined;
}
export declare class PowerpackWidgetQueryTableDefinitionRequestApmQueryMultiComputeList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryTableDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryTableDefinitionRequestApmQueryMultiComputeOutputReference;
}
export interface PowerpackWidgetQueryTableDefinitionRequestApmQuery {
    /**
    * The name of the index to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#index Powerpack#index}
    */
    readonly index: string;
    /**
    * The search query to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#search_query Powerpack#search_query}
    */
    readonly searchQuery?: string;
    /**
    * compute_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#compute_query Powerpack#compute_query}
    */
    readonly computeQuery?: PowerpackWidgetQueryTableDefinitionRequestApmQueryComputeQuery;
    /**
    * group_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#group_by Powerpack#group_by}
    */
    readonly groupBy?: PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable;
    /**
    * multi_compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#multi_compute Powerpack#multi_compute}
    */
    readonly multiCompute?: PowerpackWidgetQueryTableDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable;
}
export declare function powerpackWidgetQueryTableDefinitionRequestApmQueryToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestApmQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestApmQuery): any;
export declare function powerpackWidgetQueryTableDefinitionRequestApmQueryToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestApmQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestApmQuery): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestApmQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestApmQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestApmQuery | undefined);
    private _index?;
    get index(): string;
    set index(value: string);
    get indexInput(): string | undefined;
    private _searchQuery?;
    get searchQuery(): string;
    set searchQuery(value: string);
    resetSearchQuery(): void;
    get searchQueryInput(): string | undefined;
    private _computeQuery;
    get computeQuery(): PowerpackWidgetQueryTableDefinitionRequestApmQueryComputeQueryOutputReference;
    putComputeQuery(value: PowerpackWidgetQueryTableDefinitionRequestApmQueryComputeQuery): void;
    resetComputeQuery(): void;
    get computeQueryInput(): PowerpackWidgetQueryTableDefinitionRequestApmQueryComputeQuery | undefined;
    private _groupBy;
    get groupBy(): PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupByList;
    putGroupBy(value: PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupBy[] | cdktn.IResolvable): void;
    resetGroupBy(): void;
    get groupByInput(): cdktn.IResolvable | PowerpackWidgetQueryTableDefinitionRequestApmQueryGroupBy[] | undefined;
    private _multiCompute;
    get multiCompute(): PowerpackWidgetQueryTableDefinitionRequestApmQueryMultiComputeList;
    putMultiCompute(value: PowerpackWidgetQueryTableDefinitionRequestApmQueryMultiCompute[] | cdktn.IResolvable): void;
    resetMultiCompute(): void;
    get multiComputeInput(): cdktn.IResolvable | PowerpackWidgetQueryTableDefinitionRequestApmQueryMultiCompute[] | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestApmStatsQueryColumns {
    /**
    * A user-assigned alias for the column.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#alias Powerpack#alias}
    */
    readonly alias?: string;
    /**
    * A list of display modes for each table cell. Valid values are `number`, `bar`, `trend`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#cell_display_mode Powerpack#cell_display_mode}
    */
    readonly cellDisplayMode?: string;
    /**
    * The column name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * Widget sorting methods. Valid values are `asc`, `desc`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order?: string;
}
export declare function powerpackWidgetQueryTableDefinitionRequestApmStatsQueryColumnsToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestApmStatsQueryColumns | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryTableDefinitionRequestApmStatsQueryColumnsToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestApmStatsQueryColumns | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestApmStatsQueryColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestApmStatsQueryColumns | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestApmStatsQueryColumns | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _cellDisplayMode?;
    get cellDisplayMode(): string;
    set cellDisplayMode(value: string);
    resetCellDisplayMode(): void;
    get cellDisplayModeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export declare class PowerpackWidgetQueryTableDefinitionRequestApmStatsQueryColumnsList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryTableDefinitionRequestApmStatsQueryColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryTableDefinitionRequestApmStatsQueryColumnsOutputReference;
}
export interface PowerpackWidgetQueryTableDefinitionRequestApmStatsQuery {
    /**
    * The environment name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#env Powerpack#env}
    */
    readonly env: string;
    /**
    * The operation name associated with the service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#name Powerpack#name}
    */
    readonly name: string;
    /**
    * The organization's host group name and value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#primary_tag Powerpack#primary_tag}
    */
    readonly primaryTag: string;
    /**
    * The resource name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#resource Powerpack#resource}
    */
    readonly resource?: string;
    /**
    * The level of detail for the request. Valid values are `service`, `resource`, `span`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#row_type Powerpack#row_type}
    */
    readonly rowType: string;
    /**
    * The service name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#service Powerpack#service}
    */
    readonly service: string;
    /**
    * columns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#columns Powerpack#columns}
    */
    readonly columns?: PowerpackWidgetQueryTableDefinitionRequestApmStatsQueryColumns[] | cdktn.IResolvable;
}
export declare function powerpackWidgetQueryTableDefinitionRequestApmStatsQueryToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestApmStatsQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestApmStatsQuery): any;
export declare function powerpackWidgetQueryTableDefinitionRequestApmStatsQueryToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestApmStatsQueryOutputReference | PowerpackWidgetQueryTableDefinitionRequestApmStatsQuery): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestApmStatsQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestApmStatsQuery | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestApmStatsQuery | undefined);
    private _env?;
    get env(): string;
    set env(value: string);
    get envInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _primaryTag?;
    get primaryTag(): string;
    set primaryTag(value: string);
    get primaryTagInput(): string | undefined;
    private _resource?;
    get resource(): string;
    set resource(value: string);
    resetResource(): void;
    get resourceInput(): string | undefined;
    private _rowType?;
    get rowType(): string;
    set rowType(value: string);
    get rowTypeInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    private _columns;
    get columns(): PowerpackWidgetQueryTableDefinitionRequestApmStatsQueryColumnsList;
    putColumns(value: PowerpackWidgetQueryTableDefinitionRequestApmStatsQueryColumns[] | cdktn.IResolvable): void;
    resetColumns(): void;
    get columnsInput(): cdktn.IResolvable | PowerpackWidgetQueryTableDefinitionRequestApmStatsQueryColumns[] | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestConditionalFormats {
    /**
    * The comparator to use. Valid values are `=`, `>`, `>=`, `<`, `<=`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#comparator Powerpack#comparator}
    */
    readonly comparator: string;
    /**
    * The color palette to apply to the background, same values available as palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_bg_color Powerpack#custom_bg_color}
    */
    readonly customBgColor?: string;
    /**
    * The color palette to apply to the foreground, same values available as palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_fg_color Powerpack#custom_fg_color}
    */
    readonly customFgColor?: string;
    /**
    * Setting this to True hides values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_value Powerpack#hide_value}
    */
    readonly hideValue?: boolean | cdktn.IResolvable;
    /**
    * Displays an image as the background.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#image_url Powerpack#image_url}
    */
    readonly imageUrl?: string;
    /**
    * The metric from the request to correlate with this conditional format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
    /**
    * The color palette to apply. Valid values are `blue`, `custom_bg`, `custom_image`, `custom_text`, `gray_on_white`, `grey`, `green`, `orange`, `red`, `red_on_white`, `white_on_gray`, `white_on_green`, `green_on_white`, `white_on_red`, `white_on_yellow`, `yellow_on_white`, `black_on_light_yellow`, `black_on_light_green`, `black_on_light_red`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette Powerpack#palette}
    */
    readonly palette: string;
    /**
    * Defines the displayed timeframe.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#timeframe Powerpack#timeframe}
    */
    readonly timeframe?: string;
    /**
    * A value for the comparator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#value Powerpack#value}
    */
    readonly value: number;
}
export declare function powerpackWidgetQueryTableDefinitionRequestConditionalFormatsToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestConditionalFormats | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryTableDefinitionRequestConditionalFormatsToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestConditionalFormats | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestConditionalFormatsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestConditionalFormats | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestConditionalFormats | cdktn.IResolvable | undefined);
    private _comparator?;
    get comparator(): string;
    set comparator(value: string);
    get comparatorInput(): string | undefined;
    private _customBgColor?;
    get customBgColor(): string;
    set customBgColor(value: string);
    resetCustomBgColor(): void;
    get customBgColorInput(): string | undefined;
    private _customFgColor?;
    get customFgColor(): string;
    set customFgColor(value: string);
    resetCustomFgColor(): void;
    get customFgColorInput(): string | undefined;
    private _hideValue?;
    get hideValue(): boolean | cdktn.IResolvable;
    set hideValue(value: boolean | cdktn.IResolvable);
    resetHideValue(): void;
    get hideValueInput(): boolean | cdktn.IResolvable | undefined;
    private _imageUrl?;
    get imageUrl(): string;
    set imageUrl(value: string);
    resetImageUrl(): void;
    get imageUrlInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _palette?;
    get palette(): string;
    set palette(value: string);
    get paletteInput(): string | undefined;
    private _timeframe?;
    get timeframe(): string;
    set timeframe(value: string);
    resetTimeframe(): void;
    get timeframeInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class PowerpackWidgetQueryTableDefinitionRequestConditionalFormatsList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryTableDefinitionRequestConditionalFormats[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryTableDefinitionRequestConditionalFormatsOutputReference;
}
export interface PowerpackWidgetQueryTableDefinitionRequestFormulaCellDisplayModeOptions {
    /**
    * The type of trend line to display. Valid values are `area`, `line`, `bars`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#trend_type Powerpack#trend_type}
    */
    readonly trendType?: string;
    /**
    * The scale of the y-axis. Valid values are `shared`, `independent`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#y_scale Powerpack#y_scale}
    */
    readonly yScale?: string;
}
export declare function powerpackWidgetQueryTableDefinitionRequestFormulaCellDisplayModeOptionsToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestFormulaCellDisplayModeOptionsOutputReference | PowerpackWidgetQueryTableDefinitionRequestFormulaCellDisplayModeOptions): any;
export declare function powerpackWidgetQueryTableDefinitionRequestFormulaCellDisplayModeOptionsToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestFormulaCellDisplayModeOptionsOutputReference | PowerpackWidgetQueryTableDefinitionRequestFormulaCellDisplayModeOptions): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestFormulaCellDisplayModeOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestFormulaCellDisplayModeOptions | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestFormulaCellDisplayModeOptions | undefined);
    private _trendType?;
    get trendType(): string;
    set trendType(value: string);
    resetTrendType(): void;
    get trendTypeInput(): string | undefined;
    private _yScale?;
    get yScale(): string;
    set yScale(value: string);
    resetYScale(): void;
    get yScaleInput(): string | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestFormulaConditionalFormats {
    /**
    * The comparator to use. Valid values are `=`, `>`, `>=`, `<`, `<=`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#comparator Powerpack#comparator}
    */
    readonly comparator: string;
    /**
    * The color palette to apply to the background, same values available as palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_bg_color Powerpack#custom_bg_color}
    */
    readonly customBgColor?: string;
    /**
    * The color palette to apply to the foreground, same values available as palette.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#custom_fg_color Powerpack#custom_fg_color}
    */
    readonly customFgColor?: string;
    /**
    * Setting this to True hides values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#hide_value Powerpack#hide_value}
    */
    readonly hideValue?: boolean | cdktn.IResolvable;
    /**
    * Displays an image as the background.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#image_url Powerpack#image_url}
    */
    readonly imageUrl?: string;
    /**
    * The metric from the request to correlate with this conditional format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#metric Powerpack#metric}
    */
    readonly metric?: string;
    /**
    * The color palette to apply. Valid values are `blue`, `custom_bg`, `custom_image`, `custom_text`, `gray_on_white`, `grey`, `green`, `orange`, `red`, `red_on_white`, `white_on_gray`, `white_on_green`, `green_on_white`, `white_on_red`, `white_on_yellow`, `yellow_on_white`, `black_on_light_yellow`, `black_on_light_green`, `black_on_light_red`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#palette Powerpack#palette}
    */
    readonly palette: string;
    /**
    * Defines the displayed timeframe.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#timeframe Powerpack#timeframe}
    */
    readonly timeframe?: string;
    /**
    * A value for the comparator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#value Powerpack#value}
    */
    readonly value: number;
}
export declare function powerpackWidgetQueryTableDefinitionRequestFormulaConditionalFormatsToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable): any;
export declare function powerpackWidgetQueryTableDefinitionRequestFormulaConditionalFormatsToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestFormulaConditionalFormatsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestFormulaConditionalFormats | cdktn.IResolvable | undefined);
    private _comparator?;
    get comparator(): string;
    set comparator(value: string);
    get comparatorInput(): string | undefined;
    private _customBgColor?;
    get customBgColor(): string;
    set customBgColor(value: string);
    resetCustomBgColor(): void;
    get customBgColorInput(): string | undefined;
    private _customFgColor?;
    get customFgColor(): string;
    set customFgColor(value: string);
    resetCustomFgColor(): void;
    get customFgColorInput(): string | undefined;
    private _hideValue?;
    get hideValue(): boolean | cdktn.IResolvable;
    set hideValue(value: boolean | cdktn.IResolvable);
    resetHideValue(): void;
    get hideValueInput(): boolean | cdktn.IResolvable | undefined;
    private _imageUrl?;
    get imageUrl(): string;
    set imageUrl(value: string);
    resetImageUrl(): void;
    get imageUrlInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    private _palette?;
    get palette(): string;
    set palette(value: string);
    get paletteInput(): string | undefined;
    private _timeframe?;
    get timeframe(): string;
    set timeframe(value: string);
    resetTimeframe(): void;
    get timeframeInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class PowerpackWidgetQueryTableDefinitionRequestFormulaConditionalFormatsList extends cdktn.ComplexList {
    internalValue?: PowerpackWidgetQueryTableDefinitionRequestFormulaConditionalFormats[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PowerpackWidgetQueryTableDefinitionRequestFormulaConditionalFormatsOutputReference;
}
export interface PowerpackWidgetQueryTableDefinitionRequestFormulaLimit {
    /**
    * The number of results to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#count Powerpack#count}
    */
    readonly count?: number;
    /**
    * The direction of the sort. Valid values are `asc`, `desc`. Defaults to `"desc"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#order Powerpack#order}
    */
    readonly order?: string;
}
export declare function powerpackWidgetQueryTableDefinitionRequestFormulaLimitToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestFormulaLimitOutputReference | PowerpackWidgetQueryTableDefinitionRequestFormulaLimit): any;
export declare function powerpackWidgetQueryTableDefinitionRequestFormulaLimitToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestFormulaLimitOutputReference | PowerpackWidgetQueryTableDefinitionRequestFormulaLimit): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestFormulaLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestFormulaLimit | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestFormulaLimit | undefined);
    private _count?;
    get count(): number;
    set count(value: number);
    resetCount(): void;
    get countInput(): number | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCanonical {
    /**
    * per unit name. If you want to represent megabytes/s, you set 'unit_name' = 'megabyte' and 'per_unit_name = 'second'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#per_unit_name Powerpack#per_unit_name}
    */
    readonly perUnitName?: string;
    /**
    * Unit name. It should be in singular form ('megabyte' and not 'megabytes')
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#unit_name Powerpack#unit_name}
    */
    readonly unitName: string;
}
export declare function powerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCanonicalToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference | PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCanonical): any;
export declare function powerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCanonicalToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference | PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCanonical): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCanonicalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCanonical | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCanonical | undefined);
    private _perUnitName?;
    get perUnitName(): string;
    set perUnitName(value: string);
    resetPerUnitName(): void;
    get perUnitNameInput(): string | undefined;
    private _unitName?;
    get unitName(): string;
    set unitName(value: string);
    get unitNameInput(): string | undefined;
}
export interface PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCustom {
    /**
    * Unit label
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/powerpack#label Powerpack#label}
    */
    readonly label: string;
}
export declare function powerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCustomToTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCustomOutputReference | PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCustom): any;
export declare function powerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCustomToHclTerraform(struct?: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCustomOutputReference | PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCustom): any;
export declare class PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCustom | undefined;
    set internalValue(value: PowerpackWidgetQueryTableDefinitionRequestFormulaNumberFormatUnitCustom | undefined);
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
}
