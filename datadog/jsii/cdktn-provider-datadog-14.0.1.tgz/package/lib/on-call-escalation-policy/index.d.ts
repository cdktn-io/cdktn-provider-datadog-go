/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OnCallEscalationPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * A human-readable name for the escalation policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_escalation_policy#name OnCallEscalationPolicy#name}
    */
    readonly name: string;
    /**
    * If true, pages will be automatically resolved if unacknowledged after the final step. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_escalation_policy#resolve_page_on_policy_end OnCallEscalationPolicy#resolve_page_on_policy_end}
    */
    readonly resolvePageOnPolicyEnd?: boolean | cdktn.IResolvable;
    /**
    * If set, policy will be retried this many times after the final step. Must be in the range 0-10. Value must be between 0 and 10. Defaults to `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_escalation_policy#retries OnCallEscalationPolicy#retries}
    */
    readonly retries?: number;
    /**
    * A list of team ids associated with the escalation policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_escalation_policy#teams OnCallEscalationPolicy#teams}
    */
    readonly teams?: string[];
    /**
    * step block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_escalation_policy#step OnCallEscalationPolicy#step}
    */
    readonly step?: OnCallEscalationPolicyStep[] | cdktn.IResolvable;
}
export interface OnCallEscalationPolicyStepTarget {
    /**
    * For schedule targets, specifies which on-call user to page. Valid values: `current` (default), `previous`, `next`. Valid values are `current`, `previous`, `next`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_escalation_policy#position OnCallEscalationPolicy#position}
    */
    readonly position?: string;
    /**
    * Targeted schedule ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_escalation_policy#schedule OnCallEscalationPolicy#schedule}
    */
    readonly schedule?: string;
    /**
    * Targeted team ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_escalation_policy#team OnCallEscalationPolicy#team}
    */
    readonly team?: string;
    /**
    * Targeted user ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_escalation_policy#user OnCallEscalationPolicy#user}
    */
    readonly user?: string;
}
export declare function onCallEscalationPolicyStepTargetToTerraform(struct?: OnCallEscalationPolicyStepTarget | cdktn.IResolvable): any;
export declare function onCallEscalationPolicyStepTargetToHclTerraform(struct?: OnCallEscalationPolicyStepTarget | cdktn.IResolvable): any;
export declare class OnCallEscalationPolicyStepTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OnCallEscalationPolicyStepTarget | cdktn.IResolvable | undefined;
    set internalValue(value: OnCallEscalationPolicyStepTarget | cdktn.IResolvable | undefined);
    private _position?;
    get position(): string;
    set position(value: string);
    resetPosition(): void;
    get positionInput(): string | undefined;
    private _schedule?;
    get schedule(): string;
    set schedule(value: string);
    resetSchedule(): void;
    get scheduleInput(): string | undefined;
    private _team?;
    get team(): string;
    set team(value: string);
    resetTeam(): void;
    get teamInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
}
export declare class OnCallEscalationPolicyStepTargetList extends cdktn.ComplexList {
    internalValue?: OnCallEscalationPolicyStepTarget[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OnCallEscalationPolicyStepTargetOutputReference;
}
export interface OnCallEscalationPolicyStep {
    /**
    * Specifies how this escalation step will assign targets. Can be `default` (page all targets at once) or `round-robin`. Valid values are `default`, `round-robin`. Defaults to `"default"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_escalation_policy#assignment OnCallEscalationPolicy#assignment}
    */
    readonly assignment?: string;
    /**
    * Defines how many seconds to wait before escalating to the next step. Value must be between 60 and 36000.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_escalation_policy#escalate_after_seconds OnCallEscalationPolicy#escalate_after_seconds}
    */
    readonly escalateAfterSeconds: number;
    /**
    * target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_escalation_policy#target OnCallEscalationPolicy#target}
    */
    readonly target?: OnCallEscalationPolicyStepTarget[] | cdktn.IResolvable;
}
export declare function onCallEscalationPolicyStepToTerraform(struct?: OnCallEscalationPolicyStep | cdktn.IResolvable): any;
export declare function onCallEscalationPolicyStepToHclTerraform(struct?: OnCallEscalationPolicyStep | cdktn.IResolvable): any;
export declare class OnCallEscalationPolicyStepOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OnCallEscalationPolicyStep | cdktn.IResolvable | undefined;
    set internalValue(value: OnCallEscalationPolicyStep | cdktn.IResolvable | undefined);
    private _assignment?;
    get assignment(): string;
    set assignment(value: string);
    resetAssignment(): void;
    get assignmentInput(): string | undefined;
    private _escalateAfterSeconds?;
    get escalateAfterSeconds(): number;
    set escalateAfterSeconds(value: number);
    get escalateAfterSecondsInput(): number | undefined;
    get id(): string;
    private _target;
    get target(): OnCallEscalationPolicyStepTargetList;
    putTarget(value: OnCallEscalationPolicyStepTarget[] | cdktn.IResolvable): void;
    resetTarget(): void;
    get targetInput(): cdktn.IResolvable | OnCallEscalationPolicyStepTarget[] | undefined;
}
export declare class OnCallEscalationPolicyStepList extends cdktn.ComplexList {
    internalValue?: OnCallEscalationPolicyStep[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OnCallEscalationPolicyStepOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_escalation_policy datadog_on_call_escalation_policy}
*/
export declare class OnCallEscalationPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_on_call_escalation_policy";
    /**
    * Generates CDKTN code for importing a OnCallEscalationPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OnCallEscalationPolicy to import
    * @param importFromId The id of the existing OnCallEscalationPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_escalation_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OnCallEscalationPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/on_call_escalation_policy datadog_on_call_escalation_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OnCallEscalationPolicyConfig
    */
    constructor(scope: Construct, id: string, config: OnCallEscalationPolicyConfig);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _resolvePageOnPolicyEnd?;
    get resolvePageOnPolicyEnd(): boolean | cdktn.IResolvable;
    set resolvePageOnPolicyEnd(value: boolean | cdktn.IResolvable);
    resetResolvePageOnPolicyEnd(): void;
    get resolvePageOnPolicyEndInput(): boolean | cdktn.IResolvable | undefined;
    private _retries?;
    get retries(): number;
    set retries(value: number);
    resetRetries(): void;
    get retriesInput(): number | undefined;
    private _teams?;
    get teams(): string[];
    set teams(value: string[]);
    resetTeams(): void;
    get teamsInput(): string[] | undefined;
    private _step;
    get step(): OnCallEscalationPolicyStepList;
    putStep(value: OnCallEscalationPolicyStep[] | cdktn.IResolvable): void;
    resetStep(): void;
    get stepInput(): cdktn.IResolvable | OnCallEscalationPolicyStep[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
