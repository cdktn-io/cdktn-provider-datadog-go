/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SyntheticsSuiteConfig extends cdktn.TerraformMetaArguments {
    /**
    * Message of the Synthetics suite.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_suite#message SyntheticsSuite#message}
    */
    readonly message?: string;
    /**
    * Name of the Synthetics suite.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_suite#name SyntheticsSuite#name}
    */
    readonly name: string;
    /**
    * A set of tags to associate with your synthetics suite.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_suite#tags SyntheticsSuite#tags}
    */
    readonly tags?: string[];
    /**
    * options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_suite#options SyntheticsSuite#options}
    */
    readonly options?: SyntheticsSuiteOptions[] | cdktn.IResolvable;
    /**
    * tests block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_suite#tests SyntheticsSuite#tests}
    */
    readonly tests?: SyntheticsSuiteTests[] | cdktn.IResolvable;
}
export interface SyntheticsSuiteOptions {
    /**
    * Alerting threshold for the suite. Value must be between 0.000000 and 1.000000.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_suite#alerting_threshold SyntheticsSuite#alerting_threshold}
    */
    readonly alertingThreshold: number;
}
export declare function syntheticsSuiteOptionsToTerraform(struct?: SyntheticsSuiteOptions | cdktn.IResolvable): any;
export declare function syntheticsSuiteOptionsToHclTerraform(struct?: SyntheticsSuiteOptions | cdktn.IResolvable): any;
export declare class SyntheticsSuiteOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsSuiteOptions | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsSuiteOptions | cdktn.IResolvable | undefined);
    private _alertingThreshold?;
    get alertingThreshold(): number;
    set alertingThreshold(value: number);
    get alertingThresholdInput(): number | undefined;
}
export declare class SyntheticsSuiteOptionsList extends cdktn.ComplexList {
    internalValue?: SyntheticsSuiteOptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsSuiteOptionsOutputReference;
}
export interface SyntheticsSuiteTests {
    /**
    * Alerting criticality for the test. Valid values are `ignore`, `critical`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_suite#alerting_criticality SyntheticsSuite#alerting_criticality}
    */
    readonly alertingCriticality?: string;
    /**
    * Public ID of the test.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_suite#public_id SyntheticsSuite#public_id}
    */
    readonly publicId: string;
}
export declare function syntheticsSuiteTestsToTerraform(struct?: SyntheticsSuiteTests | cdktn.IResolvable): any;
export declare function syntheticsSuiteTestsToHclTerraform(struct?: SyntheticsSuiteTests | cdktn.IResolvable): any;
export declare class SyntheticsSuiteTestsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SyntheticsSuiteTests | cdktn.IResolvable | undefined;
    set internalValue(value: SyntheticsSuiteTests | cdktn.IResolvable | undefined);
    private _alertingCriticality?;
    get alertingCriticality(): string;
    set alertingCriticality(value: string);
    resetAlertingCriticality(): void;
    get alertingCriticalityInput(): string | undefined;
    private _publicId?;
    get publicId(): string;
    set publicId(value: string);
    get publicIdInput(): string | undefined;
}
export declare class SyntheticsSuiteTestsList extends cdktn.ComplexList {
    internalValue?: SyntheticsSuiteTests[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SyntheticsSuiteTestsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_suite datadog_synthetics_suite}
*/
export declare class SyntheticsSuite extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_synthetics_suite";
    /**
    * Generates CDKTN code for importing a SyntheticsSuite resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SyntheticsSuite to import
    * @param importFromId The id of the existing SyntheticsSuite that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_suite#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SyntheticsSuite to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/synthetics_suite datadog_synthetics_suite} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SyntheticsSuiteConfig
    */
    constructor(scope: Construct, id: string, config: SyntheticsSuiteConfig);
    get id(): string;
    private _message?;
    get message(): string;
    set message(value: string);
    resetMessage(): void;
    get messageInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _options;
    get options(): SyntheticsSuiteOptionsList;
    putOptions(value: SyntheticsSuiteOptions[] | cdktn.IResolvable): void;
    resetOptions(): void;
    get optionsInput(): cdktn.IResolvable | SyntheticsSuiteOptions[] | undefined;
    private _tests;
    get tests(): SyntheticsSuiteTestsList;
    putTests(value: SyntheticsSuiteTests[] | cdktn.IResolvable): void;
    resetTests(): void;
    get testsInput(): cdktn.IResolvable | SyntheticsSuiteTests[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
