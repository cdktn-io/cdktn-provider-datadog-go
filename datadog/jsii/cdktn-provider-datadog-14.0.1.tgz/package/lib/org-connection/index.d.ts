/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OrgConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Set of connection types to enable for this connection (., metrics, logs).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/org_connection#connection_types OrgConnection#connection_types}
    */
    readonly connectionTypes: string[];
    /**
    * UUID of the sink (destination) organization. Must be a valid UUID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/org_connection#sink_org_id OrgConnection#sink_org_id}
    */
    readonly sinkOrgId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/org_connection datadog_org_connection}
*/
export declare class OrgConnection extends cdktn.TerraformResource {
    static readonly tfResourceType = "datadog_org_connection";
    /**
    * Generates CDKTN code for importing a OrgConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OrgConnection to import
    * @param importFromId The id of the existing OrgConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/org_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OrgConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/resources/org_connection datadog_org_connection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OrgConnectionConfig
    */
    constructor(scope: Construct, id: string, config: OrgConnectionConfig);
    private _connectionTypes?;
    get connectionTypes(): string[];
    set connectionTypes(value: string[]);
    get connectionTypesInput(): string[] | undefined;
    get createdAt(): string;
    get createdBy(): string;
    get id(): string;
    private _sinkOrgId?;
    get sinkOrgId(): string;
    set sinkOrgId(value: string);
    get sinkOrgIdInput(): string | undefined;
    get sinkOrgName(): string;
    get sourceOrgId(): string;
    get sourceOrgName(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
