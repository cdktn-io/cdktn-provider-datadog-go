/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogTeamConfig extends cdktn.TerraformMetaArguments {
    /**
    * Search query. Can be team name, team handle, or email of team member.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team#filter_keyword DataDatadogTeam#filter_keyword}
    */
    readonly filterKeyword?: string;
    /**
    * The team's identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team#team_id DataDatadogTeam#team_id}
    */
    readonly teamId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team datadog_team}
*/
export declare class DataDatadogTeam extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_team";
    /**
    * Generates CDKTN code for importing a DataDatadogTeam resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogTeam to import
    * @param importFromId The id of the existing DataDatadogTeam that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogTeam to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/team datadog_team} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogTeamConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogTeamConfig);
    get description(): string;
    private _filterKeyword?;
    get filterKeyword(): string;
    set filterKeyword(value: string);
    resetFilterKeyword(): void;
    get filterKeywordInput(): string | undefined;
    get handle(): string;
    get id(): string;
    get linkCount(): number;
    get name(): string;
    get summary(): string;
    private _teamId?;
    get teamId(): string;
    set teamId(value: string);
    resetTeamId(): void;
    get teamIdInput(): string | undefined;
    get userCount(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
