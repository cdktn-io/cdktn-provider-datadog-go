/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatadogOrganizationSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/organization_settings#settings DataDatadogOrganizationSettings#settings}
    */
    readonly settings?: DataDatadogOrganizationSettingsSettings[] | cdktn.IResolvable;
}
export interface DataDatadogOrganizationSettingsSettingsSaml {
}
export declare function dataDatadogOrganizationSettingsSettingsSamlToTerraform(struct?: DataDatadogOrganizationSettingsSettingsSaml | cdktn.IResolvable): any;
export declare function dataDatadogOrganizationSettingsSettingsSamlToHclTerraform(struct?: DataDatadogOrganizationSettingsSettingsSaml | cdktn.IResolvable): any;
export declare class DataDatadogOrganizationSettingsSettingsSamlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogOrganizationSettingsSettingsSaml | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogOrganizationSettingsSettingsSaml | cdktn.IResolvable | undefined);
    get enabled(): cdktn.IResolvable;
}
export declare class DataDatadogOrganizationSettingsSettingsSamlList extends cdktn.ComplexList {
    internalValue?: DataDatadogOrganizationSettingsSettingsSaml[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogOrganizationSettingsSettingsSamlOutputReference;
}
export interface DataDatadogOrganizationSettingsSettingsSamlAutocreateUsersDomains {
}
export declare function dataDatadogOrganizationSettingsSettingsSamlAutocreateUsersDomainsToTerraform(struct?: DataDatadogOrganizationSettingsSettingsSamlAutocreateUsersDomains | cdktn.IResolvable): any;
export declare function dataDatadogOrganizationSettingsSettingsSamlAutocreateUsersDomainsToHclTerraform(struct?: DataDatadogOrganizationSettingsSettingsSamlAutocreateUsersDomains | cdktn.IResolvable): any;
export declare class DataDatadogOrganizationSettingsSettingsSamlAutocreateUsersDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogOrganizationSettingsSettingsSamlAutocreateUsersDomains | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogOrganizationSettingsSettingsSamlAutocreateUsersDomains | cdktn.IResolvable | undefined);
    get domains(): string[];
    get enabled(): cdktn.IResolvable;
}
export declare class DataDatadogOrganizationSettingsSettingsSamlAutocreateUsersDomainsList extends cdktn.ComplexList {
    internalValue?: DataDatadogOrganizationSettingsSettingsSamlAutocreateUsersDomains[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogOrganizationSettingsSettingsSamlAutocreateUsersDomainsOutputReference;
}
export interface DataDatadogOrganizationSettingsSettingsSamlIdpInitiatedLogin {
}
export declare function dataDatadogOrganizationSettingsSettingsSamlIdpInitiatedLoginToTerraform(struct?: DataDatadogOrganizationSettingsSettingsSamlIdpInitiatedLogin | cdktn.IResolvable): any;
export declare function dataDatadogOrganizationSettingsSettingsSamlIdpInitiatedLoginToHclTerraform(struct?: DataDatadogOrganizationSettingsSettingsSamlIdpInitiatedLogin | cdktn.IResolvable): any;
export declare class DataDatadogOrganizationSettingsSettingsSamlIdpInitiatedLoginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogOrganizationSettingsSettingsSamlIdpInitiatedLogin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogOrganizationSettingsSettingsSamlIdpInitiatedLogin | cdktn.IResolvable | undefined);
    get enabled(): cdktn.IResolvable;
}
export declare class DataDatadogOrganizationSettingsSettingsSamlIdpInitiatedLoginList extends cdktn.ComplexList {
    internalValue?: DataDatadogOrganizationSettingsSettingsSamlIdpInitiatedLogin[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogOrganizationSettingsSettingsSamlIdpInitiatedLoginOutputReference;
}
export interface DataDatadogOrganizationSettingsSettingsSamlStrictMode {
}
export declare function dataDatadogOrganizationSettingsSettingsSamlStrictModeToTerraform(struct?: DataDatadogOrganizationSettingsSettingsSamlStrictMode | cdktn.IResolvable): any;
export declare function dataDatadogOrganizationSettingsSettingsSamlStrictModeToHclTerraform(struct?: DataDatadogOrganizationSettingsSettingsSamlStrictMode | cdktn.IResolvable): any;
export declare class DataDatadogOrganizationSettingsSettingsSamlStrictModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogOrganizationSettingsSettingsSamlStrictMode | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogOrganizationSettingsSettingsSamlStrictMode | cdktn.IResolvable | undefined);
    get enabled(): cdktn.IResolvable;
}
export declare class DataDatadogOrganizationSettingsSettingsSamlStrictModeList extends cdktn.ComplexList {
    internalValue?: DataDatadogOrganizationSettingsSettingsSamlStrictMode[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogOrganizationSettingsSettingsSamlStrictModeOutputReference;
}
export interface DataDatadogOrganizationSettingsSettings {
    /**
    * saml block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/organization_settings#saml DataDatadogOrganizationSettings#saml}
    */
    readonly saml?: DataDatadogOrganizationSettingsSettingsSaml[] | cdktn.IResolvable;
    /**
    * saml_autocreate_users_domains block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/organization_settings#saml_autocreate_users_domains DataDatadogOrganizationSettings#saml_autocreate_users_domains}
    */
    readonly samlAutocreateUsersDomains?: DataDatadogOrganizationSettingsSettingsSamlAutocreateUsersDomains[] | cdktn.IResolvable;
    /**
    * saml_idp_initiated_login block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/organization_settings#saml_idp_initiated_login DataDatadogOrganizationSettings#saml_idp_initiated_login}
    */
    readonly samlIdpInitiatedLogin?: DataDatadogOrganizationSettingsSettingsSamlIdpInitiatedLogin[] | cdktn.IResolvable;
    /**
    * saml_strict_mode block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/organization_settings#saml_strict_mode DataDatadogOrganizationSettings#saml_strict_mode}
    */
    readonly samlStrictMode?: DataDatadogOrganizationSettingsSettingsSamlStrictMode[] | cdktn.IResolvable;
}
export declare function dataDatadogOrganizationSettingsSettingsToTerraform(struct?: DataDatadogOrganizationSettingsSettings | cdktn.IResolvable): any;
export declare function dataDatadogOrganizationSettingsSettingsToHclTerraform(struct?: DataDatadogOrganizationSettingsSettings | cdktn.IResolvable): any;
export declare class DataDatadogOrganizationSettingsSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatadogOrganizationSettingsSettings | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatadogOrganizationSettingsSettings | cdktn.IResolvable | undefined);
    get privateWidgetShare(): cdktn.IResolvable;
    get samlAutocreateAccessRole(): string;
    get samlCanBeEnabled(): cdktn.IResolvable;
    get samlIdpEndpoint(): string;
    get samlIdpMetadataUploaded(): cdktn.IResolvable;
    get samlLoginUrl(): string;
    private _saml;
    get saml(): DataDatadogOrganizationSettingsSettingsSamlList;
    putSaml(value: DataDatadogOrganizationSettingsSettingsSaml[] | cdktn.IResolvable): void;
    resetSaml(): void;
    get samlInput(): cdktn.IResolvable | DataDatadogOrganizationSettingsSettingsSaml[] | undefined;
    private _samlAutocreateUsersDomains;
    get samlAutocreateUsersDomains(): DataDatadogOrganizationSettingsSettingsSamlAutocreateUsersDomainsList;
    putSamlAutocreateUsersDomains(value: DataDatadogOrganizationSettingsSettingsSamlAutocreateUsersDomains[] | cdktn.IResolvable): void;
    resetSamlAutocreateUsersDomains(): void;
    get samlAutocreateUsersDomainsInput(): cdktn.IResolvable | DataDatadogOrganizationSettingsSettingsSamlAutocreateUsersDomains[] | undefined;
    private _samlIdpInitiatedLogin;
    get samlIdpInitiatedLogin(): DataDatadogOrganizationSettingsSettingsSamlIdpInitiatedLoginList;
    putSamlIdpInitiatedLogin(value: DataDatadogOrganizationSettingsSettingsSamlIdpInitiatedLogin[] | cdktn.IResolvable): void;
    resetSamlIdpInitiatedLogin(): void;
    get samlIdpInitiatedLoginInput(): cdktn.IResolvable | DataDatadogOrganizationSettingsSettingsSamlIdpInitiatedLogin[] | undefined;
    private _samlStrictMode;
    get samlStrictMode(): DataDatadogOrganizationSettingsSettingsSamlStrictModeList;
    putSamlStrictMode(value: DataDatadogOrganizationSettingsSettingsSamlStrictMode[] | cdktn.IResolvable): void;
    resetSamlStrictMode(): void;
    get samlStrictModeInput(): cdktn.IResolvable | DataDatadogOrganizationSettingsSettingsSamlStrictMode[] | undefined;
}
export declare class DataDatadogOrganizationSettingsSettingsList extends cdktn.ComplexList {
    internalValue?: DataDatadogOrganizationSettingsSettings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatadogOrganizationSettingsSettingsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/organization_settings datadog_organization_settings}
*/
export declare class DataDatadogOrganizationSettings extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "datadog_organization_settings";
    /**
    * Generates CDKTN code for importing a DataDatadogOrganizationSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatadogOrganizationSettings to import
    * @param importFromId The id of the existing DataDatadogOrganizationSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/organization_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatadogOrganizationSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/datadog/datadog/3.91.0/docs/data-sources/organization_settings datadog_organization_settings} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatadogOrganizationSettingsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatadogOrganizationSettingsConfig);
    get description(): string;
    get id(): string;
    get name(): string;
    get publicId(): string;
    private _settings;
    get settings(): DataDatadogOrganizationSettingsSettingsList;
    putSettings(value: DataDatadogOrganizationSettingsSettings[] | cdktn.IResolvable): void;
    resetSettings(): void;
    get settingsInput(): cdktn.IResolvable | DataDatadogOrganizationSettingsSettings[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
